<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Stock Opname</h5>
    <a href="<?= site_url('stock-opname/new') ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Opname Baru</a>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table id="tblOpname" class="table table-striped w-100">
            <thead><tr><th>No Opname</th><th>Tanggal</th><th>Oleh</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function () {
    $('#tblOpname').DataTable({
        ajax: { url: '<?= site_url('stock-opname/data') ?>', dataSrc: 'data' },
        order: [[1, 'desc']],
        columns: [
            { data: 'no_opname' },
            { data: 'tanggal', render: v => new Date(v).toLocaleString('id-ID') },
            { data: 'nama_user' },
            { data: 'status', render: v => v === 'selesai' ? '<span class="badge bg-success">Selesai</span>' : '<span class="badge bg-warning text-dark">Draft</span>' },
            { data: 'id', orderable: false, className: 'text-end', render: id => `<a href="<?= site_url('stock-opname') ?>/${id}" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i></a>` }
        ],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/id.json' }
    });
});
</script>
<?= $this->endSection() ?>
