<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>

<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<form action="<?= site_url('stock-opname') ?>" method="post">
    <?= csrf_field() ?>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body">
            <label class="form-label">Catatan</label>
            <input type="text" name="catatan" class="form-control" placeholder="Opsional">
        </div>
    </div>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-header bg-white fw-semibold">Hitung Fisik Barang</div>
        <div class="card-body p-0">
            <table class="table mb-0">
                <thead><tr><th>Barang</th><th class="text-end">Qty Sistem</th><th class="text-end">Qty Fisik</th></tr></thead>
                <tbody>
                <?php foreach ($products as $p): ?>
                    <tr>
                        <td>
                            <?= esc($p['nama_barang']) ?>
                            <input type="hidden" name="product_id[]" value="<?= $p['id'] ?>">
                            <input type="hidden" name="qty_sistem[]" value="<?= $p['qty_sistem'] ?>">
                        </td>
                        <td class="text-end"><?= number_format($p['qty_sistem']) ?></td>
                        <td class="text-end">
                            <input type="number" name="qty_fisik[]" class="form-control form-control-sm text-end" style="width:120px; margin-left:auto;" placeholder="Kosongkan jika sama">
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <div class="card-footer text-muted small bg-white">
            Baris yang dikosongkan (qty fisik tidak diisi) tidak akan dimasukkan ke opname ini.
            Barang jenis SN tidak muncul di sini — stoknya divalidasi lewat status per serial number.
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Simpan sebagai Draft</button>
    <a href="<?= site_url('stock-opname') ?>" class="btn btn-outline-secondary">Batal</a>
</form>

<?= $this->endSection() ?>
