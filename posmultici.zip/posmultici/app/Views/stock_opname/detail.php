<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Detail Stock Opname — <?= esc($opname['no_opname']) ?> <span class="badge bg-secondary"><?= esc($opname['status']) ?></span></h5>
    <a href="<?= site_url('stock-opname') ?>" class="btn btn-outline-secondary btn-sm">Kembali</a>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm mb-3">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>Barang</th><th class="text-end">Qty Sistem</th><th class="text-end">Qty Fisik</th><th class="text-end">Selisih</th></tr></thead>
            <tbody>
            <?php foreach ($items as $it): ?>
                <tr class="<?= $it['selisih'] != 0 ? 'table-warning' : '' ?>">
                    <td><?= esc($it['nama_barang']) ?></td>
                    <td class="text-end"><?= number_format($it['qty_sistem']) ?></td>
                    <td class="text-end"><?= number_format($it['qty_fisik']) ?></td>
                    <td class="text-end"><?= $it['selisih'] > 0 ? '+' : '' ?><?= number_format($it['selisih']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php if ($opname['status'] === 'draft'): ?>
<form action="<?= site_url('stock-opname/' . $opname['id'] . '/selesai') ?>" method="post" onsubmit="return confirm('Terapkan penyesuaian stok sesuai hasil opname ini? Aksi ini akan langsung mengubah stok sistem.');">
    <?= csrf_field() ?>
    <button type="submit" class="btn btn-primary">Terapkan Penyesuaian Stok</button>
</form>
<?php endif; ?>

<?= $this->endSection() ?>
