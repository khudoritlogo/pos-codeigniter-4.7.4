<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="card border-0 shadow-sm">
    <div class="card-body text-center py-5">
        <i class="bi bi-tools fs-1 text-muted"></i>
        <h5 class="mt-3"><?= esc($title) ?></h5>
        <p class="text-muted"><?= esc($message) ?></p>
    </div>
</div>

<?= $this->endSection() ?>
