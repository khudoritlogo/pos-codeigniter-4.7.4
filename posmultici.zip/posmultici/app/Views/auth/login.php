<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login - Nusantara POS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@4.9.1/dist/css/adminlte.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@600;700&display=swap');
        body.login-page { background: linear-gradient(135deg, #1B2340 0%, #12172B 100%); }
        .login-logo a { font-family: 'Sora', system-ui, sans-serif; color: #fff !important; }
        .login-logo .brand-icon-box {
            width: 48px; height: 48px; background: #C9A227; color: #1B2340;
            display: inline-flex; align-items: center; justify-content: center; border-radius: .5rem; font-size: 1.4rem;
        }
        .login-card-body { border-radius: .75rem; }
        .btn-login { background: #C9A227; border-color: #C9A227; color: #1B2340; font-weight: 600; }
        .btn-login:hover { background: #E8C468; border-color: #E8C468; color: #1B2340; }
    </style>
</head>
<body class="login-page">
<div class="login-box">
    <div class="login-logo text-center mb-3">
        <div class="brand-icon-box mb-2"><i class="bi bi-shop"></i></div>
        <div><a href="#">Nusantara POS</a></div>
        <p class="text-white-50 small mb-0">Sistem Kasir Multi Cabang</p>
    </div>

    <div class="card">
        <div class="card-body login-card-body">
            <p class="login-box-msg">Masuk untuk memulai sesi Anda</p>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger py-2"><?= esc(session()->getFlashdata('error')) ?></div>
            <?php endif; ?>
            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success py-2"><?= esc(session()->getFlashdata('success')) ?></div>
            <?php endif; ?>

            <form action="<?= site_url('login') ?>" method="post">
                <?= csrf_field() ?>
                <div class="input-group mb-3">
                    <input type="text" name="username" class="form-control" placeholder="Username" value="<?= old('username') ?>" required autofocus>
                    <div class="input-group-text"><i class="bi bi-person"></i></div>
                </div>
                <div class="input-group mb-3">
                    <input type="password" name="password" class="form-control" placeholder="Password" required>
                    <div class="input-group-text"><i class="bi bi-lock-fill"></i></div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <button type="submit" class="btn btn-login w-100">Masuk</button>
                    </div>
                </div>
            </form>

            <p class="text-center text-muted small mt-4 mb-0">&copy; <?= date('Y') ?> Nusantara POS &mdash; Sistem Kasir Multi Cabang</p>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@4.9.1/dist/js/adminlte.min.js"></script>
</body>
</html>
