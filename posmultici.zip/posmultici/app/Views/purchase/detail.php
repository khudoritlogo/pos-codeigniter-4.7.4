<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Detail Pembelian — <?= esc($purchase['no_pembelian']) ?></h5>
    <a href="<?= site_url('pembelian') ?>" class="btn btn-outline-secondary btn-sm">Kembali</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>Barang</th><th>Satuan</th><th class="text-end">Qty</th><th class="text-end">Harga Beli</th><th class="text-end">Subtotal</th><th class="text-end">Harga Jual Saat Ini</th><th class="text-end">Estimasi Laba/Unit</th></tr></thead>
            <tbody>
            <?php foreach ($items as $it): ?>
                <?php
                    $laba = (float) $it['harga_jual'] - (float) $it['harga'];
                    $persen = $it['harga'] > 0 ? ($laba / $it['harga'] * 100) : 0;
                    $labaClass = $laba < 0 ? 'text-danger' : 'text-success';
                ?>
                <tr>
                    <td><?= esc($it['nama_barang']) ?></td>
                    <td><?= esc($it['nama_satuan']) ?></td>
                    <td class="text-end"><?= number_format($it['qty']) ?></td>
                    <td class="text-end"><?= rupiah($it['harga']) ?></td>
                    <td class="text-end"><?= rupiah($it['subtotal']) ?></td>
                    <td class="text-end text-muted"><?= rupiah($it['harga_jual']) ?></td>
                    <td class="text-end <?= $labaClass ?>"><?= rupiah($laba) ?> <small>(<?= number_format($persen, 1) ?>%)</small></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr><td colspan="6" class="text-end">Subtotal</td><td class="text-end"><?= rupiah($purchase['subtotal']) ?></td></tr>
                <tr><td colspan="6" class="text-end">Diskon</td><td class="text-end"><?= rupiah($purchase['diskon']) ?></td></tr>
                <tr class="fw-bold"><td colspan="6" class="text-end">Grand Total</td><td class="text-end"><?= rupiah($purchase['grand_total']) ?></td></tr>
                <tr><td colspan="6" class="text-end">Bayar</td><td class="text-end"><?= rupiah($purchase['bayar']) ?></td></tr>
            </tfoot>
        </table>
    </div>
    <div class="card-footer bg-white text-muted small">
        Estimasi Laba/Unit dihitung dari Harga Jual Retail barang <strong>saat ini</strong> dikurangi Harga Beli pada transaksi pembelian ini &mdash; bukan laba transaksi penjualan sungguhan, hanya proyeksi margin.
    </div>
</div>

<?= $this->endSection() ?>
