<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>

<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<form action="<?= site_url('pembelian') ?>" method="post">
    <?= csrf_field() ?>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Supplier</label>
                    <select name="supplier_id" class="form-select" required>
                        <option value="">-- Pilih Supplier --</option>
                        <?php foreach ($suppliers as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= esc($s['nama_supplier']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Metode Bayar</label>
                    <select name="metode_bayar" class="form-select">
                        <option value="cash">Cash</option>
                        <option value="transfer">Transfer</option>
                        <option value="hutang">Hutang</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Jumlah Bayar</label>
                    <input type="number" step="0.01" name="bayar" class="form-control" value="0">
                </div>
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-header bg-white fw-semibold d-flex justify-content-between align-items-center">
            Daftar Barang
            <button type="button" class="btn btn-sm btn-outline-primary" id="btnAddItem"><i class="bi bi-plus-lg"></i> Tambah Baris</button>
        </div>
        <div class="card-body">
            <table class="table table-sm" id="tblItems">
                <thead><tr><th style="width:20%">Barang</th><th class="text-end">Qty</th><th class="text-end">Harga Beli</th><th class="text-end">Harga Jual Saat Ini</th><th class="text-end">Estimasi Laba</th><th>Serial Number (khusus SN)</th><th>No. Batch</th><th>Tgl. Kedaluwarsa</th><th></th></tr></thead>
                <tbody></tbody>
            </table>
        </div>
    </div>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body row g-3">
            <div class="col-md-4">
                <label class="form-label">Diskon (Rp)</label>
                <input type="number" step="0.01" name="diskon" class="form-control" value="0">
            </div>
            <div class="col-md-8">
                <label class="form-label">Catatan</label>
                <input type="text" name="catatan" class="form-control">
            </div>
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Simpan Pembelian</button>
    <a href="<?= site_url('pembelian') ?>" class="btn btn-outline-secondary">Batal</a>
</form>

<template id="itemRowTemplate">
    <tr>
        <td>
            <select name="product_id[]" class="form-select form-select-sm product-select">
                <option value="">-- Pilih Barang --</option>
                <?php foreach ($products as $p): ?>
                    <option value="<?= $p['id'] ?>" data-jenis="<?= $p['jenis_produk'] ?>" data-harga="<?= $p['harga_beli'] ?>" data-harga-jual="<?= $p['harga_jual'] ?>" data-expiry="<?= $p['has_expiry'] ?>"><?= esc($p['nama_barang']) ?> (<?= esc($p['kode_barang']) ?>)</option>
                <?php endforeach; ?>
            </select>
        </td>
        <td><input type="number" step="0.01" name="qty[]" class="form-control form-control-sm qty-input" value="1"></td>
        <td><input type="number" step="0.01" name="harga[]" class="form-control form-control-sm harga-input" value="0"></td>
        <td class="text-end align-middle harga-jual-display text-muted">-</td>
        <td class="text-end align-middle laba-display">-</td>
        <td><textarea name="serials[]" class="form-control form-control-sm serials-input" rows="1" placeholder="Kosongkan jika bukan barang SN" disabled></textarea></td>
        <td><input type="text" name="no_batch[]" class="form-control form-control-sm batch-input" placeholder="mis. BTC-001" disabled></td>
        <td><input type="date" name="tanggal_kedaluwarsa[]" class="form-control form-control-sm expired-input" disabled></td>
        <td><button type="button" class="btn btn-sm btn-outline-danger btn-remove-row"><i class="bi bi-x-lg"></i></button></td>
    </tr>
</template>

<script>
function rupiahJs(n) { return 'Rp ' + Number(n || 0).toLocaleString('id-ID'); }

function addItemRow() {
    const tpl = document.getElementById('itemRowTemplate').content.cloneNode(true);
    const tr = tpl.querySelector('tr');
    const select = tr.querySelector('.product-select');
    const hargaInput = tr.querySelector('.harga-input');
    const serialsInput = tr.querySelector('.serials-input');
    const batchInput = tr.querySelector('.batch-input');
    const expiredInput = tr.querySelector('.expired-input');
    const hargaJualDisplay = tr.querySelector('.harga-jual-display');
    const labaDisplay = tr.querySelector('.laba-display');

    function hitungLabaBaris() {
        const hargaJual = parseFloat(select.options[select.selectedIndex]?.dataset.hargaJual) || 0;
        const hargaBeli = parseFloat(hargaInput.value) || 0;
        hargaJualDisplay.innerText = hargaJual > 0 ? rupiahJs(hargaJual) : '-';
        if (hargaJual > 0 && hargaBeli > 0) {
            const laba = hargaJual - hargaBeli;
            const persen = (laba / hargaBeli * 100).toFixed(1);
            labaDisplay.innerHTML = `<span class="${laba < 0 ? 'text-danger' : 'text-success'}">${rupiahJs(laba)} (${persen}%)</span>`;
        } else {
            labaDisplay.innerText = '-';
        }
    }

    select.addEventListener('change', function () {
        const opt = this.options[this.selectedIndex];
        hargaInput.value = opt.dataset.harga || 0;
        serialsInput.disabled = opt.dataset.jenis !== 'sn';
        serialsInput.placeholder = opt.dataset.jenis === 'sn' ? 'Masukkan 1 serial number per baris' : 'Kosongkan jika bukan barang SN';
        const punyaExpiry = opt.dataset.expiry === '1';
        batchInput.disabled = !punyaExpiry;
        expiredInput.disabled = !punyaExpiry;
        batchInput.required = punyaExpiry;
        expiredInput.required = punyaExpiry;
        hitungLabaBaris();
    });
    hargaInput.addEventListener('input', hitungLabaBaris);

    tr.querySelector('.btn-remove-row').addEventListener('click', e => e.target.closest('tr').remove());
    document.querySelector('#tblItems tbody').appendChild(tr);
}
document.getElementById('btnAddItem').addEventListener('click', addItemRow);
addItemRow(); // baris pertama otomatis tersedia
</script>

<?= $this->endSection() ?>
