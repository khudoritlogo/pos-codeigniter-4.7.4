<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Pembelian</h5>
    <a href="<?= site_url('pembelian/new') ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Pembelian Baru</a>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table id="tblPurchase" class="table table-striped w-100">
            <thead><tr><th>No Pembelian</th><th>Tanggal</th><th>Supplier</th><th class="text-end">Grand Total</th><th>Status Bayar</th><th class="text-end">Aksi</th></tr></thead>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function () {
    $('#tblPurchase').DataTable({
        ajax: { url: '<?= site_url('pembelian/data') ?>', dataSrc: 'data' },
        order: [[1, 'desc']],
        columns: [
            { data: 'no_pembelian' },
            { data: 'tanggal', render: v => new Date(v).toLocaleString('id-ID') },
            { data: 'nama_supplier' },
            { data: 'grand_total', className: 'text-end', render: v => 'Rp ' + Number(v).toLocaleString('id-ID') },
            { data: 'status_bayar', render: v => v === 'lunas' ? '<span class="badge bg-success">Lunas</span>' : '<span class="badge bg-warning text-dark">' + v.replace('_',' ') + '</span>' },
            { data: 'id', orderable: false, className: 'text-end', render: id => `<a href="<?= site_url('pembelian') ?>/${id}" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i></a>` }
        ],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/id.json' }
    });
});
</script>
<?= $this->endSection() ?>
