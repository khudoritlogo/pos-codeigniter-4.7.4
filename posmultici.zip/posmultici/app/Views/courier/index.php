<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Data Pengiriman Kurir</h5>
    <span class="badge bg-success">Selesai hari ini: <?= number_format($selesaiHariIni) ?></span>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<?php if (empty($deliveries)): ?>
    <div class="card border-0 shadow-sm">
        <div class="card-body text-center py-5 text-muted">
            <i class="bi bi-check2-circle fs-1"></i>
            <p class="mt-2 mb-0">Tidak ada pengiriman yang perlu diproses saat ini.</p>
        </div>
    </div>
<?php else: ?>
    <div class="row g-3">
        <?php foreach ($deliveries as $d): ?>
            <div class="col-md-6">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                            <div>
                                <div class="fw-semibold"><?= esc($d['no_invoice']) ?></div>
                                <div class="text-muted small"><?= esc(date('d/m/Y H:i', strtotime($d['tanggal']))) ?></div>
                            </div>
                            <?php
                                $badgeMap = ['menunggu' => 'secondary', 'diproses' => 'warning', 'dikirim' => 'info'];
                                $badgeClass = $badgeMap[$d['status_kirim']] ?? 'secondary';
                            ?>
                            <span class="badge bg-<?= $badgeClass ?>"><?= esc(ucfirst($d['status_kirim'])) ?></span>
                        </div>

                        <div class="mb-1"><i class="bi bi-person"></i> <?= esc($d['nama_customer'] ?? 'Umum') ?></div>
                        <?php if (! empty($d['alamat'])): ?>
                            <div class="mb-2 text-muted small"><i class="bi bi-geo-alt"></i> <?= esc($d['alamat']) ?></div>
                        <?php endif; ?>
                        <div class="mb-3 fw-semibold"><?= rupiah($d['grand_total']) ?></div>

                        <div class="d-flex flex-wrap gap-2 mb-3">
                            <?php if ($d['wa_link']): ?>
                                <a href="<?= esc($d['wa_link']) ?>" target="_blank" class="btn btn-sm btn-success"><i class="bi bi-whatsapp"></i> WhatsApp Customer</a>
                            <?php endif; ?>
                            <?php if ($d['maps_link']): ?>
                                <a href="<?= esc($d['maps_link']) ?>" target="_blank" class="btn btn-sm btn-outline-primary"><i class="bi bi-map"></i> Buka di Maps</a>
                            <?php endif; ?>
                        </div>

                        <form action="<?= site_url('kurir/pengiriman/' . $d['id'] . '/status') ?>" method="post" class="d-flex gap-2">
                            <?= csrf_field() ?>
                            <select name="status_kirim" class="form-select form-select-sm">
                                <option value="diproses" <?= $d['status_kirim'] === 'diproses' ? 'selected' : '' ?>>Diproses</option>
                                <option value="dikirim" <?= $d['status_kirim'] === 'dikirim' ? 'selected' : '' ?>>Dikirim</option>
                                <option value="selesai">Selesai</option>
                            </select>
                            <button type="submit" class="btn btn-sm btn-primary">Update</button>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?= $this->endSection() ?>
