<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Detail Shift — <?= esc($shift['no_shift']) ?></h5>
    <a href="<?= site_url('shift-kasir') ?>" class="btn btn-outline-secondary btn-sm">Kembali</a>
</div>

<div class="card border-0 shadow-sm" style="max-width:560px;">
    <div class="card-body">
        <table class="table table-sm mb-0">
            <tr><td class="text-muted">Kasir</td><td><?= esc($shift['nama_kasir']) ?></td></tr>
            <tr><td class="text-muted">Cabang</td><td><?= esc($shift['nama_cabang']) ?></td></tr>
            <tr><td class="text-muted">Dibuka</td><td><?= esc(date('d/m/Y H:i', strtotime($shift['waktu_buka']))) ?></td></tr>
            <tr><td class="text-muted">Ditutup</td><td><?= $shift['waktu_tutup'] ? esc(date('d/m/Y H:i', strtotime($shift['waktu_tutup']))) : '-' ?></td></tr>
            <tr><td class="text-muted">Modal Awal</td><td><?= rupiah($shift['modal_awal']) ?></td></tr>
            <?php if ($shift['status'] === 'tutup'): ?>
            <tr><td class="text-muted">Penjualan Cash</td><td><?= rupiah($shift['total_penjualan_cash']) ?></td></tr>
            <tr><td class="text-muted">Penjualan Non-Cash</td><td><?= rupiah($shift['total_penjualan_non_cash']) ?></td></tr>
            <tr><td class="text-muted">Uang Seharusnya</td><td><?= rupiah($shift['uang_seharusnya']) ?></td></tr>
            <tr><td class="text-muted">Uang Fisik Aktual</td><td><?= rupiah($shift['uang_fisik_aktual']) ?></td></tr>
            <tr class="fw-bold"><td>Selisih</td><td class="<?= $shift['selisih'] < 0 ? 'text-danger' : ($shift['selisih'] > 0 ? 'text-info' : 'text-success') ?>"><?= rupiah($shift['selisih']) ?></td></tr>
            <tr><td class="text-muted">Catatan</td><td><?= esc($shift['catatan_penutupan'] ?: '-') ?></td></tr>
            <?php endif; ?>
            <tr><td class="text-muted">Status</td><td><span class="badge bg-<?= $shift['status'] === 'buka' ? 'success' : 'secondary' ?>"><?= esc(ucfirst($shift['status'])) ?></span></td></tr>
        </table>
    </div>
</div>

<?= $this->endSection() ?>
