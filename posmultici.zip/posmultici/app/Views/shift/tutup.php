<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?> — <?= esc($shift['no_shift']) ?></h5>

<div class="card border-0 shadow-sm mb-3" style="max-width:560px;">
    <div class="card-body">
        <table class="table table-sm mb-0">
            <tr><td class="text-muted">Dibuka</td><td><?= esc(date('d/m/Y H:i', strtotime($shift['waktu_buka']))) ?></td></tr>
            <tr><td class="text-muted">Modal Awal</td><td><?= rupiah($shift['modal_awal']) ?></td></tr>
            <tr><td class="text-muted">Total Penjualan Cash</td><td><?= rupiah($totalCash) ?></td></tr>
            <tr><td class="text-muted">Total Penjualan Non-Cash</td><td><?= rupiah($totalNonCash) ?></td></tr>
            <tr class="fw-bold"><td>Uang Seharusnya di Laci</td><td><?= rupiah($uangSeharusnya) ?></td></tr>
        </table>
    </div>
</div>

<div class="card border-0 shadow-sm" style="max-width:560px;">
    <div class="card-body">
        <form action="<?= site_url('shift-kasir/' . $shift['id'] . '/tutup') ?>" method="post" onsubmit="return confirm('Tutup shift sekarang? Pastikan penghitungan uang fisik sudah benar.');">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label class="form-label">Uang Fisik Aktual di Laci (hasil hitung manual)</label>
                <input type="number" step="0.01" name="uang_fisik_aktual" id="uangFisik" class="form-control" required oninput="hitungSelisih()">
            </div>
            <div class="alert alert-secondary" id="previewSelisih">Selisih akan muncul di sini setelah diisi.</div>
            <div class="mb-3">
                <label class="form-label">Catatan Penutupan (opsional)</label>
                <textarea name="catatan_penutupan" class="form-control" rows="2"></textarea>
            </div>
            <button type="submit" class="btn btn-danger w-100">Tutup Shift</button>
        </form>
    </div>
</div>

<script>
const uangSeharusnya = <?= (float) $uangSeharusnya ?>;
function hitungSelisih() {
    const fisik = parseFloat(document.getElementById('uangFisik').value) || 0;
    const selisih = fisik - uangSeharusnya;
    const el = document.getElementById('previewSelisih');
    if (selisih === 0) {
        el.className = 'alert alert-success';
        el.innerText = 'Pas, tidak ada selisih.';
    } else if (selisih > 0) {
        el.className = 'alert alert-info';
        el.innerText = 'Lebih Rp ' + selisih.toLocaleString('id-ID') + ' dari seharusnya.';
    } else {
        el.className = 'alert alert-danger';
        el.innerText = 'Kurang Rp ' + Math.abs(selisih).toLocaleString('id-ID') + ' dari seharusnya.';
    }
}
</script>

<?= $this->endSection() ?>
