<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Shift Kasir</h5>
    <?php if ($shiftAktif): ?>
        <a href="<?= site_url('shift-kasir/' . $shiftAktif['id'] . '/tutup') ?>" class="btn btn-danger btn-sm"><i class="bi bi-door-closed"></i> Tutup Shift Sekarang</a>
    <?php else: ?>
        <a href="<?= site_url('shift-kasir/buka') ?>" class="btn btn-primary btn-sm"><i class="bi bi-door-open"></i> Buka Shift Baru</a>
    <?php endif; ?>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<?php if ($shiftAktif): ?>
<div class="alert alert-success d-flex justify-content-between align-items-center">
    <div>Shift aktif: <strong><?= esc($shiftAktif['no_shift']) ?></strong> — dibuka <?= esc(date('d/m/Y H:i', strtotime($shiftAktif['waktu_buka']))) ?>, modal awal <?= rupiah($shiftAktif['modal_awal']) ?></div>
</div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table id="tblShift" class="table table-striped w-100">
            <thead><tr><th>No Shift</th><th>Kasir</th><th>Buka</th><th>Tutup</th><th class="text-end">Modal Awal</th><th class="text-end">Selisih</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function () {
    $('#tblShift').DataTable({
        ajax: { url: '<?= site_url('shift-kasir/data') ?>', dataSrc: 'data' },
        order: [[2, 'desc']],
        columns: [
            { data: 'no_shift' },
            { data: 'nama_kasir' },
            { data: 'waktu_buka', render: v => new Date(v).toLocaleString('id-ID') },
            { data: 'waktu_tutup', render: v => v ? new Date(v).toLocaleString('id-ID') : '-' },
            { data: 'modal_awal', className: 'text-end', render: v => 'Rp ' + Number(v).toLocaleString('id-ID') },
            { data: 'selisih', className: 'text-end', render: v => v === null ? '-' : ('Rp ' + Number(v).toLocaleString('id-ID')) },
            { data: 'status', render: v => v === 'buka' ? '<span class="badge bg-success">Buka</span>' : '<span class="badge bg-secondary">Tutup</span>' },
            { data: 'id', orderable: false, className: 'text-end', render: id => `<a href="<?= site_url('shift-kasir') ?>/${id}" class="btn btn-sm btn-outline-primary">Detail</a>` }
        ],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/id.json' }
    });
});
</script>
<?= $this->endSection() ?>
