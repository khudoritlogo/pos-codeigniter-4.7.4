<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm" style="max-width:480px;">
    <div class="card-body">
        <form action="<?= site_url('shift-kasir/buka') ?>" method="post">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label class="form-label">Modal Awal Kasir (uang di laci saat mulai shift)</label>
                <input type="number" step="0.01" name="modal_awal" class="form-control" value="0" required autofocus>
            </div>
            <button type="submit" class="btn btn-primary w-100">Buka Shift & Mulai Transaksi</button>
        </form>
    </div>
</div>

<?= $this->endSection() ?>
