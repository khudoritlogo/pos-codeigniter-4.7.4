<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3">Cek & Cetak Garansi</h5>

<div class="card border-0 shadow-sm mb-3" style="max-width:560px;">
    <div class="card-body">
        <label class="form-label">Masukkan Serial Number</label>
        <div class="input-group">
            <input type="text" id="snInput" class="form-control" placeholder="Scan atau ketik serial number...">
            <button class="btn btn-outline-primary" type="button" id="btnCari">Cari</button>
        </div>
    </div>
</div>

<div id="hasil" class="card border-0 shadow-sm d-none" style="max-width:560px;">
    <div class="card-body" id="hasilBody"></div>
</div>

<script>
document.getElementById('btnCari').addEventListener('click', cari);
document.getElementById('snInput').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); cari(); } });

async function cari() {
    const sn = document.getElementById('snInput').value.trim();
    if (!sn) return;
    const res = await fetch(`<?= site_url('garansi/cari') ?>?sn=${encodeURIComponent(sn)}`);
    const json = await res.json();
    const box = document.getElementById('hasil');
    const body = document.getElementById('hasilBody');
    box.classList.remove('d-none');

    if (!json.found) {
        body.innerHTML = `<div class="text-danger">Serial number tidak ditemukan.</div>`;
        return;
    }

    const s = json.serial;
    const map = { aktif: ['success', 'Garansi Aktif'], expired: ['danger', 'Garansi Sudah Habis'], belum_terjual: ['secondary', 'Belum Terjual'] };
    const [cls, label] = map[json.status_garansi];

    body.innerHTML = `
        <div class="mb-1"><strong>${s.nama_barang}</strong> (${s.kode_barang})</div>
        <div class="text-muted small mb-2">Serial: ${s.serial_number}</div>
        <span class="badge bg-${cls}">${label}</span>
        ${json.sisa_hari !== null ? `<div class="mt-2">${json.sisa_hari >= 0 ? 'Sisa ' + json.sisa_hari + ' hari lagi' : 'Sudah lewat ' + Math.abs(json.sisa_hari) + ' hari'}</div>` : ''}
        ${s.tanggal_mulai_garansi ? `<div class="text-muted small mt-2">Mulai: ${s.tanggal_mulai_garansi} — Berakhir: ${s.tanggal_akhir_garansi}</div>` : ''}
        ${json.status_garansi !== 'belum_terjual' ? `<a href="<?= site_url('garansi/cetak') ?>/${encodeURIComponent(s.serial_number)}" target="_blank" class="btn btn-sm btn-outline-primary mt-3"><i class="bi bi-printer"></i> Cetak Lembar Klaim</a>` : ''}
    `;
}
</script>

<?= $this->endSection() ?>
