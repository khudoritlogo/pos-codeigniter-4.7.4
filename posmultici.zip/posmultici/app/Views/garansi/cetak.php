<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kartu Garansi <?= esc($serial['serial_number']) ?></title>
    <style>
        @page { size: A5; margin: 15mm; }
        body { font-family: Arial, sans-serif; color: #222; }
        .header { text-align: center; border-bottom: 2px solid #222; padding-bottom: 10px; margin-bottom: 16px; }
        .header h2 { margin: 0 0 4px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        td { padding: 6px 4px; border-bottom: 1px solid #ddd; }
        td.label { color: #666; width: 40%; }
        .footer { margin-top: 30px; display: flex; justify-content: space-between; }
        .footer div { text-align: center; width: 45%; }
        .footer .line { margin-top: 50px; border-top: 1px solid #222; padding-top: 4px; }
        .no-print { text-align: center; margin-top: 20px; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body>

<div class="header">
    <h2><?= esc($store['nama_toko'] ?? 'Nama Toko') ?></h2>
    <div><?= esc($store['alamat'] ?? '') ?></div>
    <div><?= esc($store['telepon'] ?? '') ?></div>
    <h3 style="margin-top:12px;">KARTU / LEMBAR KLAIM GARANSI</h3>
</div>

<table>
    <tr><td class="label">Nama Barang</td><td><?= esc($serial['nama_barang']) ?></td></tr>
    <tr><td class="label">Kode Barang</td><td><?= esc($serial['kode_barang']) ?></td></tr>
    <tr><td class="label">Serial Number</td><td><strong><?= esc($serial['serial_number']) ?></strong></td></tr>
    <tr><td class="label">Lama Garansi</td><td><?= esc($serial['garansi_bulan']) ?> Bulan</td></tr>
    <tr><td class="label">Tanggal Mulai Garansi</td><td><?= esc($serial['tanggal_mulai_garansi']) ?></td></tr>
    <tr><td class="label">Tanggal Berakhir Garansi</td><td><strong><?= esc($serial['tanggal_akhir_garansi']) ?></strong></td></tr>
</table>

<p style="margin-top:20px; font-size: 13px; color:#555;">
    Kartu ini adalah bukti sah klaim garansi produk di atas. Garansi berlaku untuk kerusakan pabrik,
    tidak berlaku untuk kerusakan akibat kelalaian pemakaian, air, atau benturan fisik. Simpan kartu
    ini dan tunjukkan saat melakukan klaim garansi di toko.
</p>

<div class="footer">
    <div>Customer <div class="line">Tanda Tangan</div></div>
    <div>Toko <div class="line">Tanda Tangan & Stempel</div></div>
</div>

<div class="no-print">
    <button onclick="window.print()">Cetak</button>
</div>

<script>window.onload = function () { window.print(); };</script>

</body>
</html>
