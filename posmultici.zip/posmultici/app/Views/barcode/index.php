<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3">Cetak Barcode</h5>

<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<form action="<?= site_url('barcode/cetak') ?>" method="post" target="_blank">
    <?= csrf_field() ?>

    <div class="row g-3">
        <div class="col-md-7">
            <div class="card border-0 shadow-sm mb-3">
                <div class="card-body">
                    <label class="form-label">Cari Barang</label>
                    <input type="text" id="searchBox" class="form-control" placeholder="Cari nama/kode/barcode barang...">
                    <div id="searchResults" class="list-group mt-2" style="max-height: 240px; overflow-y: auto;"></div>
                </div>
            </div>

            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white fw-semibold">Daftar Barang Dipilih</div>
                <div class="card-body p-0">
                    <table class="table mb-0">
                        <thead><tr><th>Barang</th><th class="text-end" style="width:140px;">Jumlah Label</th><th></th></tr></thead>
                        <tbody id="selectedBody">
                            <tr id="emptyRow"><td colspan="3" class="text-center text-muted py-3">Belum ada barang dipilih</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-md-5">
            <div class="card border-0 shadow-sm">
                <div class="card-header bg-white fw-semibold">Pengaturan Label</div>
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-6">
                            <label class="form-label">Lebar Label (mm)</label>
                            <input type="number" name="lebar_mm" class="form-control" value="40">
                        </div>
                        <div class="col-6">
                            <label class="form-label">Tinggi Label (mm)</label>
                            <input type="number" name="tinggi_mm" class="form-control" value="25">
                        </div>
                        <div class="col-6">
                            <label class="form-label">Kolom per Baris</label>
                            <input type="number" name="kolom" class="form-control" value="3">
                        </div>
                        <div class="col-6">
                            <div class="form-check form-switch mt-4">
                                <input type="checkbox" name="tampilkan_harga" class="form-check-input" value="1" checked>
                                <label class="form-check-label">Tampilkan Harga</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-text mt-2">Sesuaikan bebas dengan ukuran stiker label yang Anda pakai (mis. 40x25mm, 30x20mm, dll).</div>
                </div>
            </div>
            <button type="submit" class="btn btn-primary w-100 mt-3"><i class="bi bi-printer"></i> Cetak Barcode</button>
        </div>
    </div>
</form>

<script>
let selected = []; // { id, kode_barang, nama_barang, jumlah }

function renderSelected() {
    const body = document.getElementById('selectedBody');
    body.innerHTML = '';
    if (selected.length === 0) {
        body.innerHTML = '<tr id="emptyRow"><td colspan="3" class="text-center text-muted py-3">Belum ada barang dipilih</td></tr>';
        return;
    }
    selected.forEach((item, idx) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${item.nama_barang} <small class="text-muted">(${item.kode_barang})</small>
                <input type="hidden" name="product_id[]" value="${item.id}"></td>
            <td class="text-end"><input type="number" name="jumlah_label[]" class="form-control form-control-sm text-end" style="width:90px; margin-left:auto;" value="${item.jumlah}" min="1" onchange="selected[${idx}].jumlah = this.value"></td>
            <td class="text-end"><button type="button" class="btn btn-sm btn-outline-danger" onclick="removeSelected(${idx})"><i class="bi bi-x-lg"></i></button></td>`;
        body.appendChild(tr);
    });
}

function removeSelected(idx) { selected.splice(idx, 1); renderSelected(); }

let searchTimeout;
document.getElementById('searchBox').addEventListener('input', function () {
    clearTimeout(searchTimeout);
    const q = this.value.trim();
    if (q.length < 2) { document.getElementById('searchResults').innerHTML = ''; return; }
    searchTimeout = setTimeout(async () => {
        const res = await fetch(`<?= site_url('barcode/cari-barang') ?>?q=${encodeURIComponent(q)}`);
        const json = await res.json();
        const box = document.getElementById('searchResults');
        box.innerHTML = '';
        json.data.forEach(p => {
            const div = document.createElement('a');
            div.href = '#';
            div.className = 'list-group-item list-group-item-action';
            div.innerText = `${p.nama_barang} (${p.kode_barang})`;
            div.addEventListener('click', (e) => {
                e.preventDefault();
                if (!selected.find(s => s.id === p.id)) {
                    selected.push({ id: p.id, kode_barang: p.kode_barang, nama_barang: p.nama_barang, jumlah: 1 });
                    renderSelected();
                }
                document.getElementById('searchBox').value = '';
                box.innerHTML = '';
            });
            box.appendChild(div);
        });
    }, 250);
});
</script>

<?= $this->endSection() ?>
