<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Barcode</title>
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>
    <style>
        @page { size: auto; margin: 5mm; }
        * { box-sizing: border-box; }
        body { font-family: Arial, sans-serif; margin: 0; }
        .sheet {
            display: grid;
            grid-template-columns: repeat(<?= (int) $kolom ?>, <?= (int) $lebarMm ?>mm);
            gap: 2mm;
        }
        .label {
            width: <?= (int) $lebarMm ?>mm;
            height: <?= (int) $tinggiMm ?>mm;
            border: 1px dashed #ccc;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 1mm;
            overflow: hidden;
            text-align: center;
        }
        .label .nama { font-size: 8px; line-height: 1.1; max-width: 100%; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
        .label .harga { font-size: 8px; font-weight: bold; }
        .label svg { width: 100%; max-height: 60%; }
        .no-print { text-align: center; margin-bottom: 12px; }
        @media print { .no-print { display: none; } .label { border: none; } }
    </style>
</head>
<body>

<div class="no-print">
    <button onclick="window.print()">Cetak</button>
    <span class="text-muted">(<?= count($labels) ?> label akan dicetak, ukuran <?= (int) $lebarMm ?>x<?= (int) $tinggiMm ?>mm, <?= (int) $kolom ?> kolom per baris)</span>
</div>

<div class="sheet">
    <?php foreach ($labels as $i => $p): ?>
        <div class="label">
            <div class="nama"><?= esc($p['nama_barang']) ?></div>
            <svg class="barcode-svg" data-value="<?= esc($p['barcode'] ?: $p['kode_barang'], 'attr') ?>"></svg>
            <?php if ($tampilkanHarga): ?>
                <div class="harga">Rp <?= number_format($p['harga_jual']) ?></div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
</div>

<script>
document.querySelectorAll('.barcode-svg').forEach(function (el) {
    JsBarcode(el, el.dataset.value, { format: "CODE128", displayValue: true, fontSize: 8, margin: 0, height: 30 });
});
</script>

</body>
</html>
