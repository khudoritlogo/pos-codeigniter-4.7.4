<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Transaksi Pending</h5>
    <a href="<?= site_url('kasir') ?>" class="btn btn-outline-secondary btn-sm">Kembali ke Kasir</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>Tanggal</th><th>Customer</th><th class="text-end">Grand Total</th><th class="text-end">Aksi</th></tr></thead>
            <tbody>
            <?php if (empty($sales)): ?>
                <tr><td colspan="4" class="text-center text-muted py-4">Tidak ada transaksi pending</td></tr>
            <?php else: foreach ($sales as $s): ?>
                <tr>
                    <td><?= esc(date('d/m/Y H:i', strtotime($s['tanggal']))) ?></td>
                    <td><?= esc($s['customer_id'] ? $s['customer_id'] : 'Umum') ?></td>
                    <td class="text-end"><?= rupiah($s['grand_total']) ?></td>
                    <td class="text-end"><a href="<?= site_url('kasir/pending/' . $s['id'] . '/lanjutkan') ?>" class="btn btn-sm btn-primary">Lanjutkan</a></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?= $this->endSection() ?>
