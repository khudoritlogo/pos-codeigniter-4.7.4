<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Riwayat Penjualan</h5>
    <a href="<?= site_url('kasir') ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Transaksi Baru</a>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table id="tblSale" class="table table-striped w-100">
            <thead><tr><th>No Invoice</th><th>Tanggal</th><th>Customer</th><th>Kasir</th><th class="text-end">Grand Total</th><th>Bayar</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function () {
    $('#tblSale').DataTable({
        ajax: { url: '<?= site_url('penjualan/data') ?>', dataSrc: 'data' },
        order: [[1, 'desc']],
        columns: [
            { data: 'no_invoice' },
            { data: 'tanggal', render: v => new Date(v).toLocaleString('id-ID') },
            { data: 'nama_customer', defaultContent: 'Umum' },
            { data: 'nama_kasir' },
            { data: 'grand_total', className: 'text-end', render: v => 'Rp ' + Number(v).toLocaleString('id-ID') },
            { data: 'metode_bayar', render: v => v.charAt(0).toUpperCase() + v.slice(1) },
            {
                data: 'status_transaksi', render: v => {
                    if (v === 'pending') return '<span class="badge bg-warning text-dark">Pending</span>';
                    if (v === 'batal') return '<span class="badge bg-danger">Batal</span>';
                    return '<span class="badge bg-success">Selesai</span>';
                }
            },
            {
                data: 'id', orderable: false, className: 'text-end',
                render: id => `<a href="<?= site_url('penjualan') ?>/${id}" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i> Detail</a>`
            }
        ],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/id.json' }
    });
});
</script>
<?= $this->endSection() ?>
