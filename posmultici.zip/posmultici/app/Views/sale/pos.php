<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0"><?= esc($title) ?></h5>
    <div>
        <span id="offlineBadge" class="badge bg-danger d-none me-2"><i class="bi bi-wifi-off"></i> Offline — <span id="offlineCount">0</span> transaksi menunggu sinkron</span>
        <button type="button" id="btnSync" class="btn btn-outline-danger btn-sm d-none me-2">Sinkronkan Sekarang</button>
        <a href="<?= site_url('kasir/cfd') ?>" target="_blank" class="btn btn-outline-secondary btn-sm"><i class="bi bi-display"></i> Buka Layar Pelanggan</a>
        <a href="<?= site_url('kasir/pending') ?>" class="btn btn-outline-warning btn-sm"><i class="bi bi-hourglass-split"></i> Transaksi Pending</a>
    </div>
</div>

<?php if (! empty($shiftAktif) && $shiftAktif['id']): ?>
<div class="alert alert-success d-flex justify-content-between align-items-center py-2">
    <span><i class="bi bi-door-open"></i> Shift aktif: <strong><?= esc($shiftAktif['no_shift']) ?></strong> — modal awal <?= rupiah($shiftAktif['modal_awal']) ?></span>
    <a href="<?= site_url('shift-kasir/' . $shiftAktif['id'] . '/tutup') ?>" class="btn btn-sm btn-outline-danger">Tutup Shift</a>
</div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-md-7">
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body">
                <label class="form-label">Cari / Scan Barcode Barang</label>
                <input type="text" id="searchBox" class="form-control form-control-lg" placeholder="Scan barcode atau ketik nama/kode barang..." autofocus>
                <div id="searchResults" class="list-group mt-2" style="max-height: 280px; overflow-y: auto;"></div>
            </div>
        </div>

        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-semibold">Keranjang</div>
            <div class="card-body p-0">
                <table class="table mb-0">
                    <thead>
                        <tr><th>Barang</th><th>Satuan</th><th class="text-end">Qty</th><th class="text-end">Harga</th><th class="text-end">Diskon</th><th class="text-end">Subtotal</th><th></th></tr>
                    </thead>
                    <tbody id="cartBody">
                        <tr id="cartEmptyRow"><td colspan="7" class="text-center text-muted py-4">Keranjang masih kosong</td></tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-5">
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body">
                <div class="mb-3">
                    <label class="form-label">Tipe Transaksi</label>
                    <select id="tipeTransaksi" class="form-select">
                        <option value="retail">Retail</option>
                        <option value="grosir">Grosir</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label">Customer</label>
                    <select id="customerId" class="form-select">
                        <option value="">-- Umum / Tanpa Customer --</option>
                        <?php foreach ($customers as $c): ?>
                            <option value="<?= $c['id'] ?>" data-tipe="<?= $c['tipe_customer'] ?>" data-poin="<?= $c['poin'] ?>" data-level="<?= esc($c['nama_level'] ?? '') ?>" data-diskon-level="<?= $c['diskon_persen'] ?? 0 ?>">
                                <?= esc($c['nama_customer']) ?> (<?= esc($c['kode_customer']) ?>)<?= $c['nama_level'] ? ' — ' . esc($c['nama_level']) : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div id="customerPoinInfo" class="form-text d-none"></div>
                </div>
                <div class="mb-3 d-none" id="wrapRedeemPoin">
                    <label class="form-label">Tukar Poin untuk Potongan (1 poin = Rp 1.000)</label>
                    <input type="number" id="poinDipakai" class="form-control" value="0" min="0">
                </div>
                <?php if (! empty($branches)): ?>
                <div class="mb-3">
                    <label class="form-label">Cabang</label>
                    <select id="branchId" class="form-select">
                        <?php foreach ($branches as $b): ?>
                            <option value="<?= $b['id'] ?>"><?= esc($b['nama_cabang']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php else: ?>
                    <input type="hidden" id="branchId" value="<?= $user['branch_id'] ?>">
                <?php endif; ?>
            </div>
        </div>

        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body">
                <div class="form-check form-switch mb-2">
                    <input type="checkbox" class="form-check-input" id="perluKirim">
                    <label class="form-check-label">Pesanan Perlu Dikirim (pakai Kurir/Ekspedisi)</label>
                </div>
                <div id="wrapKurim" class="d-none">
                    <div class="mb-2">
                        <label class="form-label">Kurir</label>
                        <select id="kurirId" class="form-select">
                            <option value="">-- Pilih Kurir --</option>
                        </select>
                        <div class="form-text">Status kurir ditampilkan langsung di daftar supaya mudah pilih yang sedang free.</div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Ekspedisi (opsional)</label>
                        <select id="expeditionId" class="form-select">
                            <option value="">-- Tidak pakai ekspedisi --</option>
                            <?php foreach ($expeditions as $ex): ?>
                                <option value="<?= $ex['id'] ?>"><?= esc($ex['nama_ekspedisi']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>

        <div class="card border-0 pos-total-panel">
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2"><span class="text-muted">Subtotal</span><strong id="txtSubtotal">Rp 0</strong></div>
                <div class="mb-2">
                    <label class="form-label" style="color:#B8C0DE;">Diskon Transaksi (Rp)</label>
                    <input type="number" id="diskonTransaksi" class="form-control" value="0" min="0">
                </div>
                <hr>
                <div class="d-flex justify-content-between mb-3 fs-4 fw-bold"><span>Grand Total</span><strong id="txtGrandTotal">Rp 0</strong></div>

                <div class="mb-2">
                    <label class="form-label" style="color:#B8C0DE;">Metode Bayar</label>
                    <select id="metodeBayar" class="form-select">
                        <option value="cash">Cash</option>
                        <option value="transfer">Transfer</option>
                        <option value="qris">QRIS</option>
                        <option value="piutang">Piutang (belum lunas)</option>
                    </select>
                </div>
                <div class="mb-3 d-none text-center" id="wrapQris">
                    <div id="qrisCode" class="d-inline-block p-2 bg-white border rounded"></div>
                    <div class="form-text" style="color:#9AA3C2;">Tampilkan QR ini ke customer, atau buka "Layar Pelanggan" di monitor kedua untuk tampilan lebih besar.</div>
                </div>
                <div class="mb-3">
                    <label class="form-label" style="color:#B8C0DE;">Jumlah Bayar</label>
                    <input type="number" id="bayar" class="form-control" value="0" min="0">
                </div>
                <div class="d-flex justify-content-between mb-3"><span class="text-muted">Kembalian</span><strong id="txtKembalian">Rp 0</strong></div>

                <div class="d-grid gap-2">
                    <button type="button" class="btn btn-primary btn-lg" id="btnBayar"><i class="bi bi-check-circle"></i> Selesaikan & Bayar</button>
                    <button type="button" class="btn btn-outline-light" id="btnPending" style="border-color:#3A4470;color:#B8C0DE;"><i class="bi bi-hourglass-split"></i> Simpan sebagai Pending</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
<script>
const searchUrl   = '<?= site_url('kasir/cari-barang') ?>';
const serialsUrl  = '<?= site_url('kasir/serial-tersedia') ?>';
const priceUrl    = '<?= site_url('kasir/cek-harga-bertingkat') ?>';
const poinUrl     = '<?= site_url('kasir/cek-poin') ?>';
const logHapusUrl = '<?= site_url('kasir/log-hapus-item') ?>';
const storeUrl    = '<?= site_url('kasir/simpan') ?>';
const csrfName    = '<?= csrf_token() ?>';
const csrfHash    = '<?= csrf_hash() ?>';
const resumeData  = <?= json_encode($resume) ?>;
const noInvoicePreview = 'CFD-' + Date.now(); // referensi tampilan QR di layar sebelum invoice sungguhan terbit

let cart = []; // { product_id, nama_barang, unit_id, nama_satuan, konversi, qty, harga, diskon, jenis_produk, serials: [] }

function rupiah(n) { return 'Rp ' + Number(n || 0).toLocaleString('id-ID'); }
function branchId() { return document.getElementById('branchId').value; }
function tipeTransaksi() { return document.getElementById('tipeTransaksi').value; }

function renderCart() {
    const body = document.getElementById('cartBody');
    body.innerHTML = '';
    if (cart.length === 0) {
        body.innerHTML = '<tr id="cartEmptyRow"><td colspan="7" class="text-center text-muted py-4">Keranjang masih kosong</td></tr>';
    }
    cart.forEach((item, idx) => {
        const subtotal = (item.qty * item.harga) - item.diskon;
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td>${item.nama_barang}${item.jenis_produk === 'sn' ? ' <span class="badge bg-warning text-dark">SN</span>' : ''}</td>
            <td>${item.nama_satuan}</td>
            <td class="text-end"><input type="number" min="1" value="${item.qty}" class="form-control form-control-sm text-end" style="width:70px" onchange="updateQty(${idx}, this.value)"></td>
            <td class="text-end">${rupiah(item.harga)}</td>
            <td class="text-end"><input type="number" min="0" value="${item.diskon}" class="form-control form-control-sm text-end" style="width:80px" onchange="updateDiskon(${idx}, this.value)"></td>
            <td class="text-end">${rupiah(subtotal)}</td>
            <td><button class="btn btn-sm btn-outline-danger" onclick="removeItem(${idx})"><i class="bi bi-x-lg"></i></button></td>`;
        body.appendChild(tr);
    });
    recalcTotals();
}

function updateQty(idx, val) { cart[idx].qty = parseFloat(val) || 1; refreshTieredPrice(idx); }
function updateDiskon(idx, val) { cart[idx].diskon = parseFloat(val) || 0; renderCart(); }

/** Fitur #4: setiap penghapusan item dari keranjang SEBELUM struk dicetak otomatis tercatat di Audit Log */
function removeItem(idx) {
    const item = cart[idx];
    fetch(logHapusUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', [csrfName]: csrfHash },
        body: JSON.stringify({ nama_barang: item.nama_barang, qty: item.qty, harga: item.harga })
    }).catch(() => { /* jangan blokir UX kasir kalau log gagal terkirim */ });

    cart.splice(idx, 1);
    renderCart();
}

async function refreshTieredPrice(idx) {
    const item = cart[idx];
    const url = `${priceUrl}?product_id=${item.product_id}&unit_id=${item.unit_id}&qty=${item.qty}&tipe=${tipeTransaksi()}`;
    try {
        const res = await fetch(url);
        const json = await res.json();
        if (json.harga !== null && json.harga !== undefined) {
            item.harga = parseFloat(json.harga);
        }
    } catch (e) { /* abaikan, tetap pakai harga sebelumnya */ }
    renderCart();
}

function recalcTotals() {
    const subtotal = cart.reduce((sum, i) => sum + (i.qty * i.harga) - i.diskon, 0);
    const diskonTransaksi = parseFloat(document.getElementById('diskonTransaksi').value) || 0;
    const poinDipakai = parseInt(document.getElementById('poinDipakai')?.value) || 0;
    const potonganPoin = poinDipakai * 1000;

    // Fitur #1: preview diskon otomatis dari level member customer yang dipilih
    const custOpt = document.getElementById('customerId').options[document.getElementById('customerId').selectedIndex];
    const diskonLevelPersen = custOpt ? parseFloat(custOpt.dataset.diskonLevel || 0) : 0;
    const diskonLevel = diskonLevelPersen > 0 ? Math.round(subtotal * diskonLevelPersen / 100) : 0;

    const grandTotal = Math.max(0, subtotal - diskonTransaksi - potonganPoin - diskonLevel);
    document.getElementById('txtSubtotal').innerText = rupiah(subtotal);
    document.getElementById('txtGrandTotal').innerText = rupiah(grandTotal) + (diskonLevel > 0 ? ` (termasuk diskon level ${diskonLevelPersen}%)` : '');
    const bayar = parseFloat(document.getElementById('bayar').value) || 0;
    document.getElementById('txtKembalian').innerText = rupiah(Math.max(0, bayar - grandTotal));

    syncCfd(grandTotal);
    return { subtotal, grandTotal };
}

/** Fitur #5: sinkronkan total belanja saat ini ke tab "Layar Pelanggan" (CFD) lewat localStorage */
function syncCfd(grandTotal) {
    localStorage.setItem('cfd_state', JSON.stringify({
        items: cart.map(i => ({ nama: i.nama_barang, qty: i.qty, subtotal: (i.qty * i.harga) - i.diskon })),
        grandTotal, metodeBayar: document.getElementById('metodeBayar').value,
        qrisContent: document.getElementById('metodeBayar').value === 'qris' ? buildQrisContent(grandTotal) : null,
        ts: Date.now()
    }));
}

document.getElementById('diskonTransaksi').addEventListener('input', recalcTotals);
document.getElementById('bayar').addEventListener('input', recalcTotals);
document.getElementById('tipeTransaksi').addEventListener('change', () => cart.forEach((_, idx) => refreshTieredPrice(idx)));
document.getElementById('poinDipakai')?.addEventListener('input', recalcTotals);

document.getElementById('customerId').addEventListener('change', async function () {
    const opt = this.options[this.selectedIndex];
    const tipe = opt.dataset.tipe;
    if (tipe) document.getElementById('tipeTransaksi').value = tipe;

    const poinInfo = document.getElementById('customerPoinInfo');
    const wrapRedeem = document.getElementById('wrapRedeemPoin');
    if (this.value) {
        const poin = parseInt(opt.dataset.poin || 0);
        poinInfo.classList.remove('d-none');
        poinInfo.innerText = `Saldo poin: ${poin}${opt.dataset.level ? ' · Level ' + opt.dataset.level : ''}`;
        wrapRedeem.classList.remove('d-none');
        document.getElementById('poinDipakai').max = poin;
    } else {
        poinInfo.classList.add('d-none');
        wrapRedeem.classList.add('d-none');
        document.getElementById('poinDipakai').value = 0;
    }
    recalcTotals();
});

// --- Fitur #5: QRIS Dynamic (QR menyesuaikan nilai transaksi) & Customer Facing Display ---
document.getElementById('metodeBayar').addEventListener('change', function () {
    const wrapQris = document.getElementById('wrapQris');
    if (this.value === 'qris') {
        wrapQris.classList.remove('d-none');
        renderQris();
    } else {
        wrapQris.classList.add('d-none');
    }
    recalcTotals();
});

function buildQrisContent(grandTotal) {
    // Catatan: ini QR simulasi (bukan payload EMV QRIS resmi dari bank/PJSP) berisi referensi
    // transaksi + nominal, karena QRIS dinamis sungguhan butuh kredensial merchant dari bank/PJSP
    // yang tidak tersedia di lingkungan ini. Struktur payload gampang diganti begitu API QRIS resmi didapat.
    return `QRIS-SIMULASI|REF:${noInvoicePreview}|NOMINAL:${grandTotal}`;
}

function renderQris() {
    const el = document.getElementById('qrisCode');
    el.innerHTML = '';
    const totals = recalcTotals();
    if (window.QRCode) {
        new QRCode(el, { text: buildQrisContent(totals.grandTotal), width: 160, height: 160 });
    }
}

// --- Kurir & Ekspedisi ---
const listCouriersUrl = '<?= site_url('kasir/daftar-kurir') ?>';
document.getElementById('perluKirim').addEventListener('change', function () {
    document.getElementById('wrapKurim').classList.toggle('d-none', !this.checked);
    if (this.checked) loadCouriers();
});

async function loadCouriers() {
    const res = await fetch(`${listCouriersUrl}?branch_id=${branchId()}`);
    const json = await res.json();
    const select = document.getElementById('kurirId');
    select.innerHTML = '<option value="">-- Pilih Kurir --</option>';
    json.data.forEach(k => {
        const label = {'free': '🟢 Free', 'sibuk': '🟠 Sibuk', 'off': '⚪ Off'}[k.status_kurir] || k.status_kurir;
        const opt = document.createElement('option');
        opt.value = k.id;
        opt.innerText = `${k.nama} (${label})`;
        select.appendChild(opt);
    });
}

// --- Pencarian barang ---
let searchTimeout;
document.getElementById('searchBox').addEventListener('input', function () {
    clearTimeout(searchTimeout);
    const q = this.value.trim();
    if (q.length < 2) { document.getElementById('searchResults').innerHTML = ''; return; }
    searchTimeout = setTimeout(() => doSearch(q), 250);
});
document.getElementById('searchBox').addEventListener('keydown', function (e) {
    if (e.key === 'Enter') { e.preventDefault(); doSearch(this.value.trim(), true); }
});

async function doSearch(q, autoAddOnExactBarcode = false) {
    if (!q) return;
    const url = `${searchUrl}?q=${encodeURIComponent(q)}&branch_id=${branchId()}&tipe=${tipeTransaksi()}`;
    const res = await fetch(url);
    const json = await res.json();
    const box = document.getElementById('searchResults');
    box.innerHTML = '';

    if (autoAddOnExactBarcode && json.data.length && json.data[0].exact_barcode) {
        addToCart(json.data[0], json.data[0].units[0]);
        document.getElementById('searchBox').value = '';
        box.innerHTML = '';
        return;
    }

    json.data.forEach(p => {
        const div = document.createElement('a');
        div.href = '#';
        div.className = 'list-group-item list-group-item-action';
        div.innerHTML = `<div class="d-flex justify-content-between"><span>${p.nama_barang} <small class="text-muted">(${p.kode_barang})</small></span><span>Stok: ${p.stok}</span></div>`;
        div.addEventListener('click', (e) => { e.preventDefault(); addToCart(p, p.units[0]); document.getElementById('searchBox').value = ''; box.innerHTML = ''; });
        box.appendChild(div);
    });
}

async function addToCart(product, unit) {
    let serials = [];
    if (product.jenis_produk === 'sn') {
        const res = await fetch(`${serialsUrl}?product_id=${product.id}&branch_id=${branchId()}`);
        const json = await res.json();
        if (!json.data.length) { alert('Tidak ada serial number tersedia untuk barang ini.'); return; }
        const sn = prompt('Masukkan/pilih Serial Number:\n' + json.data.map(s => s.serial_number).join(', '));
        const found = json.data.find(s => s.serial_number === sn);
        if (!found) { alert('Serial number tidak ditemukan.'); return; }
        serials = [found.id];
    }

    cart.push({
        product_id: product.id, nama_barang: product.nama_barang, jenis_produk: product.jenis_produk,
        unit_id: unit.unit_id, nama_satuan: unit.nama_satuan, konversi: unit.konversi,
        qty: 1, harga: unit.harga, diskon: 0, serials
    });
    renderCart();
}

async function submitTransaction(statusTransaksi) {
    if (cart.length === 0) { alert('Keranjang masih kosong.'); return; }
    const totals = recalcTotals();
    const payload = {
        branch_id: branchId(),
        customer_id: document.getElementById('customerId').value || null,
        tipe_transaksi: tipeTransaksi(),
        metode_bayar: document.getElementById('metodeBayar').value,
        bayar: parseFloat(document.getElementById('bayar').value) || 0,
        diskon: parseFloat(document.getElementById('diskonTransaksi').value) || 0,
        poin_dipakai: parseInt(document.getElementById('poinDipakai')?.value) || 0,
        status_transaksi: statusTransaksi,
        kurir_id: document.getElementById('perluKirim').checked ? (document.getElementById('kurirId').value || null) : null,
        expedition_id: document.getElementById('perluKirim').checked ? (document.getElementById('expeditionId').value || null) : null,
        resume_sale_id: resumeData ? resumeData.sale.id : null,
        items: cart
    };

    try {
        const res = await fetch(storeUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', [csrfName]: csrfHash },
            body: JSON.stringify(payload)
        });
        const json = await res.json();
        if (json.success) {
            clearCartLocalState();
            window.location.href = json.redirect || '<?= site_url('penjualan') ?>';
        } else {
            alert(json.message || 'Gagal menyimpan transaksi.');
        }
    } catch (networkError) {
        // Fitur #6: Mode Offline -- kalau fetch gagal total (jaringan putus), simpan transaksi ke
        // antrean lokal di browser dulu supaya kasir tetap bisa lanjut transaksi berikutnya, lalu
        // sinkronkan otomatis / manual begitu koneksi kembali normal.
        queueOfflineTransaction(payload);
        alert('Koneksi internet terputus. Transaksi disimpan sementara di perangkat ini dan akan otomatis disinkronkan begitu jaringan kembali normal.');
        cart = [];
        renderCart();
    }
}

function clearCartLocalState() {
    localStorage.removeItem('cfd_state');
}

// --- Fitur #6: antrean transaksi offline (offline-first) ---
function getOfflineQueue() {
    return JSON.parse(localStorage.getItem('offline_sale_queue') || '[]');
}
function saveOfflineQueue(queue) {
    localStorage.setItem('offline_sale_queue', JSON.stringify(queue));
    updateOfflineBadge();
}
function queueOfflineTransaction(payload) {
    const queue = getOfflineQueue();
    queue.push({ payload, queuedAt: Date.now() });
    saveOfflineQueue(queue);
}
function updateOfflineBadge() {
    const queue = getOfflineQueue();
    const badge = document.getElementById('offlineBadge');
    const btnSync = document.getElementById('btnSync');
    if (queue.length > 0) {
        badge.classList.remove('d-none');
        btnSync.classList.remove('d-none');
        document.getElementById('offlineCount').innerText = queue.length;
    } else {
        badge.classList.add('d-none');
        btnSync.classList.add('d-none');
    }
}
async function syncOfflineQueue() {
    let queue = getOfflineQueue();
    if (queue.length === 0) { return; }
    const sisa = [];
    for (const entry of queue) {
        try {
            const res = await fetch(storeUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', [csrfName]: csrfHash },
                body: JSON.stringify(entry.payload)
            });
            const json = await res.json();
            if (! json.success) {
                sisa.push(entry); // gagal karena alasan lain (bukan jaringan) -- simpan lagi utk dicek manual
            }
        } catch (e) {
            sisa.push(entry); // masih offline, coba lagi nanti
        }
    }
    saveOfflineQueue(sisa);
    if (sisa.length === 0) {
        alert('Semua transaksi offline berhasil disinkronkan.');
    } else {
        alert(`${queue.length - sisa.length} transaksi berhasil disinkron, ${sisa.length} masih gagal/menunggu koneksi.`);
    }
}
document.getElementById('btnSync').addEventListener('click', syncOfflineQueue);
window.addEventListener('online', syncOfflineQueue);
updateOfflineBadge();

document.getElementById('btnBayar').addEventListener('click', () => submitTransaction('selesai'));
document.getElementById('btnPending').addEventListener('click', () => submitTransaction('pending'));

// Isi ulang keranjang jika melanjutkan transaksi pending
if (resumeData) {
    document.getElementById('metodeBayar').value = resumeData.sale.metode_bayar;
    document.getElementById('bayar').value = resumeData.sale.bayar;
    document.getElementById('diskonTransaksi').value = resumeData.sale.diskon;
    resumeData.items.forEach(it => {
        cart.push({
            product_id: it.product_id, nama_barang: it.nama_barang, jenis_produk: it.jenis_produk,
            unit_id: it.unit_id, nama_satuan: it.nama_satuan, konversi: 1,
            qty: parseFloat(it.qty), harga: parseFloat(it.harga), diskon: parseFloat(it.diskon), serials: []
        });
    });
    renderCart();
}
</script>

<?= $this->endSection() ?>
