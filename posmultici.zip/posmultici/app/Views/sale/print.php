<?php
$lebarMm = \App\Models\PrinterSettingModel::lebarMm($printer);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Nota <?= esc($sale['no_invoice']) ?></title>
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.6/dist/JsBarcode.all.min.js"></script>
    <style>
        @page { size: <?= $lebarMm ?>mm auto; margin: 0; }
        * { box-sizing: border-box; }
        body {
            font-family: 'Courier New', Courier, monospace;
            font-size: <?= (int) $printer['font_size'] ?>px;
            width: <?= $lebarMm ?>mm;
            margin: 0 auto;
            padding: 4mm 2mm;
        }
        .center { text-align: center; }
        .bold { font-weight: bold; }
        .line { border-top: 1px dashed #000; margin: 4px 0; }
        table { width: 100%; border-collapse: collapse; }
        td { padding: 0; vertical-align: top; }
        .right { text-align: right; }
        .row-flex { display: flex; justify-content: space-between; }
        .no-print { text-align: center; margin-top: 12px; }
        .receipt-copy { page-break-after: always; }
        .receipt-copy:last-child { page-break-after: auto; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body>

<?php for ($copy = 1; $copy <= max(1, (int) $printer['jumlah_copy']); $copy++): ?>
<div class="receipt-copy">

<div class="center">
    <?php if ($printer['tampilkan_logo'] && ! empty($store['logo'])): ?>
        <img src="<?= esc($store['logo']) ?>" style="max-width: 100%; max-height: 60px;">
    <?php endif; ?>
    <div class="bold"><?= esc($store['nama_toko'] ?? 'Nama Toko') ?></div>
    <?php if (! empty($store['alamat'])): ?><div><?= esc($store['alamat']) ?></div><?php endif; ?>
    <?php if (! empty($store['telepon'])): ?><div><?= esc($store['telepon']) ?></div><?php endif; ?>
</div>
<div class="line"></div>

<div>No: <?= esc($sale['no_invoice']) ?></div>
<div>Tgl: <?= esc(date('d/m/Y H:i', strtotime($sale['tanggal']))) ?></div>
<div class="line"></div>

<table>
    <?php foreach ($items as $it): ?>
        <tr>
            <td colspan="2"><?= esc($it['nama_barang']) ?></td>
        </tr>
        <tr>
            <td><?= number_format($it['qty']) ?> <?= esc($it['nama_satuan']) ?> x <?= number_format($it['harga']) ?></td>
            <td class="right"><?= number_format($it['subtotal']) ?></td>
        </tr>
    <?php endforeach; ?>
</table>
<div class="line"></div>

<div class="row-flex"><span>Subtotal</span><span><?= number_format($sale['subtotal']) ?></span></div>
<?php if ($sale['diskon'] > 0): ?><div class="row-flex"><span>Diskon</span><span>-<?= number_format($sale['diskon']) ?></span></div><?php endif; ?>
<div class="row-flex bold"><span>Total</span><span><?= number_format($sale['grand_total']) ?></span></div>
<div class="row-flex"><span>Bayar</span><span><?= number_format($sale['bayar']) ?></span></div>
<div class="row-flex"><span>Kembali</span><span><?= number_format($sale['kembalian']) ?></span></div>
<div class="line"></div>

<div class="center">
    <svg class="barcode-svg" data-value="<?= esc($sale['no_invoice'], 'attr') ?>"></svg>
</div>

<?php if (! empty($store['footer_struk'])): ?>
    <div class="center" style="margin-top:6px;"><?= esc($store['footer_struk']) ?></div>
<?php else: ?>
    <div class="center" style="margin-top:6px;">Terima kasih atas kunjungan Anda</div>
<?php endif; ?>

</div>
<?php endfor; ?>

<div class="no-print">
    <button onclick="window.print()">Cetak</button>
</div>

<script>
document.querySelectorAll('.barcode-svg').forEach(function (el) {
    JsBarcode(el, el.dataset.value, { format: "CODE128", width: 1.4, height: 35, displayValue: true, fontSize: 10, margin: 0 });
});
// Cetak otomatis begitu halaman siap; jumlah salinan sudah digandakan langsung di dalam halaman ini
// sesuai Pengaturan Printer (bukan lewat dialog "copies" browser yang perilakunya beda-beda per OS).
window.onload = function () { window.print(); };
</script>

</body>
</html>
