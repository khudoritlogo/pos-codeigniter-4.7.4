<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Detail Transaksi — <?= esc($sale['no_invoice']) ?> <?= $sale['status_transaksi'] === 'batal' ? '<span class="badge bg-danger">VOID</span>' : '' ?></h5>
    <div>
        <a href="<?= site_url('penjualan/' . $sale['id'] . '/cetak') ?>" target="_blank" class="btn btn-outline-secondary btn-sm"><i class="bi bi-printer"></i> Cetak Nota</a>
        <?php if ($sale['status_transaksi'] === 'selesai' && can_access('void_transaction')): ?>
            <button type="button" class="btn btn-outline-danger btn-sm" data-bs-toggle="modal" data-bs-target="#modalVoid"><i class="bi bi-x-octagon"></i> Void Transaksi</button>
        <?php endif; ?>
        <a href="<?= site_url('penjualan') ?>" class="btn btn-outline-secondary btn-sm">Kembali</a>
    </div>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="row g-3">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <table class="table table-sm mb-0">
                    <tr><td class="text-muted">Tanggal</td><td><?= esc(date('d/m/Y H:i', strtotime($sale['tanggal']))) ?></td></tr>
                    <tr><td class="text-muted">Tipe</td><td><?= esc(ucfirst($sale['tipe_transaksi'])) ?></td></tr>
                    <tr><td class="text-muted">Metode Bayar</td><td><?= esc(ucfirst($sale['metode_bayar'])) ?></td></tr>
                    <tr><td class="text-muted">Status Bayar</td><td><?= esc(str_replace('_', ' ', ucfirst($sale['status_bayar']))) ?></td></tr>
                    <tr><td class="text-muted">Status</td><td><?= esc(ucfirst($sale['status_transaksi'])) ?></td></tr>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card border-0 shadow-sm">
            <div class="card-body p-0">
                <table class="table mb-0">
                    <thead><tr><th>Barang</th><th>Satuan</th><th class="text-end">Qty</th><th class="text-end">Harga</th><th class="text-end">Diskon</th><th class="text-end">Subtotal</th></tr></thead>
                    <tbody>
                    <?php foreach ($items as $it): ?>
                        <tr>
                            <td><?= esc($it['nama_barang']) ?></td>
                            <td><?= esc($it['nama_satuan']) ?></td>
                            <td class="text-end"><?= number_format($it['qty']) ?></td>
                            <td class="text-end"><?= rupiah($it['harga']) ?></td>
                            <td class="text-end"><?= rupiah($it['diskon']) ?></td>
                            <td class="text-end"><?= rupiah($it['subtotal']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr><td colspan="5" class="text-end">Subtotal</td><td class="text-end"><?= rupiah($sale['subtotal']) ?></td></tr>
                        <tr><td colspan="5" class="text-end">Diskon</td><td class="text-end"><?= rupiah($sale['diskon']) ?></td></tr>
                        <tr class="fw-bold"><td colspan="5" class="text-end">Grand Total</td><td class="text-end"><?= rupiah($sale['grand_total']) ?></td></tr>
                        <tr><td colspan="5" class="text-end">Bayar</td><td class="text-end"><?= rupiah($sale['bayar']) ?></td></tr>
                        <tr><td colspan="5" class="text-end">Kembalian</td><td class="text-end"><?= rupiah($sale['kembalian']) ?></td></tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
</div>

<?php if ($sale['status_transaksi'] === 'selesai' && can_access('void_transaction')): ?>
<div class="modal fade" id="modalVoid" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?= site_url('penjualan/' . $sale['id'] . '/void') ?>" method="post" id="formVoid">
                <?= csrf_field() ?>
                <input type="hidden" name="otorisator_id" id="otorisatorId">
                <div class="modal-header">
                    <h6 class="modal-title">Void Transaksi — <?= esc($sale['no_invoice']) ?></h6>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="text-danger small">Aksi ini akan membatalkan transaksi, mengembalikan stok barang, dan wajib otorisasi Admin/Super Admin. Tercatat permanen di Audit Log.</p>
                    <div class="mb-3">
                        <label class="form-label">Alasan Void</label>
                        <textarea name="alasan" class="form-control" rows="2" required></textarea>
                    </div>
                    <hr>
                    <p class="fw-semibold small mb-2">Otorisasi Supervisor (Admin/Super Admin)</p>
                    <div class="mb-2">
                        <input type="text" id="otorUsername" class="form-control form-control-sm" placeholder="Username otorisator">
                    </div>
                    <div class="mb-2">
                        <input type="password" id="otorPassword" class="form-control form-control-sm" placeholder="Password otorisator">
                    </div>
                    <div id="otorStatus" class="small"></div>
                    <button type="button" id="btnCekOtor" class="btn btn-sm btn-outline-primary mt-1">Verifikasi Otorisasi</button>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-danger" id="btnSubmitVoid" disabled>Void Transaksi Sekarang</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.getElementById('btnCekOtor').addEventListener('click', async function () {
    const username = document.getElementById('otorUsername').value;
    const password = document.getElementById('otorPassword').value;
    const status = document.getElementById('otorStatus');

    const res = await fetch('<?= site_url('kasir/cek-otorisasi') ?>', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&<?= csrf_token() ?>=<?= csrf_hash() ?>`
    });
    const json = await res.json();

    if (json.success) {
        status.className = 'small text-success';
        status.innerText = `Terotorisasi oleh ${json.nama}.`;
        document.getElementById('otorisatorId').value = json.otorisator_id;
        document.getElementById('btnSubmitVoid').disabled = false;
    } else {
        status.className = 'small text-danger';
        status.innerText = json.message;
        document.getElementById('btnSubmitVoid').disabled = true;
    }
});
</script>
<?php endif; ?>

<?= $this->endSection() ?>
