<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Layar Pelanggan</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
    <style>
        body { margin: 0; background: #12172B; color: #fff; font-family: 'Segoe UI', Arial, sans-serif; height: 100vh; display: flex; flex-direction: column; }
        .header { text-align: center; padding: 24px; font-size: 28px; font-weight: 700; border-bottom: 1px solid #2a3150; }
        .items { flex: 1; overflow-y: auto; padding: 24px 40px; }
        .item-row { display: flex; justify-content: space-between; font-size: 22px; padding: 10px 0; border-bottom: 1px dashed #2a3150; }
        .footer { padding: 30px 40px; background: #1b2340; }
        .total-row { display: flex; justify-content: space-between; align-items: center; font-size: 42px; font-weight: 700; }
        .waiting { text-align: center; margin-top: 100px; font-size: 26px; color: #7d8ea3; }
        .qris-box { text-align: center; margin-top: 16px; }
        .qris-box .box { background: #fff; display: inline-block; padding: 16px; border-radius: 12px; }
    </style>
</head>
<body>
    <div class="header">🛒 Belanja Anda Hari Ini</div>
    <div class="items" id="items">
        <div class="waiting">Menunggu transaksi dari kasir...</div>
    </div>
    <div class="footer">
        <div class="total-row"><span>Total</span><span id="total">Rp 0</span></div>
        <div id="qrisArea" class="qris-box" style="display:none;">
            <div class="box"><div id="qrisCanvas"></div></div>
            <div style="margin-top:8px; color:#c9a227;">Scan QRIS untuk membayar</div>
        </div>
    </div>

<script>
function rupiah(n) { return 'Rp ' + Number(n || 0).toLocaleString('id-ID'); }

function render(state) {
    const itemsEl = document.getElementById('items');
    if (!state || !state.items || state.items.length === 0) {
        itemsEl.innerHTML = '<div class="waiting">Menunggu transaksi dari kasir...</div>';
    } else {
        itemsEl.innerHTML = state.items.map(i => `
            <div class="item-row"><span>${i.qty}x ${i.nama}</span><span>${rupiah(i.subtotal)}</span></div>
        `).join('');
    }
    document.getElementById('total').innerText = rupiah(state ? state.grandTotal : 0);

    const qrisArea = document.getElementById('qrisArea');
    if (state && state.metodeBayar === 'qris' && state.qrisContent) {
        qrisArea.style.display = 'block';
        const canvas = document.getElementById('qrisCanvas');
        canvas.innerHTML = '';
        new QRCode(canvas, { text: state.qrisContent, width: 200, height: 200 });
    } else {
        qrisArea.style.display = 'none';
    }
}

// Fitur #5: sinkronisasi real-time dengan tab kasir lewat localStorage 'storage' event
// (bekerja lintas tab/window pada browser & perangkat yang sama -- cocok dipakai sebagai monitor kedua)
window.addEventListener('storage', function (e) {
    if (e.key === 'cfd_state') {
        render(e.newValue ? JSON.parse(e.newValue) : null);
    }
});

// Muat state terakhir saat halaman pertama dibuka
const initial = localStorage.getItem('cfd_state');
render(initial ? JSON.parse(initial) : null);
</script>
</body>
</html>
