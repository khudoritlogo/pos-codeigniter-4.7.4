<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title><?= esc($title ?? 'POS Multi Cabang') ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- AdminLTE 4.9.1 + Bootstrap 5.3.8 (CSS) -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/styles/overlayscrollbars.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@4.9.1/dist/css/adminlte.min.css">

    <style>
        /* Sentuhan kecil di atas AdminLTE bawaan: font judul & angka uang, warna brand Nusantara POS */
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@600;700&family=IBM+Plex+Mono:wght@500;600&display=swap');
        :root {
            --ink: #1B2340; --ink-deep: #12172B; --gold: #C9A227; --gold-light: #E8C468;
            --canvas: #F6F4EF; --text-muted: #6B7280; --success: #1F9D6B; --warning: #E0A72E;
            --danger: #D14343; --border: #E7E3D8;
        }
        .brand-link, .app-content-header h3, .card-title { font-family: 'Sora', system-ui, sans-serif; }
        .table td.text-end, .table th.text-end, td.text-end, th.text-end {
            font-family: 'IBM Plex Mono', ui-monospace, monospace;
            font-variant-numeric: tabular-nums;
        }
        .sidebar-brand .brand-icon-box {
            width: 30px; height: 30px; background: #C9A227; color: #1B2340;
            display: inline-flex; align-items: center; justify-content: center; border-radius: .375rem;
        }
        .nav-sidebar .nav-link.active { border-left: 3px solid #C9A227; }
        /* Panel total di layar Kasir (sale/pos.php) dibuat gelap ala mesin kasir sungguhan */
        .pos-total-panel { background: var(--ink); color: #fff; border-radius: 14px; }
        .pos-total-panel .text-muted { color: #9AA3C2 !important; }
        .pos-total-panel hr { border-color: var(--ink-deep); }
    </style>
</head>
<body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
<div class="app-wrapper">

    <!-- ============ HEADER ============ -->
    <nav class="app-header navbar navbar-expand bg-body">
        <div class="container-fluid">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-lte-toggle="sidebar" href="#" role="button">
                        <i class="bi bi-list"></i>
                    </a>
                </li>
                <li class="nav-item d-none d-md-block">
                    <span class="nav-link fw-semibold"><?= esc($title ?? '') ?></span>
                </li>
            </ul>

            <ul class="navbar-nav ms-auto align-items-center">
                <li class="nav-item d-none d-sm-block">
                    <span class="nav-link text-muted small"><i class="bi bi-shop"></i> <?= esc(session()->get('branch_name')) ?></span>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#">
                        <i class="bi bi-person-circle"></i>
                        <?= esc(session()->get('nama')) ?>
                        <span class="badge text-bg-secondary ms-1"><?= esc(session()->get('role_name')) ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><span class="dropdown-item-text text-muted small"><?= esc(session()->get('username')) ?></span></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="<?= site_url('logout') ?>"><i class="bi bi-box-arrow-right"></i> Keluar</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>

    <!-- ============ SIDEBAR ============ -->
    <aside class="app-sidebar bg-body-secondary shadow" data-bs-theme="dark">
        <div class="sidebar-brand">
            <a href="<?= site_url('dashboard') ?>" class="brand-link">
                <span class="brand-icon-box me-2"><i class="bi bi-shop"></i></span>
                <span class="brand-text fw-semibold">Nusantara POS</span>
            </a>
        </div>

        <div class="sidebar-wrapper">
            <nav class="mt-2">
                <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">

                    <?php if (can_access('dashboard')): ?>
                        <li class="nav-item"><a href="<?= site_url('dashboard') ?>" class="nav-link"><i class="nav-icon bi bi-speedometer2"></i><p>Dashboard</p></a></li>
                    <?php endif; ?>
                    <?php if (can_access('dashboard_kurir')): ?>
                        <li class="nav-item"><a href="<?= site_url('kurir/dashboard') ?>" class="nav-link"><i class="nav-icon bi bi-speedometer2"></i><p>Dashboard Kurir</p></a></li>
                    <?php endif; ?>

                    <?php if (can_access('category') || can_access('unit') || can_access('product') || can_access('supplier') || can_access('customer') || can_access('expedition')): ?>
                        <li class="nav-header">MASTER DATA</li>
                    <?php endif; ?>
                    <?php if (can_access('store_setting')): ?><li class="nav-item"><a href="<?= site_url('pengaturan-toko') ?>" class="nav-link"><i class="nav-icon bi bi-shop"></i><p>Info Toko</p></a></li><?php endif; ?>
                    <?php if (can_access('branch')): ?><li class="nav-item"><a href="<?= site_url('cabang') ?>" class="nav-link"><i class="nav-icon bi bi-diagram-3"></i><p>Cabang</p></a></li><?php endif; ?>
                    <?php if (can_access('user')): ?><li class="nav-item"><a href="<?= site_url('user') ?>" class="nav-link"><i class="nav-icon bi bi-people"></i><p>Pengguna</p></a></li><?php endif; ?>
                    <?php if (can_access('category')): ?><li class="nav-item"><a href="<?= site_url('kategori') ?>" class="nav-link"><i class="nav-icon bi bi-tags"></i><p>Kategori</p></a></li><?php endif; ?>
                    <?php if (can_access('unit')): ?><li class="nav-item"><a href="<?= site_url('satuan') ?>" class="nav-link"><i class="nav-icon bi bi-rulers"></i><p>Satuan</p></a></li><?php endif; ?>
                    <?php if (can_access('product')): ?><li class="nav-item"><a href="<?= site_url('barang') ?>" class="nav-link"><i class="nav-icon bi bi-box-seam"></i><p>Barang</p></a></li><?php endif; ?>
                    <?php if (can_access('customer')): ?><li class="nav-item"><a href="<?= site_url('customer') ?>" class="nav-link"><i class="nav-icon bi bi-person-badge"></i><p>Customer</p></a></li><?php endif; ?>
                    <?php if (can_access('customer_level')): ?><li class="nav-item"><a href="<?= site_url('level-member') ?>" class="nav-link"><i class="nav-icon bi bi-star"></i><p>Level Member</p></a></li><?php endif; ?>
                    <?php if (can_access('supplier')): ?><li class="nav-item"><a href="<?= site_url('supplier') ?>" class="nav-link"><i class="nav-icon bi bi-truck"></i><p>Supplier</p></a></li><?php endif; ?>
                    <?php if (can_access('expedition')): ?><li class="nav-item"><a href="<?= site_url('ekspedisi') ?>" class="nav-link"><i class="nav-icon bi bi-signpost-split"></i><p>Ekspedisi</p></a></li><?php endif; ?>

                    <?php if (can_access('loyalty_reward') || can_access('loyalty_redemption')): ?>
                        <li class="nav-header">LOYALTY POIN</li>
                    <?php endif; ?>
                    <?php if (can_access('loyalty_reward')): ?><li class="nav-item"><a href="<?= site_url('hadiah-poin') ?>" class="nav-link"><i class="nav-icon bi bi-gift"></i><p>Katalog Hadiah</p></a></li><?php endif; ?>
                    <?php if (can_access('loyalty_redemption')): ?><li class="nav-item"><a href="<?= site_url('tukar-poin') ?>" class="nav-link"><i class="nav-icon bi bi-arrow-repeat"></i><p>Tukar Poin</p></a></li><?php endif; ?>

                    <?php if (can_access('sale') || can_access('purchase')): ?>
                        <li class="nav-header">TRANSAKSI</li>
                    <?php endif; ?>
                    <?php if (can_access('sale')): ?><li class="nav-item"><a href="<?= site_url('kasir') ?>" class="nav-link"><i class="nav-icon bi bi-cash-coin"></i><p>Transaksi Kasir</p></a></li><?php endif; ?>
                    <?php if (can_access('sale')): ?><li class="nav-item"><a href="<?= site_url('penjualan') ?>" class="nav-link"><i class="nav-icon bi bi-receipt"></i><p>Riwayat Penjualan</p></a></li><?php endif; ?>
                    <?php if (can_access('sale_return')): ?><li class="nav-item"><a href="<?= site_url('retur-penjualan') ?>" class="nav-link"><i class="nav-icon bi bi-arrow-return-left"></i><p>Retur Penjualan</p></a></li><?php endif; ?>
                    <?php if (can_access('purchase')): ?><li class="nav-item"><a href="<?= site_url('pembelian') ?>" class="nav-link"><i class="nav-icon bi bi-bag-plus"></i><p>Pembelian</p></a></li><?php endif; ?>
                    <?php if (can_access('purchase_return')): ?><li class="nav-item"><a href="<?= site_url('retur-pembelian') ?>" class="nav-link"><i class="nav-icon bi bi-arrow-return-right"></i><p>Retur Pembelian</p></a></li><?php endif; ?>
                    <?php if (can_access('stock_transfer')): ?><li class="nav-item"><a href="<?= site_url('transfer-stok') ?>" class="nav-link"><i class="nav-icon bi bi-arrow-left-right"></i><p>Transfer Stok</p></a></li><?php endif; ?>
                    <?php if (can_access('stock_opname')): ?><li class="nav-item"><a href="<?= site_url('stock-opname') ?>" class="nav-link"><i class="nav-icon bi bi-clipboard-check"></i><p>Stock Opname</p></a></li><?php endif; ?>
                    <?php if (can_access('receivable')): ?><li class="nav-item"><a href="<?= site_url('piutang') ?>" class="nav-link"><i class="nav-icon bi bi-cash"></i><p>Piutang</p></a></li><?php endif; ?>
                    <?php if (can_access('payable')): ?><li class="nav-item"><a href="<?= site_url('hutang') ?>" class="nav-link"><i class="nav-icon bi bi-wallet2"></i><p>Hutang</p></a></li><?php endif; ?>
                    <?php if (can_access('cashier_shift')): ?><li class="nav-item"><a href="<?= site_url('shift-kasir') ?>" class="nav-link"><i class="nav-icon bi bi-clock-history"></i><p>Shift Kasir</p></a></li><?php endif; ?>
                    <?php if (can_access('garansi')): ?><li class="nav-item"><a href="<?= site_url('garansi') ?>" class="nav-link"><i class="nav-icon bi bi-shield-check"></i><p>Cek Garansi</p></a></li><?php endif; ?>

                    <?php if (can_access('courier_delivery')): ?>
                        <li class="nav-header">KURIR</li>
                        <li class="nav-item"><a href="<?= site_url('kurir/pengiriman') ?>" class="nav-link"><i class="nav-icon bi bi-geo-alt"></i><p>Pengiriman</p></a></li>
                    <?php endif; ?>

                    <?php if (can_access('report_kasir')): ?>
                        <li class="nav-header">LAPORAN</li>
                        <li class="nav-item"><a href="<?= site_url('laporan/kasir') ?>" class="nav-link"><i class="nav-icon bi bi-file-earmark-text"></i><p>Laporan Kasir</p></a></li>
                        <?php if (can_access('report_customer')): ?><li class="nav-item"><a href="<?= site_url('laporan/customer') ?>" class="nav-link"><i class="nav-icon bi bi-circle"></i><p>Laporan Customer</p></a></li><?php endif; ?>
                        <?php if (can_access('report_sale_periode')): ?><li class="nav-item"><a href="<?= site_url('laporan/penjualan-periode') ?>" class="nav-link"><i class="nav-icon bi bi-circle"></i><p>Penjualan per Periode</p></a></li><?php endif; ?>
                        <?php if (can_access('report_sale_return')): ?><li class="nav-item"><a href="<?= site_url('laporan/penjualan-retur') ?>" class="nav-link"><i class="nav-icon bi bi-circle"></i><p>Penjualan Retur</p></a></li><?php endif; ?>
                        <?php if (can_access('report_supplier')): ?><li class="nav-item"><a href="<?= site_url('laporan/supplier') ?>" class="nav-link"><i class="nav-icon bi bi-circle"></i><p>Data Supplier</p></a></li><?php endif; ?>
                        <?php if (can_access('report_purchase_periode')): ?><li class="nav-item"><a href="<?= site_url('laporan/pembelian-periode') ?>" class="nav-link"><i class="nav-icon bi bi-circle"></i><p>Pembelian per Periode</p></a></li><?php endif; ?>
                        <?php if (can_access('report_purchase_return')): ?><li class="nav-item"><a href="<?= site_url('laporan/pembelian-retur') ?>" class="nav-link"><i class="nav-icon bi bi-circle"></i><p>Pembelian Retur</p></a></li><?php endif; ?>
                        <?php if (can_access('report_top_product')): ?><li class="nav-item"><a href="<?= site_url('laporan/barang-terlaris') ?>" class="nav-link"><i class="nav-icon bi bi-circle"></i><p>Barang Terlaris</p></a></li><?php endif; ?>
                        <?php if (can_access('report_low_stock')): ?><li class="nav-item"><a href="<?= site_url('laporan/stok-terkecil') ?>" class="nav-link"><i class="nav-icon bi bi-circle"></i><p>Stok Terkecil</p></a></li><?php endif; ?>
                        <?php if (can_access('report_courier')): ?><li class="nav-item"><a href="<?= site_url('laporan/kurir') ?>" class="nav-link"><i class="nav-icon bi bi-circle"></i><p>Laporan Kurir</p></a></li><?php endif; ?>
                        <?php if (can_access('report_cash_transfer')): ?><li class="nav-item"><a href="<?= site_url('laporan/cash-transfer') ?>" class="nav-link"><i class="nav-icon bi bi-circle"></i><p>Cash & Transfer</p></a></li><?php endif; ?>
                        <?php if (can_access('report_profit')): ?><li class="nav-item"><a href="<?= site_url('laporan/laba-bersih') ?>" class="nav-link"><i class="nav-icon bi bi-circle"></i><p>Laba Bersih</p></a></li><?php endif; ?>
                        <?php if (can_access('report_expiry')): ?><li class="nav-item"><a href="<?= site_url('laporan/kedaluwarsa') ?>" class="nav-link"><i class="nav-icon bi bi-circle"></i><p>Barang Kedaluwarsa</p></a></li><?php endif; ?>
                    <?php endif; ?>

                    <?php if (can_access('barcode_print') || can_access('printer_setting')): ?>
                        <li class="nav-header">CETAK</li>
                    <?php endif; ?>
                    <?php if (can_access('barcode_print')): ?><li class="nav-item"><a href="<?= site_url('barcode/cetak') ?>" class="nav-link"><i class="nav-icon bi bi-upc-scan"></i><p>Cetak Barcode</p></a></li><?php endif; ?>
                    <?php if (can_access('printer_setting')): ?><li class="nav-item"><a href="<?= site_url('pengaturan-printer') ?>" class="nav-link"><i class="nav-icon bi bi-printer"></i><p>Pengaturan Printer</p></a></li><?php endif; ?>

                    <?php if (can_access('backup_restore') || can_access('audit_log') || can_access('wa_bot_setting') || can_access('telegram_bot_setting')): ?>
                        <li class="nav-header">SISTEM</li>
                    <?php endif; ?>
                    <?php if (can_access('backup_restore')): ?><li class="nav-item"><a href="<?= site_url('backup-restore') ?>" class="nav-link"><i class="nav-icon bi bi-hdd-network"></i><p>Backup & Restore</p></a></li><?php endif; ?>
                    <?php if (can_access('audit_log')): ?><li class="nav-item"><a href="<?= site_url('audit-log') ?>" class="nav-link"><i class="nav-icon bi bi-journal-text"></i><p>Audit Log</p></a></li><?php endif; ?>
                    <?php if (can_access('wa_bot_setting')): ?><li class="nav-item"><a href="<?= site_url('pengaturan-wa-bot') ?>" class="nav-link"><i class="nav-icon bi bi-whatsapp"></i><p>WA Bot Omzet</p></a></li><?php endif; ?>
                    <?php if (can_access('telegram_bot_setting')): ?><li class="nav-item"><a href="<?= site_url('pengaturan-telegram-bot') ?>" class="nav-link"><i class="nav-icon bi bi-telegram"></i><p>Telegram Bot Omzet</p></a></li><?php endif; ?>

                </ul>
            </nav>
        </div>
    </aside>

    <!-- ============ MAIN CONTENT ============ -->
    <main class="app-main">
        <div class="app-content-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6"><h3 class="mb-0"><?= esc($title ?? '') ?></h3></div>
                </div>
            </div>
        </div>
        <div class="app-content">
            <div class="container-fluid">
                <?= $this->renderSection('content') ?>
            </div>
        </div>
    </main>

    <!-- ============ FOOTER ============ -->
    <footer class="app-footer">
        <div class="float-end d-none d-sm-inline">Nusantara POS</div>
        <strong>&copy; <?= date('Y') ?> POS Multi Cabang.</strong> All rights reserved.
    </footer>

</div>

<!-- Bootstrap + Popper + AdminLTE (JS) -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/overlayscrollbars@2.11.0/browser/overlayscrollbars.browser.es6.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@4.9.1/dist/js/adminlte.min.js"></script>
<script>
// Tandai link sidebar yang cocok dengan URL saat ini sebagai "active" (AdminLTE mewarnainya otomatis lewat class .active)
(function () {
    const path = window.location.pathname.replace(/\/$/, '');
    document.querySelectorAll('.app-sidebar .nav-link').forEach(function (a) {
        const linkPath = (a.getAttribute('href') || '').replace(/\/$/, '');
        if (linkPath && (path === linkPath || (linkPath !== '<?= site_url() ?>'.replace(/\/$/, '') && path.startsWith(linkPath)))) {
            a.classList.add('active');
        }
    });
})();
</script>
</body>
</html>
