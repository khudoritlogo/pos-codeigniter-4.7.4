<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>
<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger"><ul class="mb-0"><?php foreach (session()->getFlashdata('errors') as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?></ul></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= $reward ? site_url('hadiah-poin/' . $reward['id']) : site_url('hadiah-poin') ?>" method="post">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-8">
                    <label class="form-label">Nama Hadiah</label>
                    <input type="text" name="nama_hadiah" class="form-control" value="<?= old('nama_hadiah', $reward['nama_hadiah'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Poin Dibutuhkan</label>
                    <input type="number" name="poin_dibutuhkan" class="form-control" value="<?= old('poin_dibutuhkan', $reward['poin_dibutuhkan'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Barang Terkait (opsional)</label>
                    <select name="product_id" class="form-select">
                        <option value="">-- Hadiah bebas, tidak terhubung barang master --</option>
                        <?php foreach ($products as $p): ?>
                            <option value="<?= $p['id'] ?>" <?= old('product_id', $reward['product_id'] ?? '') == $p['id'] ? 'selected' : '' ?>><?= esc($p['nama_barang']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text">Kalau dipilih, stok barang otomatis berkurang saat hadiah ditukar.</div>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Stok Hadiah</label>
                    <input type="number" name="stok_hadiah" class="form-control" value="<?= old('stok_hadiah', $reward['stok_hadiah'] ?? 0) ?>">
                </div>
                <div class="col-md-3">
                    <div class="form-check form-switch mt-4">
                        <input type="checkbox" name="status" class="form-check-input" value="1" <?= old('status', $reward['status'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label">Aktif</label>
                    </div>
                </div>
            </div>
            <div class="mt-3">
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="<?= site_url('hadiah-poin') ?>" class="btn btn-outline-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
