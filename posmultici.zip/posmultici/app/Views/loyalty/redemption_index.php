<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Penukaran Poin</h5>
    <a href="<?= site_url('tukar-poin/new') ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Tukar Poin Baru</a>
</div>
<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table id="tblRedeem" class="table table-striped w-100">
            <thead><tr><th>No Penukaran</th><th>Tanggal</th><th>Customer</th><th>Hadiah</th><th class="text-end">Poin Dipakai</th><th>Oleh</th></tr></thead>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function () {
    $('#tblRedeem').DataTable({
        ajax: { url: '<?= site_url('tukar-poin/data') ?>', dataSrc: 'data' },
        order: [[1, 'desc']],
        columns: [
            { data: 'no_penukaran' },
            { data: 'tanggal', render: v => new Date(v).toLocaleString('id-ID') },
            { data: 'nama_customer' },
            { data: 'nama_hadiah' },
            { data: 'poin_dipakai', className: 'text-end' },
            { data: 'nama_user' }
        ],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/id.json' }
    });
});
</script>
<?= $this->endSection() ?>
