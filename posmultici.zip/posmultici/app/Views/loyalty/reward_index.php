<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Katalog Hadiah Poin</h5>
    <a href="<?= site_url('hadiah-poin/new') ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Tambah Hadiah</a>
</div>
<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table id="tblReward" class="table table-striped w-100">
            <thead><tr><th>Nama Hadiah</th><th>Barang Terkait</th><th class="text-end">Poin Dibutuhkan</th><th class="text-end">Stok Hadiah</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function () {
    $('#tblReward').DataTable({
        ajax: { url: '<?= site_url('hadiah-poin/data') ?>', dataSrc: 'data' },
        columns: [
            { data: 'nama_hadiah' },
            { data: 'nama_barang', defaultContent: '-' },
            { data: 'poin_dibutuhkan', className: 'text-end' },
            { data: 'stok_hadiah', className: 'text-end' },
            { data: 'status', render: v => v == 1 ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Nonaktif</span>' },
            {
                data: 'id', orderable: false, className: 'text-end',
                render: id => `
                    <a href="<?= site_url('hadiah-poin') ?>/${id}/edit" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                    <form action="<?= site_url('hadiah-poin') ?>/${id}/delete" method="post" class="d-inline" onsubmit="return confirm('Hapus hadiah ini?');">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                    </form>`
            }
        ],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/id.json' }
    });
});
</script>
<?= $this->endSection() ?>
