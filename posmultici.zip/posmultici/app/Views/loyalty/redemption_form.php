<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<form action="<?= site_url('tukar-poin') ?>" method="post" id="formTukar">
    <?= csrf_field() ?>
    <input type="hidden" name="customer_id" id="customerId" required>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body">
            <label class="form-label">Cari Customer</label>
            <input type="text" id="searchBox" class="form-control" placeholder="Cari nama/kode customer...">
            <div id="searchResults" class="list-group mt-2"></div>
            <div id="customerInfo" class="alert alert-info mt-3 d-none"></div>
        </div>
    </div>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-header bg-white fw-semibold">Pilih Hadiah</div>
        <div class="card-body">
            <?php if (empty($rewards)): ?>
                <p class="text-muted mb-0">Belum ada hadiah aktif dengan stok tersedia.</p>
            <?php else: ?>
                <div class="row g-3">
                    <?php foreach ($rewards as $r): ?>
                        <div class="col-md-4">
                            <label class="card border-0 shadow-sm p-3 h-100" style="cursor:pointer;">
                                <input type="radio" name="reward_id" value="<?= $r['id'] ?>" class="form-check-input mb-2" required>
                                <div class="fw-semibold"><?= esc($r['nama_hadiah']) ?></div>
                                <div class="text-muted small">Stok: <?= $r['stok_hadiah'] ?></div>
                                <div class="text-primary fw-bold mt-1"><?= number_format($r['poin_dibutuhkan']) ?> Poin</div>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <button type="submit" class="btn btn-primary" id="btnSubmit" disabled>Proses Penukaran</button>
    <a href="<?= site_url('tukar-poin') ?>" class="btn btn-outline-secondary">Batal</a>
</form>

<script>
document.getElementById('searchBox').addEventListener('input', async function () {
    const q = this.value.trim();
    const box = document.getElementById('searchResults');
    if (q.length < 2) { box.innerHTML = ''; return; }
    const res = await fetch(`<?= site_url('tukar-poin/cari-customer') ?>?q=${encodeURIComponent(q)}`);
    const json = await res.json();
    box.innerHTML = '';
    json.data.forEach(c => {
        const a = document.createElement('a');
        a.href = '#';
        a.className = 'list-group-item list-group-item-action';
        a.innerHTML = `${c.nama_customer} <span class="text-muted">(${c.kode_customer})</span> — <strong>${c.poin} poin</strong> ${c.nama_level ? '· ' + c.nama_level : ''}`;
        a.addEventListener('click', (e) => {
            e.preventDefault();
            document.getElementById('customerId').value = c.id;
            document.getElementById('customerInfo').classList.remove('d-none');
            document.getElementById('customerInfo').innerText = `Dipilih: ${c.nama_customer} — saldo poin saat ini: ${c.poin}`;
            document.getElementById('btnSubmit').disabled = false;
            document.getElementById('searchBox').value = '';
            box.innerHTML = '';
        });
        box.appendChild(a);
    });
});
</script>

<?= $this->endSection() ?>
