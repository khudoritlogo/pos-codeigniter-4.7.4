<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm"><div class="card-body">
            <div class="text-muted small">Pengiriman Berjalan</div>
            <div class="fs-4 fw-bold"><?= number_format($pending) ?></div>
        </div></div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm"><div class="card-body">
            <div class="text-muted small">Selesai Hari Ini</div>
            <div class="fs-4 fw-bold"><?= number_format($selesaiHariIni) ?></div>
        </div></div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm"><div class="card-body">
            <div class="text-muted small mb-2">Status Ketersediaan Anda</div>
            <form action="<?= site_url('kurir/status') ?>" method="post" class="d-flex gap-2">
                <?= csrf_field() ?>
                <select name="status_kurir" class="form-select form-select-sm">
                    <option value="free" <?= $statusSaatIni === 'free' ? 'selected' : '' ?>>🟢 Free</option>
                    <option value="sibuk" <?= $statusSaatIni === 'sibuk' ? 'selected' : '' ?>>🟠 Sibuk</option>
                    <option value="off" <?= $statusSaatIni === 'off' ? 'selected' : '' ?>>⚪ Off</option>
                </select>
                <button type="submit" class="btn btn-sm btn-primary">Ubah</button>
            </form>
        </div></div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body text-center py-4">
        <i class="bi bi-truck fs-1 text-primary"></i>
        <p class="mt-2 mb-3">Lihat daftar lengkap pengiriman Anda, hubungi customer via WhatsApp, dan buka lokasi di Google Maps.</p>
        <a href="<?= site_url('kurir/pengiriman') ?>" class="btn btn-primary">Buka Data Pengiriman</a>
    </div>
</div>

<?= $this->endSection() ?>
