<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="row g-3 mb-4">
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <span class="text-muted small">Barang Terjual</span>
                    <span class="d-inline-flex align-items-center justify-content-center rounded-2" style="width:30px;height:30px;background:rgba(201,162,39,.12);">
                        <i class="bi bi-receipt" style="color:var(--gold);"></i>
                    </span>
                </div>
                <div class="fs-4 fw-bold text-end"><?= number_format($total_terjual) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <span class="text-muted small">Jumlah Barang</span>
                    <span class="d-inline-flex align-items-center justify-content-center rounded-2" style="width:30px;height:30px;background:rgba(31,157,107,.12);">
                        <i class="bi bi-boxes" style="color:var(--success);"></i>
                    </span>
                </div>
                <div class="fs-4 fw-bold text-end"><?= number_format($total_barang) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <span class="text-muted small">Customer</span>
                    <span class="d-inline-flex align-items-center justify-content-center rounded-2" style="width:30px;height:30px;background:rgba(27,35,64,.08);">
                        <i class="bi bi-people" style="color:var(--ink);"></i>
                    </span>
                </div>
                <div class="fs-4 fw-bold text-end"><?= number_format($total_customer) ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-2">
                    <span class="text-muted small">Data Invoice</span>
                    <span class="d-inline-flex align-items-center justify-content-center rounded-2" style="width:30px;height:30px;background:rgba(224,167,46,.15);">
                        <i class="bi bi-file-earmark-bar-graph" style="color:var(--warning);"></i>
                    </span>
                </div>
                <div class="fs-4 fw-bold text-end"><?= number_format($total_invoice) ?></div>
            </div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-semibold"><i class="bi bi-trophy" style="color:var(--gold);"></i> Barang Terlaris</div>
            <div class="card-body p-0">
                <table class="table mb-0">
                    <thead><tr><th>Nama Barang</th><th class="text-end">Qty Terjual</th></tr></thead>
                    <tbody>
                    <?php if (empty($barang_terlaris)): ?>
                        <tr><td colspan="2" class="text-center text-muted py-3">Belum ada data</td></tr>
                    <?php else: foreach ($barang_terlaris as $row): ?>
                        <tr>
                            <td><?= esc($row['nama_barang']) ?></td>
                            <td class="text-end"><?= number_format($row['total_qty']) ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-semibold"><i class="bi bi-exclamation-triangle" style="color:var(--danger);"></i> Stok Terkecil</div>
            <div class="card-body p-0">
                <table class="table mb-0">
                    <thead><tr><th>Nama Barang</th><th class="text-end">Stok</th><th class="text-end">Min</th></tr></thead>
                    <tbody>
                    <?php if (empty($stok_terkecil)): ?>
                        <tr><td colspan="3" class="text-center text-muted py-3">Belum ada data</td></tr>
                    <?php else: foreach ($stok_terkecil as $row): ?>
                        <tr>
                            <td><?= esc($row['nama_barang']) ?></td>
                            <td class="text-end"><?= number_format($row['qty']) ?></td>
                            <td class="text-end"><?= number_format($row['stok_minimal']) ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
