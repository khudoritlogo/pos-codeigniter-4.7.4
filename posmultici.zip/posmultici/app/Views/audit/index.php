<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3">Audit Log</h5>
<p class="text-muted small">Mencatat setiap penghapusan item keranjang sebelum struk dicetak, dan setiap pembatalan (void) transaksi yang sudah selesai — beserta siapa yang mengotorisasi. 500 log terbaru ditampilkan.</p>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table id="tblAudit" class="table table-striped w-100">
            <thead><tr><th>Waktu</th><th>Aksi</th><th>Oleh</th><th>Otorisator</th><th>Detail</th></tr></thead>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function () {
    $('#tblAudit').DataTable({
        ajax: { url: '<?= site_url('audit-log/data') ?>', dataSrc: 'data' },
        order: [[0, 'desc']],
        columns: [
            { data: 'created_at', render: v => new Date(v).toLocaleString('id-ID') },
            { data: 'aksi', render: v => {
                const map = { hapus_item_kasir: 'warning', void_transaksi: 'danger', void_ditolak: 'secondary' };
                const label = { hapus_item_kasir: 'Hapus Item Kasir', void_transaksi: 'Void Transaksi', void_ditolak: 'Void Ditolak' };
                return `<span class="badge bg-${map[v] || 'secondary'} ${v==='hapus_item_kasir'?'text-dark':''}">${label[v] || v}</span>`;
            } },
            { data: 'nama_user' },
            { data: 'nama_otorisator', defaultContent: '-' },
            { data: 'detail_text' }
        ],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/id.json' }
    });
});
</script>
<?= $this->endSection() ?>
