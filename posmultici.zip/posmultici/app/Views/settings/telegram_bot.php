<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3">Pengaturan Telegram Bot — Notifikasi Omzet Harian</h5>
<p class="text-muted small">Sistem akan mengirim ringkasan omzet harian otomatis ke Telegram Owner/Super Admin setiap malam (dijadwalkan lewat cron server yang menjalankan <code>php spark kirim:omzet-harian</code>).</p>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="row g-3">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <form action="<?= site_url('pengaturan-telegram-bot') ?>" method="post">
                    <?= csrf_field() ?>
                    <div class="form-check form-switch mb-3">
                        <input type="checkbox" name="enabled" class="form-check-input" value="1" <?= $config['enabled'] ? 'checked' : '' ?>>
                        <label class="form-check-label">Aktifkan Telegram Bot</label>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Bot Token</label>
                        <input type="text" name="bot_token" class="form-control" value="<?= esc($config['bot_token']) ?>" placeholder="123456789:AAExxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Chat ID Owner/Super Admin</label>
                        <input type="text" name="chat_id" class="form-control" value="<?= esc($config['chat_id']) ?>" placeholder="mis. 123456789">
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan Pengaturan</button>
                </form>
                <hr>
                <form action="<?= site_url('pengaturan-telegram-bot/tes-kirim') ?>" method="post" onsubmit="return confirm('Kirim pesan tes ke Chat ID sekarang?');">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-outline-secondary"><i class="bi bi-send"></i> Tes Kirim Sekarang</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-semibold">Cara Mendapatkan Bot Token & Chat ID</div>
            <div class="card-body">
                <ol class="small mb-3">
                    <li>Buka Telegram, cari <strong>@BotFather</strong>, kirim perintah <code>/newbot</code> dan ikuti instruksinya.</li>
                    <li>Setelah bot dibuat, @BotFather akan memberi <strong>Bot Token</strong> (format: <code>123456789:AAE...</code>) — salin ke kolom di samping.</li>
                    <li>Cari bot Anda di Telegram, tekan <strong>Start</strong> supaya bot bisa mengirim pesan ke Anda.</li>
                    <li>Untuk dapat <strong>Chat ID</strong>: cari <strong>@userinfobot</strong> di Telegram, kirim pesan apa saja, bot itu akan membalas dengan Chat ID Anda.</li>
                    <li>Isi Bot Token & Chat ID di form sebelah kiri, aktifkan, lalu klik <strong>Tes Kirim Sekarang</strong> untuk memastikan berhasil.</li>
                </ol>
                <p class="text-muted small mb-0">Berbeda dengan WA Bot (yang butuh gateway pihak ketiga berbayar), Telegram Bot API ini resmi dan gratis dari Telegram — begitu token & chat id benar, pengiriman langsung berfungsi tanpa perlu daftar layanan lain.</p>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
