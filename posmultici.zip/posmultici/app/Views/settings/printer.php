<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3">Pengaturan Printer</h5>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <ul class="mb-0"><?php foreach (session()->getFlashdata('errors') as $error): ?><li><?= esc($error) ?></li><?php endforeach; ?></ul>
    </div>
<?php endif; ?>

<div class="row g-3">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <form action="<?= site_url('pengaturan-printer') ?>" method="post" id="formPrinter">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label">Ukuran Kertas</label>
                        <select name="ukuran_kertas" id="ukuranKertas" class="form-select">
                            <?php $uk = old('ukuran_kertas', $setting['ukuran_kertas']); ?>
                            <option value="58mm" <?= $uk === '58mm' ? 'selected' : '' ?>>58mm (umum untuk printer kasir kecil)</option>
                            <option value="80mm" <?= $uk === '80mm' ? 'selected' : '' ?>>80mm (umum untuk printer kasir besar)</option>
                            <option value="custom" <?= $uk === 'custom' ? 'selected' : '' ?>>Custom</option>
                        </select>
                    </div>
                    <div class="mb-3" id="wrapCustomWidth" style="<?= $uk === 'custom' ? '' : 'display:none' ?>">
                        <label class="form-label">Lebar Custom (mm)</label>
                        <input type="number" name="lebar_custom_mm" class="form-control" value="<?= old('lebar_custom_mm', $setting['lebar_custom_mm'] ?? 58) ?>">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Ukuran Font (px)</label>
                        <input type="number" name="font_size" class="form-control" value="<?= old('font_size', $setting['font_size']) ?>">
                    </div>
                    <div class="mb-3">
                        <div class="form-check form-switch">
                            <input type="checkbox" name="tampilkan_logo" class="form-check-input" value="1" <?= old('tampilkan_logo', $setting['tampilkan_logo']) ? 'checked' : '' ?>>
                            <label class="form-check-label">Tampilkan Logo Toko di Struk</label>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Jumlah Copy Cetak</label>
                        <input type="number" name="jumlah_copy" class="form-control" value="<?= old('jumlah_copy', $setting['jumlah_copy']) ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-semibold">Preview Struk</div>
            <div class="card-body d-flex justify-content-center bg-light">
                <div id="previewReceipt" style="background:#fff; padding:8px; font-family: 'Courier New', monospace; border:1px solid #ddd;">
                    <div style="text-align:center;">
                        <div id="pvLogo" style="font-weight:bold;">[LOGO TOKO]</div>
                        <div style="font-weight:bold;">Nama Toko Anda</div>
                        <div>Jl. Contoh Alamat No. 1</div>
                    </div>
                    <hr style="border-top:1px dashed #000;">
                    <div>1x Contoh Barang A .......... 15.000</div>
                    <div>2x Contoh Barang B .......... 30.000</div>
                    <hr style="border-top:1px dashed #000;">
                    <div style="display:flex; justify-content:space-between;"><span>Total</span><span>45.000</span></div>
                    <hr style="border-top:1px dashed #000;">
                    <div style="text-align:center;">Terima kasih atas kunjungan Anda</div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('ukuranKertas').addEventListener('change', function () {
    document.getElementById('wrapCustomWidth').style.display = this.value === 'custom' ? '' : 'none';
    updatePreview();
});
document.querySelector('[name="font_size"]').addEventListener('input', updatePreview);
document.querySelector('[name="lebar_custom_mm"]')?.addEventListener('input', updatePreview);

function mmToPx(mm) { return mm * 3.78; } // perkiraan px per mm @ 96dpi

function updatePreview() {
    const uk = document.getElementById('ukuranKertas').value;
    const custom = document.querySelector('[name="lebar_custom_mm"]')?.value || 58;
    const widthMm = uk === '80mm' ? 80 : (uk === 'custom' ? custom : 58);
    const fontSize = document.querySelector('[name="font_size"]').value || 12;
    const el = document.getElementById('previewReceipt');
    el.style.width = mmToPx(widthMm) + 'px';
    el.style.fontSize = fontSize + 'px';
    document.getElementById('pvLogo').style.display = document.querySelector('[name="tampilkan_logo"]').checked ? '' : 'none';
}
document.querySelector('[name="tampilkan_logo"]').addEventListener('change', updatePreview);
updatePreview();
</script>

<?= $this->endSection() ?>
