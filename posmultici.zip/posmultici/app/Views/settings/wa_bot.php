<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3">Pengaturan WA Bot — Notifikasi Omzet Harian</h5>
<p class="text-muted small">Sistem akan mengirim ringkasan omzet harian otomatis ke nomor Owner/Super Admin di bawah ini setiap malam (dijadwalkan lewat cron server yang menjalankan <code>php spark kirim:omzet-harian</code>).</p>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm" style="max-width:600px;">
    <div class="card-body">
        <form action="<?= site_url('pengaturan-wa-bot') ?>" method="post">
            <?= csrf_field() ?>
            <div class="form-check form-switch mb-3">
                <input type="checkbox" name="enabled" class="form-check-input" value="1" <?= $config['enabled'] ? 'checked' : '' ?>>
                <label class="form-check-label">Aktifkan WA Bot</label>
            </div>
            <div class="mb-3">
                <label class="form-label">Nomor WhatsApp Owner/Super Admin</label>
                <input type="text" name="nomor_owner" class="form-control" value="<?= esc($config['nomor_owner']) ?>" placeholder="08123456789">
            </div>
            <div class="mb-3">
                <label class="form-label">API Endpoint Gateway WA</label>
                <input type="text" name="api_endpoint" class="form-control" value="<?= esc($config['api_endpoint']) ?>" placeholder="https://api.contoh-gateway-wa.com/send">
                <div class="form-text">Isi dengan endpoint dari provider gateway WA yang dipakai toko (mis. Fonnte, Wablas, atau sejenis).</div>
            </div>
            <div class="mb-3">
                <label class="form-label">API Key</label>
                <input type="text" name="api_key" class="form-control" value="<?= esc($config['api_key']) ?>">
            </div>
            <button type="submit" class="btn btn-primary">Simpan Pengaturan</button>
        </form>
        <hr>
        <form action="<?= site_url('pengaturan-wa-bot/tes-kirim') ?>" method="post" onsubmit="return confirm('Kirim pesan tes ke Nomor Owner sekarang?');">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-outline-secondary"><i class="bi bi-whatsapp"></i> Tes Kirim Sekarang</button>
        </form>
    </div>
</div>

<?= $this->endSection() ?>
