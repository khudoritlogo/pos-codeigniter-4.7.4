<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3">Informasi Toko</h5>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <ul class="mb-0"><?php foreach (session()->getFlashdata('errors') as $error): ?><li><?= esc($error) ?></li><?php endforeach; ?></ul>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= site_url('pengaturan-toko') ?>" method="post">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Nama Toko</label>
                    <input type="text" name="nama_toko" class="form-control" value="<?= old('nama_toko', $setting['nama_toko'] ?? '') ?>" required>
                </div>
                <div class="col-md-3">
                    <label class="form-label">Telepon</label>
                    <input type="text" name="telepon" class="form-control" value="<?= old('telepon', $setting['telepon'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?= old('email', $setting['email'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Alamat</label>
                    <textarea name="alamat" class="form-control" rows="2"><?= old('alamat', $setting['alamat'] ?? '') ?></textarea>
                </div>
                <div class="col-md-3">
                    <label class="form-label">NPWP</label>
                    <input type="text" name="npwp" class="form-control" value="<?= old('npwp', $setting['npwp'] ?? '') ?>">
                </div>
                <div class="col-md-3">
                    <label class="form-label">Footer Struk</label>
                    <input type="text" name="footer_struk" class="form-control" value="<?= old('footer_struk', $setting['footer_struk'] ?? '') ?>" placeholder="Terima kasih atas kunjungan Anda">
                </div>
            </div>
            <div class="mt-3">
                <button type="submit" class="btn btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>

<?= $this->endSection() ?>
