<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Detail Piutang — <?= esc($receivable['no_invoice']) ?></h5>
    <a href="<?= site_url('piutang') ?>" class="btn btn-outline-secondary btn-sm">Kembali</a>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="row g-3">
    <div class="col-md-5">
        <div class="card border-0 shadow-sm mb-3">
            <div class="card-body">
                <table class="table table-sm mb-0">
                    <tr><td class="text-muted">Customer</td><td><?= esc($receivable['nama_customer']) ?></td></tr>
                    <tr><td class="text-muted">Telepon</td><td><?= esc($receivable['telepon'] ?: '-') ?></td></tr>
                    <tr><td class="text-muted">Total Piutang</td><td><?= rupiah($receivable['total_piutang']) ?></td></tr>
                    <tr><td class="text-muted">Sudah Dibayar</td><td><?= rupiah($receivable['total_dibayar']) ?></td></tr>
                    <tr><td class="text-muted">Sisa Piutang</td><td class="fw-bold"><?= rupiah($receivable['sisa_piutang']) ?></td></tr>
                    <tr><td class="text-muted">Jatuh Tempo</td><td><?= esc($receivable['jatuh_tempo']) ?></td></tr>
                    <tr><td class="text-muted">Status</td><td>
                        <?php
                            $map = ['lunas' => 'success', 'cicilan' => 'info', 'belum_lunas' => 'warning', 'menunggak' => 'danger'];
                            $cls = $map[$receivable['status']] ?? 'secondary';
                        ?>
                        <span class="badge bg-<?= $cls ?> <?= $receivable['status'] === 'belum_lunas' ? 'text-dark' : '' ?>"><?= esc(str_replace('_', ' ', $receivable['status'])) ?></span>
                    </td></tr>
                </table>
            </div>
        </div>

        <?php if ($receivable['status'] !== 'lunas'): ?>
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-semibold">Catat Pembayaran Cicilan</div>
            <div class="card-body">
                <form action="<?= site_url('piutang/' . $receivable['id'] . '/bayar') ?>" method="post">
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label class="form-label">Jumlah Bayar</label>
                        <input type="number" step="0.01" name="jumlah_bayar" class="form-control" max="<?= $receivable['sisa_piutang'] ?>" required>
                        <div class="form-text">Maksimal <?= rupiah($receivable['sisa_piutang']) ?></div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Metode Bayar</label>
                        <select name="metode_bayar" class="form-select">
                            <option value="cash">Cash</option>
                            <option value="transfer">Transfer</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Catatan</label>
                        <input type="text" name="catatan" class="form-control">
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Simpan Pembayaran</button>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <div class="col-md-7">
        <div class="card border-0 shadow-sm">
            <div class="card-header bg-white fw-semibold">Riwayat Pembayaran</div>
            <div class="card-body p-0">
                <table class="table mb-0">
                    <thead><tr><th>Tanggal</th><th class="text-end">Jumlah</th><th>Metode</th><th>Catatan</th></tr></thead>
                    <tbody>
                    <?php if (empty($payments)): ?>
                        <tr><td colspan="4" class="text-center text-muted py-4">Belum ada pembayaran cicilan</td></tr>
                    <?php else: foreach ($payments as $p): ?>
                        <tr>
                            <td><?= esc(date('d/m/Y H:i', strtotime($p['tanggal_bayar']))) ?></td>
                            <td class="text-end"><?= rupiah($p['jumlah_bayar']) ?></td>
                            <td><?= esc(ucfirst($p['metode_bayar'])) ?></td>
                            <td><?= esc($p['catatan']) ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
