<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Hutang</h5>
    <div class="btn-group btn-group-sm" role="group">
        <button type="button" class="btn btn-outline-secondary active" id="btnSemua">Semua</button>
        <button type="button" class="btn btn-outline-danger" id="btnMenunggak"><i class="bi bi-exclamation-triangle"></i> Menunggak</button>
    </div>
</div>
<p class="text-muted small">Hutang dibuat otomatis saat transaksi pembelian memakai metode bayar "Hutang". Klik salah satu baris untuk melihat detail & mencatat pembayaran cicilan.</p>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table id="tblHutang" class="table table-striped w-100">
            <thead><tr><th>No Pembelian</th><th>Supplier</th><th class="text-end">Total Hutang</th><th class="text-end">Sisa</th><th>Jatuh Tempo</th><th>Status</th><th></th></tr></thead>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script>
let onlyMenunggak = false;
let table;

function loadTable() {
    const url = '<?= site_url('hutang/data') ?>' + (onlyMenunggak ? '?menunggak=1' : '');
    if (table) { table.ajax.url(url).load(); return; }
    table = $('#tblHutang').DataTable({
        ajax: { url: url, dataSrc: 'data' },
        columns: [
            { data: 'no_pembelian' },
            { data: 'nama_supplier' },
            { data: 'total_hutang', className: 'text-end', render: v => 'Rp ' + Number(v).toLocaleString('id-ID') },
            { data: 'sisa_hutang', className: 'text-end', render: v => 'Rp ' + Number(v).toLocaleString('id-ID') },
            { data: 'jatuh_tempo' },
            { data: 'status', render: v => {
                const map = { lunas: 'success', cicilan: 'info', belum_lunas: 'warning', menunggak: 'danger' };
                return `<span class="badge bg-${map[v] || 'secondary'} ${v==='belum_lunas'?'text-dark':''}">${v.replace('_',' ')}</span>`;
            } },
            { data: 'id', orderable: false, render: id => `<a href="<?= site_url('hutang') ?>/${id}" class="btn btn-sm btn-outline-primary">Detail</a>` }
        ],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/id.json' }
    });
}
$(function () {
    loadTable();
    document.getElementById('btnSemua').addEventListener('click', function () {
        onlyMenunggak = false; this.classList.add('active'); document.getElementById('btnMenunggak').classList.remove('active'); loadTable();
    });
    document.getElementById('btnMenunggak').addEventListener('click', function () {
        onlyMenunggak = true; this.classList.add('active'); document.getElementById('btnSemua').classList.remove('active'); loadTable();
    });
});
</script>
<?= $this->endSection() ?>
