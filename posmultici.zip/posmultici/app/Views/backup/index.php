<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3">Backup & Restore Database</h5>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="row g-3 mb-3">
    <div class="col-md-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h6 class="fw-semibold">Buat Backup Baru</h6>
                <p class="text-muted small">Menyimpan seluruh data (tanpa struktur tabel) ke file .sql yang bisa diunduh dan dipulihkan kapan saja. Otomatis memakai <code>mysqldump</code> jika tersedia di server, atau metode export bawaan PHP jika tidak.</p>
                <form action="<?= site_url('backup-restore/buat') ?>" method="post" onsubmit="return confirm('Buat backup database sekarang?');">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-primary"><i class="bi bi-cloud-download"></i> Buat Backup Sekarang</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card border-0 shadow-sm h-100">
            <div class="card-body">
                <h6 class="fw-semibold text-danger">Restore dari File Upload</h6>
                <p class="text-muted small">⚠️ Restore akan <strong>menimpa data yang ada saat ini</strong> dengan isi file backup. Pastikan Anda benar-benar yakin sebelum melanjutkan — sebaiknya buat backup terbaru dulu sebagai jaga-jaga.</p>
                <form action="<?= site_url('backup-restore/restore-upload') ?>" method="post" enctype="multipart/form-data" onsubmit="return confirm('PERINGATAN: Restore akan menimpa data saat ini dan tidak bisa dibatalkan. Lanjutkan?');">
                    <?= csrf_field() ?>
                    <input type="file" name="backup_file" accept=".sql" class="form-control mb-2" required>
                    <div class="form-check mb-2">
                        <input type="checkbox" name="konfirmasi" value="1" class="form-check-input" id="konfirmasiUpload" required>
                        <label class="form-check-label small" for="konfirmasiUpload">Saya paham risiko dan ingin melanjutkan restore.</label>
                    </div>
                    <button type="submit" class="btn btn-outline-danger w-100">Restore dari File Ini</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white fw-semibold">Riwayat Backup</div>
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>Nama File</th><th>Dibuat</th><th>Ukuran</th><th class="text-end">Aksi</th></tr></thead>
            <tbody>
            <?php if (empty($backups)): ?>
                <tr><td colspan="4" class="text-center text-muted py-4">Belum ada backup yang dibuat</td></tr>
            <?php else: foreach ($backups as $b): ?>
                <tr>
                    <td><?= esc($b['filename']) ?></td>
                    <td><?= esc($b['created']) ?></td>
                    <td><?= number_format($b['size'] / 1024, 1) ?> KB</td>
                    <td class="text-end">
                        <a href="<?= site_url('backup-restore/unduh/' . $b['filename']) ?>" class="btn btn-sm btn-outline-secondary"><i class="bi bi-download"></i> Unduh</a>
                        <button type="button" class="btn btn-sm btn-outline-danger" data-bs-toggle="collapse" data-bs-target="#restore-<?= md5($b['filename']) ?>">Restore</button>
                        <form action="<?= site_url('backup-restore/hapus/' . $b['filename']) ?>" method="post" class="d-inline" onsubmit="return confirm('Hapus file backup ini secara permanen?');">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-sm btn-outline-secondary"><i class="bi bi-trash"></i></button>
                        </form>
                    </td>
                </tr>
                <tr class="collapse" id="restore-<?= md5($b['filename']) ?>">
                    <td colspan="4" class="bg-light">
                        <form action="<?= site_url('backup-restore/restore/' . $b['filename']) ?>" method="post" class="py-2" onsubmit="return confirm('PERINGATAN: Restore akan menimpa data saat ini dan tidak bisa dibatalkan. Lanjutkan?');">
                            <?= csrf_field() ?>
                            <div class="form-check mb-2">
                                <input type="checkbox" name="konfirmasi" value="1" class="form-check-input" id="konfirmasi-<?= md5($b['filename']) ?>" required>
                                <label class="form-check-label small" for="konfirmasi-<?= md5($b['filename']) ?>">Saya paham risiko dan ingin memulihkan database dari <?= esc($b['filename']) ?>.</label>
                            </div>
                            <button type="submit" class="btn btn-sm btn-danger">Konfirmasi Restore dari File Ini</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?= $this->endSection() ?>
