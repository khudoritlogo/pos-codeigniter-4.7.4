<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <ul class="mb-0"><?php foreach (session()->getFlashdata('errors') as $error): ?><li><?= esc($error) ?></li><?php endforeach; ?></ul>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= $user_row ? site_url('user/' . $user_row['id']) : site_url('user') ?>" method="post">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-6">
                    <label class="form-label">Nama Lengkap</label>
                    <input type="text" name="nama" class="form-control" value="<?= old('nama', $user_row['nama'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" value="<?= old('username', $user_row['username'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Password <?= $user_row ? '(kosongkan jika tidak diubah)' : '' ?></label>
                    <input type="password" name="password" class="form-control" <?= $user_row ? '' : 'required' ?> minlength="8">
                </div>
                <div class="col-md-6">
                    <label class="form-label">No. HP</label>
                    <input type="text" name="no_hp" class="form-control" value="<?= old('no_hp', $user_row['no_hp'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?= old('email', $user_row['email'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Role</label>
                    <select name="role_id" class="form-select" required>
                        <option value="">-- Pilih Role --</option>
                        <?php foreach ($roles as $role): ?>
                            <option value="<?= $role['id'] ?>" <?= old('role_id', $user_row['role_id'] ?? '') == $role['id'] ? 'selected' : '' ?>>
                                <?= esc($role['nama_role']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Cabang</label>
                    <select name="branch_id" class="form-select">
                        <option value="">-- Semua Cabang (khusus Super Admin) --</option>
                        <?php foreach ($branches as $branch): ?>
                            <option value="<?= $branch['id'] ?>" <?= old('branch_id', $user_row['branch_id'] ?? '') == $branch['id'] ? 'selected' : '' ?>>
                                <?= esc($branch['nama_cabang']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <div class="form-text">Diabaikan otomatis jika role yang dipilih adalah Super Admin.</div>
                </div>
                <div class="col-md-6">
                    <div class="form-check form-switch mt-4">
                        <input type="checkbox" name="is_active" class="form-check-input" value="1" <?= old('is_active', $user_row['is_active'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label">Aktif</label>
                    </div>
                </div>
            </div>
            <div class="mt-3">
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="<?= site_url('user') ?>" class="btn btn-outline-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
