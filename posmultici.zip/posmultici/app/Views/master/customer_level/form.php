<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>
<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger"><ul class="mb-0"><?php foreach (session()->getFlashdata('errors') as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?></ul></div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= $level ? site_url('level-member/' . $level['id']) : site_url('level-member') ?>" method="post">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Kode Level</label>
                    <input type="text" name="kode_level" class="form-control" value="<?= old('kode_level', $level['kode_level'] ?? '') ?>" required>
                </div>
                <div class="col-md-8">
                    <label class="form-label">Nama Level</label>
                    <input type="text" name="nama_level" class="form-control" value="<?= old('nama_level', $level['nama_level'] ?? '') ?>" placeholder="Regular, Silver, Gold, dst" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Diskon Otomatis (%)</label>
                    <input type="number" step="0.01" name="diskon_persen" class="form-control" value="<?= old('diskon_persen', $level['diskon_persen'] ?? 0) ?>">
                    <div class="form-text">Diterapkan otomatis di transaksi kasir saat customer level ini dipilih.</div>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Minimal Poin untuk Naik ke Level Ini</label>
                    <input type="number" name="min_poin_naik" class="form-control" value="<?= old('min_poin_naik', $level['min_poin_naik'] ?? 0) ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Urutan Tingkatan</label>
                    <input type="number" name="urutan" class="form-control" value="<?= old('urutan', $level['urutan'] ?? 0) ?>">
                    <div class="form-text">Angka lebih besar = level lebih tinggi.</div>
                </div>
            </div>
            <div class="mt-3">
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="<?= site_url('level-member') ?>" class="btn btn-outline-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
