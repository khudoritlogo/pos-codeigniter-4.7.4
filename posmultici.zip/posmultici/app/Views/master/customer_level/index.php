<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Level Member</h5>
    <a href="<?= site_url('level-member/new') ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Tambah Level</a>
</div>
<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table id="tblLevel" class="table table-striped w-100">
            <thead><tr><th>Kode</th><th>Nama Level</th><th class="text-end">Diskon Otomatis</th><th class="text-end">Min. Poin Naik</th><th class="text-end">Aksi</th></tr></thead>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function () {
    $('#tblLevel').DataTable({
        ajax: { url: '<?= site_url('level-member/data') ?>', dataSrc: 'data' },
        order: [[3, 'asc']],
        columns: [
            { data: 'kode_level' },
            { data: 'nama_level' },
            { data: 'diskon_persen', className: 'text-end', render: v => Number(v) + '%' },
            { data: 'min_poin_naik', className: 'text-end' },
            {
                data: 'id', orderable: false, className: 'text-end',
                render: id => `
                    <a href="<?= site_url('level-member') ?>/${id}/edit" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                    <form action="<?= site_url('level-member') ?>/${id}/delete" method="post" class="d-inline" onsubmit="return confirm('Hapus level ini?');">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                    </form>`
            }
        ],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/id.json' }
    });
});
</script>
<?= $this->endSection() ?>
