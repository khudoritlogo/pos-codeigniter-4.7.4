<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <ul class="mb-0"><?php foreach (session()->getFlashdata('errors') as $error): ?><li><?= esc($error) ?></li><?php endforeach; ?></ul>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= $supplier ? site_url('supplier/' . $supplier['id']) : site_url('supplier') ?>" method="post">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Kode Supplier</label>
                    <input type="text" name="kode_supplier" class="form-control" value="<?= old('kode_supplier', $supplier['kode_supplier'] ?? '') ?>" required>
                </div>
                <div class="col-md-8">
                    <label class="form-label">Nama Supplier</label>
                    <input type="text" name="nama_supplier" class="form-control" value="<?= old('nama_supplier', $supplier['nama_supplier'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Penanggung Jawab</label>
                    <input type="text" name="penanggung_jawab" class="form-control" value="<?= old('penanggung_jawab', $supplier['penanggung_jawab'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Telepon</label>
                    <input type="text" name="telepon" class="form-control" value="<?= old('telepon', $supplier['telepon'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?= old('email', $supplier['email'] ?? '') ?>">
                </div>
                <div class="col-md-12">
                    <label class="form-label">Alamat</label>
                    <textarea name="alamat" class="form-control" rows="2"><?= old('alamat', $supplier['alamat'] ?? '') ?></textarea>
                </div>
            </div>
            <div class="mt-3">
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="<?= site_url('supplier') ?>" class="btn btn-outline-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
