<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <ul class="mb-0"><?php foreach (session()->getFlashdata('errors') as $error): ?><li><?= esc($error) ?></li><?php endforeach; ?></ul>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= $branch ? site_url('cabang/' . $branch['id']) : site_url('cabang') ?>" method="post">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Kode Cabang</label>
                    <input type="text" name="kode_cabang" class="form-control" value="<?= old('kode_cabang', $branch['kode_cabang'] ?? '') ?>" required>
                </div>
                <div class="col-md-8">
                    <label class="form-label">Nama Cabang</label>
                    <input type="text" name="nama_cabang" class="form-control" value="<?= old('nama_cabang', $branch['nama_cabang'] ?? '') ?>" required>
                </div>
                <div class="col-md-6">
                    <label class="form-label">Telepon</label>
                    <input type="text" name="telepon" class="form-control" value="<?= old('telepon', $branch['telepon'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?= old('email', $branch['email'] ?? '') ?>">
                </div>
                <div class="col-md-12">
                    <label class="form-label">Alamat</label>
                    <textarea name="alamat" class="form-control" rows="2"><?= old('alamat', $branch['alamat'] ?? '') ?></textarea>
                </div>
                <div class="col-md-6">
                    <div class="form-check form-switch mt-2">
                        <input type="checkbox" name="is_pusat" class="form-check-input" value="1" <?= old('is_pusat', $branch['is_pusat'] ?? 0) ? 'checked' : '' ?>>
                        <label class="form-check-label">Cabang Pusat</label>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-check form-switch mt-2">
                        <input type="checkbox" name="status" class="form-check-input" value="1" <?= old('status', $branch['status'] ?? 1) ? 'checked' : '' ?>>
                        <label class="form-check-label">Aktif</label>
                    </div>
                </div>
            </div>
            <div class="mt-3">
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="<?= site_url('cabang') ?>" class="btn btn-outline-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
