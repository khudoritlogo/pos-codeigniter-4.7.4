<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Customer</h5>
    <a href="<?= site_url('customer/new') ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Tambah Customer</a>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table id="tblCustomer" class="table table-striped w-100">
            <thead><tr><th>Kode</th><th>Nama</th><th>Tipe</th><th>Level</th><th class="text-end">Poin</th><th>Telepon</th><th class="text-end">Limit Piutang</th><th class="text-end">Aksi</th></tr></thead>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function () {
    $('#tblCustomer').DataTable({
        ajax: { url: '<?= site_url('customer/data') ?>', dataSrc: 'data' },
        columns: [
            { data: 'kode_customer' },
            { data: 'nama_customer' },
            { data: 'tipe_customer', render: t => t === 'grosir' ? '<span class="badge bg-info">Grosir</span>' : '<span class="badge bg-secondary">Retail</span>' },
            { data: 'nama_level', defaultContent: '-' },
            { data: 'poin', className: 'text-end', defaultContent: 0 },
            { data: 'telepon', defaultContent: '-' },
            { data: 'limit_piutang', className: 'text-end', render: v => 'Rp ' + Number(v).toLocaleString('id-ID') },
            {
                data: 'id', orderable: false, className: 'text-end',
                render: function (id) {
                    return `
                        <a href="<?= site_url('customer') ?>/${id}/edit" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                        <form action="<?= site_url('customer') ?>/${id}/delete" method="post" class="d-inline" onsubmit="return confirm('Hapus customer ini?');">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                        </form>`;
                }
            }
        ],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/id.json' }
    });
});
</script>
<?= $this->endSection() ?>
