<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <ul class="mb-0"><?php foreach (session()->getFlashdata('errors') as $error): ?><li><?= esc($error) ?></li><?php endforeach; ?></ul>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= $customer ? site_url('customer/' . $customer['id']) : site_url('customer') ?>" method="post">
            <?= csrf_field() ?>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Kode Customer</label>
                    <input type="text" name="kode_customer" class="form-control" value="<?= old('kode_customer', $customer['kode_customer'] ?? '') ?>" required>
                </div>
                <div class="col-md-8">
                    <label class="form-label">Nama Customer</label>
                    <input type="text" name="nama_customer" class="form-control" value="<?= old('nama_customer', $customer['nama_customer'] ?? '') ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Tipe Customer</label>
                    <select name="tipe_customer" class="form-select">
                        <?php $tipe = old('tipe_customer', $customer['tipe_customer'] ?? 'retail'); ?>
                        <option value="retail" <?= $tipe === 'retail' ? 'selected' : '' ?>>Retail</option>
                        <option value="grosir" <?= $tipe === 'grosir' ? 'selected' : '' ?>>Grosir</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Level Member</label>
                    <select name="customer_level_id" class="form-select">
                        <option value="">-- Tidak diset --</option>
                        <?php foreach ($levels as $l): ?>
                            <option value="<?= $l['id'] ?>" <?= old('customer_level_id', $customer['customer_level_id'] ?? '') == $l['id'] ? 'selected' : '' ?>>
                                <?= esc($l['nama_level']) ?> (diskon <?= $l['diskon_persen'] ?>%)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <?php if ($customer): ?><div class="form-text">Poin saat ini: <strong><?= number_format($customer['poin']) ?></strong> (naik level otomatis mengikuti akumulasi poin belanja)</div><?php endif; ?>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Telepon</label>
                    <input type="text" name="telepon" class="form-control" value="<?= old('telepon', $customer['telepon'] ?? '') ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control" value="<?= old('email', $customer['email'] ?? '') ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label">Limit Piutang</label>
                    <input type="number" step="0.01" name="limit_piutang" class="form-control" value="<?= old('limit_piutang', $customer['limit_piutang'] ?? 0) ?>">
                    <div class="form-text">Batas maksimal piutang customer ini (0 = tanpa batas khusus).</div>
                </div>
                <div class="col-md-12">
                    <label class="form-label">Alamat</label>
                    <textarea name="alamat" class="form-control" rows="2"><?= old('alamat', $customer['alamat'] ?? '') ?></textarea>
                </div>
            </div>
            <div class="mt-3">
                <button type="submit" class="btn btn-primary">Simpan</button>
                <a href="<?= site_url('customer') ?>" class="btn btn-outline-secondary">Batal</a>
            </div>
        </form>
    </div>
</div>

<?php if ($customer && ! empty($poinHistory)): ?>
<div class="card border-0 shadow-sm mt-3">
    <div class="card-header bg-white fw-semibold">Riwayat Poin</div>
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>Tanggal</th><th>Tipe</th><th class="text-end">Mutasi</th><th class="text-end">Saldo Sesudah</th><th>Keterangan</th></tr></thead>
            <tbody>
            <?php foreach ($poinHistory as $p): ?>
                <tr>
                    <td><?= esc(date('d/m/Y H:i', strtotime($p['created_at']))) ?></td>
                    <td><?= esc(ucfirst(str_replace('_', ' ', $p['tipe']))) ?></td>
                    <td class="text-end <?= $p['poin_mutasi'] < 0 ? 'text-danger' : 'text-success' ?>"><?= $p['poin_mutasi'] > 0 ? '+' : '' ?><?= $p['poin_mutasi'] ?></td>
                    <td class="text-end"><?= $p['poin_sesudah'] ?></td>
                    <td><?= esc($p['keterangan']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
<?= $this->endSection() ?>
