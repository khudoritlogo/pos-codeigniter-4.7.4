<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <ul class="mb-0"><?php foreach (session()->getFlashdata('errors') as $error): ?><li><?= esc($error) ?></li><?php endforeach; ?></ul>
    </div>
<?php endif; ?>

<form action="<?= $product ? site_url('barang/' . $product['id']) : site_url('barang') ?>" method="post" id="formBarang">
<?= csrf_field() ?>

<div class="card border-0 shadow-sm mb-3">
    <div class="card-header bg-white fw-semibold">Informasi Dasar</div>
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Kode Barang</label>
                <input type="text" name="kode_barang" class="form-control" value="<?= old('kode_barang', $product['kode_barang'] ?? '') ?>" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">Barcode</label>
                <input type="text" name="barcode" class="form-control" value="<?= old('barcode', $product['barcode'] ?? '') ?>" placeholder="Scan / ketik manual">
            </div>
            <div class="col-md-6">
                <label class="form-label">Nama Barang</label>
                <input type="text" name="nama_barang" class="form-control" value="<?= old('nama_barang', $product['nama_barang'] ?? '') ?>" required>
            </div>

            <div class="col-md-3">
                <label class="form-label">Kategori</label>
                <select name="category_id" class="form-select" required>
                    <option value="">-- Pilih --</option>
                    <?php foreach ($categories as $c): ?>
                        <option value="<?= $c['id'] ?>" <?= old('category_id', $product['category_id'] ?? '') == $c['id'] ? 'selected' : '' ?>><?= esc($c['nama_kategori']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Satuan Dasar</label>
                <select name="unit_id" class="form-select" required>
                    <option value="">-- Pilih --</option>
                    <?php foreach ($units as $u): ?>
                        <option value="<?= $u['id'] ?>" <?= old('unit_id', $product['unit_id'] ?? '') == $u['id'] ? 'selected' : '' ?>><?= esc($u['nama_satuan']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Supplier</label>
                <select name="supplier_id" class="form-select">
                    <option value="">-- Tidak diset --</option>
                    <?php foreach ($suppliers as $s): ?>
                        <option value="<?= $s['id'] ?>" <?= old('supplier_id', $product['supplier_id'] ?? '') == $s['id'] ? 'selected' : '' ?>><?= esc($s['nama_supplier']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Jenis Produk</label>
                <select name="jenis_produk" id="jenisProduk" class="form-select" onchange="toggleGaransiField()">
                    <?php $jenis = old('jenis_produk', $product['jenis_produk'] ?? 'non_sn'); ?>
                    <option value="non_sn" <?= $jenis === 'non_sn' ? 'selected' : '' ?>>Non-SN (stok biasa)</option>
                    <option value="sn" <?= $jenis === 'sn' ? 'selected' : '' ?>>SN (per serial number)</option>
                </select>
                <div class="form-text">Produk SN dikelola per unit fisik (mis. IMEI/serial), stok dihitung dari jumlah SN berstatus tersedia.</div>
            </div>
            <div class="col-md-3" id="wrapGaransi" style="<?= $jenis === 'sn' ? '' : 'display:none' ?>">
                <label class="form-label">Lama Garansi (bulan)</label>
                <input type="number" name="garansi_bulan" class="form-control" value="<?= old('garansi_bulan', $product['garansi_bulan'] ?? '') ?>" placeholder="mis. 12">
                <div class="form-text">Dipakai untuk menghitung tanggal berakhir garansi otomatis saat barang ini terjual.</div>
            </div>
            <div class="col-md-3">
                <div class="form-check form-switch mt-4">
                    <input type="checkbox" name="has_expiry" class="form-check-input" value="1" <?= old('has_expiry', $product['has_expiry'] ?? 0) ? 'checked' : '' ?>>
                    <label class="form-check-label">Punya Tanggal Kedaluwarsa</label>
                </div>
                <div class="form-text">Kalau dicentang, setiap pembelian barang ini wajib isi nomor batch & tanggal expired (untuk FEFO & peringatan dini).</div>
            </div>

            <div class="col-md-3">
                <label class="form-label">Harga Beli (Modal)</label>
                <input type="number" step="0.01" name="harga_beli" id="hargaBeli" class="form-control" value="<?= old('harga_beli', $product['harga_beli'] ?? 0) ?>" oninput="hitungLaba()" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">Harga Jual Retail</label>
                <input type="number" step="0.01" name="harga_jual" id="hargaJual" class="form-control" value="<?= old('harga_jual', $product['harga_jual'] ?? 0) ?>" oninput="hitungLaba()" required>
            </div>
            <div class="col-md-3">
                <label class="form-label">Harga Jual Grosir</label>
                <input type="number" step="0.01" name="harga_grosir" id="hargaGrosir" class="form-control" value="<?= old('harga_grosir', $product['harga_grosir'] ?? 0) ?>" oninput="hitungLaba()">
            </div>
            <div class="col-md-3">
                <label class="form-label">Estimasi Laba</label>
                <div class="border rounded-2 p-2 bg-light">
                    <div class="d-flex justify-content-between small">
                        <span class="text-muted">Retail:</span>
                        <strong id="labaRetail">Rp 0 (0%)</strong>
                    </div>
                    <div class="d-flex justify-content-between small">
                        <span class="text-muted">Grosir:</span>
                        <strong id="labaGrosir">Rp 0 (0%)</strong>
                    </div>
                </div>
                <div class="form-text">Dihitung otomatis: Harga Jual &minus; Harga Beli.</div>
            </div>
            <div class="col-md-3">
                <label class="form-label">Stok Minimal</label>
                <input type="number" name="stok_minimal" class="form-control" value="<?= old('stok_minimal', $product['stok_minimal'] ?? 0) ?>">
                <div class="form-text">Dipakai untuk peringatan di laporan stok terkecil.</div>
            </div>

            <div class="col-md-3">
                <div class="form-check form-switch mt-4">
                    <input type="checkbox" name="status" class="form-check-input" value="1" <?= old('status', $product['status'] ?? 1) ? 'checked' : '' ?>>
                    <label class="form-check-label">Aktif</label>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="card border-0 shadow-sm mb-3">
    <div class="card-header bg-white fw-semibold d-flex justify-content-between align-items-center">
        Multi Satuan
        <button type="button" class="btn btn-sm btn-outline-primary" id="btnAddUnit"><i class="bi bi-plus-lg"></i> Tambah Baris</button>
    </div>
    <div class="card-body">
        <p class="text-muted small">Tambahkan satuan turunan lain untuk barang ini, mis. 1 Box = 12 Pcs. Satuan dasar sudah otomatis berlaku tanpa perlu ditambahkan di sini.</p>
        <table class="table table-sm" id="tblUnits">
            <thead><tr><th>Satuan</th><th>Konversi ke Satuan Dasar</th><th>Harga Jual Retail</th><th>Harga Jual Grosir</th><th>Default?</th><th></th></tr></thead>
            <tbody></tbody>
        </table>
    </div>
</div>

<div class="card border-0 shadow-sm mb-3">
    <div class="card-header bg-white fw-semibold d-flex justify-content-between align-items-center">
        Harga Bertingkat / Dinamis
        <button type="button" class="btn btn-sm btn-outline-primary" id="btnAddPrice"><i class="bi bi-plus-lg"></i> Tambah Baris</button>
    </div>
    <div class="card-body">
        <p class="text-muted small">Contoh: beli minimal 12 Pcs harga jadi lebih murah, atau harga khusus untuk tipe customer tertentu.</p>
        <table class="table table-sm" id="tblPrices">
            <thead><tr><th>Satuan</th><th>Qty Minimal</th><th>Harga</th><th>Berlaku Untuk</th><th></th></tr></thead>
            <tbody></tbody>
        </table>
    </div>
</div>

<?php if (! empty($stocks)): ?>
<div class="card border-0 shadow-sm mb-3">
    <div class="card-header bg-white fw-semibold">Stok per Cabang</div>
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>Cabang</th><th class="text-end">Stok (satuan dasar)</th></tr></thead>
            <tbody>
            <?php foreach ($stocks as $s): ?>
                <tr><td><?= esc($s['nama_cabang']) ?></td><td class="text-end"><?= number_format($s['qty']) ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer text-muted small bg-white">
        Stok diubah melalui transaksi pembelian, penjualan, transfer stok, atau stock opname — bukan diedit manual di sini.
    </div>
</div>
<?php endif; ?>

<button type="submit" class="btn btn-primary">Simpan</button>
<a href="<?= site_url('barang') ?>" class="btn btn-outline-secondary">Batal</a>
</form>

<template id="unitRowTemplate">
    <tr>
        <td>
            <select name="units_unit_id[]" class="form-select form-select-sm">
                <option value="">-- Pilih --</option>
                <?php foreach ($units as $u): ?><option value="<?= $u['id'] ?>"><?= esc($u['nama_satuan']) ?></option><?php endforeach; ?>
            </select>
        </td>
        <td><input type="number" step="0.0001" name="units_konversi[]" class="form-control form-control-sm" value="1"></td>
        <td><input type="number" step="0.01" name="units_harga_jual[]" class="form-control form-control-sm" value="0"></td>
        <td><input type="number" step="0.01" name="units_harga_grosir[]" class="form-control form-control-sm" value="0"></td>
        <td class="text-center"><input type="checkbox" name="units_default[]" class="form-check-input row-index" value=""></td>
        <td><button type="button" class="btn btn-sm btn-outline-danger btn-remove-row"><i class="bi bi-x-lg"></i></button></td>
    </tr>
</template>

<template id="priceRowTemplate">
    <tr>
        <td>
            <select name="prices_unit_id[]" class="form-select form-select-sm">
                <option value="">-- Pilih --</option>
                <?php foreach ($units as $u): ?><option value="<?= $u['id'] ?>"><?= esc($u['nama_satuan']) ?></option><?php endforeach; ?>
            </select>
        </td>
        <td><input type="number" step="0.01" name="prices_min_qty[]" class="form-control form-control-sm" value="1"></td>
        <td><input type="number" step="0.01" name="prices_harga[]" class="form-control form-control-sm" value="0"></td>
        <td>
            <select name="prices_tipe[]" class="form-select form-select-sm">
                <option value="semua">Semua</option>
                <option value="retail">Retail</option>
                <option value="grosir">Grosir</option>
            </select>
        </td>
        <td><button type="button" class="btn btn-sm btn-outline-danger btn-remove-row"><i class="bi bi-x-lg"></i></button></td>
    </tr>
</template>

<script>
// Data existing dikirim dari controller (mode edit) supaya baris multi satuan/harga terisi otomatis
const existingUnits  = <?= json_encode($units_used ?? []) ?>;
const existingPrices = <?= json_encode($prices ?? []) ?>;

function addUnitRow(data) {
    const tpl = document.getElementById('unitRowTemplate').content.cloneNode(true);
    const tr = tpl.querySelector('tr');
    if (data) {
        tr.querySelector('[name="units_unit_id[]"]').value = data.unit_id;
        tr.querySelector('[name="units_konversi[]"]').value = data.konversi;
        tr.querySelector('[name="units_harga_jual[]"]').value = data.harga_jual;
        tr.querySelector('[name="units_harga_grosir[]"]').value = data.harga_grosir;
        tr.querySelector('.row-index').checked = data.is_default == 1;
    }
    tr.querySelector('.btn-remove-row').addEventListener('click', e => e.target.closest('tr').remove());
    document.querySelector('#tblUnits tbody').appendChild(tr);
}

function addPriceRow(data) {
    const tpl = document.getElementById('priceRowTemplate').content.cloneNode(true);
    const tr = tpl.querySelector('tr');
    if (data) {
        tr.querySelector('[name="prices_unit_id[]"]').value = data.unit_id;
        tr.querySelector('[name="prices_min_qty[]"]').value = data.min_qty;
        tr.querySelector('[name="prices_harga[]"]').value = data.harga;
        tr.querySelector('[name="prices_tipe[]"]').value = data.tipe_customer;
    }
    tr.querySelector('.btn-remove-row').addEventListener('click', e => e.target.closest('tr').remove());
    document.querySelector('#tblPrices tbody').appendChild(tr);
}

document.getElementById('btnAddUnit').addEventListener('click', () => addUnitRow(null));
document.getElementById('btnAddPrice').addEventListener('click', () => addPriceRow(null));

existingUnits.forEach(addUnitRow);
existingPrices.forEach(addPriceRow);

function toggleGaransiField() {
    document.getElementById('wrapGaransi').style.display = document.getElementById('jenisProduk').value === 'sn' ? '' : 'none';
}

function rupiahJs(n) { return 'Rp ' + Number(n || 0).toLocaleString('id-ID'); }

/** Hitung & tampilkan estimasi laba (Rp dan %) secara real-time saat harga beli/jual diubah */
function hitungLaba() {
    const beli = parseFloat(document.getElementById('hargaBeli').value) || 0;
    const retail = parseFloat(document.getElementById('hargaJual').value) || 0;
    const grosir = parseFloat(document.getElementById('hargaGrosir').value) || 0;

    const labaRetail = retail - beli;
    const persenRetail = beli > 0 ? (labaRetail / beli * 100) : 0;
    const elRetail = document.getElementById('labaRetail');
    elRetail.innerText = `${rupiahJs(labaRetail)} (${persenRetail.toFixed(1)}%)`;
    elRetail.className = labaRetail < 0 ? 'text-danger' : 'text-success';

    const labaGrosir = grosir > 0 ? grosir - beli : 0;
    const persenGrosir = (beli > 0 && grosir > 0) ? (labaGrosir / beli * 100) : 0;
    const elGrosir = document.getElementById('labaGrosir');
    elGrosir.innerText = grosir > 0 ? `${rupiahJs(labaGrosir)} (${persenGrosir.toFixed(1)}%)` : '-';
    elGrosir.className = labaGrosir < 0 ? 'text-danger' : 'text-success';
}
hitungLaba(); // hitung langsung saat halaman dimuat (penting untuk mode edit barang)

// Set value checkbox "default" ke index barisnya masing-masing tepat sebelum submit,
// supaya backend bisa tahu baris ke berapa yang ditandai sebagai satuan default.
document.getElementById('formBarang').addEventListener('submit', function () {
    document.querySelectorAll('#tblUnits tbody tr').forEach((tr, idx) => {
        const cb = tr.querySelector('.row-index');
        cb.value = idx;
    });
});
</script>

<?= $this->endSection() ?>
