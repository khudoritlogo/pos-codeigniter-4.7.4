<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Data Barang</h5>
    <div>
        <a href="<?= site_url('barcode/cetak') ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-upc-scan"></i> Cetak Barcode</a>
        <a href="<?= site_url('barang/new') ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Tambah Barang</a>
    </div>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table id="tblBarang" class="table table-striped w-100">
            <thead><tr><th>Kode</th><th>Nama Barang</th><th>Kategori</th><th>Satuan</th><th>Jenis</th><th class="text-end">Harga Beli</th><th class="text-end">Harga Jual</th><th class="text-end">Laba</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function () {
    $('#tblBarang').DataTable({
        ajax: { url: '<?= site_url('barang/data') ?>', dataSrc: 'data' },
        columns: [
            { data: 'kode_barang' },
            { data: 'nama_barang' },
            { data: 'nama_kategori' },
            { data: 'nama_satuan' },
            { data: 'jenis_produk', render: v => v === 'sn' ? '<span class="badge bg-warning text-dark">SN</span>' : '<span class="badge bg-light text-dark border">Non-SN</span>' },
            { data: 'harga_beli', className: 'text-end', render: v => 'Rp ' + Number(v).toLocaleString('id-ID') },
            { data: 'harga_jual', className: 'text-end', render: v => 'Rp ' + Number(v).toLocaleString('id-ID') },
            {
                data: null, orderable: false, className: 'text-end',
                render: function (row) {
                    const beli = Number(row.harga_beli), jual = Number(row.harga_jual);
                    const laba = jual - beli;
                    const persen = beli > 0 ? (laba / beli * 100) : 0;
                    const cls = laba < 0 ? 'text-danger' : 'text-success';
                    return `<span class="${cls}">Rp ${laba.toLocaleString('id-ID')} <small>(${persen.toFixed(1)}%)</small></span>`;
                }
            },
            { data: 'status', render: v => v == 1 ? '<span class="badge bg-success">Aktif</span>' : '<span class="badge bg-secondary">Nonaktif</span>' },
            {
                data: 'id', orderable: false, className: 'text-end',
                render: function (id) {
                    return `
                        <a href="<?= site_url('barang') ?>/${id}/edit" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                        <form action="<?= site_url('barang') ?>/${id}/delete" method="post" class="d-inline" onsubmit="return confirm('Hapus barang ini?');">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                        </form>`;
                }
            }
        ],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/id.json' }
    });
});
</script>
<?= $this->endSection() ?>
