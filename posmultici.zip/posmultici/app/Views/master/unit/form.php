<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <ul class="mb-0"><?php foreach (session()->getFlashdata('errors') as $error): ?><li><?= esc($error) ?></li><?php endforeach; ?></ul>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= $unit ? site_url('satuan/' . $unit['id']) : site_url('satuan') ?>" method="post">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label class="form-label">Nama Satuan</label>
                <input type="text" name="nama_satuan" class="form-control" value="<?= old('nama_satuan', $unit['nama_satuan'] ?? '') ?>" placeholder="Pcs, Box, Karton, dll" required>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="<?= site_url('satuan') ?>" class="btn btn-outline-secondary">Batal</a>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
