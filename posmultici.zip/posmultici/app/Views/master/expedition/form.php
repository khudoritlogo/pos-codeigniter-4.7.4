<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>

<?php if (session()->getFlashdata('errors')): ?>
    <div class="alert alert-danger">
        <ul class="mb-0"><?php foreach (session()->getFlashdata('errors') as $error): ?><li><?= esc($error) ?></li><?php endforeach; ?></ul>
    </div>
<?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <form action="<?= $expedition ? site_url('ekspedisi/' . $expedition['id']) : site_url('ekspedisi') ?>" method="post">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label class="form-label">Nama Ekspedisi</label>
                <input type="text" name="nama_ekspedisi" class="form-control" value="<?= old('nama_ekspedisi', $expedition['nama_ekspedisi'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Telepon</label>
                <input type="text" name="telepon" class="form-control" value="<?= old('telepon', $expedition['telepon'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label">Keterangan</label>
                <textarea name="keterangan" class="form-control" rows="2"><?= old('keterangan', $expedition['keterangan'] ?? '') ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="<?= site_url('ekspedisi') ?>" class="btn btn-outline-secondary">Batal</a>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
