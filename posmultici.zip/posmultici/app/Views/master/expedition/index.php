<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Ekspedisi</h5>
    <a href="<?= site_url('ekspedisi/new') ?>" class="btn btn-primary btn-sm"><i class="bi bi-plus-lg"></i> Tambah Ekspedisi</a>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table id="tblEkspedisi" class="table table-striped w-100">
            <thead><tr><th>Nama Ekspedisi</th><th>Telepon</th><th>Keterangan</th><th class="text-end">Aksi</th></tr></thead>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script>
$(function () {
    $('#tblEkspedisi').DataTable({
        ajax: { url: '<?= site_url('ekspedisi/data') ?>', dataSrc: 'data' },
        columns: [
            { data: 'nama_ekspedisi' },
            { data: 'telepon', defaultContent: '-' },
            { data: 'keterangan', defaultContent: '-' },
            {
                data: 'id', orderable: false, className: 'text-end',
                render: function (id) {
                    return `
                        <a href="<?= site_url('ekspedisi') ?>/${id}/edit" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
                        <form action="<?= site_url('ekspedisi') ?>/${id}/delete" method="post" class="d-inline" onsubmit="return confirm('Hapus ekspedisi ini?');">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button>
                        </form>`;
                }
            }
        ],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/id.json' }
    });
});
</script>
<?= $this->endSection() ?>
