<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h5 class="mb-0">Detail Transfer — <?= esc($transfer['no_transfer']) ?> <span class="badge bg-secondary"><?= esc($transfer['status']) ?></span></h5>
    <a href="<?= site_url('transfer-stok') ?>" class="btn btn-outline-secondary btn-sm">Kembali</a>
</div>

<?php if (session()->getFlashdata('success')): ?><div class="alert alert-success"><?= esc(session()->getFlashdata('success')) ?></div><?php endif; ?>
<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm mb-3">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>Barang</th><th>Satuan</th><th class="text-end">Qty</th></tr></thead>
            <tbody>
            <?php foreach ($items as $it): ?>
                <tr><td><?= esc($it['nama_barang']) ?></td><td><?= esc($it['nama_satuan']) ?></td><td class="text-end"><?= number_format($it['qty']) ?></td></tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="d-flex gap-2">
    <?php if ($transfer['status'] === 'diajukan'): ?>
        <form action="<?= site_url('transfer-stok/' . $transfer['id'] . '/kirim') ?>" method="post" onsubmit="return confirm('Tandai barang sudah dikirim? Stok cabang asal akan langsung berkurang.');">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-primary">Tandai Dikirim</button>
        </form>
    <?php endif; ?>
    <?php if ($transfer['status'] === 'dikirim'): ?>
        <form action="<?= site_url('transfer-stok/' . $transfer['id'] . '/terima') ?>" method="post" onsubmit="return confirm('Konfirmasi barang sudah diterima? Stok cabang tujuan akan langsung bertambah.');">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-success">Konfirmasi Diterima</button>
        </form>
    <?php endif; ?>
    <?php if (in_array($transfer['status'], ['diajukan', 'dikirim'])): ?>
        <form action="<?= site_url('transfer-stok/' . $transfer['id'] . '/batal') ?>" method="post" onsubmit="return confirm('Batalkan transfer ini?');">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-outline-danger">Batalkan</button>
        </form>
    <?php endif; ?>
</div>

<?= $this->endSection() ?>
