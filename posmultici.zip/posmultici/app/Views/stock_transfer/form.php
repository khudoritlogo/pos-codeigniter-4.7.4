<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>

<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<form action="<?= site_url('transfer-stok') ?>" method="post">
    <?= csrf_field() ?>
    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body row g-3">
            <div class="col-md-6">
                <label class="form-label">Cabang Tujuan</label>
                <select name="branch_to_id" class="form-select" required>
                    <option value="">-- Pilih Cabang Tujuan --</option>
                    <?php foreach ($branches as $b): ?>
                        <option value="<?= $b['id'] ?>"><?= esc($b['nama_cabang']) ?></option>
                    <?php endforeach; ?>
                </select>
                <div class="form-text">Cabang asal otomatis mengikuti cabang Anda saat ini.</div>
            </div>
            <div class="col-md-6">
                <label class="form-label">Catatan</label>
                <input type="text" name="catatan" class="form-control">
            </div>
        </div>
    </div>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-header bg-white fw-semibold d-flex justify-content-between align-items-center">
            Barang yang Ditransfer
            <button type="button" class="btn btn-sm btn-outline-primary" id="btnAddItem"><i class="bi bi-plus-lg"></i> Tambah Baris</button>
        </div>
        <div class="card-body">
            <p class="text-muted small">Hanya barang non-SN yang bisa ditransfer lewat form ini. Stok cabang asal baru berkurang saat status ditandai "Dikirim".</p>
            <table class="table table-sm" id="tblItems">
                <thead><tr><th>Barang</th><th class="text-end">Qty</th><th></th></tr></thead>
                <tbody></tbody>
            </table>
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Ajukan Transfer</button>
    <a href="<?= site_url('transfer-stok') ?>" class="btn btn-outline-secondary">Batal</a>
</form>

<template id="itemRowTemplate">
    <tr>
        <td>
            <select name="product_id[]" class="form-select form-select-sm">
                <option value="">-- Pilih Barang --</option>
                <?php foreach ($products as $p): ?><option value="<?= $p['id'] ?>"><?= esc($p['nama_barang']) ?> (<?= esc($p['kode_barang']) ?>)</option><?php endforeach; ?>
            </select>
        </td>
        <td><input type="number" step="0.01" name="qty[]" class="form-control form-control-sm" value="1"></td>
        <td><button type="button" class="btn btn-sm btn-outline-danger btn-remove-row"><i class="bi bi-x-lg"></i></button></td>
    </tr>
</template>

<script>
function addItemRow() {
    const tpl = document.getElementById('itemRowTemplate').content.cloneNode(true);
    const tr = tpl.querySelector('tr');
    tr.querySelector('.btn-remove-row').addEventListener('click', e => e.target.closest('tr').remove());
    document.querySelector('#tblItems tbody').appendChild(tr);
}
document.getElementById('btnAddItem').addEventListener('click', addItemRow);
addItemRow();
</script>

<?= $this->endSection() ?>
