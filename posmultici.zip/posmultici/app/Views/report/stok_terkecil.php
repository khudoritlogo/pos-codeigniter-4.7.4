<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h5 class="mb-3"><?= esc($title) ?></h5>
<?= $this->include('report/_filter') ?>
<?= $this->include('report/_export') ?>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>Kode</th><th>Nama Barang</th><th>Cabang</th><th class="text-end">Stok Saat Ini</th><th class="text-end">Stok Minimal</th></tr></thead>
            <tbody>
            <?php if (empty($rows)): ?>
                <tr><td colspan="5" class="text-center text-muted py-4">Tidak ada barang dengan stok di bawah/sama dengan minimal</td></tr>
            <?php else: foreach ($rows as $r): ?>
                <tr class="table-danger">
                    <td><?= esc($r['kode_barang']) ?></td>
                    <td><?= esc($r['nama_barang']) ?></td>
                    <td><?= esc($r['nama_cabang']) ?></td>
                    <td class="text-end"><?= number_format($r['qty']) ?></td>
                    <td class="text-end"><?= number_format($r['stok_minimal']) ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>
