<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h5 class="mb-3"><?= esc($title) ?> <span class="badge bg-info text-dark">DataTable Server-Side</span></h5>
<?= $this->include('report/_filter') ?>

<div class="mb-3">
    <a href="#" id="btnExportCsv" class="btn btn-outline-success btn-sm"><i class="bi bi-filetype-csv"></i> Export CSV</a>
    <a href="#" id="btnExportTxt" class="btn btn-outline-secondary btn-sm"><i class="bi bi-filetype-txt"></i> Export TXT</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
        <table id="tblPenjualanPeriode" class="table table-striped w-100">
            <thead><tr><th>No Invoice</th><th>Tanggal</th><th>Cabang</th><th>Customer</th><th>Kasir</th><th class="text-end">Grand Total</th><th>Metode Bayar</th><th>Status</th></tr></thead>
        </table>
    </div>
</div>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/css/dataTables.bootstrap5.min.css">
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net@2.1.8/js/dataTables.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/datatables.net-bs5@2.1.8/js/dataTables.bootstrap5.min.js"></script>
<script>
// Beda dengan tabel-tabel lain di aplikasi ini (yang memuat semua data sekaligus / client-side),
// tabel ini memakai serverSide:true -- setiap ganti halaman/urutan/pencarian mengirim request baru
// ke server dan hanya baris yang perlu ditampilkan yang diambil dari database. Cocok untuk data
// transaksi yang jumlahnya bisa sangat besar dari waktu ke waktu.
const baseParams = new URLSearchParams(window.location.search);
baseParams.delete('format');

$(function () {
    $('#tblPenjualanPeriode').DataTable({
        serverSide: true,
        processing: true,
        ajax: {
            url: '<?= site_url('laporan/penjualan-periode/data') ?>?' + baseParams.toString(),
            dataSrc: 'data'
        },
        columns: [
            { data: 'no_invoice' },
            { data: 'tanggal', render: v => new Date(v).toLocaleString('id-ID') },
            { data: 'nama_cabang' },
            { data: 'nama_customer' },
            { data: 'nama_kasir' },
            { data: 'grand_total', className: 'text-end', render: v => 'Rp ' + Number(v).toLocaleString('id-ID') },
            { data: 'metode_bayar', render: v => v.charAt(0).toUpperCase() + v.slice(1) },
            { data: 'status_transaksi' }
        ],
        language: { url: 'https://cdn.datatables.net/plug-ins/2.1.8/i18n/id.json' }
    });

    const exportUrl = '<?= site_url('laporan/penjualan-periode/export') ?>?' + baseParams.toString();
    document.getElementById('btnExportCsv').href = exportUrl + '&format=csv';
    document.getElementById('btnExportTxt').href = exportUrl + '&format=txt';
});
</script>
<?= $this->endSection() ?>
