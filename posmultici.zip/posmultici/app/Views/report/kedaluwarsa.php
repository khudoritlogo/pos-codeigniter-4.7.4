<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h5 class="mb-3"><?= esc($title) ?></h5>

<div class="card border-0 shadow-sm mb-3">
    <div class="card-body">
        <form method="get" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Peringatan dalam (hari)</label>
                <input type="number" name="hari" class="form-control" value="<?= esc($hariMendatang) ?>">
            </div>
            <?php if (! empty($branches)): ?>
            <div class="col-md-3">
                <label class="form-label">Cabang</label>
                <select name="branch_id" class="form-select">
                    <option value="">Semua Cabang</option>
                    <?php foreach ($branches as $b): ?>
                        <option value="<?= $b['id'] ?>" <?= (string) $branchId === (string) $b['id'] ? 'selected' : '' ?>><?= esc($b['nama_cabang']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            <div class="col-md-3"><button type="submit" class="btn btn-primary"><i class="bi bi-funnel"></i> Terapkan</button></div>
        </form>
    </div>
</div>
<?= $this->include('report/_export') ?>

<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>Kode</th><th>Nama Barang</th><th>Cabang</th><th>No Batch</th><th>Tgl Kedaluwarsa</th><th class="text-end">Qty Sisa</th><th class="text-end">Sisa Hari</th></tr></thead>
            <tbody>
            <?php if (empty($rows)): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">Tidak ada barang yang mendekati kedaluwarsa dalam rentang ini</td></tr>
            <?php else: foreach ($rows as $r): ?>
                <tr class="<?= $r['sisa_hari'] < 0 ? 'table-danger' : ($r['sisa_hari'] <= 7 ? 'table-warning' : '') ?>">
                    <td><?= esc($r['kode_barang']) ?></td>
                    <td><?= esc($r['nama_barang']) ?></td>
                    <td><?= esc($r['nama_cabang']) ?></td>
                    <td><?= esc($r['no_batch']) ?></td>
                    <td><?= esc($r['tanggal_kedaluwarsa']) ?></td>
                    <td class="text-end"><?= number_format($r['qty_sisa']) ?></td>
                    <td class="text-end"><?= $r['sisa_hari'] < 0 ? 'Sudah lewat ' . abs($r['sisa_hari']) . ' hari' : $r['sisa_hari'] . ' hari lagi' ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>
