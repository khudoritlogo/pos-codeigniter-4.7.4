<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h5 class="mb-3"><?= esc($title) ?></h5>
<?= $this->include('report/_filter') ?>
<?= $this->include('report/_export') ?>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>No Pembelian</th><th>Tanggal</th><th>Cabang</th><th>Supplier</th><th>Oleh</th><th class="text-end">Grand Total</th><th>Bayar</th><th>Status</th></tr></thead>
            <tbody>
            <?php if (empty($rows)): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">Tidak ada data pada periode ini</td></tr>
            <?php else: foreach ($rows as $r): ?>
                <tr>
                    <td><?= esc($r['no_pembelian']) ?></td>
                    <td><?= esc(date('d/m/Y', strtotime($r['tanggal']))) ?></td>
                    <td><?= esc($r['nama_cabang']) ?></td>
                    <td><?= esc($r['nama_supplier']) ?></td>
                    <td><?= esc($r['nama_user']) ?></td>
                    <td class="text-end"><?= rupiah($r['grand_total']) ?></td>
                    <td><?= esc(ucfirst($r['metode_bayar'])) ?></td>
                    <td><?= esc(str_replace('_',' ', ucfirst($r['status_bayar']))) ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>
