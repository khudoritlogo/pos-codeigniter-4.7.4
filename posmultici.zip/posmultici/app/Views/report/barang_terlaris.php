<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h5 class="mb-3"><?= esc($title) ?></h5>
<?= $this->include('report/_filter') ?>
<?= $this->include('report/_export') ?>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>#</th><th>Kode</th><th>Nama Barang</th><th class="text-end">Qty Terjual</th><th class="text-end">Total Nilai</th></tr></thead>
            <tbody>
            <?php if (empty($rows)): ?>
                <tr><td colspan="5" class="text-center text-muted py-4">Tidak ada data pada periode ini</td></tr>
            <?php else: foreach ($rows as $i => $r): ?>
                <tr>
                    <td><?= $i + 1 ?></td>
                    <td><?= esc($r['kode_barang']) ?></td>
                    <td><?= esc($r['nama_barang']) ?></td>
                    <td class="text-end"><?= number_format($r['total_qty']) ?></td>
                    <td class="text-end"><?= rupiah($r['total_nilai']) ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>
