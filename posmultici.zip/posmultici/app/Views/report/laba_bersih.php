<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h5 class="mb-3"><?= esc($title) ?></h5>
<?= $this->include('report/_filter') ?>
<?= $this->include('report/_export') ?>

<div class="row g-3 mb-3">
    <div class="col-md-4">
        <div class="card border-0 shadow-sm"><div class="card-body">
            <div class="text-muted small">Total Penjualan</div>
            <div class="fs-5 fw-bold"><?= rupiah($totalPenjualan) ?></div>
        </div></div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm"><div class="card-body">
            <div class="text-muted small">Total HPP (Harga Pokok Penjualan)</div>
            <div class="fs-5 fw-bold"><?= rupiah($totalHpp) ?></div>
        </div></div>
    </div>
    <div class="col-md-4">
        <div class="card border-0 shadow-sm bg-success bg-opacity-10"><div class="card-body">
            <div class="text-muted small">Laba Kotor Periode Ini</div>
            <div class="fs-5 fw-bold text-success"><?= rupiah($totalLaba) ?></div>
        </div></div>
    </div>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-header bg-white fw-semibold">Rincian per Hari</div>
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>Tanggal</th><th class="text-end">Penjualan</th><th class="text-end">HPP</th><th class="text-end">Laba Kotor</th></tr></thead>
            <tbody>
            <?php if (empty($rows)): ?>
                <tr><td colspan="4" class="text-center text-muted py-4">Tidak ada data pada periode ini</td></tr>
            <?php else: foreach ($rows as $r): ?>
                <tr>
                    <td><?= esc(date('d/m/Y', strtotime($r['tgl']))) ?></td>
                    <td class="text-end"><?= rupiah($r['total_penjualan']) ?></td>
                    <td class="text-end"><?= rupiah($r['total_hpp']) ?></td>
                    <td class="text-end fw-semibold"><?= rupiah($r['laba_kotor']) ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<p class="text-muted small mt-2">Perhitungan laba kotor = total penjualan (setelah diskon item) dikurangi HPP (harga beli barang saat ini x qty terjual). Belum memperhitungkan biaya operasional lain di luar barang.</p>
<?= $this->endSection() ?>
