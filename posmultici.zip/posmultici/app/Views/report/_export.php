<?php
// $currentUrl otomatis dari uri saat ini + query string yang berlaku, tinggal ganti/tambah format=csv|txt
$query = $_GET;
unset($query['format']);
$baseUrl = current_url() . '?' . http_build_query($query);
$sep = str_contains($baseUrl, '?') ? '&' : '?';
?>
<div class="mb-3">
    <a href="<?= $baseUrl . $sep . 'format=csv' ?>" class="btn btn-outline-success btn-sm"><i class="bi bi-filetype-csv"></i> Export CSV</a>
    <a href="<?= $baseUrl . $sep . 'format=txt' ?>" class="btn btn-outline-secondary btn-sm"><i class="bi bi-filetype-txt"></i> Export TXT</a>
</div>
