<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h5 class="mb-3"><?= esc($title) ?></h5>
<?= $this->include('report/_filter') ?>
<?= $this->include('report/_export') ?>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>Kode</th><th>Nama Customer</th><th>Tipe</th><th class="text-end">Jumlah Transaksi</th><th class="text-end">Total Belanja</th></tr></thead>
            <tbody>
            <?php if (empty($rows)): ?>
                <tr><td colspan="5" class="text-center text-muted py-4">Tidak ada data</td></tr>
            <?php else: foreach ($rows as $r): ?>
                <tr>
                    <td><?= esc($r['kode_customer']) ?></td>
                    <td><?= esc($r['nama_customer']) ?></td>
                    <td><?= esc(ucfirst($r['tipe_customer'])) ?></td>
                    <td class="text-end"><?= number_format($r['jumlah_transaksi']) ?></td>
                    <td class="text-end"><?= rupiah($r['total_belanja']) ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>
