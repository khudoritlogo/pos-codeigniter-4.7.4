<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h5 class="mb-3"><?= esc($title) ?></h5>
<?= $this->include('report/_filter') ?>
<?= $this->include('report/_export') ?>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>Metode Bayar</th><th class="text-end">Jumlah Transaksi</th><th class="text-end">Total Nilai</th></tr></thead>
            <tbody>
            <?php if (empty($rows)): ?>
                <tr><td colspan="3" class="text-center text-muted py-4">Tidak ada data pada periode ini</td></tr>
            <?php else: foreach ($rows as $r): ?>
                <tr>
                    <td><?= esc(ucfirst($r['metode_bayar'])) ?></td>
                    <td class="text-end"><?= number_format($r['jumlah_transaksi']) ?></td>
                    <td class="text-end"><?= rupiah($r['total_nilai']) ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>
