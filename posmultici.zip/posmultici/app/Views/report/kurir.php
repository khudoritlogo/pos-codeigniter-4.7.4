<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<h5 class="mb-3"><?= esc($title) ?></h5>
<?= $this->include('report/_filter') ?>
<?= $this->include('report/_export') ?>
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <table class="table mb-0">
            <thead><tr><th>No Invoice</th><th>Tanggal</th><th>Kurir</th><th>Status Kirim</th><th>Ekspedisi</th><th class="text-end">Grand Total</th></tr></thead>
            <tbody>
            <?php if (empty($rows)): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">Tidak ada data pengiriman pada periode ini</td></tr>
            <?php else: foreach ($rows as $r): ?>
                <tr>
                    <td><?= esc($r['no_invoice']) ?></td>
                    <td><?= esc(date('d/m/Y', strtotime($r['tanggal']))) ?></td>
                    <td><?= esc($r['nama_kurir'] ?: '-') ?></td>
                    <td><?= esc($r['status_kirim']) ?></td>
                    <td><?= esc($r['nama_ekspedisi'] ?: '-') ?></td>
                    <td class="text-end"><?= rupiah($r['grand_total']) ?></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</div>
<p class="text-muted small mt-2">Fitur penunjukan kurir berdasarkan status free/sibuk & dashboard terintegrasi WhatsApp/Google Maps dibangun lengkap di Fase 6.</p>
<?= $this->endSection() ?>
