<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<h5 class="mb-3"><?= esc($title) ?></h5>

<?php if (session()->getFlashdata('error')): ?><div class="alert alert-danger"><?= esc(session()->getFlashdata('error')) ?></div><?php endif; ?>

<div class="card border-0 shadow-sm mb-3">
    <div class="card-body">
        <label class="form-label">Nomor Invoice</label>
        <div class="input-group">
            <input type="text" id="noInvoice" class="form-control" placeholder="Masukkan nomor invoice, mis. INV-PST-20260828-0001">
            <button class="btn btn-outline-primary" type="button" id="btnCari">Cari</button>
        </div>
        <div id="notFound" class="text-danger mt-2 d-none">Transaksi tidak ditemukan atau belum berstatus selesai.</div>
    </div>
</div>

<form action="<?= site_url('retur-penjualan') ?>" method="post" id="formRetur" class="d-none">
    <?= csrf_field() ?>
    <input type="hidden" name="sale_id" id="saleId">

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-header bg-white fw-semibold">Pilih Barang yang Diretur</div>
        <div class="card-body p-0">
            <table class="table mb-0">
                <thead><tr><th></th><th>Barang</th><th class="text-end">Qty Terjual</th><th class="text-end">Sudah Diretur</th><th class="text-end">Qty Retur</th></tr></thead>
                <tbody id="itemsBody"></tbody>
            </table>
        </div>
    </div>

    <div class="card border-0 shadow-sm mb-3">
        <div class="card-body">
            <label class="form-label">Alasan Retur</label>
            <textarea name="alasan" class="form-control" rows="2" required></textarea>
        </div>
    </div>

    <button type="submit" class="btn btn-primary">Simpan Retur</button>
    <a href="<?= site_url('retur-penjualan') ?>" class="btn btn-outline-secondary">Batal</a>
</form>

<script>
document.getElementById('btnCari').addEventListener('click', async function () {
    const noInvoice = document.getElementById('noInvoice').value.trim();
    if (!noInvoice) return;
    const res = await fetch(`<?= site_url('retur-penjualan/cari-invoice') ?>?no_invoice=${encodeURIComponent(noInvoice)}`);
    const json = await res.json();

    if (!json.found) {
        document.getElementById('notFound').classList.remove('d-none');
        document.getElementById('formRetur').classList.add('d-none');
        return;
    }
    document.getElementById('notFound').classList.add('d-none');
    document.getElementById('formRetur').classList.remove('d-none');
    document.getElementById('saleId').value = json.sale.id;

    const body = document.getElementById('itemsBody');
    body.innerHTML = '';
    json.items.forEach(it => {
        if (it.qty_bisa_retur <= 0) return;
        const tr = document.createElement('tr');
        tr.innerHTML = `
            <td><input type="checkbox" class="form-check-input"></td>
            <td>${it.nama_barang} (${it.nama_satuan})<input type="hidden" name="sale_item_id[]" value="${it.id}"></td>
            <td class="text-end">${it.qty}</td>
            <td class="text-end">${it.qty_retur}</td>
            <td class="text-end"><input type="number" name="qty[]" class="form-control form-control-sm text-end" style="width:100px" min="0" max="${it.qty_bisa_retur}" value="0"></td>`;
        body.appendChild(tr);
    });
});
</script>

<?= $this->endSection() ?>
