<?php

namespace App\Filters;

use App\Config\AuthGroups;
use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Filter: membatasi akses fitur berdasarkan role.
 * Contoh penerapan di Routes.php:
 *   $routes->get('produk', 'ProductController::index', ['filter' => 'role:product']);
 *
 * Argumen filter ('product', 'sale', dll) harus sama dengan key di AuthGroups::$permissions
 */
class RoleFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        $roleCode = $session->get('role_code');

        if (empty($arguments)) {
            return; // tidak ada fitur spesifik yang dicek, lanjut saja
        }

        $feature = $arguments[0];
        $authGroups = new AuthGroups();

        if (! $authGroups->can($roleCode, $feature)) {
            return redirect()->to('/dashboard')->with('error', 'Anda tidak memiliki akses ke fitur tersebut.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // tidak digunakan
    }
}
