<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

/**
 * Filter: memastikan user sudah login sebelum mengakses halaman.
 * Pasang di app/Config/Filters.php pada alias 'auth'.
 */
class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();

        if (! $session->get('logged_in')) {
            return redirect()->to('/login')->with('error', 'Silakan login terlebih dahulu.');
        }

        // Cek user masih aktif (bisa dinonaktifkan admin saat sedang login)
        if ($session->get('is_active') != 1) {
            $session->destroy();
            return redirect()->to('/login')->with('error', 'Akun Anda dinonaktifkan. Hubungi Super Admin.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // tidak digunakan
    }
}
