<?php

if (! function_exists('can_access')) {
    /**
     * Cek permission role user yang sedang login terhadap suatu fitur.
     * Dipakai di view untuk sembunyikan/tampilkan menu, tombol, dsb.
     * Contoh: <?php if (can_access('product')): ?> ... <?php endif; ?>
     */
    function can_access(string $feature): bool
    {
        $roleCode = session()->get('role_code');
        if (! $roleCode) {
            return false;
        }
        $authGroups = new \App\Config\AuthGroups();
        return $authGroups->can($roleCode, $feature);
    }
}

if (! function_exists('current_branch_id')) {
    /**
     * null = Super Admin (akses semua cabang), selain itu = ID cabang user login.
     */
    function current_branch_id(): ?int
    {
        $branchId = session()->get('branch_id');
        return $branchId !== null ? (int) $branchId : null;
    }
}

if (! function_exists('rupiah')) {
    function rupiah($angka): string
    {
        return 'Rp ' . number_format((float) $angka, 0, ',', '.');
    }
}
