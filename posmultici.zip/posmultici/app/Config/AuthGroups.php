<?php

namespace Config;

/**
 * Definisi role & hak akses (permission map) untuk RBAC.
 * kode_role harus sama dengan kolom roles.kode_role di database.
 *
 * Struktur permission: 'nama_fitur' => ['super_admin','admin','kasir','kurir']
 * Kalau role tidak ada di array fitur tsb, berarti tidak boleh akses.
 */
class AuthGroups
{
    // Daftar role yang ada di sistem
    public array $roles = [
        'super_admin' => 'Super Admin',
        'admin'       => 'Admin',
        'kasir'       => 'Kasir',
        'kurir'       => 'Kurir',
    ];

    // Mapping fitur -> role yang boleh akses
    public array $permissions = [
        'dashboard'            => ['super_admin', 'admin', 'kasir'],
        'dashboard_kurir'      => ['kurir'],
        'store_setting'        => ['super_admin'],
        'user'                 => ['super_admin'],
        'branch'               => ['super_admin'],
        'category'             => ['super_admin', 'admin'],
        'unit'                 => ['super_admin', 'admin'],
        'product'              => ['super_admin', 'admin'],
        'expedition'           => ['super_admin', 'admin'],
        'customer'             => ['super_admin', 'admin', 'kasir'],
        'sale'                 => ['super_admin', 'admin', 'kasir'],
        'sale_return'          => ['super_admin', 'admin', 'kasir'],
        'supplier'             => ['super_admin', 'admin'],
        'purchase'             => ['super_admin', 'admin'],
        'purchase_return'      => ['super_admin', 'admin'],
        'stock_transfer'       => ['super_admin', 'admin'],
        'stock_opname'         => ['super_admin', 'admin'],
        'receivable'           => ['super_admin', 'admin', 'kasir'],
        'payable'              => ['super_admin', 'admin'],
        'barcode_print'        => ['super_admin', 'admin'],
        'printer_setting'      => ['super_admin', 'admin'],
        'backup_restore'       => ['super_admin'],
        'report_kasir'         => ['super_admin', 'admin', 'kasir'], // kasir hanya lihat data sendiri
        'report_customer'      => ['super_admin', 'admin'],
        'report_sale_periode'  => ['super_admin', 'admin'],
        'report_sale_return'   => ['super_admin', 'admin'],
        'report_supplier'      => ['super_admin', 'admin'],
        'report_purchase_periode' => ['super_admin', 'admin'],
        'report_purchase_return'  => ['super_admin', 'admin'],
        'report_top_product'   => ['super_admin', 'admin'],
        'report_low_stock'     => ['super_admin', 'admin'],
        'report_courier'       => ['super_admin', 'kasir', 'kurir'], // kasir: cek kurir, kurir: laporan pribadi
        'report_cash_transfer' => ['super_admin', 'admin'],
        'report_profit'        => ['super_admin'],
        'courier_delivery'     => ['kurir'],

        // --- Fitur tambahan lanjutan ---
        'customer_level'       => ['super_admin', 'admin'],        // Fitur #1: Member/Customer Level
        'loyalty_reward'       => ['super_admin', 'admin'],        // Fitur #2: kelola katalog hadiah poin
        'loyalty_redemption'   => ['super_admin', 'admin', 'kasir'], // Fitur #2: proses penukaran poin di kasir
        'cashier_shift'        => ['super_admin', 'admin', 'kasir'], // Fitur #3: buka/tutup shift (kasir pribadi, admin lihat semua)
        'audit_log'            => ['super_admin', 'admin'],        // Fitur #4: lihat log audit & otorisasi void
        'void_transaction'     => ['super_admin', 'admin'],        // Fitur #4: yang boleh mengotorisasi void
        'garansi'              => ['super_admin', 'admin', 'kasir'], // Fitur #7: lookup & cetak klaim garansi SN
        'report_expiry'        => ['super_admin', 'admin'],        // Fitur #8: laporan barang mendekati kedaluwarsa
        'wa_bot_setting'       => ['super_admin'],                 // Fitur #9: pengaturan WA Bot omzet harian
        'telegram_bot_setting' => ['super_admin'],                 // Fitur tambahan: pengaturan Telegram Bot omzet harian
    ];

    /**
     * Cek apakah sebuah role boleh mengakses fitur tertentu.
     */
    public function can(string $roleCode, string $feature): bool
    {
        if ($roleCode === 'super_admin' && $feature !== 'dashboard_kurir' && $feature !== 'courier_delivery') {
            // Super Admin akses semua fitur kecuali fitur kurir (sesuai spesifikasi)
            return true;
        }

        return in_array($roleCode, $this->permissions[$feature] ?? [], true);
    }
}
