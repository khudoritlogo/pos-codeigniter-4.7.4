<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Auth\LoginController');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
$routes->setAutoRoute(false);

// ==================== AUTH (tanpa login) ====================
$routes->get('/', 'Auth\LoginController::index');
$routes->get('login', 'Auth\LoginController::index');
$routes->post('login', 'Auth\LoginController::attempt');
$routes->get('logout', 'Auth\LoginController::logout');

/**
 * Helper: mendaftarkan rute CRUD sederhana berbasis form HTML biasa (GET + POST saja,
 * tanpa PUT/DELETE/method-spoofing) supaya konsisten & mudah dipakai di semua modul master data.
 *
 *   GET  {base}            -> index
 *   GET  {base}/data        -> data   (JSON untuk DataTable)
 *   GET  {base}/new         -> new    (form tambah)
 *   POST {base}             -> create
 *   GET  {base}/(:num)/edit -> edit   (form edit)
 *   POST {base}/(:num)      -> update
 *   POST {base}/(:num)/delete -> delete
 */
function crudRoutes($routes, string $base, string $controller, string $feature): void
{
    $filter = ['filter' => "role:{$feature}"];
    $routes->get($base, "{$controller}::index", $filter);
    $routes->get("{$base}/data", "{$controller}::data", $filter);
    $routes->get("{$base}/new", "{$controller}::new", $filter);
    $routes->post($base, "{$controller}::create", $filter);
    $routes->get("{$base}/(:num)/edit", "{$controller}::edit/$1", $filter);
    $routes->post("{$base}/(:num)", "{$controller}::update/$1", $filter);
    $routes->post("{$base}/(:num)/delete", "{$controller}::delete/$1", $filter);
}

// ==================== AREA LOGIN (butuh auth) ====================
$routes->group('', ['filter' => 'auth'], function ($routes) {

    $routes->get('dashboard', 'DashboardController::index', ['filter' => 'role:dashboard']);
    $routes->get('kurir/dashboard', 'DashboardController::kurir', ['filter' => 'role:dashboard_kurir']);

    // --- Master data ---
    $routes->get('pengaturan-toko', 'StoreSettingController::index', ['filter' => 'role:store_setting']);
    $routes->post('pengaturan-toko', 'StoreSettingController::update', ['filter' => 'role:store_setting']);

    crudRoutes($routes, 'cabang', 'BranchController', 'branch');
    crudRoutes($routes, 'user', 'UserController', 'user');
    crudRoutes($routes, 'kategori', 'CategoryController', 'category');
    crudRoutes($routes, 'satuan', 'UnitController', 'unit');
    crudRoutes($routes, 'barang', 'ProductController', 'product');
    crudRoutes($routes, 'ekspedisi', 'ExpeditionController', 'expedition');
    crudRoutes($routes, 'customer', 'CustomerController', 'customer');
    crudRoutes($routes, 'supplier', 'SupplierController', 'supplier');
    crudRoutes($routes, 'level-member', 'CustomerLevelController', 'customer_level');
    crudRoutes($routes, 'hadiah-poin', 'LoyaltyRewardController', 'loyalty_reward');

    // --- Transaksi (Fase 3) ---
    // Kasir: layar POS untuk transaksi baru (search barang, keranjang, bayar)
    $routes->get('kasir', 'SaleController::posScreen', ['filter' => 'role:sale']);
    $routes->get('kasir/cari-barang', 'SaleController::searchProduct', ['filter' => 'role:sale']);
    $routes->get('kasir/serial-tersedia', 'SaleController::serialsAvailable', ['filter' => 'role:sale']);
    $routes->get('kasir/cek-harga-bertingkat', 'SaleController::checkTieredPrice', ['filter' => 'role:sale']);
    $routes->get('kasir/cek-poin', 'SaleController::cekPoinCustomer', ['filter' => 'role:sale']);
    $routes->post('kasir/simpan', 'SaleController::store', ['filter' => 'role:sale']);
    $routes->get('kasir/pending', 'SaleController::pendingList', ['filter' => 'role:sale']);
    $routes->get('kasir/pending/(:num)/lanjutkan', 'SaleController::resumePending/$1', ['filter' => 'role:sale']);
    // Penjualan: riwayat transaksi yang sudah selesai
    $routes->get('penjualan', 'SaleController::index', ['filter' => 'role:sale']);
    $routes->get('penjualan/data', 'SaleController::data', ['filter' => 'role:sale']);
    $routes->get('penjualan/(:num)', 'SaleController::detail/$1', ['filter' => 'role:sale']);

    // Retur Penjualan
    $routes->get('retur-penjualan', 'SaleReturnController::index', ['filter' => 'role:sale_return']);
    $routes->get('retur-penjualan/data', 'SaleReturnController::data', ['filter' => 'role:sale_return']);
    $routes->get('retur-penjualan/new', 'SaleReturnController::new', ['filter' => 'role:sale_return']);
    $routes->get('retur-penjualan/cari-invoice', 'SaleReturnController::cariInvoice', ['filter' => 'role:sale_return']);
    $routes->post('retur-penjualan', 'SaleReturnController::create', ['filter' => 'role:sale_return']);

    // Pembelian
    $routes->get('pembelian', 'PurchaseController::index', ['filter' => 'role:purchase']);
    $routes->get('pembelian/data', 'PurchaseController::data', ['filter' => 'role:purchase']);
    $routes->get('pembelian/new', 'PurchaseController::new', ['filter' => 'role:purchase']);
    $routes->post('pembelian', 'PurchaseController::create', ['filter' => 'role:purchase']);
    $routes->get('pembelian/(:num)', 'PurchaseController::detail/$1', ['filter' => 'role:purchase']);

    // Retur Pembelian
    $routes->get('retur-pembelian', 'PurchaseReturnController::index', ['filter' => 'role:purchase_return']);
    $routes->get('retur-pembelian/data', 'PurchaseReturnController::data', ['filter' => 'role:purchase_return']);
    $routes->get('retur-pembelian/new', 'PurchaseReturnController::new', ['filter' => 'role:purchase_return']);
    $routes->get('retur-pembelian/cari-pembelian', 'PurchaseReturnController::cariPembelian', ['filter' => 'role:purchase_return']);
    $routes->post('retur-pembelian', 'PurchaseReturnController::create', ['filter' => 'role:purchase_return']);

    // Transfer Stok antar cabang
    $routes->get('transfer-stok', 'StockTransferController::index', ['filter' => 'role:stock_transfer']);
    $routes->get('transfer-stok/data', 'StockTransferController::data', ['filter' => 'role:stock_transfer']);
    $routes->get('transfer-stok/new', 'StockTransferController::new', ['filter' => 'role:stock_transfer']);
    $routes->post('transfer-stok', 'StockTransferController::create', ['filter' => 'role:stock_transfer']);
    $routes->get('transfer-stok/(:num)', 'StockTransferController::detail/$1', ['filter' => 'role:stock_transfer']);
    $routes->post('transfer-stok/(:num)/kirim', 'StockTransferController::kirim/$1', ['filter' => 'role:stock_transfer']);
    $routes->post('transfer-stok/(:num)/terima', 'StockTransferController::terima/$1', ['filter' => 'role:stock_transfer']);
    $routes->post('transfer-stok/(:num)/batal', 'StockTransferController::batal/$1', ['filter' => 'role:stock_transfer']);

    // Stock Opname
    $routes->get('stock-opname', 'StockOpnameController::index', ['filter' => 'role:stock_opname']);
    $routes->get('stock-opname/data', 'StockOpnameController::data', ['filter' => 'role:stock_opname']);
    $routes->get('stock-opname/new', 'StockOpnameController::new', ['filter' => 'role:stock_opname']);
    $routes->post('stock-opname', 'StockOpnameController::create', ['filter' => 'role:stock_opname']);
    $routes->get('stock-opname/(:num)', 'StockOpnameController::detail/$1', ['filter' => 'role:stock_opname']);
    $routes->post('stock-opname/(:num)/selesai', 'StockOpnameController::selesai/$1', ['filter' => 'role:stock_opname']);

    // Piutang & Hutang: dibuat otomatis dari transaksi penjualan/pembelian bermetode piutang/hutang.
    $routes->get('piutang', 'ReceivableController::index', ['filter' => 'role:receivable']);
    $routes->get('piutang/data', 'ReceivableController::data', ['filter' => 'role:receivable']);
    $routes->get('piutang/(:num)', 'ReceivableController::detail/$1', ['filter' => 'role:receivable']);
    $routes->post('piutang/(:num)/bayar', 'ReceivableController::bayar/$1', ['filter' => 'role:receivable']);
    $routes->get('hutang', 'PayableController::index', ['filter' => 'role:payable']);
    $routes->get('hutang/data', 'PayableController::data', ['filter' => 'role:payable']);
    $routes->get('hutang/(:num)', 'PayableController::detail/$1', ['filter' => 'role:payable']);
    $routes->post('hutang/(:num)/bayar', 'PayableController::bayar/$1', ['filter' => 'role:payable']);

    // --- Fitur #2: Loyalty Points (tukar poin dengan hadiah) ---
    $routes->get('tukar-poin', 'LoyaltyRedemptionController::index', ['filter' => 'role:loyalty_redemption']);
    $routes->get('tukar-poin/data', 'LoyaltyRedemptionController::data', ['filter' => 'role:loyalty_redemption']);
    $routes->get('tukar-poin/new', 'LoyaltyRedemptionController::new', ['filter' => 'role:loyalty_redemption']);
    $routes->post('tukar-poin', 'LoyaltyRedemptionController::create', ['filter' => 'role:loyalty_redemption']);
    $routes->get('tukar-poin/cari-customer', 'LoyaltyRedemptionController::cariCustomer', ['filter' => 'role:loyalty_redemption']);

    // --- Fitur #3: Manajemen Shift Kasir ---
    $routes->get('shift-kasir', 'CashierShiftController::index', ['filter' => 'role:cashier_shift']);
    $routes->get('shift-kasir/data', 'CashierShiftController::data', ['filter' => 'role:cashier_shift']);
    $routes->get('shift-kasir/buka', 'CashierShiftController::formBuka', ['filter' => 'role:cashier_shift']);
    $routes->post('shift-kasir/buka', 'CashierShiftController::buka', ['filter' => 'role:cashier_shift']);
    $routes->get('shift-kasir/(:num)/tutup', 'CashierShiftController::formTutup/$1', ['filter' => 'role:cashier_shift']);
    $routes->post('shift-kasir/(:num)/tutup', 'CashierShiftController::tutup/$1', ['filter' => 'role:cashier_shift']);
    $routes->get('shift-kasir/(:num)', 'CashierShiftController::detail/$1', ['filter' => 'role:cashier_shift']);

    // --- Fitur #4: Audit Log & Void ---
    $routes->get('audit-log', 'AuditLogController::index', ['filter' => 'role:audit_log']);
    $routes->get('audit-log/data', 'AuditLogController::data', ['filter' => 'role:audit_log']);
    $routes->post('kasir/log-hapus-item', 'SaleController::logHapusItem', ['filter' => 'role:sale']);
    $routes->post('penjualan/(:num)/void', 'SaleController::voidTransaction/$1', ['filter' => 'role:void_transaction']);
    $routes->post('kasir/cek-otorisasi', 'SaleController::cekOtorisasi', ['filter' => 'role:sale']);

    // --- Fitur #5: QRIS & Customer Facing Display ---
    $routes->get('kasir/cfd', 'SaleController::cfd', ['filter' => 'role:sale']);
    $routes->get('kasir/cfd/data', 'SaleController::cfdData', ['filter' => 'role:sale']);

    // --- Fitur #7: Garansi berbasis SN ---
    $routes->get('garansi', 'GaransiController::index', ['filter' => 'role:garansi']);
    $routes->get('garansi/cari', 'GaransiController::cari', ['filter' => 'role:garansi']);
    $routes->get('garansi/cetak/(:any)', 'GaransiController::cetak/$1', ['filter' => 'role:garansi']);

    // --- Fitur #8: Expired Date / FEFO ---
    $routes->get('laporan/kedaluwarsa', 'ReportController::expiredWarning', ['filter' => 'role:report_expiry']);

    // --- Fitur #9: Pengaturan WA Bot ---
    $routes->get('pengaturan-wa-bot', 'WaBotSettingController::index', ['filter' => 'role:wa_bot_setting']);
    $routes->post('pengaturan-wa-bot', 'WaBotSettingController::update', ['filter' => 'role:wa_bot_setting']);
    $routes->post('pengaturan-wa-bot/tes-kirim', 'WaBotSettingController::testKirim', ['filter' => 'role:wa_bot_setting']);

    // --- Pengaturan Telegram Bot (notifikasi resmi via Telegram Bot API) ---
    $routes->get('pengaturan-telegram-bot', 'TelegramSettingController::index', ['filter' => 'role:telegram_bot_setting']);
    $routes->post('pengaturan-telegram-bot', 'TelegramSettingController::update', ['filter' => 'role:telegram_bot_setting']);
    $routes->post('pengaturan-telegram-bot/tes-kirim', 'TelegramSettingController::testKirim', ['filter' => 'role:telegram_bot_setting']);

    // --- Kurir (Fase 6) ---
    $routes->get('kurir/pengiriman', 'CourierDeliveryController::index', ['filter' => 'role:courier_delivery']);
    $routes->post('kurir/pengiriman/(:num)/status', 'CourierDeliveryController::updateStatus/$1', ['filter' => 'role:courier_delivery']);
    $routes->post('kurir/status', 'CourierDeliveryController::toggleStatus', ['filter' => 'role:courier_delivery']);
    $routes->get('kasir/daftar-kurir', 'SaleController::listCouriers', ['filter' => 'role:sale']);

    // --- Laporan (Fase 5) ---
    $routes->get('laporan/kasir', 'ReportController::kasir', ['filter' => 'role:report_kasir']);
    $routes->get('laporan/customer', 'ReportController::customer', ['filter' => 'role:report_customer']);
    $routes->get('laporan/penjualan-periode', 'ReportController::penjualanPeriode', ['filter' => 'role:report_sale_periode']);
    $routes->get('laporan/penjualan-periode/data', 'ReportController::penjualanPeriodeData', ['filter' => 'role:report_sale_periode']);
    $routes->get('laporan/penjualan-periode/export', 'ReportController::penjualanPeriodeExport', ['filter' => 'role:report_sale_periode']);
    $routes->get('laporan/penjualan-retur', 'ReportController::penjualanRetur', ['filter' => 'role:report_sale_return']);
    $routes->get('laporan/supplier', 'ReportController::supplier', ['filter' => 'role:report_supplier']);
    $routes->get('laporan/pembelian-periode', 'ReportController::pembelianPeriode', ['filter' => 'role:report_purchase_periode']);
    $routes->get('laporan/pembelian-retur', 'ReportController::pembelianRetur', ['filter' => 'role:report_purchase_return']);
    $routes->get('laporan/barang-terlaris', 'ReportController::barangTerlaris', ['filter' => 'role:report_top_product']);
    $routes->get('laporan/stok-terkecil', 'ReportController::stokTerkecil', ['filter' => 'role:report_low_stock']);
    $routes->get('laporan/kurir', 'ReportController::kurir', ['filter' => 'role:report_courier']);
    $routes->get('laporan/cash-transfer', 'ReportController::cashTransfer', ['filter' => 'role:report_cash_transfer']);
    $routes->get('laporan/laba-bersih', 'ReportController::labaBersih', ['filter' => 'role:report_profit']);

    // --- Cetak & lainnya ---
    $routes->get('barcode/cetak', 'BarcodeController::index', ['filter' => 'role:barcode_print']);
    $routes->get('barcode/cari-barang', 'BarcodeController::searchProduct', ['filter' => 'role:barcode_print']);
    $routes->post('barcode/cetak', 'BarcodeController::cetak', ['filter' => 'role:barcode_print']);
    $routes->get('pengaturan-printer', 'PrinterSettingController::index', ['filter' => 'role:printer_setting']);
    $routes->post('pengaturan-printer', 'PrinterSettingController::update', ['filter' => 'role:printer_setting']);
    $routes->get('penjualan/(:num)/cetak', 'SaleController::printReceipt/$1', ['filter' => 'role:sale']);
    $routes->get('backup-restore', 'BackupController::index', ['filter' => 'role:backup_restore']);
    $routes->post('backup-restore/buat', 'BackupController::create', ['filter' => 'role:backup_restore']);
    $routes->get('backup-restore/unduh/(:any)', 'BackupController::download/$1', ['filter' => 'role:backup_restore']);
    $routes->post('backup-restore/hapus/(:any)', 'BackupController::delete/$1', ['filter' => 'role:backup_restore']);
    $routes->post('backup-restore/restore-upload', 'BackupController::restore', ['filter' => 'role:backup_restore']);
    $routes->post('backup-restore/restore/(:any)', 'BackupController::restoreExisting/$1', ['filter' => 'role:backup_restore']);
});
