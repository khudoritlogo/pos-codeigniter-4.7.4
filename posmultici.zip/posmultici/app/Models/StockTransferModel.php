<?php

namespace App\Models;

use CodeIgniter\Model;

class StockTransferModel extends Model
{
    protected $table         = 'stock_transfers';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['no_transfer', 'branch_from_id', 'branch_to_id', 'user_id', 'tanggal', 'status', 'catatan'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function generateNoTransfer(): string
    {
        $prefix = 'TR-' . date('Ymd') . '-';
        $last   = $this->where('no_transfer LIKE', $prefix . '%')->orderBy('id', 'DESC')->first();
        $urutan = $last ? ((int) substr($last['no_transfer'], -4) + 1) : 1;
        return $prefix . str_pad((string) $urutan, 4, '0', STR_PAD_LEFT);
    }

    /** Transfer yang relevan untuk sebuah cabang: sebagai pengirim ATAU penerima */
    public function listForBranch(?int $branchId)
    {
        $builder = $this->select('stock_transfers.*, bf.nama_cabang as cabang_asal, bt.nama_cabang as cabang_tujuan, users.nama as nama_user')
            ->join('branches bf', 'bf.id = stock_transfers.branch_from_id')
            ->join('branches bt', 'bt.id = stock_transfers.branch_to_id')
            ->join('users', 'users.id = stock_transfers.user_id')
            ->orderBy('stock_transfers.tanggal', 'DESC');
        if ($branchId !== null) {
            $builder->groupStart()->where('branch_from_id', $branchId)->orWhere('branch_to_id', $branchId)->groupEnd();
        }
        return $builder->findAll();
    }
}
