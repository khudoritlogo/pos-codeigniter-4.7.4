<?php

namespace App\Models;

use CodeIgniter\Model;

class SystemSettingModel extends Model
{
    protected $table         = 'system_settings';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['branch_id', 'setting_key', 'setting_value', 'updated_at'];
    protected $useTimestamps = false;

    public function get(string $key, ?int $branchId = null, $default = null)
    {
        $row = $this->where('setting_key', $key)->where('branch_id', $branchId)->first();
        return $row['setting_value'] ?? $default;
    }

    public function set(string $key, $value, ?int $branchId = null): void
    {
        $existing = $this->where('setting_key', $key)->where('branch_id', $branchId)->first();
        $data = ['branch_id' => $branchId, 'setting_key' => $key, 'setting_value' => $value, 'updated_at' => date('Y-m-d H:i:s')];
        if ($existing) {
            $this->update($existing['id'], $data);
        } else {
            $this->insert($data);
        }
    }
}
