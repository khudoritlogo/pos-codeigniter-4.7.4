<?php

namespace App\Models;

use CodeIgniter\Model;

class PurchaseItemModel extends Model
{
    protected $table         = 'purchase_items';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['purchase_id', 'product_id', 'unit_id', 'qty', 'harga', 'subtotal', 'qty_retur'];
    protected $useTimestamps = false;

    public function byPurchase(int $purchaseId)
    {
        return $this->select('purchase_items.*, products.nama_barang, products.jenis_produk, products.harga_jual, products.harga_grosir, units.nama_satuan')
            ->join('products', 'products.id = purchase_items.product_id')
            ->join('units', 'units.id = purchase_items.unit_id')
            ->where('purchase_id', $purchaseId)
            ->findAll();
    }
}
