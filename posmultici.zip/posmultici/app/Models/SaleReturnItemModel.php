<?php

namespace App\Models;

use CodeIgniter\Model;

class SaleReturnItemModel extends Model
{
    protected $table         = 'sale_return_items';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['sale_return_id', 'sale_item_id', 'product_id', 'qty', 'subtotal'];
    protected $useTimestamps = false;
}
