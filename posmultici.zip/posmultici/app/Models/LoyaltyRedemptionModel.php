<?php

namespace App\Models;

use CodeIgniter\Model;

class LoyaltyRedemptionModel extends Model
{
    protected $table         = 'loyalty_redemptions';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['no_penukaran', 'customer_id', 'reward_id', 'branch_id', 'user_id', 'poin_dipakai', 'tanggal'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = null;

    public function generateNoPenukaran(): string
    {
        $prefix = 'RWD-' . date('Ymd') . '-';
        $last   = $this->where('no_penukaran LIKE', $prefix . '%')->orderBy('id', 'DESC')->first();
        $urutan = $last ? ((int) substr($last['no_penukaran'], -4) + 1) : 1;
        return $prefix . str_pad((string) $urutan, 4, '0', STR_PAD_LEFT);
    }

    public function listWithRelations(?int $branchId)
    {
        $builder = $this->select('loyalty_redemptions.*, customers.nama_customer, loyalty_rewards.nama_hadiah, users.nama as nama_user')
            ->join('customers', 'customers.id = loyalty_redemptions.customer_id')
            ->join('loyalty_rewards', 'loyalty_rewards.id = loyalty_redemptions.reward_id')
            ->join('users', 'users.id = loyalty_redemptions.user_id')
            ->orderBy('loyalty_redemptions.tanggal', 'DESC');
        if ($branchId !== null) {
            $builder->where('loyalty_redemptions.branch_id', $branchId);
        }
        return $builder->findAll();
    }
}
