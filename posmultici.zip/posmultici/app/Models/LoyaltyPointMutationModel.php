<?php

namespace App\Models;

use CodeIgniter\Model;

class LoyaltyPointMutationModel extends Model
{
    protected $table         = 'loyalty_point_mutations';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['customer_id', 'tipe', 'ref_table', 'ref_id', 'poin_sebelum', 'poin_mutasi', 'poin_sesudah', 'keterangan'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = null;

    public function byCustomer(int $customerId)
    {
        return $this->where('customer_id', $customerId)->orderBy('created_at', 'DESC')->findAll();
    }
}
