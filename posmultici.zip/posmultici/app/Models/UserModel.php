<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $protectFields    = true;

    protected $allowedFields = [
        'branch_id', 'role_id', 'nama', 'username', 'email', 'no_hp',
        'password', 'foto', 'status_kurir', 'is_active', 'last_login',
    ];

    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    protected $validationRules = [
        'nama'     => 'required|min_length[3]|max_length[150]',
        'username' => 'required|min_length[4]|max_length[100]|is_unique[users.username,id,{id}]',
        'role_id'  => 'required|integer',
    ];

    protected $validationMessages = [
        'username' => [
            'is_unique' => 'Username sudah digunakan, silakan pilih yang lain.',
        ],
    ];

    /**
     * Ambil user beserta nama role & nama cabang (untuk keperluan login & listing)
     */
    public function getUserWithRole(string $username)
    {
        return $this->select('users.*, roles.kode_role, roles.nama_role, branches.nama_cabang')
            ->join('roles', 'roles.id = users.role_id')
            ->join('branches', 'branches.id = users.branch_id', 'left')
            ->where('users.username', $username)
            ->where('users.is_active', 1)
            ->first();
    }

    public function findByUsername(string $username)
    {
        return $this->where('username', $username)->first();
    }

    /** Daftar user berperan kurir di sebuah cabang (atau semua cabang jika $branchId null), beserta status free/sibuk/off */
    public function listCouriers(?int $branchId = null)
    {
        $builder = $this->select('users.id, users.nama, users.no_hp, users.status_kurir, branches.nama_cabang')
            ->join('roles', 'roles.id = users.role_id')
            ->join('branches', 'branches.id = users.branch_id', 'left')
            ->where('roles.kode_role', 'kurir')
            ->where('users.is_active', 1)
            ->orderBy('users.nama', 'ASC');
        if ($branchId !== null) {
            $builder->where('users.branch_id', $branchId);
        }
        return $builder->findAll();
    }
}
