<?php

namespace App\Models;

use CodeIgniter\Model;

class StockOpnameItemModel extends Model
{
    protected $table         = 'stock_opname_items';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['stock_opname_id', 'product_id', 'qty_sistem', 'qty_fisik', 'selisih'];
    protected $useTimestamps = false;

    public function byOpname(int $opnameId)
    {
        return $this->select('stock_opname_items.*, products.nama_barang, units.nama_satuan')
            ->join('products', 'products.id = stock_opname_items.product_id')
            ->join('units', 'units.id = products.unit_id')
            ->where('stock_opname_id', $opnameId)
            ->findAll();
    }
}
