<?php

namespace App\Models;

use CodeIgniter\Model;

class PurchaseModel extends Model
{
    protected $table            = 'purchases';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $allowedFields    = [
        'no_pembelian', 'branch_id', 'supplier_id', 'user_id', 'tanggal', 'subtotal', 'diskon',
        'grand_total', 'bayar', 'metode_bayar', 'status_bayar', 'catatan',
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    public function generateNoPembelian(int $branchId): string
    {
        $branch = $this->db->table('branches')->where('id', $branchId)->get()->getRow();
        $kode   = $branch->kode_cabang ?? 'PST';
        $prefix = 'PO-' . $kode . '-' . date('Ymd') . '-';
        $last   = $this->where('no_pembelian LIKE', $prefix . '%')->orderBy('id', 'DESC')->first();
        $urutan = $last ? ((int) substr($last['no_pembelian'], -4) + 1) : 1;
        return $prefix . str_pad((string) $urutan, 4, '0', STR_PAD_LEFT);
    }

    public function listWithRelations(?int $branchId)
    {
        $builder = $this->select('purchases.*, suppliers.nama_supplier, users.nama as nama_user')
            ->join('suppliers', 'suppliers.id = purchases.supplier_id')
            ->join('users', 'users.id = purchases.user_id')
            ->orderBy('purchases.tanggal', 'DESC');
        if ($branchId !== null) {
            $builder->where('purchases.branch_id', $branchId);
        }
        return $builder->findAll();
    }
}
