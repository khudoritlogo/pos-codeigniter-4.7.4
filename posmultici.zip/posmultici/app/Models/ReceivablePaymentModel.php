<?php

namespace App\Models;

use CodeIgniter\Model;

class ReceivablePaymentModel extends Model
{
    protected $table         = 'receivable_payments';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['receivable_id', 'user_id', 'tanggal_bayar', 'jumlah_bayar', 'metode_bayar', 'catatan'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = null;

    public function byReceivable(int $receivableId)
    {
        return $this->where('receivable_id', $receivableId)->orderBy('tanggal_bayar', 'DESC')->findAll();
    }
}
