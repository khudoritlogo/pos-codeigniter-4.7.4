<?php

namespace App\Models;

use CodeIgniter\Model;

// Serial number per unit fisik barang (untuk produk jenis SN), dilacak per cabang
class ProductSerialModel extends Model
{
    protected $table            = 'product_serials';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'product_id', 'branch_id', 'serial_number', 'status', 'purchase_item_id', 'sale_item_id',
        'tanggal_mulai_garansi', 'tanggal_akhir_garansi',
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function tersediaDiCabang(int $productId, int $branchId)
    {
        return $this->where('product_id', $productId)
            ->where('branch_id', $branchId)
            ->where('status', 'tersedia')
            ->findAll();
    }

    public function countTersediaDiCabang(int $productId, int $branchId): int
    {
        return $this->where('product_id', $productId)
            ->where('branch_id', $branchId)
            ->where('status', 'tersedia')
            ->countAllResults();
    }

    /** Cari berdasarkan nomor serial persis (untuk lookup klaim garansi) */
    public function bySerialNumber(string $serialNumber)
    {
        return $this->select('product_serials.*, products.nama_barang, products.kode_barang, products.garansi_bulan')
            ->join('products', 'products.id = product_serials.product_id')
            ->where('product_serials.serial_number', $serialNumber)
            ->first();
    }
}
