<?php

namespace App\Models;

use CodeIgniter\Model;

class CustomerModel extends Model
{
    protected $table            = 'customers';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $allowedFields    = [
        'kode_customer', 'nama_customer', 'tipe_customer', 'customer_level_id', 'telepon', 'email',
        'alamat', 'limit_piutang', 'poin',
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    protected $validationRules = [
        'kode_customer' => 'required|max_length[30]|is_unique[customers.kode_customer,id,{id}]',
        'nama_customer' => 'required|min_length[2]|max_length[150]',
        'tipe_customer' => 'required|in_list[retail,grosir]',
        'email'         => 'permit_empty|valid_email',
    ];

    /**
     * Total piutang berjalan seorang customer (dipakai saat transaksi kasir untuk cek limit).
     */
    public function totalPiutangAktif(int $customerId): float
    {
        $row = $this->db->table('receivables')
            ->selectSum('sisa_piutang')
            ->where('customer_id', $customerId)
            ->whereIn('status', ['belum_lunas', 'cicilan', 'menunggak'])
            ->get()->getRow();
        return (float) ($row->sisa_piutang ?? 0);
    }

    /** Daftar customer beserta nama level membernya (untuk listing & pemilihan di kasir) */
    public function listWithLevel()
    {
        return $this->select('customers.*, customer_levels.nama_level, customer_levels.diskon_persen')
            ->join('customer_levels', 'customer_levels.id = customers.customer_level_id', 'left')
            ->orderBy('customers.nama_customer', 'ASC')
            ->findAll();
    }
}
