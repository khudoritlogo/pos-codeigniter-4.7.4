<?php

namespace App\Models;

use CodeIgniter\Model;

class CustomerLevelModel extends Model
{
    protected $table         = 'customer_levels';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['kode_level', 'nama_level', 'diskon_persen', 'min_poin_naik', 'urutan'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    protected $validationRules = [
        'kode_level' => 'required|max_length[30]|is_unique[customer_levels.kode_level,id,{id}]',
        'nama_level' => 'required|min_length[2]|max_length[100]',
    ];

    public function ordered()
    {
        return $this->orderBy('urutan', 'ASC')->findAll();
    }

    /** Cari level tertinggi yang syarat poinnya terpenuhi -- dipakai untuk kenaikan level otomatis */
    public function levelUntukPoin(int $poin): ?array
    {
        return $this->where('min_poin_naik <=', $poin)->orderBy('urutan', 'DESC')->first();
    }
}
