<?php

namespace App\Models;

use CodeIgniter\Model;

class PurchaseReturnItemModel extends Model
{
    protected $table         = 'purchase_return_items';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['purchase_return_id', 'purchase_item_id', 'product_id', 'qty', 'subtotal'];
    protected $useTimestamps = false;
}
