<?php

namespace App\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table            = 'products';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $allowedFields    = [
        'kode_barang', 'barcode', 'nama_barang', 'category_id', 'unit_id', 'supplier_id',
        'jenis_produk', 'garansi_bulan', 'has_expiry', 'harga_beli', 'harga_jual', 'harga_grosir',
        'stok_minimal', 'foto', 'status',
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    protected $validationRules = [
        'kode_barang'  => 'required|max_length[50]|is_unique[products.kode_barang,id,{id}]',
        'nama_barang'  => 'required|min_length[2]|max_length[200]',
        'category_id'  => 'required|integer',
        'unit_id'      => 'required|integer',
        'jenis_produk' => 'required|in_list[non_sn,sn]',
        'harga_beli'   => 'required|numeric',
        'harga_jual'   => 'required|numeric',
    ];

    /** Daftar barang lengkap dengan nama kategori, satuan, dan total stok semua cabang (untuk listing) */
    public function listWithRelations()
    {
        return $this->select('products.*, categories.nama_kategori, units.nama_satuan')
            ->join('categories', 'categories.id = products.category_id')
            ->join('units', 'units.id = products.unit_id')
            ->orderBy('products.nama_barang', 'ASC')
            ->findAll();
    }

    /** Stok barang di sebuah cabang tertentu (dari tabel stocks) */
    public function stokDiCabang(int $productId, int $branchId): float
    {
        $row = $this->db->table('stocks')
            ->where('product_id', $productId)
            ->where('branch_id', $branchId)
            ->get()->getRow();
        return (float) ($row->qty ?? 0);
    }
}
