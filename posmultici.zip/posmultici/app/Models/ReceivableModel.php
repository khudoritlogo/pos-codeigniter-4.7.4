<?php

namespace App\Models;

use CodeIgniter\Model;

// Piutang: dibuat otomatis saat transaksi penjualan dengan metode bayar 'piutang'
class ReceivableModel extends Model
{
    protected $table         = 'receivables';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = [
        'sale_id', 'customer_id', 'branch_id', 'total_piutang', 'total_dibayar', 'sisa_piutang',
        'jatuh_tempo', 'status',
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function listWithRelations(?int $branchId, bool $onlyMenunggak = false)
    {
        $builder = $this->select('receivables.*, customers.nama_customer, sales.no_invoice')
            ->join('customers', 'customers.id = receivables.customer_id')
            ->join('sales', 'sales.id = receivables.sale_id')
            ->orderBy('receivables.jatuh_tempo', 'ASC');
        if ($branchId !== null) {
            $builder->where('receivables.branch_id', $branchId);
        }
        if ($onlyMenunggak) {
            $builder->where('receivables.status', 'menunggak');
        } else {
            $builder->whereIn('receivables.status', ['belum_lunas', 'cicilan', 'lunas', 'menunggak']);
        }
        return $builder->findAll();
    }

    /** Tandai status 'menunggak' untuk piutang yang sudah lewat jatuh tempo tapi belum lunas */
    public function tandaiMenunggak(): void
    {
        $this->where('jatuh_tempo <', date('Y-m-d'))
            ->whereIn('status', ['belum_lunas', 'cicilan'])
            ->set('status', 'menunggak')
            ->update();
    }
}
