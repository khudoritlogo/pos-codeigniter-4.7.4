<?php

namespace App\Models;

use CodeIgniter\Model;

class StoreSettingModel extends Model
{
    protected $table         = 'store_settings';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['branch_id', 'nama_toko', 'alamat', 'telepon', 'email', 'logo', 'npwp', 'footer_struk', 'updated_at'];
    protected $useTimestamps = false;

    /** Ambil pengaturan untuk cabang tertentu, fallback ke pengaturan global (branch_id null) jika belum ada */
    public function getForBranch(?int $branchId)
    {
        if ($branchId !== null) {
            $row = $this->where('branch_id', $branchId)->first();
            if ($row) {
                return $row;
            }
        }
        return $this->where('branch_id', null)->first();
    }
}
