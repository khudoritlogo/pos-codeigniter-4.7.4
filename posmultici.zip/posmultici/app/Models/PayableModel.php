<?php

namespace App\Models;

use CodeIgniter\Model;

class PayableModel extends Model
{
    protected $table         = 'payables';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = [
        'purchase_id', 'supplier_id', 'branch_id', 'total_hutang', 'total_dibayar', 'sisa_hutang',
        'jatuh_tempo', 'status',
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function listWithRelations(?int $branchId, bool $onlyMenunggak = false)
    {
        $builder = $this->select('payables.*, suppliers.nama_supplier, purchases.no_pembelian')
            ->join('suppliers', 'suppliers.id = payables.supplier_id')
            ->join('purchases', 'purchases.id = payables.purchase_id')
            ->orderBy('payables.jatuh_tempo', 'ASC');
        if ($branchId !== null) {
            $builder->where('payables.branch_id', $branchId);
        }
        if ($onlyMenunggak) {
            $builder->where('payables.status', 'menunggak');
        }
        return $builder->findAll();
    }

    public function tandaiMenunggak(): void
    {
        $this->where('jatuh_tempo <', date('Y-m-d'))
            ->whereIn('status', ['belum_lunas', 'cicilan'])
            ->set('status', 'menunggak')
            ->update();
    }
}
