<?php

namespace App\Models;

use CodeIgniter\Model;

class StockTransferItemModel extends Model
{
    protected $table         = 'stock_transfer_items';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['stock_transfer_id', 'product_id', 'qty'];
    protected $useTimestamps = false;

    public function byTransfer(int $transferId)
    {
        return $this->select('stock_transfer_items.*, products.nama_barang, units.nama_satuan')
            ->join('products', 'products.id = stock_transfer_items.product_id')
            ->join('units', 'units.id = products.unit_id')
            ->where('stock_transfer_id', $transferId)
            ->findAll();
    }
}
