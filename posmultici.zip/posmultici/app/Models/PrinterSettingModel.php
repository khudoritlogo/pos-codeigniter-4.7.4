<?php

namespace App\Models;

use CodeIgniter\Model;

class PrinterSettingModel extends Model
{
    protected $table         = 'printer_settings';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = [
        'branch_id', 'ukuran_kertas', 'lebar_custom_mm', 'font_size', 'tampilkan_logo', 'jumlah_copy', 'updated_at',
    ];
    protected $useTimestamps = false;

    /** Ambil pengaturan printer untuk cabang tertentu, fallback ke pengaturan global (branch_id null) */
    public function getForBranch(?int $branchId)
    {
        if ($branchId !== null) {
            $row = $this->where('branch_id', $branchId)->first();
            if ($row) {
                return $row;
            }
        }
        $global = $this->where('branch_id', null)->first();

        // Default pabrik jika belum pernah diatur sama sekali
        return $global ?: [
            'ukuran_kertas'   => '58mm',
            'lebar_custom_mm' => null,
            'font_size'       => 12,
            'tampilkan_logo'  => 1,
            'jumlah_copy'     => 1,
        ];
    }

    /** Lebar aktual dalam mm sesuai pilihan ukuran kertas */
    public static function lebarMm(array $setting): int
    {
        return match ($setting['ukuran_kertas']) {
            '80mm'   => 80,
            'custom' => (int) ($setting['lebar_custom_mm'] ?: 58),
            default  => 58,
        };
    }
}
