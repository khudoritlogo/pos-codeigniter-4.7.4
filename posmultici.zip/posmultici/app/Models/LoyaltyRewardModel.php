<?php

namespace App\Models;

use CodeIgniter\Model;

class LoyaltyRewardModel extends Model
{
    protected $table         = 'loyalty_rewards';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['product_id', 'nama_hadiah', 'poin_dibutuhkan', 'stok_hadiah', 'status'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    protected $validationRules = [
        'nama_hadiah'      => 'required|min_length[2]|max_length[150]',
        'poin_dibutuhkan'  => 'required|integer|greater_than[0]',
    ];

    public function aktif()
    {
        return $this->where('status', 1)->where('stok_hadiah >', 0)->findAll();
    }
}
