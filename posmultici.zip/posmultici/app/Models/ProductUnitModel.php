<?php

namespace App\Models;

use CodeIgniter\Model;

// Multi satuan per barang, mis. Pcs (dasar) -> Box -> Karton, masing-masing dengan konversi & harga sendiri
class ProductUnitModel extends Model
{
    protected $table            = 'product_units';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = ['product_id', 'unit_id', 'konversi', 'harga_jual', 'harga_grosir', 'is_default'];
    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = null;

    public function byProduct(int $productId)
    {
        return $this->select('product_units.*, units.nama_satuan')
            ->join('units', 'units.id = product_units.unit_id')
            ->where('product_id', $productId)
            ->findAll();
    }

    public function deleteByProduct(int $productId)
    {
        return $this->where('product_id', $productId)->delete();
    }
}
