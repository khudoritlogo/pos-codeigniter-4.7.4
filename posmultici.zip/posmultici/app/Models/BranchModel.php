<?php

namespace App\Models;

use CodeIgniter\Model;

class BranchModel extends Model
{
    protected $table            = 'branches';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = [
        'kode_cabang', 'nama_cabang', 'alamat', 'telepon', 'email', 'logo', 'is_pusat', 'status',
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    protected $validationRules = [
        'kode_cabang' => 'required|is_unique[branches.kode_cabang,id,{id}]',
        'nama_cabang' => 'required|min_length[3]|max_length[150]',
    ];
}
