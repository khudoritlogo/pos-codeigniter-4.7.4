<?php

namespace App\Models;

use CodeIgniter\Model;

class SaleReturnModel extends Model
{
    protected $table         = 'sale_returns';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['no_retur', 'sale_id', 'branch_id', 'user_id', 'tanggal', 'total_retur', 'alasan'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = null;

    public function generateNoRetur(int $branchId): string
    {
        $branch = $this->db->table('branches')->where('id', $branchId)->get()->getRow();
        $kode   = $branch->kode_cabang ?? 'PST';
        $prefix = 'RJ-' . $kode . '-' . date('Ymd') . '-';

        $last = $this->where('no_retur LIKE', $prefix . '%')->orderBy('id', 'DESC')->first();
        $urutan = $last ? ((int) substr($last['no_retur'], -4) + 1) : 1;
        return $prefix . str_pad((string) $urutan, 4, '0', STR_PAD_LEFT);
    }

    public function listWithRelations(?int $branchId)
    {
        $builder = $this->select('sale_returns.*, sales.no_invoice, users.nama as nama_user')
            ->join('sales', 'sales.id = sale_returns.sale_id')
            ->join('users', 'users.id = sale_returns.user_id')
            ->orderBy('sale_returns.tanggal', 'DESC');
        if ($branchId !== null) {
            $builder->where('sale_returns.branch_id', $branchId);
        }
        return $builder->findAll();
    }
}
