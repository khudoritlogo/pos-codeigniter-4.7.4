<?php

namespace App\Models;

use CodeIgniter\Model;

class PurchaseReturnModel extends Model
{
    protected $table         = 'purchase_returns';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['no_retur', 'purchase_id', 'branch_id', 'user_id', 'tanggal', 'total_retur', 'alasan'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = null;

    public function generateNoRetur(int $branchId): string
    {
        $branch = $this->db->table('branches')->where('id', $branchId)->get()->getRow();
        $kode   = $branch->kode_cabang ?? 'PST';
        $prefix = 'RB-' . $kode . '-' . date('Ymd') . '-';
        $last   = $this->where('no_retur LIKE', $prefix . '%')->orderBy('id', 'DESC')->first();
        $urutan = $last ? ((int) substr($last['no_retur'], -4) + 1) : 1;
        return $prefix . str_pad((string) $urutan, 4, '0', STR_PAD_LEFT);
    }

    public function listWithRelations(?int $branchId)
    {
        $builder = $this->select('purchase_returns.*, purchases.no_pembelian, users.nama as nama_user')
            ->join('purchases', 'purchases.id = purchase_returns.purchase_id')
            ->join('users', 'users.id = purchase_returns.user_id')
            ->orderBy('purchase_returns.tanggal', 'DESC');
        if ($branchId !== null) {
            $builder->where('purchase_returns.branch_id', $branchId);
        }
        return $builder->findAll();
    }
}
