<?php

namespace App\Models;

use CodeIgniter\Model;

class SaleItemModel extends Model
{
    protected $table         = 'sale_items';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['sale_id', 'product_id', 'unit_id', 'qty', 'harga', 'diskon', 'subtotal', 'qty_retur'];
    protected $useTimestamps = false;

    public function bySale(int $saleId)
    {
        return $this->select('sale_items.*, products.nama_barang, products.jenis_produk, units.nama_satuan')
            ->join('products', 'products.id = sale_items.product_id')
            ->join('units', 'units.id = sale_items.unit_id')
            ->where('sale_id', $saleId)
            ->findAll();
    }
}
