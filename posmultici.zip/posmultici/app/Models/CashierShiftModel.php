<?php

namespace App\Models;

use CodeIgniter\Model;

class CashierShiftModel extends Model
{
    protected $table         = 'cashier_shifts';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = [
        'no_shift', 'branch_id', 'user_id', 'modal_awal', 'waktu_buka', 'waktu_tutup',
        'total_penjualan_cash', 'total_penjualan_non_cash', 'uang_seharusnya', 'uang_fisik_aktual',
        'selisih', 'catatan_penutupan', 'status',
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = null;

    public function generateNoShift(): string
    {
        $prefix = 'SHIFT-' . date('Ymd') . '-';
        $last   = $this->where('no_shift LIKE', $prefix . '%')->orderBy('id', 'DESC')->first();
        $urutan = $last ? ((int) substr($last['no_shift'], -4) + 1) : 1;
        return $prefix . str_pad((string) $urutan, 4, '0', STR_PAD_LEFT);
    }

    /** Shift yang sedang berjalan (belum ditutup) milik seorang kasir */
    public function shiftAktif(int $userId): ?array
    {
        return $this->where('user_id', $userId)->where('status', 'buka')->orderBy('id', 'DESC')->first();
    }

    public function listWithRelations(?int $branchId)
    {
        $builder = $this->select('cashier_shifts.*, users.nama as nama_kasir, branches.nama_cabang')
            ->join('users', 'users.id = cashier_shifts.user_id')
            ->join('branches', 'branches.id = cashier_shifts.branch_id')
            ->orderBy('cashier_shifts.waktu_buka', 'DESC');
        if ($branchId !== null) {
            $builder->where('cashier_shifts.branch_id', $branchId);
        }
        return $builder->findAll();
    }
}
