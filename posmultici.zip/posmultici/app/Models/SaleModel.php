<?php

namespace App\Models;

use CodeIgniter\Model;

class SaleModel extends Model
{
    protected $table            = 'sales';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $allowedFields    = [
        'no_invoice', 'branch_id', 'shift_id', 'customer_id', 'kasir_id', 'kurir_id', 'expedition_id',
        'tipe_transaksi', 'tanggal', 'subtotal', 'diskon', 'diskon_persen', 'pajak', 'grand_total',
        'bayar', 'kembalian', 'metode_bayar', 'status_bayar', 'status_transaksi', 'status_kirim', 'catatan',
        'poin_didapat', 'poin_dipakai',
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    /** Nomor invoice unik: INV-{kode cabang}-{Ymd}-{urutan 4 digit per hari per cabang} */
    public function generateNoInvoice(int $branchId): string
    {
        $branch = $this->db->table('branches')->where('id', $branchId)->get()->getRow();
        $kode   = $branch->kode_cabang ?? 'PST';
        $prefix = 'INV-' . $kode . '-' . date('Ymd') . '-';

        $last = $this->where('no_invoice LIKE', $prefix . '%')->orderBy('id', 'DESC')->first();
        $urutan = 1;
        if ($last) {
            $urutan = (int) substr($last['no_invoice'], -4) + 1;
        }
        return $prefix . str_pad((string) $urutan, 4, '0', STR_PAD_LEFT);
    }

    public function listWithRelations(?int $branchId, ?int $kasirId = null)
    {
        $builder = $this->select('sales.*, customers.nama_customer, users.nama as nama_kasir')
            ->join('customers', 'customers.id = sales.customer_id', 'left')
            ->join('users', 'users.id = sales.kasir_id')
            ->orderBy('sales.tanggal', 'DESC');
        if ($branchId !== null) {
            $builder->where('sales.branch_id', $branchId);
        }
        if ($kasirId !== null) {
            $builder->where('sales.kasir_id', $kasirId);
        }
        return $builder->findAll();
    }
}
