<?php

namespace App\Models;

use CodeIgniter\Model;

// Stok barang non-SN per cabang, dalam satuan dasar barang
class StockModel extends Model
{
    protected $table         = 'stocks';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['product_id', 'branch_id', 'qty', 'updated_at'];
    protected $useTimestamps = false;

    /** Pastikan baris stok ada untuk kombinasi barang+cabang (dibuat dengan qty 0 kalau belum ada) */
    public function ensureRow(int $productId, int $branchId): void
    {
        $exists = $this->where('product_id', $productId)->where('branch_id', $branchId)->first();
        if (! $exists) {
            $this->insert(['product_id' => $productId, 'branch_id' => $branchId, 'qty' => 0, 'updated_at' => date('Y-m-d H:i:s')]);
        }
    }

    public function getQty(int $productId, int $branchId): float
    {
        $row = $this->where('product_id', $productId)->where('branch_id', $branchId)->first();
        return (float) ($row['qty'] ?? 0);
    }

    public function byProductAllBranches(int $productId)
    {
        return $this->select('stocks.*, branches.nama_cabang')
            ->join('branches', 'branches.id = stocks.branch_id')
            ->where('product_id', $productId)
            ->findAll();
    }
}
