<?php

namespace App\Models;

use CodeIgniter\Model;

class SupplierModel extends Model
{
    protected $table            = 'suppliers';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $allowedFields    = [
        'kode_supplier', 'nama_supplier', 'penanggung_jawab', 'telepon', 'email', 'alamat',
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';

    protected $validationRules = [
        'kode_supplier' => 'required|max_length[30]|is_unique[suppliers.kode_supplier,id,{id}]',
        'nama_supplier' => 'required|min_length[2]|max_length[150]',
        'email'         => 'permit_empty|valid_email',
    ];
}
