<?php

namespace App\Models;

use CodeIgniter\Database\BaseBuilder;
use CodeIgniter\Model;

/**
 * Query-query ringkasan untuk halaman dashboard.
 * Semua method menerima $branchId; jika null (Super Admin), data digabung semua cabang.
 */
class DashboardModel extends Model
{
    protected $table = 'sales';

    private function applyBranch(BaseBuilder $builder, ?int $branchId, string $column = 'branch_id'): BaseBuilder
    {
        if ($branchId !== null) {
            $builder->where($column, $branchId);
        }
        return $builder;
    }

    public function totalBarangTerjual(?int $branchId = null): float
    {
        $builder = $this->db->table('sale_items si')
            ->selectSum('si.qty')
            ->join('sales s', 's.id = si.sale_id')
            ->where('s.status_transaksi', 'selesai')
            ->where('s.deleted_at', null);
        if ($branchId !== null) {
            $builder->where('s.branch_id', $branchId);
        }
        return (float) ($builder->get()->getRow()->qty ?? 0);
    }

    public function totalBarang(): int
    {
        return $this->db->table('products')->where('deleted_at', null)->countAllResults();
    }

    public function totalCustomer(): int
    {
        return $this->db->table('customers')->where('deleted_at', null)->countAllResults();
    }

    public function totalInvoice(?int $branchId = null): int
    {
        $builder = $this->db->table('sales')->where('deleted_at', null);
        if ($branchId !== null) {
            $builder->where('branch_id', $branchId);
        }
        return $builder->countAllResults();
    }

    public function barangTerlaris(?int $branchId = null, int $limit = 5): array
    {
        $builder = $this->db->table('sale_items si')
            ->select('p.nama_barang, SUM(si.qty) as total_qty')
            ->join('sales s', 's.id = si.sale_id')
            ->join('products p', 'p.id = si.product_id')
            ->where('s.status_transaksi', 'selesai')
            ->groupBy('p.id, p.nama_barang')
            ->orderBy('total_qty', 'DESC')
            ->limit($limit);
        if ($branchId !== null) {
            $builder->where('s.branch_id', $branchId);
        }
        return $builder->get()->getResultArray();
    }

    public function stokTerkecil(?int $branchId = null, int $limit = 5): array
    {
        $builder = $this->db->table('stocks st')
            ->select('p.nama_barang, st.qty, p.stok_minimal')
            ->join('products p', 'p.id = st.product_id')
            ->where('p.deleted_at', null)
            ->orderBy('st.qty', 'ASC')
            ->limit($limit);
        if ($branchId !== null) {
            $builder->where('st.branch_id', $branchId);
        }
        return $builder->get()->getResultArray();
    }
}
