<?php

namespace App\Models;

use CodeIgniter\Model;

class StockOpnameModel extends Model
{
    protected $table         = 'stock_opnames';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['no_opname', 'branch_id', 'user_id', 'tanggal', 'status', 'catatan'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = null;

    public function generateNoOpname(int $branchId): string
    {
        $branch = $this->db->table('branches')->where('id', $branchId)->get()->getRow();
        $kode   = $branch->kode_cabang ?? 'PST';
        $prefix = 'SO-' . $kode . '-' . date('Ymd') . '-';
        $last   = $this->where('no_opname LIKE', $prefix . '%')->orderBy('id', 'DESC')->first();
        $urutan = $last ? ((int) substr($last['no_opname'], -4) + 1) : 1;
        return $prefix . str_pad((string) $urutan, 4, '0', STR_PAD_LEFT);
    }

    public function listWithRelations(?int $branchId)
    {
        $builder = $this->select('stock_opnames.*, users.nama as nama_user')
            ->join('users', 'users.id = stock_opnames.user_id')
            ->orderBy('stock_opnames.tanggal', 'DESC');
        if ($branchId !== null) {
            $builder->where('stock_opnames.branch_id', $branchId);
        }
        return $builder->findAll();
    }
}
