<?php

namespace App\Models;

use CodeIgniter\Model;

// Fitur #8: batch + tanggal kedaluwarsa, dasar prinsip FEFO (First-Expired-First-Out)
class ProductBatchModel extends Model
{
    protected $table         = 'product_batches';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = [
        'product_id', 'branch_id', 'no_batch', 'tanggal_masuk', 'tanggal_kedaluwarsa',
        'qty_masuk', 'qty_sisa', 'purchase_item_id',
    ];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = null;

    /** Batch yang masih ada sisa qty di sebuah cabang, diurutkan FEFO (expired terdekat duluan) */
    public function batchFefo(int $productId, int $branchId)
    {
        return $this->where('product_id', $productId)
            ->where('branch_id', $branchId)
            ->where('qty_sisa >', 0)
            ->orderBy('tanggal_kedaluwarsa', 'ASC')
            ->findAll();
    }

    /**
     * Kurangi qty_sisa mengikuti urutan FEFO untuk sejumlah qty yang terjual/keluar.
     * Dipanggil dari SaleController saat menyelesaikan transaksi barang ber-batch.
     */
    public function kurangiFefo(int $productId, int $branchId, float $qty): void
    {
        $sisaKurang = $qty;
        foreach ($this->batchFefo($productId, $branchId) as $batch) {
            if ($sisaKurang <= 0) {
                break;
            }
            $ambil = min($sisaKurang, (float) $batch['qty_sisa']);
            $this->update($batch['id'], ['qty_sisa' => (float) $batch['qty_sisa'] - $ambil]);
            $sisaKurang -= $ambil;
        }
    }

    /** Barang yang mendekati/sudah lewat kedaluwarsa, untuk peringatan dini */
    public function mendekatiExpired(?int $branchId, int $hariMendatang = 30)
    {
        $builder = $this->select('product_batches.*, products.nama_barang, products.kode_barang, branches.nama_cabang')
            ->join('products', 'products.id = product_batches.product_id')
            ->join('branches', 'branches.id = product_batches.branch_id')
            ->where('product_batches.qty_sisa >', 0)
            ->where('product_batches.tanggal_kedaluwarsa <=', date('Y-m-d', strtotime("+{$hariMendatang} days")))
            ->orderBy('product_batches.tanggal_kedaluwarsa', 'ASC');
        if ($branchId !== null) {
            $builder->where('product_batches.branch_id', $branchId);
        }
        return $builder->findAll();
    }
}
