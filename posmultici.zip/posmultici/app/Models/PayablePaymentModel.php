<?php

namespace App\Models;

use CodeIgniter\Model;

class PayablePaymentModel extends Model
{
    protected $table         = 'payable_payments';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['payable_id', 'user_id', 'tanggal_bayar', 'jumlah_bayar', 'metode_bayar', 'catatan'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = null;

    public function byPayable(int $payableId)
    {
        return $this->where('payable_id', $payableId)->orderBy('tanggal_bayar', 'DESC')->findAll();
    }
}
