<?php

namespace App\Models;

use CodeIgniter\Model;

class AuditLogModel extends Model
{
    protected $table         = 'audit_logs';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['branch_id', 'user_id', 'aksi', 'ref_table', 'ref_id', 'detail', 'otorisator_id'];
    protected $useTimestamps = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = null;

    public function catat(string $aksi, ?string $refTable, ?int $refId, array $detail, ?int $otorisatorId = null): void
    {
        $session = session();
        $this->insert([
            'branch_id'      => $session->get('branch_id'),
            'user_id'        => $session->get('user_id'),
            'aksi'           => $aksi,
            'ref_table'      => $refTable,
            'ref_id'         => $refId,
            'detail'         => json_encode($detail, JSON_UNESCAPED_UNICODE),
            'otorisator_id'  => $otorisatorId,
        ]);
    }

    public function listWithRelations(?int $branchId)
    {
        $builder = $this->select('audit_logs.*, users.nama as nama_user, otor.nama as nama_otorisator')
            ->join('users', 'users.id = audit_logs.user_id')
            ->join('users otor', 'otor.id = audit_logs.otorisator_id', 'left')
            ->orderBy('audit_logs.created_at', 'DESC')
            ->limit(500);
        if ($branchId !== null) {
            $builder->where('audit_logs.branch_id', $branchId);
        }
        return $builder->findAll();
    }
}
