<?php

namespace App\Models;

use CodeIgniter\Model;

class ExpeditionModel extends Model
{
    protected $table            = 'expeditions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $allowedFields    = ['nama_ekspedisi', 'telepon', 'keterangan'];
    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';
    protected $deletedField     = 'deleted_at';

    protected $validationRules = [
        'nama_ekspedisi' => 'required|min_length[2]|max_length[150]',
    ];
}
