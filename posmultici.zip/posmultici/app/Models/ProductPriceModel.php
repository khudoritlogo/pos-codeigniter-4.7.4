<?php

namespace App\Models;

use CodeIgniter\Model;

// Harga bertingkat/dinamis: mis. beli >=12 pcs harga turun, beda harga utk grosir vs retail
class ProductPriceModel extends Model
{
    protected $table            = 'product_prices';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $allowedFields    = ['product_id', 'unit_id', 'min_qty', 'harga', 'tipe_customer'];
    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = null;

    public function byProduct(int $productId)
    {
        return $this->select('product_prices.*, units.nama_satuan')
            ->join('units', 'units.id = product_prices.unit_id')
            ->where('product_id', $productId)
            ->orderBy('min_qty', 'ASC')
            ->findAll();
    }

    public function deleteByProduct(int $productId)
    {
        return $this->where('product_id', $productId)->delete();
    }

    /**
     * Cari harga yang berlaku untuk qty & tipe customer tertentu (harga bertingkat tertinggi yang qty-nya terpenuhi).
     */
    public function findApplicablePrice(int $productId, int $unitId, float $qty, string $tipeCustomer)
    {
        return $this->where('product_id', $productId)
            ->where('unit_id', $unitId)
            ->where('min_qty <=', $qty)
            ->groupStart()
                ->where('tipe_customer', 'semua')
                ->orWhere('tipe_customer', $tipeCustomer)
            ->groupEnd()
            ->orderBy('min_qty', 'DESC')
            ->first();
    }
}
