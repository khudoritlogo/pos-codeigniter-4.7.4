<?php

namespace App\Models;

use CodeIgniter\Model;

// Log histori cetak barcode (siapa mencetak, berapa label, kapan)
class BarcodePrintModel extends Model
{
    protected $table         = 'barcode_prints';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $allowedFields = ['product_id', 'user_id', 'jumlah_label', 'ukuran_label', 'created_at'];
    protected $useTimestamps = false;
}
