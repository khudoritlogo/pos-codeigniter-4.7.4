<?php

namespace App\Models;

use CodeIgniter\Model;

class CategoryModel extends Model
{
    protected $table            = 'categories';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $allowedFields    = ['kode_kategori', 'nama_kategori'];
    protected $useTimestamps    = true;
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';
    protected $deletedField     = 'deleted_at';

    protected $validationRules = [
        'kode_kategori' => 'required|max_length[30]|is_unique[categories.kode_kategori,id,{id}]',
        'nama_kategori' => 'required|min_length[2]|max_length[150]',
    ];
}
