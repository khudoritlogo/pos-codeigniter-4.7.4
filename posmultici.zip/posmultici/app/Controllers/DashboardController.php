<?php

namespace App\Controllers;

use App\Models\DashboardModel;

class DashboardController extends BaseController
{
    protected DashboardModel $dashboardModel;

    public function __construct()
    {
        $this->dashboardModel = new DashboardModel();
    }

    public function index()
    {
        $user     = $this->currentUser();
        $branchId = $user['branch_id']; // null = super admin, tampilkan data semua cabang

        $data = [
            'title'            => 'Dashboard',
            'user'             => $user,
            'total_terjual'    => $this->dashboardModel->totalBarangTerjual($branchId),
            'total_barang'     => $this->dashboardModel->totalBarang(),
            'total_customer'   => $this->dashboardModel->totalCustomer(),
            'total_invoice'    => $this->dashboardModel->totalInvoice($branchId),
            'barang_terlaris'  => $this->dashboardModel->barangTerlaris($branchId, 5),
            'stok_terkecil'    => $this->dashboardModel->stokTerkecil($branchId, 5),
        ];

        return view('dashboard/index', $data);
    }

    /** Dashboard khusus role Kurir: ringkasan pengiriman + status ketersediaan + link ke daftar lengkap */
    public function kurir()
    {
        $user = $this->currentUser();
        $db   = \Config\Database::connect();

        $pending = $db->table('sales')
            ->where('kurir_id', $user['id'])
            ->whereIn('status_kirim', ['menunggu', 'diproses', 'dikirim'])
            ->countAllResults();

        $selesaiHariIni = $db->table('sales')
            ->where('kurir_id', $user['id'])
            ->where('status_kirim', 'selesai')
            ->where('DATE(tanggal)', date('Y-m-d'))
            ->countAllResults();

        $currentStatus = $db->table('users')->select('status_kurir')->where('id', $user['id'])->get()->getRow();

        return view('dashboard/kurir', [
            'title'          => 'Dashboard Kurir',
            'user'           => $user,
            'pending'        => $pending,
            'selesaiHariIni' => $selesaiHariIni,
            'statusSaatIni'  => $currentStatus->status_kurir ?? 'off',
        ]);
    }
}
