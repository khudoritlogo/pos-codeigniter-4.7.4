<?php

namespace App\Controllers;

use App\Libraries\StockService;
use App\Models\ProductModel;
use App\Models\StockModel;
use App\Models\StockOpnameItemModel;
use App\Models\StockOpnameModel;

class StockOpnameController extends BaseController
{
    protected StockOpnameModel $stockOpnameModel;
    protected StockOpnameItemModel $stockOpnameItemModel;
    protected ProductModel $productModel;
    protected StockModel $stockModel;
    protected StockService $stockService;

    public function __construct()
    {
        $this->stockOpnameModel     = new StockOpnameModel();
        $this->stockOpnameItemModel = new StockOpnameItemModel();
        $this->productModel         = new ProductModel();
        $this->stockModel           = new StockModel();
        $this->stockService         = new StockService();
    }

    public function index()
    {
        return view('stock_opname/index', ['title' => 'Stock Opname']);
    }

    public function data()
    {
        $user = $this->currentUser();
        return $this->response->setJSON(['data' => $this->stockOpnameModel->listWithRelations($user['branch_id'])]);
    }

    public function new()
    {
        $user     = $this->currentUser();
        $branchId = $user['branch_id'];
        if (! $branchId) {
            return redirect()->to('stock-opname')->with('error', 'Super Admin tidak terikat cabang; stock opname harus dilakukan oleh user cabang.');
        }

        $products = $this->productModel->where('status', 1)->where('jenis_produk', 'non_sn')->orderBy('nama_barang')->findAll();
        $productsWithStock = array_map(function ($p) use ($branchId) {
            $p['qty_sistem'] = $this->stockModel->getQty((int) $p['id'], $branchId);
            return $p;
        }, $products);

        return view('stock_opname/form', ['title' => 'Stock Opname Baru', 'products' => $productsWithStock]);
    }

    public function create()
    {
        $user     = $this->currentUser();
        $branchId = $user['branch_id'];

        $productIds = $this->request->getPost('product_id') ?? [];
        $qtySistem  = $this->request->getPost('qty_sistem') ?? [];
        $qtyFisik   = $this->request->getPost('qty_fisik') ?? [];

        $validItems = [];
        foreach ($productIds as $i => $productId) {
            if (! isset($qtyFisik[$i]) || $qtyFisik[$i] === '') {
                continue;
            }
            $validItems[] = [
                'product_id' => $productId,
                'qty_sistem' => (float) ($qtySistem[$i] ?? 0),
                'qty_fisik'  => (float) $qtyFisik[$i],
            ];
        }

        if (empty($validItems)) {
            return redirect()->back()->with('error', 'Isi minimal 1 barang dengan qty fisik hasil hitung.');
        }

        $noOpname = $this->stockOpnameModel->generateNoOpname($branchId);
        $opnameId = $this->stockOpnameModel->insert([
            'no_opname' => $noOpname,
            'branch_id' => $branchId,
            'user_id'   => $user['id'],
            'tanggal'   => date('Y-m-d H:i:s'),
            'status'    => 'draft',
            'catatan'   => $this->request->getPost('catatan'),
        ], true);

        foreach ($validItems as $v) {
            $this->stockOpnameItemModel->insert([
                'stock_opname_id' => $opnameId,
                'product_id'      => $v['product_id'],
                'qty_sistem'      => $v['qty_sistem'],
                'qty_fisik'       => $v['qty_fisik'],
                'selisih'         => $v['qty_fisik'] - $v['qty_sistem'],
            ]);
        }

        return redirect()->to('stock-opname/' . $opnameId)->with('success', "Stock opname {$noOpname} tersimpan sebagai draft. Terapkan penyesuaian stok untuk menyelesaikan.");
    }

    public function detail($id = null)
    {
        $opname = $this->stockOpnameModel->find($id);
        if (! $opname) {
            return redirect()->to('stock-opname')->with('error', 'Data tidak ditemukan.');
        }
        return view('stock_opname/detail', [
            'title'  => 'Detail Stock Opname ' . $opname['no_opname'],
            'opname' => $opname,
            'items'  => $this->stockOpnameItemModel->byOpname((int) $id),
        ]);
    }

    /** Terapkan selisih hasil opname ke stok sesungguhnya (baru boleh dilakukan sekali) */
    public function selesai($id = null)
    {
        $opname = $this->stockOpnameModel->find($id);
        if (! $opname || $opname['status'] !== 'draft') {
            return redirect()->back()->with('error', 'Stock opname sudah diterapkan sebelumnya.');
        }

        $user = $this->currentUser();
        $db = \Config\Database::connect();
        $db->transStart();
        try {
            foreach ($this->stockOpnameItemModel->byOpname((int) $id) as $item) {
                $this->stockService->setTo(
                    (int) $item['product_id'], (int) $opname['branch_id'], (float) $item['qty_fisik'],
                    'opname', 'stock_opnames', (int) $id, "Stock opname {$opname['no_opname']}", $user['id']
                );
            }
            $this->stockOpnameModel->update($id, ['status' => 'selesai']);
            $db->transComplete();
            if ($db->transStatus() === false) {
                throw new \RuntimeException('Gagal menerapkan penyesuaian stok.');
            }
            return redirect()->to('stock-opname/' . $id)->with('success', 'Penyesuaian stok berhasil diterapkan.');
        } catch (\Throwable $e) {
            $db->transRollback();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
