<?php

namespace App\Controllers;

use App\Libraries\BackupService;

/**
 * Backup & Restore Database melalui sistem, khusus Super Admin (lihat AuthGroups).
 * Restore adalah operasi berisiko tinggi -- selalu minta konfirmasi eksplisit di UI
 * dan jalankan dalam transaksi supaya tidak ada perubahan setengah jalan kalau gagal.
 */
class BackupController extends BaseController
{
    protected BackupService $backupService;

    public function __construct()
    {
        $this->backupService = new BackupService();
    }

    public function index()
    {
        return view('backup/index', [
            'title'   => 'Backup & Restore Database',
            'backups' => $this->backupService->listBackups(),
        ]);
    }

    public function create()
    {
        try {
            $filename = $this->backupService->createBackup();
            return redirect()->to('backup-restore')->with('success', "Backup berhasil dibuat: {$filename}");
        } catch (\Throwable $e) {
            return redirect()->to('backup-restore')->with('error', 'Gagal membuat backup: ' . $e->getMessage());
        }
    }

    public function download($filename = null)
    {
        $path = $this->backupService->backupDir() . basename((string) $filename);
        if (! is_file($path)) {
            return redirect()->to('backup-restore')->with('error', 'File backup tidak ditemukan.');
        }
        return $this->response->download($path, null);
    }

    public function delete($filename = null)
    {
        $path = $this->backupService->backupDir() . basename((string) $filename);
        if (is_file($path)) {
            unlink($path);
        }
        return redirect()->to('backup-restore')->with('success', 'File backup berhasil dihapus.');
    }

    /** Restore dari file .sql yang diupload -- perlu konfirmasi checkbox eksplisit di form */
    public function restore()
    {
        if (! $this->request->getPost('konfirmasi')) {
            return redirect()->to('backup-restore')->with('error', 'Restore dibatalkan: konfirmasi belum dicentang.');
        }

        $file = $this->request->getFile('backup_file');
        if (! $file || ! $file->isValid()) {
            return redirect()->to('backup-restore')->with('error', 'File backup tidak valid atau gagal diupload.');
        }
        if (strtolower($file->getClientExtension()) !== 'sql') {
            return redirect()->to('backup-restore')->with('error', 'File harus berformat .sql.');
        }

        try {
            $tmpPath = $file->getTempName();
            $this->backupService->restoreFromFile($tmpPath);
            return redirect()->to('backup-restore')->with('success', 'Database berhasil dipulihkan dari file backup.');
        } catch (\Throwable $e) {
            return redirect()->to('backup-restore')->with('error', 'Gagal restore: ' . $e->getMessage());
        }
    }

    /** Restore langsung dari salah satu file backup yang sudah ada di server (tanpa upload ulang) */
    public function restoreExisting($filename = null)
    {
        if (! $this->request->getPost('konfirmasi')) {
            return redirect()->to('backup-restore')->with('error', 'Restore dibatalkan: konfirmasi belum dicentang.');
        }

        $path = $this->backupService->backupDir() . basename((string) $filename);
        if (! is_file($path)) {
            return redirect()->to('backup-restore')->with('error', 'File backup tidak ditemukan.');
        }

        try {
            $this->backupService->restoreFromFile($path);
            return redirect()->to('backup-restore')->with('success', "Database berhasil dipulihkan dari {$filename}.");
        } catch (\Throwable $e) {
            return redirect()->to('backup-restore')->with('error', 'Gagal restore: ' . $e->getMessage());
        }
    }
}
