<?php

namespace App\Controllers;

use App\Models\BarcodePrintModel;
use App\Models\ProductModel;

class BarcodeController extends BaseController
{
    protected ProductModel $productModel;
    protected BarcodePrintModel $barcodePrintModel;

    public function __construct()
    {
        $this->productModel      = new ProductModel();
        $this->barcodePrintModel = new BarcodePrintModel();
    }

    public function index()
    {
        return view('barcode/index', ['title' => 'Cetak Barcode']);
    }

    /** AJAX: cari barang untuk dipilih ke daftar cetak */
    public function searchProduct()
    {
        $q = trim((string) $this->request->getGet('q'));
        if ($q === '') {
            return $this->response->setJSON(['data' => []]);
        }
        $products = $this->productModel
            ->where('status', 1)
            ->groupStart()->like('nama_barang', $q)->orLike('kode_barang', $q)->orWhere('barcode', $q)->groupEnd()
            ->limit(20)->findAll();

        return $this->response->setJSON(['data' => array_map(fn ($p) => [
            'id' => $p['id'], 'kode_barang' => $p['kode_barang'], 'nama_barang' => $p['nama_barang'],
            'barcode' => $p['barcode'] ?: $p['kode_barang'], 'harga_jual' => $p['harga_jual'],
        ], $products)]);
    }

    /**
     * Terima daftar barang + jumlah label masing-masing + ukuran label yang diinginkan,
     * lalu render halaman siap cetak berisi barcode berulang sesuai jumlah yang diminta.
     * Sesuai fitur "Cetak Barcode sesuai keinginan": ukuran label & kolom per baris bisa diatur bebas.
     */
    public function cetak()
    {
        $productIds   = $this->request->getPost('product_id') ?? [];
        $jumlahLabel  = $this->request->getPost('jumlah_label') ?? [];
        $lebarMm      = (int) ($this->request->getPost('lebar_mm') ?: 40);
        $tinggiMm     = (int) ($this->request->getPost('tinggi_mm') ?: 25);
        $kolom        = (int) ($this->request->getPost('kolom') ?: 3);
        $tampilkanHarga = (bool) $this->request->getPost('tampilkan_harga');

        if (empty($productIds)) {
            return redirect()->back()->with('error', 'Pilih minimal 1 barang untuk dicetak.');
        }

        $user = $this->currentUser();
        $labels = [];
        foreach ($productIds as $i => $productId) {
            $product = $this->productModel->find($productId);
            if (! $product) {
                continue;
            }
            $jumlah = max(1, (int) ($jumlahLabel[$i] ?? 1));
            for ($j = 0; $j < $jumlah; $j++) {
                $labels[] = $product;
            }
            $this->barcodePrintModel->insert([
                'product_id'   => $productId,
                'user_id'      => $user['id'],
                'jumlah_label' => $jumlah,
                'ukuran_label' => "{$lebarMm}x{$tinggiMm}mm",
                'created_at'   => date('Y-m-d H:i:s'),
            ]);
        }

        return view('barcode/print', [
            'labels'         => $labels,
            'lebarMm'        => $lebarMm,
            'tinggiMm'       => $tinggiMm,
            'kolom'          => $kolom,
            'tampilkanHarga' => $tampilkanHarga,
        ]);
    }
}
