<?php

namespace App\Controllers;

use App\Libraries\DataTableServerSide;
use App\Libraries\ExportService;
use CodeIgniter\Database\BaseConnection;

class ReportController extends BaseController
{
    protected BaseConnection $conn;

    public function __construct()
    {
        $this->conn = \Config\Database::connect();
    }

    /** Rentang tanggal dari querystring, default: awal bulan ini s/d hari ini */
    private function periode(): array
    {
        $from = $this->request->getGet('dari') ?: date('Y-m-01');
        $to   = $this->request->getGet('sampai') ?: date('Y-m-d');
        return [$from, $to];
    }

    /** branch_id efektif: user cabang selalu terkunci ke cabangnya; Super Admin bebas pilih lewat filter */
    private function effectiveBranchId(): ?int
    {
        $user = $this->currentUser();
        if ($user['branch_id'] !== null) {
            return $user['branch_id'];
        }
        $filter = $this->request->getGet('branch_id');
        return $filter !== null && $filter !== '' ? (int) $filter : null;
    }

    private function branchOptions(): array
    {
        return $this->conn->table('branches')->where('status', 1)->get()->getResultArray();
    }

    // ============================== 1. LAPORAN KASIR ==============================
    public function kasir()
    {
        [$from, $to] = $this->periode();
        $user = $this->currentUser();
        $branchId = $this->effectiveBranchId();

        $builder = $this->conn->table('sales s')
            ->select('users.nama as nama_kasir, COUNT(s.id) as jumlah_transaksi, SUM(s.grand_total) as total_penjualan')
            ->join('users', 'users.id = s.kasir_id')
            ->where('s.status_transaksi', 'selesai')
            ->where('s.deleted_at', null)
            ->where('DATE(s.tanggal) >=', $from)
            ->where('DATE(s.tanggal) <=', $to)
            ->groupBy('s.kasir_id, users.nama')
            ->orderBy('total_penjualan', 'DESC');

        if ($branchId !== null) {
            $builder->where('s.branch_id', $branchId);
        }
        // Kasir hanya boleh melihat performanya sendiri (laporan pribadi)
        if ($user['role_code'] === 'kasir') {
            $builder->where('s.kasir_id', $user['id']);
        }

        $rows = $builder->get()->getResultArray();

        $headers = ['nama_kasir' => 'Nama Kasir', 'jumlah_transaksi' => 'Jumlah Transaksi', 'total_penjualan' => 'Total Penjualan'];
        if ($this->maybeExport($headers, $rows, 'laporan_kasir', 'Laporan Kasir')) {
            return;
        }

        return view('report/kasir', [
            'title' => 'Laporan Kasir', 'rows' => $rows, 'from' => $from, 'to' => $to,
            'branches' => $this->branchOptions(), 'branchId' => $branchId,
        ]);
    }

    // ============================== 2. LAPORAN CUSTOMER ==============================
    public function customer()
    {
        [$from, $to] = $this->periode();
        $branchId = $this->effectiveBranchId();

        $builder = $this->conn->table('customers c')
            ->select('c.kode_customer, c.nama_customer, c.tipe_customer, COUNT(s.id) as jumlah_transaksi, COALESCE(SUM(s.grand_total),0) as total_belanja')
            ->join('sales s', 's.customer_id = c.id AND s.status_transaksi = "selesai" AND DATE(s.tanggal) >= ' . $this->conn->escape($from) . ' AND DATE(s.tanggal) <= ' . $this->conn->escape($to) . ($branchId !== null ? ' AND s.branch_id = ' . (int) $branchId : ''), 'left')
            ->where('c.deleted_at', null)
            ->groupBy('c.id, c.kode_customer, c.nama_customer, c.tipe_customer')
            ->orderBy('total_belanja', 'DESC');

        $rows = $builder->get()->getResultArray();

        $headers = ['kode_customer' => 'Kode', 'nama_customer' => 'Nama Customer', 'tipe_customer' => 'Tipe', 'jumlah_transaksi' => 'Jumlah Transaksi', 'total_belanja' => 'Total Belanja'];
        if ($this->maybeExport($headers, $rows, 'laporan_customer', 'Laporan Customer')) {
            return;
        }

        return view('report/customer', [
            'title' => 'Laporan Customer', 'rows' => $rows, 'from' => $from, 'to' => $to,
            'branches' => $this->branchOptions(), 'branchId' => $branchId,
        ]);
    }

    // ============================== 3. LAPORAN PENJUALAN PER PERIODE (DataTable server-side) ==============================
    public function penjualanPeriode()
    {
        [$from, $to] = $this->periode();
        return view('report/penjualan_periode', [
            'title' => 'Laporan Penjualan per Periode', 'from' => $from, 'to' => $to,
            'branches' => $this->branchOptions(), 'branchId' => $this->effectiveBranchId(),
        ]);
    }

    /** Endpoint DataTable server-side untuk Laporan Penjualan per Periode */
    public function penjualanPeriodeData()
    {
        [$from, $to] = $this->periode();
        $branchId = $this->effectiveBranchId();

        $builder = $this->conn->table('sales s')
            ->select('s.no_invoice, s.tanggal, branches.nama_cabang, COALESCE(customers.nama_customer, "Umum") as nama_customer, users.nama as nama_kasir, s.grand_total, s.metode_bayar, s.status_transaksi')
            ->join('branches', 'branches.id = s.branch_id')
            ->join('customers', 'customers.id = s.customer_id', 'left')
            ->join('users', 'users.id = s.kasir_id')
            ->where('s.deleted_at', null)
            ->where('DATE(s.tanggal) >=', $from)
            ->where('DATE(s.tanggal) <=', $to);

        if ($branchId !== null) {
            $builder->where('s.branch_id', $branchId);
        }

        $result = DataTableServerSide::process(
            $builder,
            ['s.no_invoice', 'customers.nama_customer', 'users.nama'],
            ['s.no_invoice', 's.tanggal', 'branches.nama_cabang', 'nama_customer', 'users.nama', 's.grand_total', 's.metode_bayar', 's.status_transaksi'],
            $this->request->getGet()
        );

        return $this->response->setJSON($result);
    }

    public function penjualanPeriodeExport()
    {
        [$from, $to] = $this->periode();
        $branchId = $this->effectiveBranchId();

        $builder = $this->conn->table('sales s')
            ->select('s.no_invoice, s.tanggal, branches.nama_cabang, COALESCE(customers.nama_customer, "Umum") as nama_customer, users.nama as nama_kasir, s.grand_total, s.metode_bayar, s.status_transaksi')
            ->join('branches', 'branches.id = s.branch_id')
            ->join('customers', 'customers.id = s.customer_id', 'left')
            ->join('users', 'users.id = s.kasir_id')
            ->where('s.deleted_at', null)
            ->where('DATE(s.tanggal) >=', $from)
            ->where('DATE(s.tanggal) <=', $to);
        if ($branchId !== null) {
            $builder->where('s.branch_id', $branchId);
        }
        $rows = $builder->orderBy('s.tanggal', 'DESC')->get()->getResultArray();

        $headers = ['no_invoice' => 'No Invoice', 'tanggal' => 'Tanggal', 'nama_cabang' => 'Cabang', 'nama_customer' => 'Customer', 'nama_kasir' => 'Kasir', 'grand_total' => 'Grand Total', 'metode_bayar' => 'Metode Bayar', 'status_transaksi' => 'Status'];
        $this->maybeExport($headers, $rows, 'laporan_penjualan_periode', 'Laporan Penjualan per Periode', true);
    }

    // ============================== 4. LAPORAN PENJUALAN RETUR ==============================
    public function penjualanRetur()
    {
        [$from, $to] = $this->periode();
        $branchId = $this->effectiveBranchId();

        $builder = $this->conn->table('sale_returns sr')
            ->select('sr.no_retur, sr.tanggal, sales.no_invoice, users.nama as nama_user, sr.total_retur, sr.alasan')
            ->join('sales', 'sales.id = sr.sale_id')
            ->join('users', 'users.id = sr.user_id')
            ->where('DATE(sr.tanggal) >=', $from)
            ->where('DATE(sr.tanggal) <=', $to)
            ->orderBy('sr.tanggal', 'DESC');
        if ($branchId !== null) {
            $builder->where('sr.branch_id', $branchId);
        }
        $rows = $builder->get()->getResultArray();

        $headers = ['no_retur' => 'No Retur', 'tanggal' => 'Tanggal', 'no_invoice' => 'No Invoice', 'nama_user' => 'Oleh', 'total_retur' => 'Total Retur', 'alasan' => 'Alasan'];
        if ($this->maybeExport($headers, $rows, 'laporan_penjualan_retur', 'Laporan Penjualan Retur')) {
            return;
        }

        return view('report/penjualan_retur', [
            'title' => 'Laporan Penjualan Retur', 'rows' => $rows, 'from' => $from, 'to' => $to,
            'branches' => $this->branchOptions(), 'branchId' => $branchId,
        ]);
    }

    // ============================== 5. LAPORAN DATA SUPPLIER ==============================
    public function supplier()
    {
        [$from, $to] = $this->periode();

        $builder = $this->conn->table('suppliers sup')
            ->select('sup.kode_supplier, sup.nama_supplier, sup.telepon, COUNT(p.id) as jumlah_transaksi, COALESCE(SUM(p.grand_total),0) as total_pembelian')
            ->join('purchases p', 'p.supplier_id = sup.id AND DATE(p.tanggal) >= ' . $this->conn->escape($from) . ' AND DATE(p.tanggal) <= ' . $this->conn->escape($to) . ' AND p.deleted_at IS NULL', 'left')
            ->where('sup.deleted_at', null)
            ->groupBy('sup.id, sup.kode_supplier, sup.nama_supplier, sup.telepon')
            ->orderBy('total_pembelian', 'DESC');
        $rows = $builder->get()->getResultArray();

        $headers = ['kode_supplier' => 'Kode', 'nama_supplier' => 'Nama Supplier', 'telepon' => 'Telepon', 'jumlah_transaksi' => 'Jumlah Transaksi', 'total_pembelian' => 'Total Pembelian'];
        if ($this->maybeExport($headers, $rows, 'laporan_supplier', 'Laporan Data Supplier')) {
            return;
        }

        return view('report/supplier', ['title' => 'Laporan Data Supplier', 'rows' => $rows, 'from' => $from, 'to' => $to]);
    }

    // ============================== 6. LAPORAN PEMBELIAN PER PERIODE ==============================
    public function pembelianPeriode()
    {
        [$from, $to] = $this->periode();
        $branchId = $this->effectiveBranchId();

        $builder = $this->conn->table('purchases p')
            ->select('p.no_pembelian, p.tanggal, branches.nama_cabang, suppliers.nama_supplier, users.nama as nama_user, p.grand_total, p.metode_bayar, p.status_bayar')
            ->join('branches', 'branches.id = p.branch_id')
            ->join('suppliers', 'suppliers.id = p.supplier_id')
            ->join('users', 'users.id = p.user_id')
            ->where('p.deleted_at', null)
            ->where('DATE(p.tanggal) >=', $from)
            ->where('DATE(p.tanggal) <=', $to)
            ->orderBy('p.tanggal', 'DESC');
        if ($branchId !== null) {
            $builder->where('p.branch_id', $branchId);
        }
        $rows = $builder->get()->getResultArray();

        $headers = ['no_pembelian' => 'No Pembelian', 'tanggal' => 'Tanggal', 'nama_cabang' => 'Cabang', 'nama_supplier' => 'Supplier', 'nama_user' => 'Oleh', 'grand_total' => 'Grand Total', 'metode_bayar' => 'Metode Bayar', 'status_bayar' => 'Status Bayar'];
        if ($this->maybeExport($headers, $rows, 'laporan_pembelian_periode', 'Laporan Pembelian per Periode')) {
            return;
        }

        return view('report/pembelian_periode', [
            'title' => 'Laporan Pembelian per Periode', 'rows' => $rows, 'from' => $from, 'to' => $to,
            'branches' => $this->branchOptions(), 'branchId' => $branchId,
        ]);
    }

    // ============================== 7. LAPORAN PEMBELIAN RETUR ==============================
    public function pembelianRetur()
    {
        [$from, $to] = $this->periode();
        $branchId = $this->effectiveBranchId();

        $builder = $this->conn->table('purchase_returns pr')
            ->select('pr.no_retur, pr.tanggal, purchases.no_pembelian, users.nama as nama_user, pr.total_retur, pr.alasan')
            ->join('purchases', 'purchases.id = pr.purchase_id')
            ->join('users', 'users.id = pr.user_id')
            ->where('DATE(pr.tanggal) >=', $from)
            ->where('DATE(pr.tanggal) <=', $to)
            ->orderBy('pr.tanggal', 'DESC');
        if ($branchId !== null) {
            $builder->where('pr.branch_id', $branchId);
        }
        $rows = $builder->get()->getResultArray();

        $headers = ['no_retur' => 'No Retur', 'tanggal' => 'Tanggal', 'no_pembelian' => 'No Pembelian', 'nama_user' => 'Oleh', 'total_retur' => 'Total Retur', 'alasan' => 'Alasan'];
        if ($this->maybeExport($headers, $rows, 'laporan_pembelian_retur', 'Laporan Pembelian Retur')) {
            return;
        }

        return view('report/pembelian_retur', [
            'title' => 'Laporan Pembelian Retur', 'rows' => $rows, 'from' => $from, 'to' => $to,
            'branches' => $this->branchOptions(), 'branchId' => $branchId,
        ]);
    }

    // ============================== 8. LAPORAN BARANG TERLARIS ==============================
    public function barangTerlaris()
    {
        [$from, $to] = $this->periode();
        $branchId = $this->effectiveBranchId();

        $builder = $this->conn->table('sale_items si')
            ->select('products.kode_barang, products.nama_barang, SUM(si.qty) as total_qty, SUM(si.subtotal) as total_nilai')
            ->join('sales s', 's.id = si.sale_id')
            ->join('products', 'products.id = si.product_id')
            ->where('s.status_transaksi', 'selesai')
            ->where('DATE(s.tanggal) >=', $from)
            ->where('DATE(s.tanggal) <=', $to)
            ->groupBy('products.id, products.kode_barang, products.nama_barang')
            ->orderBy('total_qty', 'DESC')
            ->limit(50);
        if ($branchId !== null) {
            $builder->where('s.branch_id', $branchId);
        }
        $rows = $builder->get()->getResultArray();

        $headers = ['kode_barang' => 'Kode', 'nama_barang' => 'Nama Barang', 'total_qty' => 'Qty Terjual', 'total_nilai' => 'Total Nilai'];
        if ($this->maybeExport($headers, $rows, 'laporan_barang_terlaris', 'Laporan Barang Terlaris')) {
            return;
        }

        return view('report/barang_terlaris', [
            'title' => 'Laporan Barang Terlaris', 'rows' => $rows, 'from' => $from, 'to' => $to,
            'branches' => $this->branchOptions(), 'branchId' => $branchId,
        ]);
    }

    // ============================== 9. LAPORAN STOK TERKECIL ==============================
    public function stokTerkecil()
    {
        $branchId = $this->effectiveBranchId();

        $builder = $this->conn->table('stocks st')
            ->select('products.kode_barang, products.nama_barang, branches.nama_cabang, st.qty, products.stok_minimal')
            ->join('products', 'products.id = st.product_id')
            ->join('branches', 'branches.id = st.branch_id')
            ->where('products.deleted_at', null)
            ->where('st.qty <=', 'products.stok_minimal', false) // qty <= stok_minimal (perbandingan antar kolom)
            ->orderBy('st.qty', 'ASC');
        if ($branchId !== null) {
            $builder->where('st.branch_id', $branchId);
        }
        $rows = $builder->get()->getResultArray();

        $headers = ['kode_barang' => 'Kode', 'nama_barang' => 'Nama Barang', 'nama_cabang' => 'Cabang', 'qty' => 'Stok Saat Ini', 'stok_minimal' => 'Stok Minimal'];
        if ($this->maybeExport($headers, $rows, 'laporan_stok_terkecil', 'Laporan Stok Terkecil')) {
            return;
        }

        return view('report/stok_terkecil', [
            'title' => 'Laporan Stok Terkecil', 'rows' => $rows,
            'branches' => $this->branchOptions(), 'branchId' => $branchId,
        ]);
    }

    // ============================== 10. LAPORAN KURIR ==============================
    public function kurir()
    {
        [$from, $to] = $this->periode();
        $user = $this->currentUser();
        $branchId = $this->effectiveBranchId();

        $builder = $this->conn->table('sales s')
            ->select('s.no_invoice, s.tanggal, kurir.nama as nama_kurir, s.status_kirim, expeditions.nama_ekspedisi, s.grand_total')
            ->join('users kurir', 'kurir.id = s.kurir_id', 'left')
            ->join('expeditions', 'expeditions.id = s.expedition_id', 'left')
            ->where('s.kurir_id IS NOT NULL')
            ->where('DATE(s.tanggal) >=', $from)
            ->where('DATE(s.tanggal) <=', $to)
            ->orderBy('s.tanggal', 'DESC');
        if ($branchId !== null) {
            $builder->where('s.branch_id', $branchId);
        }
        // Role kurir hanya boleh melihat pengiriman miliknya sendiri (laporan pribadi)
        if ($user['role_code'] === 'kurir') {
            $builder->where('s.kurir_id', $user['id']);
        }
        $rows = $builder->get()->getResultArray();

        $headers = ['no_invoice' => 'No Invoice', 'tanggal' => 'Tanggal', 'nama_kurir' => 'Kurir', 'status_kirim' => 'Status Kirim', 'nama_ekspedisi' => 'Ekspedisi', 'grand_total' => 'Grand Total'];
        if ($this->maybeExport($headers, $rows, 'laporan_kurir', 'Laporan Kurir')) {
            return;
        }

        return view('report/kurir', [
            'title' => 'Laporan Kurir', 'rows' => $rows, 'from' => $from, 'to' => $to,
            'branches' => $this->branchOptions(), 'branchId' => $branchId,
        ]);
    }

    // ============================== 11. LAPORAN CASH & TRANSFER ==============================
    public function cashTransfer()
    {
        [$from, $to] = $this->periode();
        $branchId = $this->effectiveBranchId();

        $builder = $this->conn->table('sales s')
            ->select('s.metode_bayar, COUNT(s.id) as jumlah_transaksi, SUM(s.grand_total) as total_nilai')
            ->where('s.status_transaksi', 'selesai')
            ->where('s.deleted_at', null)
            ->where('DATE(s.tanggal) >=', $from)
            ->where('DATE(s.tanggal) <=', $to)
            ->groupBy('s.metode_bayar');
        if ($branchId !== null) {
            $builder->where('s.branch_id', $branchId);
        }
        $rows = $builder->get()->getResultArray();

        $headers = ['metode_bayar' => 'Metode Bayar', 'jumlah_transaksi' => 'Jumlah Transaksi', 'total_nilai' => 'Total Nilai'];
        if ($this->maybeExport($headers, $rows, 'laporan_cash_transfer', 'Laporan Cash & Transfer')) {
            return;
        }

        return view('report/cash_transfer', [
            'title' => 'Laporan Transaksi Cash & Transfer', 'rows' => $rows, 'from' => $from, 'to' => $to,
            'branches' => $this->branchOptions(), 'branchId' => $branchId,
        ]);
    }

    // ============================== 12. LABA BERSIH PER PERIODE ==============================
    public function labaBersih()
    {
        [$from, $to] = $this->periode();
        $branchId = $this->effectiveBranchId();

        $builder = $this->conn->table('sale_items si')
            ->select('DATE(s.tanggal) as tgl, SUM(si.subtotal) as total_penjualan, SUM(si.qty * products.harga_beli) as total_hpp')
            ->join('sales s', 's.id = si.sale_id')
            ->join('products', 'products.id = si.product_id')
            ->where('s.status_transaksi', 'selesai')
            ->where('DATE(s.tanggal) >=', $from)
            ->where('DATE(s.tanggal) <=', $to)
            ->groupBy('DATE(s.tanggal)')
            ->orderBy('tgl', 'ASC');
        if ($branchId !== null) {
            $builder->where('s.branch_id', $branchId);
        }
        $rows = $builder->get()->getResultArray();

        $totalPenjualan = 0; $totalHpp = 0;
        foreach ($rows as &$r) {
            $r['laba_kotor'] = $r['total_penjualan'] - $r['total_hpp'];
            $totalPenjualan += $r['total_penjualan'];
            $totalHpp += $r['total_hpp'];
        }
        unset($r);

        $headers = ['tgl' => 'Tanggal', 'total_penjualan' => 'Total Penjualan', 'total_hpp' => 'Total HPP', 'laba_kotor' => 'Laba Kotor'];
        if ($this->maybeExport($headers, $rows, 'laporan_laba_bersih', 'Laba Bersih per Periode')) {
            return;
        }

        return view('report/laba_bersih', [
            'title' => 'Laba Bersih per Periode', 'rows' => $rows, 'from' => $from, 'to' => $to,
            'branches' => $this->branchOptions(), 'branchId' => $branchId,
            'totalPenjualan' => $totalPenjualan, 'totalHpp' => $totalHpp, 'totalLaba' => $totalPenjualan - $totalHpp,
        ]);
    }

    // ============================== 13. LAPORAN BARANG KEDALUWARSA (Fitur #8) ==============================
    public function expiredWarning()
    {
        $branchId = $this->effectiveBranchId();
        $batchModel = new \App\Models\ProductBatchModel();
        $hariMendatang = (int) ($this->request->getGet('hari') ?: 30);

        $rows = $batchModel->mendekatiExpired($branchId, $hariMendatang);
        foreach ($rows as &$r) {
            $r['sisa_hari'] = (int) floor((strtotime($r['tanggal_kedaluwarsa']) - time()) / 86400);
        }
        unset($r);

        $headers = ['kode_barang' => 'Kode', 'nama_barang' => 'Nama Barang', 'nama_cabang' => 'Cabang', 'no_batch' => 'No Batch', 'tanggal_kedaluwarsa' => 'Tgl Kedaluwarsa', 'qty_sisa' => 'Qty Sisa', 'sisa_hari' => 'Sisa Hari'];
        if ($this->maybeExport($headers, $rows, 'laporan_kedaluwarsa', 'Laporan Barang Mendekati Kedaluwarsa')) {
            return;
        }

        return view('report/kedaluwarsa', [
            'title' => 'Barang Mendekati Kedaluwarsa', 'rows' => $rows,
            'branches' => $this->branchOptions(), 'branchId' => $branchId, 'hariMendatang' => $hariMendatang,
        ]);
    }

    /**
     * Cek parameter ?format=csv|txt di querystring (atau force=true untuk endpoint export terpisah)
     * dan jika ada, langsung kirim file lalu hentikan eksekusi -- dipanggil di setiap method laporan.
     */
    private function maybeExport(array $headers, array $rows, string $filename, string $title, bool $force = false): bool
    {
        $format = $this->request->getGet('format');
        if (! $force && ! $format) {
            return false;
        }
        $format = $format ?: $this->request->getGet('format');

        if ($format === 'csv') {
            ExportService::toCsv($headers, $rows, $filename . '_' . date('Ymd'));
        } elseif ($format === 'txt') {
            ExportService::toTxt($headers, $rows, $filename . '_' . date('Ymd'), $title);
        }
        return true;
    }
}
