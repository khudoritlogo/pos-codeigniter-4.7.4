<?php

namespace App\Controllers;

use App\Models\ExpeditionModel;

class ExpeditionController extends BaseController
{
    protected ExpeditionModel $expeditionModel;

    public function __construct()
    {
        $this->expeditionModel = new ExpeditionModel();
    }

    public function index()
    {
        return view('master/expedition/index', ['title' => 'Ekspedisi']);
    }

    public function data()
    {
        return $this->response->setJSON(['data' => $this->expeditionModel->orderBy('nama_ekspedisi', 'ASC')->findAll()]);
    }

    public function new()
    {
        return view('master/expedition/form', ['title' => 'Tambah Ekspedisi', 'expedition' => null]);
    }

    public function create()
    {
        if (! $this->validateData($this->request->getPost(), $this->expeditionModel->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->expeditionModel->insert($this->request->getPost(['nama_ekspedisi', 'telepon', 'keterangan']));
        return redirect()->to('ekspedisi')->with('success', 'Ekspedisi berhasil ditambahkan.');
    }

    public function edit($id = null)
    {
        $expedition = $this->expeditionModel->find($id);
        if (! $expedition) {
            return redirect()->to('ekspedisi')->with('error', 'Data tidak ditemukan.');
        }
        return view('master/expedition/form', ['title' => 'Edit Ekspedisi', 'expedition' => $expedition]);
    }

    public function update($id = null)
    {
        if (! $this->validateData($this->request->getPost(), $this->expeditionModel->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->expeditionModel->update($id, $this->request->getPost(['nama_ekspedisi', 'telepon', 'keterangan']));
        return redirect()->to('ekspedisi')->with('success', 'Ekspedisi berhasil diperbarui.');
    }

    public function delete($id = null)
    {
        $this->expeditionModel->delete($id);
        return redirect()->to('ekspedisi')->with('success', 'Ekspedisi berhasil dihapus.');
    }
}
