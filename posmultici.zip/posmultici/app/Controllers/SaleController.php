<?php

namespace App\Controllers;

use App\Libraries\LoyaltyService;
use App\Libraries\StockService;
use App\Models\AuditLogModel;
use App\Models\BranchModel;
use App\Models\CashierShiftModel;
use App\Models\CustomerModel;
use App\Models\ExpeditionModel;
use App\Models\ProductBatchModel;
use App\Models\ProductModel;
use App\Models\ProductPriceModel;
use App\Models\ProductSerialModel;
use App\Models\ProductUnitModel;
use App\Models\ReceivableModel;
use App\Models\SaleItemModel;
use App\Models\SaleModel;
use App\Models\UserModel;

class SaleController extends BaseController
{
    protected SaleModel $saleModel;
    protected SaleItemModel $saleItemModel;
    protected ProductModel $productModel;
    protected ProductUnitModel $productUnitModel;
    protected ProductPriceModel $productPriceModel;
    protected ProductSerialModel $serialModel;
    protected ProductBatchModel $batchModel;
    protected CustomerModel $customerModel;
    protected ReceivableModel $receivableModel;
    protected CashierShiftModel $shiftModel;
    protected AuditLogModel $auditLogModel;
    protected StockService $stockService;
    protected LoyaltyService $loyaltyService;

    public function __construct()
    {
        $this->saleModel         = new SaleModel();
        $this->saleItemModel     = new SaleItemModel();
        $this->productModel      = new ProductModel();
        $this->productUnitModel  = new ProductUnitModel();
        $this->productPriceModel = new ProductPriceModel();
        $this->serialModel       = new ProductSerialModel();
        $this->batchModel        = new ProductBatchModel();
        $this->customerModel     = new CustomerModel();
        $this->receivableModel   = new ReceivableModel();
        $this->shiftModel        = new CashierShiftModel();
        $this->auditLogModel     = new AuditLogModel();
        $this->stockService      = new StockService();
        $this->loyaltyService    = new LoyaltyService();
    }

    /** Layar kasir (POS) untuk transaksi baru -- wajib sudah buka shift dulu (Fitur #3) */
    public function posScreen()
    {
        $user = $this->currentUser();

        $shiftAktif = $user['role_code'] === 'kasir' ? $this->shiftModel->shiftAktif($user['id']) : ['id' => null];
        if ($user['role_code'] === 'kasir' && ! $shiftAktif) {
            return redirect()->to('shift-kasir/buka')->with('error', 'Anda wajib membuka shift terlebih dahulu sebelum bertransaksi.');
        }

        return view('sale/pos', [
            'title'      => 'Transaksi Kasir',
            'user'       => $user,
            'customers'  => $this->customerModel->listWithLevel(),
            'branches'   => $user['branch_id'] === null ? (new BranchModel())->where('status', 1)->findAll() : [],
            'expeditions'=> (new ExpeditionModel())->orderBy('nama_ekspedisi')->findAll(),
            'shiftAktif' => $shiftAktif,
            'resume'     => null,
        ]);
    }

    /** Lanjutkan transaksi pending yang sudah tersimpan sebelumnya */
    public function resumePending($id = null)
    {
        $sale = $this->saleModel->find($id);
        if (! $sale || $sale['status_transaksi'] !== 'pending') {
            return redirect()->to('kasir')->with('error', 'Transaksi pending tidak ditemukan.');
        }
        $user = $this->currentUser();
        $shiftAktif = $user['role_code'] === 'kasir' ? $this->shiftModel->shiftAktif($user['id']) : ['id' => null];

        return view('sale/pos', [
            'title'      => 'Lanjutkan Transaksi Pending',
            'user'       => $user,
            'customers'  => $this->customerModel->listWithLevel(),
            'branches'   => [],
            'expeditions'=> (new ExpeditionModel())->orderBy('nama_ekspedisi')->findAll(),
            'shiftAktif' => $shiftAktif,
            'resume'     => [
                'sale'  => $sale,
                'items' => $this->saleItemModel->bySale((int) $id),
            ],
        ]);
    }

    public function pendingList()
    {
        $user = $this->currentUser();
        $sales = $this->saleModel->where('status_transaksi', 'pending')
            ->where($user['branch_id'] !== null ? 'branch_id' : '1', $user['branch_id'] !== null ? $user['branch_id'] : 1)
            ->orderBy('tanggal', 'DESC')->findAll();
        return view('sale/pending', ['title' => 'Transaksi Pending', 'sales' => $sales]);
    }

    /**
     * AJAX: cari barang berdasarkan barcode atau nama, kembalikan harga & satuan yang berlaku
     * (mendukung barcode scanner: hasil exact-match barcode otomatis ada di urutan pertama).
     */
    public function searchProduct()
    {
        $q         = trim((string) $this->request->getGet('q'));
        $branchId  = (int) $this->request->getGet('branch_id');
        $tipe      = $this->request->getGet('tipe') ?: 'retail';

        if ($q === '' || $branchId === 0) {
            return $this->response->setJSON(['data' => []]);
        }

        $products = $this->productModel
            ->where('status', 1)
            ->groupStart()
                ->like('nama_barang', $q)
                ->orLike('kode_barang', $q)
                ->orWhere('barcode', $q)
            ->groupEnd()
            ->limit(20)
            ->findAll();

        $result = [];
        foreach ($products as $p) {
            $stok = $this->stockService->stokTersedia((int) $p['id'], $branchId, $p['jenis_produk']);

            $unitOptions = [[
                'unit_id'      => $p['unit_id'],
                'nama_satuan'  => $this->productModel->db->table('units')->where('id', $p['unit_id'])->get()->getRow()->nama_satuan ?? '',
                'konversi'     => 1,
                'harga'        => $tipe === 'grosir' && $p['harga_grosir'] > 0 ? $p['harga_grosir'] : $p['harga_jual'],
                'is_default'   => true,
            ]];
            foreach ($this->productUnitModel->byProduct((int) $p['id']) as $pu) {
                $unitOptions[] = [
                    'unit_id'     => $pu['unit_id'],
                    'nama_satuan' => $pu['nama_satuan'],
                    'konversi'    => $pu['konversi'],
                    'harga'       => $tipe === 'grosir' && $pu['harga_grosir'] > 0 ? $pu['harga_grosir'] : $pu['harga_jual'],
                    'is_default'  => false,
                ];
            }

            $result[] = [
                'id'           => $p['id'],
                'kode_barang'  => $p['kode_barang'],
                'barcode'      => $p['barcode'],
                'nama_barang'  => $p['nama_barang'],
                'jenis_produk' => $p['jenis_produk'],
                'stok'         => $stok,
                'units'        => $unitOptions,
                'exact_barcode'=> ($p['barcode'] === $q),
            ];
        }

        // barcode exact match diprioritaskan paling atas (penting untuk alur scan cepat)
        usort($result, fn ($a, $b) => $b['exact_barcode'] <=> $a['exact_barcode']);

        return $this->response->setJSON(['data' => $result]);
    }

    /** AJAX: ambil daftar serial number tersedia untuk barang jenis SN */
    public function serialsAvailable()
    {
        $productId = (int) $this->request->getGet('product_id');
        $branchId  = (int) $this->request->getGet('branch_id');
        $serials   = $this->serialModel->tersediaDiCabang($productId, $branchId);
        return $this->response->setJSON(['data' => $serials]);
    }

    /** AJAX: cek harga bertingkat yang berlaku untuk qty & tipe customer tertentu */
    public function checkTieredPrice()
    {
        $productId = (int) $this->request->getGet('product_id');
        $unitId    = (int) $this->request->getGet('unit_id');
        $qty       = (float) $this->request->getGet('qty');
        $tipe      = $this->request->getGet('tipe') ?: 'retail';

        $price = $this->productPriceModel->findApplicablePrice($productId, $unitId, $qty, $tipe);
        return $this->response->setJSON(['harga' => $price['harga'] ?? null]);
    }

    /** Simpan transaksi (baru atau melanjutkan pending) */
    public function store()
    {
        $payload = $this->request->getJSON(true);
        $user    = $this->currentUser();

        $branchId = $user['branch_id'] ?? (int) ($payload['branch_id'] ?? 0);
        if (! $branchId) {
            return $this->response->setJSON(['success' => false, 'message' => 'Cabang tidak valid.'])->setStatusCode(422);
        }
        if (empty($payload['items'])) {
            return $this->response->setJSON(['success' => false, 'message' => 'Keranjang masih kosong.'])->setStatusCode(422);
        }

        $statusTransaksi = $payload['status_transaksi'] ?? 'selesai'; // 'selesai' atau 'pending'
        $metodeBayar     = $payload['metode_bayar'] ?? 'cash';
        $customerId      = $payload['customer_id'] ?: null;
        $poinDipakai     = (int) ($payload['poin_dipakai'] ?? 0);

        if ($metodeBayar === 'piutang' && ! $customerId) {
            return $this->response->setJSON(['success' => false, 'message' => 'Transaksi piutang wajib memilih customer.'])->setStatusCode(422);
        }
        if ($poinDipakai > 0 && ! $customerId) {
            return $this->response->setJSON(['success' => false, 'message' => 'Penukaran poin wajib memilih customer.'])->setStatusCode(422);
        }

        // Fitur #3: shift wajib aktif untuk role kasir sebelum transaksi bisa diselesaikan
        $shiftId = null;
        if ($user['role_code'] === 'kasir' && $statusTransaksi === 'selesai') {
            $shiftAktif = $this->shiftModel->shiftAktif($user['id']);
            if (! $shiftAktif) {
                return $this->response->setJSON(['success' => false, 'message' => 'Shift Anda belum dibuka. Buka shift terlebih dahulu.'])->setStatusCode(422);
            }
            $shiftId = $shiftAktif['id'];
        }

        $db = \Config\Database::connect();
        $db->transStart();

        try {
            $resumeId = $payload['resume_sale_id'] ?? null;

            $subtotal = 0;
            foreach ($payload['items'] as $item) {
                $subtotal += ((float) $item['qty'] * (float) $item['harga']) - (float) ($item['diskon'] ?? 0);
            }
            $diskonTotal = (float) ($payload['diskon'] ?? 0);

            // Fitur #1: diskon otomatis sesuai level member customer (Regular/Silver/Gold, dst)
            if ($customerId) {
                $customer = $this->customerModel->find($customerId);
                if ($customer && $customer['customer_level_id']) {
                    $level = (new \App\Models\CustomerLevelModel())->find($customer['customer_level_id']);
                    if ($level && $level['diskon_persen'] > 0) {
                        $diskonTotal += round($subtotal * ((float) $level['diskon_persen'] / 100));
                    }
                }
            }

            // Fitur #2: potongan langsung dari penukaran poin saat transaksi (1 poin = Rp 1.000)
            $nilaiPoinDipakai = $poinDipakai * 1000;
            $diskonTotal += $nilaiPoinDipakai;

            $grandTotal  = max(0, $subtotal - $diskonTotal);
            $bayar       = (float) ($payload['bayar'] ?? 0);
            $kembalian   = $statusTransaksi === 'selesai' ? max(0, $bayar - $grandTotal) : 0;

            $statusBayar = 'lunas';
            if ($metodeBayar === 'piutang') {
                $statusBayar = $bayar >= $grandTotal ? 'lunas' : ($bayar > 0 ? 'cicilan' : 'belum_lunas');
            }

            $saleData = [
                'branch_id'        => $branchId,
                'shift_id'         => $shiftId,
                'customer_id'      => $customerId,
                'kasir_id'         => $user['id'],
                'kurir_id'         => $payload['kurir_id'] ?: null,
                'expedition_id'    => $payload['expedition_id'] ?: null,
                'tipe_transaksi'   => $payload['tipe_transaksi'] ?? 'retail',
                'tanggal'          => date('Y-m-d H:i:s'),
                'subtotal'         => $subtotal,
                'diskon'           => $diskonTotal,
                'diskon_persen'    => $payload['diskon_persen'] ?? 0,
                'grand_total'      => $grandTotal,
                'bayar'            => $bayar,
                'kembalian'        => $kembalian,
                'metode_bayar'     => $metodeBayar,
                'status_bayar'     => $statusBayar,
                'status_transaksi' => $statusTransaksi,
                'status_kirim'     => $payload['kurir_id'] ? 'menunggu' : '-',
                'poin_dipakai'     => $poinDipakai,
                'catatan'          => $payload['catatan'] ?? null,
            ];

            if ($resumeId) {
                // Melanjutkan transaksi pending: hapus item lama, timpa dengan item baru
                $this->saleModel->update($resumeId, $saleData);
                $this->saleItemModel->where('sale_id', $resumeId)->delete();
                $saleId = $resumeId;
            } else {
                $saleData['no_invoice'] = $this->saleModel->generateNoInvoice($branchId);
                $saleId = $this->saleModel->insert($saleData, true);
            }

            foreach ($payload['items'] as $item) {
                $itemSubtotal = ((float) $item['qty'] * (float) $item['harga']) - (float) ($item['diskon'] ?? 0);
                $saleItemId = $this->saleItemModel->insert([
                    'sale_id'    => $saleId,
                    'product_id' => $item['product_id'],
                    'unit_id'    => $item['unit_id'],
                    'qty'        => $item['qty'],
                    'harga'      => $item['harga'],
                    'diskon'     => $item['diskon'] ?? 0,
                    'subtotal'   => $itemSubtotal,
                ], true);

                // Stok baru dipotong kalau transaksi berstatus 'selesai' (bukan pending)
                if ($statusTransaksi === 'selesai') {
                    $product = $this->productModel->find($item['product_id']);
                    $qtyDasar = (float) $item['qty'] * (float) ($item['konversi'] ?? 1);

                    if ($product['jenis_produk'] === 'sn') {
                        foreach ((array) ($item['serials'] ?? []) as $serialId) {
                            $updateSerial = ['status' => 'terjual', 'sale_item_id' => $saleItemId];

                            // Fitur #7: catat mulai/akhir garansi otomatis begitu barang SN terjual
                            if ($product['garansi_bulan']) {
                                $updateSerial['tanggal_mulai_garansi'] = date('Y-m-d');
                                $updateSerial['tanggal_akhir_garansi'] = date('Y-m-d', strtotime('+' . (int) $product['garansi_bulan'] . ' months'));
                            }
                            $this->serialModel->update($serialId, $updateSerial);
                        }
                    } else {
                        $this->stockService->decrease(
                            (int) $item['product_id'], $branchId, $qtyDasar, 'penjualan',
                            'sales', (int) $saleId, "Penjualan {$saleData['no_invoice']}", $user['id']
                        );

                        // Fitur #8: kurangi stok mengikuti prinsip FEFO untuk barang yang punya tanggal kedaluwarsa
                        if ($product['has_expiry']) {
                            $this->batchModel->kurangiFefo((int) $item['product_id'], $branchId, $qtyDasar);
                        }
                    }
                }
            }

            // Buat/perbarui piutang jika metode bayar piutang & transaksi sudah selesai
            if ($statusTransaksi === 'selesai' && $metodeBayar === 'piutang' && $grandTotal > $bayar) {
                $this->receivableModel->insert([
                    'sale_id'       => $saleId,
                    'customer_id'   => $customerId,
                    'branch_id'     => $branchId,
                    'total_piutang' => $grandTotal,
                    'total_dibayar' => $bayar,
                    'sisa_piutang'  => $grandTotal - $bayar,
                    'jatuh_tempo'   => date('Y-m-d', strtotime('+30 days')),
                    'status'        => $statusBayar,
                ]);
            }

            // Fitur #2: proses poin -- kurangi kalau dipakai untuk potongan, tambahkan dari nilai belanja
            $poinDidapat = 0;
            if ($statusTransaksi === 'selesai' && $customerId) {
                if ($poinDipakai > 0) {
                    $this->loyaltyService->tukarPoin($customerId, $poinDipakai, 'sales', $saleId, "Potongan langsung transaksi {$saleData['no_invoice']}");
                }
                $poinDidapat = $this->loyaltyService->tambahPoinBelanja($customerId, $grandTotal, 'sales', $saleId);
                $this->saleModel->update($saleId, ['poin_didapat' => $poinDidapat]);
            }

            $db->transComplete();

            if ($db->transStatus() === false) {
                throw new \RuntimeException('Gagal menyimpan transaksi.');
            }

            return $this->response->setJSON([
                'success'  => true,
                'sale_id'  => $saleId,
                'redirect' => site_url('penjualan/' . $saleId),
            ]);
        } catch (\Throwable $e) {
            $db->transRollback();
            return $this->response->setJSON(['success' => false, 'message' => $e->getMessage()])->setStatusCode(422);
        }
    }

    /** AJAX: cek saldo poin customer -- dipakai POS untuk validasi sebelum redeem poin di kasir */
    public function cekPoinCustomer()
    {
        $customerId = (int) $this->request->getGet('customer_id');
        $customer = $this->customerModel->find($customerId);
        return $this->response->setJSON(['poin' => (int) ($customer['poin'] ?? 0)]);
    }

    /**
     * Fitur #4: catat log tiap kali kasir menghapus item dari keranjang SEBELUM struk dicetak
     * (dipanggil dari JS POS setiap tombol hapus item ditekan, sebelum transaksi difinalisasi).
     */
    public function logHapusItem()
    {
        $payload = $this->request->getJSON(true);
        $this->auditLogModel->catat('hapus_item_kasir', 'sale_items_draft', null, [
            'nama_barang' => $payload['nama_barang'] ?? '-',
            'qty'         => $payload['qty'] ?? 0,
            'harga'       => $payload['harga'] ?? 0,
        ]);
        return $this->response->setJSON(['success' => true]);
    }

    /** Fitur #4: verifikasi username+password supervisor untuk otorisasi aksi sensitif (void, dsb) */
    public function cekOtorisasi()
    {
        $username = (string) $this->request->getPost('username');
        $password = (string) $this->request->getPost('password');

        $userModel = new UserModel();
        $otorisator = $userModel->getUserWithRole($username);

        if (! $otorisator || ! password_verify($password, $otorisator['password'])) {
            return $this->response->setJSON(['success' => false, 'message' => 'Username atau password otorisator salah.']);
        }
        if (! in_array($otorisator['kode_role'], ['admin', 'super_admin'], true)) {
            return $this->response->setJSON(['success' => false, 'message' => 'Hanya Admin/Super Admin yang boleh mengotorisasi.']);
        }

        return $this->response->setJSON(['success' => true, 'otorisator_id' => $otorisator['id'], 'nama' => $otorisator['nama']]);
    }

    /**
     * Fitur #4: void (batalkan) transaksi yang sudah selesai -- mengembalikan stok, membatalkan
     * piutang terkait, dan wajib menyertakan id otorisator (hasil dari cekOtorisasi di atas).
     */
    public function voidTransaction($id = null)
    {
        $sale = $this->saleModel->find($id);
        if (! $sale || $sale['status_transaksi'] !== 'selesai') {
            return redirect()->back()->with('error', 'Transaksi tidak ditemukan atau sudah dibatalkan sebelumnya.');
        }

        $otorisatorId = (int) $this->request->getPost('otorisator_id');
        $alasan = (string) $this->request->getPost('alasan');
        $user = $this->currentUser();

        if (! $otorisatorId) {
            $this->auditLogModel->catat('void_ditolak', 'sales', (int) $id, ['alasan' => $alasan, 'sebab' => 'Tanpa otorisasi supervisor']);
            return redirect()->back()->with('error', 'Void wajib diotorisasi oleh Admin/Super Admin.');
        }

        $db = \Config\Database::connect();
        $db->transStart();

        try {
            // Kembalikan stok non-SN & tandai serial SN kembali 'tersedia'
            foreach ($this->saleItemModel->bySale((int) $id) as $item) {
                if ($item['jenis_produk'] === 'sn') {
                    $this->serialModel->where('sale_item_id', $item['id'])->set(['status' => 'tersedia', 'sale_item_id' => null])->update();
                } else {
                    $this->stockService->increase(
                        (int) $item['product_id'], (int) $sale['branch_id'], (float) $item['qty'], 'penyesuaian',
                        'sales', (int) $id, "Void transaksi {$sale['no_invoice']}", $user['id']
                    );
                }
            }

            // Batalkan piutang terkait kalau ada
            $receivable = $this->receivableModel->where('sale_id', $id)->first();
            if ($receivable) {
                $this->receivableModel->update($receivable['id'], ['status' => 'lunas', 'sisa_piutang' => 0]);
            }

            $this->saleModel->update($id, ['status_transaksi' => 'batal']);

            $this->auditLogModel->catat('void_transaksi', 'sales', (int) $id, [
                'no_invoice' => $sale['no_invoice'], 'grand_total' => $sale['grand_total'], 'alasan' => $alasan,
            ], $otorisatorId);

            $db->transComplete();
            if ($db->transStatus() === false) {
                throw new \RuntimeException('Gagal membatalkan transaksi.');
            }

            return redirect()->to('penjualan/' . $id)->with('success', 'Transaksi berhasil dibatalkan (void).');
        } catch (\Throwable $e) {
            $db->transRollback();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /** Fitur #5: halaman Customer Facing Display -- dibuka di monitor kedua, mensinkron total belanja dari tab kasir */
    public function cfd()
    {
        return view('sale/cfd', ['title' => 'Customer Display']);
    }

    public function cfdData()
    {
        // Data CFD disinkronkan lewat localStorage antar tab di sisi browser (lihat sale/pos.php &
        // sale/cfd.php) supaya real-time tanpa perlu websocket/polling server. Endpoint ini
        // disediakan sebagai cadangan/hook kalau nanti mau dipindah ke sinkronisasi server-side.
        return $this->response->setJSON(['message' => 'CFD memakai sinkronisasi localStorage sisi client.']);
    }

    /** AJAX: daftar kurir di cabang terkait beserta status free/sibuk, untuk dipilih saat transaksi pengiriman */
    public function listCouriers()
    {
        $branchId = (int) $this->request->getGet('branch_id');
        $userModel = new UserModel();
        return $this->response->setJSON(['data' => $userModel->listCouriers($branchId ?: null)]);
    }

    /** Riwayat transaksi penjualan */
    public function index()
    {
        return view('sale/index', ['title' => 'Riwayat Penjualan']);
    }

    public function data()
    {
        $user = $this->currentUser();
        // Kasir hanya boleh melihat transaksi miliknya sendiri (laporan pribadi)
        $kasirId = $user['role_code'] === 'kasir' ? $user['id'] : null;
        return $this->response->setJSON(['data' => $this->saleModel->listWithRelations($user['branch_id'], $kasirId)]);
    }

    public function detail($id = null)
    {
        $sale = $this->saleModel->find($id);
        if (! $sale) {
            return redirect()->to('penjualan')->with('error', 'Transaksi tidak ditemukan.');
        }
        return view('sale/detail', [
            'title' => 'Detail Transaksi ' . $sale['no_invoice'],
            'sale'  => $sale,
            'items' => $this->saleItemModel->bySale((int) $id),
        ]);
    }

    /** Cetak nota thermal untuk sebuah transaksi, mengikuti pengaturan printer cabang terkait */
    public function printReceipt($id = null)
    {
        $sale = $this->saleModel->find($id);
        if (! $sale) {
            return redirect()->to('penjualan')->with('error', 'Transaksi tidak ditemukan.');
        }

        $printerSettingModel = new \App\Models\PrinterSettingModel();
        $storeSettingModel   = new \App\Models\StoreSettingModel();

        return view('sale/print', [
            'sale'    => $sale,
            'items'   => $this->saleItemModel->bySale((int) $id),
            'printer' => $printerSettingModel->getForBranch((int) $sale['branch_id']),
            'store'   => $storeSettingModel->getForBranch((int) $sale['branch_id']),
        ]);
    }
}
