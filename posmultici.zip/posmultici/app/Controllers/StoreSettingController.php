<?php

namespace App\Controllers;

use App\Models\StoreSettingModel;

class StoreSettingController extends BaseController
{
    protected StoreSettingModel $storeSettingModel;

    public function __construct()
    {
        $this->storeSettingModel = new StoreSettingModel();
    }

    public function index()
    {
        $user    = $this->currentUser();
        $setting = $this->storeSettingModel->getForBranch($user['branch_id']);

        return view('settings/store', [
            'title'   => 'Informasi Toko',
            'setting' => $setting,
        ]);
    }

    public function update()
    {
        $rules = [
            'nama_toko' => 'required|min_length[2]|max_length[150]',
            'email'     => 'permit_empty|valid_email',
        ];
        if (! $this->validateData($this->request->getPost(), $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $user = $this->currentUser();
        $data = [
            'branch_id'    => $user['branch_id'], // Super Admin (null) mengatur pengaturan global default
            'nama_toko'    => $this->request->getPost('nama_toko'),
            'alamat'       => $this->request->getPost('alamat'),
            'telepon'      => $this->request->getPost('telepon'),
            'email'        => $this->request->getPost('email'),
            'npwp'         => $this->request->getPost('npwp'),
            'footer_struk' => $this->request->getPost('footer_struk'),
            'updated_at'   => date('Y-m-d H:i:s'),
        ];

        $existing = $this->storeSettingModel->where('branch_id', $user['branch_id'])->first();
        if ($existing) {
            $this->storeSettingModel->update($existing['id'], $data);
        } else {
            $this->storeSettingModel->insert($data);
        }

        return redirect()->to('pengaturan-toko')->with('success', 'Informasi toko berhasil diperbarui.');
    }
}
