<?php

namespace App\Controllers;

use App\Models\BranchModel;
use App\Models\CategoryModel;
use App\Models\ProductModel;
use App\Models\ProductPriceModel;
use App\Models\ProductUnitModel;
use App\Models\StockModel;
use App\Models\SupplierModel;
use App\Models\UnitModel;

class ProductController extends BaseController
{
    protected ProductModel $productModel;
    protected ProductUnitModel $productUnitModel;
    protected ProductPriceModel $productPriceModel;
    protected StockModel $stockModel;
    protected CategoryModel $categoryModel;
    protected UnitModel $unitModel;
    protected SupplierModel $supplierModel;
    protected BranchModel $branchModel;

    public function __construct()
    {
        $this->productModel      = new ProductModel();
        $this->productUnitModel  = new ProductUnitModel();
        $this->productPriceModel = new ProductPriceModel();
        $this->stockModel        = new StockModel();
        $this->categoryModel     = new CategoryModel();
        $this->unitModel         = new UnitModel();
        $this->supplierModel     = new SupplierModel();
        $this->branchModel       = new BranchModel();
    }

    public function index()
    {
        return view('master/product/index', ['title' => 'Data Barang']);
    }

    public function data()
    {
        return $this->response->setJSON(['data' => $this->productModel->listWithRelations()]);
    }

    public function new()
    {
        return view('master/product/form', [
            'title'      => 'Tambah Barang',
            'product'    => null,
            'units_used' => [],
            'prices'     => [],
            'categories' => $this->categoryModel->orderBy('nama_kategori')->findAll(),
            'units'      => $this->unitModel->orderBy('nama_satuan')->findAll(),
            'suppliers'  => $this->supplierModel->orderBy('nama_supplier')->findAll(),
        ]);
    }

    public function create()
    {
        if (! $this->validateData($this->request->getPost(), $this->productModel->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $productId = $this->productModel->insert([
            'kode_barang'  => $this->request->getPost('kode_barang'),
            'barcode'      => $this->request->getPost('barcode'),
            'nama_barang'  => $this->request->getPost('nama_barang'),
            'category_id'  => $this->request->getPost('category_id'),
            'unit_id'      => $this->request->getPost('unit_id'),
            'supplier_id'  => $this->request->getPost('supplier_id') ?: null,
            'jenis_produk' => $this->request->getPost('jenis_produk'),
            'garansi_bulan'=> $this->request->getPost('jenis_produk') === 'sn' ? ($this->request->getPost('garansi_bulan') ?: null) : null,
            'has_expiry'   => $this->request->getPost('has_expiry') ? 1 : 0,
            'harga_beli'   => $this->request->getPost('harga_beli'),
            'harga_jual'   => $this->request->getPost('harga_jual'),
            'harga_grosir' => $this->request->getPost('harga_grosir') ?: 0,
            'stok_minimal' => $this->request->getPost('stok_minimal') ?: 0,
            'status'       => $this->request->getPost('status') ? 1 : 0,
        ], true);

        $this->saveUnitsAndPrices((int) $productId);
        $this->initStockAllBranches((int) $productId);

        return redirect()->to('barang')->with('success', 'Barang berhasil ditambahkan.');
    }

    public function edit($id = null)
    {
        $product = $this->productModel->find($id);
        if (! $product) {
            return redirect()->to('barang')->with('error', 'Data tidak ditemukan.');
        }
        return view('master/product/form', [
            'title'      => 'Edit Barang',
            'product'    => $product,
            'units_used' => $this->productUnitModel->byProduct((int) $id),
            'prices'     => $this->productPriceModel->byProduct((int) $id),
            'categories' => $this->categoryModel->orderBy('nama_kategori')->findAll(),
            'units'      => $this->unitModel->orderBy('nama_satuan')->findAll(),
            'suppliers'  => $this->supplierModel->orderBy('nama_supplier')->findAll(),
            'stocks'     => $this->stockModel->byProductAllBranches((int) $id),
        ]);
    }

    public function update($id = null)
    {
        $rules = $this->productModel->validationRules;
        $rules['kode_barang'] = "required|max_length[50]|is_unique[products.kode_barang,id,{$id}]";

        if (! $this->validateData($this->request->getPost(), $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->productModel->update($id, [
            'kode_barang'  => $this->request->getPost('kode_barang'),
            'barcode'      => $this->request->getPost('barcode'),
            'nama_barang'  => $this->request->getPost('nama_barang'),
            'category_id'  => $this->request->getPost('category_id'),
            'unit_id'      => $this->request->getPost('unit_id'),
            'supplier_id'  => $this->request->getPost('supplier_id') ?: null,
            'jenis_produk' => $this->request->getPost('jenis_produk'),
            'garansi_bulan'=> $this->request->getPost('jenis_produk') === 'sn' ? ($this->request->getPost('garansi_bulan') ?: null) : null,
            'has_expiry'   => $this->request->getPost('has_expiry') ? 1 : 0,
            'harga_beli'   => $this->request->getPost('harga_beli'),
            'harga_jual'   => $this->request->getPost('harga_jual'),
            'harga_grosir' => $this->request->getPost('harga_grosir') ?: 0,
            'stok_minimal' => $this->request->getPost('stok_minimal') ?: 0,
            'status'       => $this->request->getPost('status') ? 1 : 0,
        ]);

        $this->saveUnitsAndPrices((int) $id);

        return redirect()->to('barang')->with('success', 'Barang berhasil diperbarui.');
    }

    public function delete($id = null)
    {
        $this->productModel->delete($id);
        return redirect()->to('barang')->with('success', 'Barang berhasil dihapus.');
    }

    /**
     * Simpan ulang baris multi-satuan & harga bertingkat (hapus lalu insert ulang -- sederhana & aman
     * untuk jumlah baris yang kecil per barang).
     * Format input: units_unit_id[], units_konversi[], units_harga_jual[], units_harga_grosir[], units_default[]
     *               prices_unit_id[], prices_min_qty[], prices_harga[], prices_tipe[]
     */
    private function saveUnitsAndPrices(int $productId): void
    {
        $this->productUnitModel->deleteByProduct($productId);
        $unitIds  = $this->request->getPost('units_unit_id') ?? [];
        $konversi = $this->request->getPost('units_konversi') ?? [];
        $hargaJual   = $this->request->getPost('units_harga_jual') ?? [];
        $hargaGrosir = $this->request->getPost('units_harga_grosir') ?? [];
        $default     = $this->request->getPost('units_default') ?? [];

        foreach ($unitIds as $i => $unitId) {
            if (empty($unitId)) {
                continue;
            }
            $this->productUnitModel->insert([
                'product_id'   => $productId,
                'unit_id'      => $unitId,
                'konversi'     => $konversi[$i] ?? 1,
                'harga_jual'   => $hargaJual[$i] ?? 0,
                'harga_grosir' => $hargaGrosir[$i] ?? 0,
                'is_default'   => in_array((string) $i, (array) $default, true) ? 1 : 0,
            ]);
        }

        $this->productPriceModel->deleteByProduct($productId);
        $pUnitIds = $this->request->getPost('prices_unit_id') ?? [];
        $minQty   = $this->request->getPost('prices_min_qty') ?? [];
        $harga    = $this->request->getPost('prices_harga') ?? [];
        $tipe     = $this->request->getPost('prices_tipe') ?? [];

        foreach ($pUnitIds as $i => $unitId) {
            if (empty($unitId) || ! isset($harga[$i]) || $harga[$i] === '') {
                continue;
            }
            $this->productPriceModel->insert([
                'product_id'    => $productId,
                'unit_id'       => $unitId,
                'min_qty'       => $minQty[$i] ?? 1,
                'harga'         => $harga[$i],
                'tipe_customer' => $tipe[$i] ?? 'semua',
            ]);
        }
    }

    /** Barang baru otomatis dapat baris stok (qty 0) di semua cabang aktif */
    private function initStockAllBranches(int $productId): void
    {
        foreach ($this->branchModel->where('status', 1)->findAll() as $branch) {
            $this->stockModel->ensureRow($productId, (int) $branch['id']);
        }
    }
}
