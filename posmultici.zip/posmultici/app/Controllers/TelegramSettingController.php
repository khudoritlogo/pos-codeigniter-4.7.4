<?php

namespace App\Controllers;

use App\Libraries\TelegramNotifier;

class TelegramSettingController extends BaseController
{
    protected TelegramNotifier $notifier;

    public function __construct()
    {
        $this->notifier = new TelegramNotifier();
    }

    public function index()
    {
        return view('settings/telegram_bot', [
            'title'  => 'Pengaturan Telegram Bot',
            'config' => $this->notifier->getConfig(),
        ]);
    }

    public function update()
    {
        $this->notifier->saveConfig(
            (bool) $this->request->getPost('enabled'),
            (string) $this->request->getPost('bot_token'),
            (string) $this->request->getPost('chat_id')
        );
        return redirect()->to('pengaturan-telegram-bot')->with('success', 'Pengaturan Telegram Bot berhasil disimpan.');
    }

    /** Kirim pesan tes manual untuk memastikan bot token & chat id sudah benar */
    public function testKirim()
    {
        $config = $this->notifier->getConfig();
        if (empty($config['chat_id'])) {
            return redirect()->to('pengaturan-telegram-bot')->with('error', 'Isi dulu Chat ID sebelum tes kirim.');
        }

        $pesan = $this->notifier->formatRingkasanOmzet('Cabang Pusat (contoh)', date('d/m/Y'), 4250000, 37);
        $result = $this->notifier->send("*[TES]* " . $pesan);

        return redirect()->to('pengaturan-telegram-bot')->with($result['success'] ? 'success' : 'error', $result['message']);
    }
}
