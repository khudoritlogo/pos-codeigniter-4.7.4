<?php

namespace App\Controllers;

use App\Models\ProductSerialModel;

class GaransiController extends BaseController
{
    protected ProductSerialModel $serialModel;

    public function __construct()
    {
        $this->serialModel = new ProductSerialModel();
    }

    public function index()
    {
        return view('garansi/index', ['title' => 'Cek & Cetak Garansi']);
    }

    /** AJAX: cari serial number, kembalikan status garansi (aktif/expired/belum terjual) */
    public function cari()
    {
        $sn = trim((string) $this->request->getGet('sn'));
        if ($sn === '') {
            return $this->response->setJSON(['found' => false]);
        }

        $serial = $this->serialModel->bySerialNumber($sn);
        if (! $serial) {
            return $this->response->setJSON(['found' => false]);
        }

        $statusGaransi = 'belum_terjual';
        $sisaHari = null;
        if ($serial['tanggal_akhir_garansi']) {
            $akhir = strtotime($serial['tanggal_akhir_garansi']);
            $sisaHari = (int) floor(($akhir - time()) / 86400);
            $statusGaransi = $sisaHari >= 0 ? 'aktif' : 'expired';
        }

        return $this->response->setJSON([
            'found'          => true,
            'serial'         => $serial,
            'status_garansi' => $statusGaransi,
            'sisa_hari'      => $sisaHari,
        ]);
    }

    /** Cetak lembar klaim garansi untuk sebuah serial number */
    public function cetak($sn = null)
    {
        $serial = $this->serialModel->bySerialNumber((string) $sn);
        if (! $serial || ! $serial['tanggal_akhir_garansi']) {
            return redirect()->to('garansi')->with('error', 'Serial number tidak ditemukan atau belum punya data garansi (barang belum terjual).');
        }

        $storeSettingModel = new \App\Models\StoreSettingModel();

        return view('garansi/cetak', [
            'serial' => $serial,
            'store'  => $storeSettingModel->getForBranch((int) $serial['branch_id']),
        ]);
    }
}
