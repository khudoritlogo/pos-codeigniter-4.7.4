<?php

namespace App\Controllers\Auth;

use App\Controllers\BaseController;
use App\Models\UserModel;

class LoginController extends BaseController
{
    protected UserModel $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function index()
    {
        if ($this->session->get('logged_in')) {
            return redirect()->to('/dashboard');
        }
        return view('auth/login');
    }

    public function attempt()
    {
        $rules = [
            'username' => 'required',
            'password' => 'required',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('error', 'Username dan password wajib diisi.');
        }

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $user = $this->userModel->getUserWithRole($username);

        if (! $user || ! password_verify($password, $user['password'])) {
            return redirect()->back()->withInput()->with('error', 'Username atau password salah.');
        }

        // Set session data untuk dipakai di seluruh aplikasi (RBAC, filter cabang, dsb)
        $sessionData = [
            'user_id'     => $user['id'],
            'nama'        => $user['nama'],
            'username'    => $user['username'],
            'role_id'     => $user['role_id'],
            'role_code'   => $user['kode_role'],   // super_admin | admin | kasir | kurir
            'role_name'   => $user['nama_role'],
            'branch_id'   => $user['branch_id'],   // null untuk super admin (semua cabang)
            'branch_name' => $user['nama_cabang'] ?? 'Semua Cabang',
            'is_active'   => $user['is_active'],
            'logged_in'   => true,
        ];
        $this->session->set($sessionData);

        $this->userModel->update($user['id'], ['last_login' => date('Y-m-d H:i:s')]);

        // Redirect sesuai role: kurir ke dashboard khusus, lainnya ke dashboard umum
        if ($user['kode_role'] === 'kurir') {
            return redirect()->to('/kurir/dashboard');
        }
        return redirect()->to('/dashboard');
    }

    public function logout()
    {
        $this->session->destroy();
        return redirect()->to('/login')->with('success', 'Anda telah keluar.');
    }
}
