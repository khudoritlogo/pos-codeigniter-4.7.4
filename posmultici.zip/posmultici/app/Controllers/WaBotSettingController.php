<?php

namespace App\Controllers;

use App\Libraries\WhatsappNotifier;

class WaBotSettingController extends BaseController
{
    protected WhatsappNotifier $notifier;

    public function __construct()
    {
        $this->notifier = new WhatsappNotifier();
    }

    public function index()
    {
        return view('settings/wa_bot', [
            'title'  => 'Pengaturan WA Bot',
            'config' => $this->notifier->getConfig(),
        ]);
    }

    public function update()
    {
        $this->notifier->saveConfig(
            (bool) $this->request->getPost('enabled'),
            (string) $this->request->getPost('api_endpoint'),
            (string) $this->request->getPost('api_key'),
            (string) $this->request->getPost('nomor_owner')
        );
        return redirect()->to('pengaturan-wa-bot')->with('success', 'Pengaturan WA Bot berhasil disimpan.');
    }

    /** Kirim pesan tes manual untuk memastikan konfigurasi gateway sudah benar */
    public function testKirim()
    {
        $config = $this->notifier->getConfig();
        if (empty($config['nomor_owner'])) {
            return redirect()->to('pengaturan-wa-bot')->with('error', 'Isi dulu Nomor Owner sebelum tes kirim.');
        }

        $pesan = $this->notifier->formatRingkasanOmzet('Cabang Pusat (contoh)', date('d/m/Y'), 4250000, 37);
        $result = $this->notifier->send($config['nomor_owner'], "*[TES]* " . $pesan);

        return redirect()->to('pengaturan-wa-bot')->with($result['success'] ? 'success' : 'error', $result['message']);
    }
}
