<?php

namespace App\Controllers;

use App\Models\SaleModel;
use App\Models\UserModel;

class CourierDeliveryController extends BaseController
{
    protected SaleModel $saleModel;
    protected UserModel $userModel;

    public function __construct()
    {
        $this->saleModel = new SaleModel();
        $this->userModel = new UserModel();
    }

    /** Daftar pengiriman milik kurir yang sedang login, lengkap link WhatsApp & Google Maps */
    public function index()
    {
        $user = $this->currentUser();

        $deliveries = $this->saleModel
            ->select('sales.id, sales.no_invoice, sales.tanggal, sales.status_kirim, sales.grand_total, customers.nama_customer, customers.telepon, customers.alamat')
            ->join('customers', 'customers.id = sales.customer_id', 'left')
            ->where('sales.kurir_id', $user['id'])
            ->whereIn('sales.status_kirim', ['menunggu', 'diproses', 'dikirim'])
            ->orderBy('sales.tanggal', 'ASC')
            ->findAll();

        // Siapkan link WhatsApp (format nomor ke 62xxx) & Google Maps pencarian alamat untuk tiap baris
        foreach ($deliveries as &$d) {
            $d['wa_link'] = $this->waLink($d['telepon'], $d['no_invoice']);
            $d['maps_link'] = $this->mapsLink($d['alamat']);
        }
        unset($d);

        $riwayatSelesaiHariIni = $this->saleModel
            ->where('kurir_id', $user['id'])
            ->where('status_kirim', 'selesai')
            ->where('DATE(tanggal)', date('Y-m-d'))
            ->countAllResults();

        return view('courier/index', [
            'title'      => 'Data Pengiriman Kurir',
            'deliveries' => $deliveries,
            'user'       => $user,
            'selesaiHariIni' => $riwayatSelesaiHariIni,
        ]);
    }

    /** Kurir mengubah status pengiriman satu invoice: menunggu -> diproses -> dikirim -> selesai */
    public function updateStatus($saleId = null)
    {
        $user = $this->currentUser();
        $sale = $this->saleModel->find($saleId);
        if (! $sale || (int) $sale['kurir_id'] !== (int) $user['id']) {
            return redirect()->to('kurir/pengiriman')->with('error', 'Pengiriman tidak ditemukan.');
        }

        $status = $this->request->getPost('status_kirim');
        if (! in_array($status, ['diproses', 'dikirim', 'selesai'], true)) {
            return redirect()->back()->with('error', 'Status tidak valid.');
        }

        $this->saleModel->update($saleId, ['status_kirim' => $status]);

        // Kurir otomatis ditandai "sibuk" saat mulai memproses, dan "free" lagi setelah pengiriman selesai
        // (kecuali dia masih punya pengiriman lain yang berjalan)
        if ($status === 'diproses' || $status === 'dikirim') {
            $this->userModel->update($user['id'], ['status_kurir' => 'sibuk']);
        } elseif ($status === 'selesai') {
            $masihAda = $this->saleModel->where('kurir_id', $user['id'])->whereIn('status_kirim', ['menunggu', 'diproses', 'dikirim'])->countAllResults();
            if ($masihAda === 0) {
                $this->userModel->update($user['id'], ['status_kurir' => 'free']);
            }
        }

        return redirect()->to('kurir/pengiriman')->with('success', 'Status pengiriman berhasil diperbarui.');
    }

    /** Kurir mengubah status ketersediaan dirinya sendiri secara manual (free/sibuk/off) */
    public function toggleStatus()
    {
        $user = $this->currentUser();
        $status = $this->request->getPost('status_kurir');
        if (! in_array($status, ['free', 'sibuk', 'off'], true)) {
            return redirect()->back()->with('error', 'Status tidak valid.');
        }
        $this->userModel->update($user['id'], ['status_kurir' => $status]);
        return redirect()->back()->with('success', 'Status Anda berhasil diperbarui.');
    }

    private function waLink(?string $telepon, string $noInvoice): ?string
    {
        if (! $telepon) {
            return null;
        }
        $normalized = preg_replace('/[^0-9]/', '', $telepon);
        if (str_starts_with($normalized, '0')) {
            $normalized = '62' . substr($normalized, 1);
        }
        $pesan = rawurlencode("Halo, pesanan Anda dengan nomor invoice {$noInvoice} sedang dalam pengiriman.");
        return "https://wa.me/{$normalized}?text={$pesan}";
    }

    private function mapsLink(?string $alamat): ?string
    {
        if (! $alamat) {
            return null;
        }
        return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($alamat);
    }
}
