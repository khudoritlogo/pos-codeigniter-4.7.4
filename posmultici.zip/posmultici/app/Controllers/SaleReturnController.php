<?php

namespace App\Controllers;

use App\Libraries\StockService;
use App\Models\ReceivableModel;
use App\Models\SaleItemModel;
use App\Models\SaleModel;
use App\Models\SaleReturnItemModel;
use App\Models\SaleReturnModel;

class SaleReturnController extends BaseController
{
    protected SaleReturnModel $saleReturnModel;
    protected SaleReturnItemModel $saleReturnItemModel;
    protected SaleModel $saleModel;
    protected SaleItemModel $saleItemModel;
    protected ReceivableModel $receivableModel;
    protected StockService $stockService;

    public function __construct()
    {
        $this->saleReturnModel     = new SaleReturnModel();
        $this->saleReturnItemModel = new SaleReturnItemModel();
        $this->saleModel           = new SaleModel();
        $this->saleItemModel       = new SaleItemModel();
        $this->receivableModel     = new ReceivableModel();
        $this->stockService        = new StockService();
    }

    public function index()
    {
        return view('sale_return/index', ['title' => 'Retur Penjualan']);
    }

    public function data()
    {
        $user = $this->currentUser();
        return $this->response->setJSON(['data' => $this->saleReturnModel->listWithRelations($user['branch_id'])]);
    }

    public function new()
    {
        return view('sale_return/form', ['title' => 'Retur Penjualan Baru']);
    }

    /** AJAX: cari transaksi penjualan berdasarkan no invoice, kembalikan item yang masih bisa diretur */
    public function cariInvoice()
    {
        $noInvoice = trim((string) $this->request->getGet('no_invoice'));
        $sale = $this->saleModel->where('no_invoice', $noInvoice)->where('status_transaksi', 'selesai')->first();
        if (! $sale) {
            return $this->response->setJSON(['found' => false]);
        }

        $items = $this->saleItemModel->bySale((int) $sale['id']);
        $items = array_map(function ($it) {
            $it['qty_bisa_retur'] = (float) $it['qty'] - (float) $it['qty_retur'];
            return $it;
        }, $items);

        return $this->response->setJSON(['found' => true, 'sale' => $sale, 'items' => $items]);
    }

    public function create()
    {
        $saleId = (int) $this->request->getPost('sale_id');
        $itemIds = $this->request->getPost('sale_item_id') ?? [];
        $qtys    = $this->request->getPost('qty') ?? [];
        $alasan  = $this->request->getPost('alasan');

        $sale = $this->saleModel->find($saleId);
        if (! $sale) {
            return redirect()->back()->with('error', 'Transaksi asal tidak ditemukan.');
        }

        $user = $this->currentUser();
        $db   = \Config\Database::connect();
        $db->transStart();

        try {
            $totalRetur = 0;
            $validItems = [];
            foreach ($itemIds as $i => $saleItemId) {
                $qty = (float) ($qtys[$i] ?? 0);
                if ($qty <= 0) {
                    continue;
                }
                $saleItem = $this->saleItemModel->find($saleItemId);
                $bisaRetur = (float) $saleItem['qty'] - (float) $saleItem['qty_retur'];
                if ($qty > $bisaRetur) {
                    throw new \RuntimeException("Qty retur melebihi qty yang bisa diretur untuk salah satu barang.");
                }
                $subtotal = ($saleItem['harga'] * $qty);
                $totalRetur += $subtotal;
                $validItems[] = ['sale_item' => $saleItem, 'qty' => $qty, 'subtotal' => $subtotal];
            }

            if (empty($validItems)) {
                throw new \RuntimeException('Tidak ada barang yang diretur.');
            }

            $noRetur = $this->saleReturnModel->generateNoRetur($sale['branch_id']);
            $returId = $this->saleReturnModel->insert([
                'no_retur'    => $noRetur,
                'sale_id'     => $saleId,
                'branch_id'   => $sale['branch_id'],
                'user_id'     => $user['id'],
                'tanggal'     => date('Y-m-d H:i:s'),
                'total_retur' => $totalRetur,
                'alasan'      => $alasan,
            ], true);

            foreach ($validItems as $v) {
                $this->saleReturnItemModel->insert([
                    'sale_return_id' => $returId,
                    'sale_item_id'   => $v['sale_item']['id'],
                    'product_id'     => $v['sale_item']['product_id'],
                    'qty'            => $v['qty'],
                    'subtotal'       => $v['subtotal'],
                ]);

                $this->saleItemModel->update($v['sale_item']['id'], [
                    'qty_retur' => (float) $v['sale_item']['qty_retur'] + $v['qty'],
                ]);

                // Barang kembali ke stok cabang asal transaksi (khusus barang non-SN; barang SN
                // dikembalikan manual oleh Admin lewat penyesuaian status serial jika diperlukan)
                $this->stockService->increase(
                    (int) $v['sale_item']['product_id'], (int) $sale['branch_id'], $v['qty'],
                    'retur_penjualan', 'sale_returns', $returId, "Retur {$noRetur}", $user['id']
                );
            }

            // Jika transaksi asal berstatus piutang, kurangi nilai piutangnya sesuai nilai retur
            $receivable = $this->receivableModel->where('sale_id', $saleId)->first();
            if ($receivable) {
                $sisaBaru = max(0, (float) $receivable['sisa_piutang'] - $totalRetur);
                $this->receivableModel->update($receivable['id'], [
                    'sisa_piutang' => $sisaBaru,
                    'status'       => $sisaBaru <= 0 ? 'lunas' : $receivable['status'],
                ]);
            }

            $db->transComplete();
            if ($db->transStatus() === false) {
                throw new \RuntimeException('Gagal menyimpan retur.');
            }

            return redirect()->to('retur-penjualan')->with('success', "Retur {$noRetur} berhasil disimpan.");
        } catch (\Throwable $e) {
            $db->transRollback();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
