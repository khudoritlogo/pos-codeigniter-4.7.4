<?php

namespace App\Controllers;

use App\Libraries\LoyaltyService;
use App\Libraries\StockService;
use App\Models\CustomerModel;
use App\Models\LoyaltyRedemptionModel;
use App\Models\LoyaltyRewardModel;

class LoyaltyRedemptionController extends BaseController
{
    protected LoyaltyRedemptionModel $redemptionModel;
    protected LoyaltyRewardModel $rewardModel;
    protected CustomerModel $customerModel;
    protected LoyaltyService $loyaltyService;
    protected StockService $stockService;

    public function __construct()
    {
        $this->redemptionModel = new LoyaltyRedemptionModel();
        $this->rewardModel     = new LoyaltyRewardModel();
        $this->customerModel   = new CustomerModel();
        $this->loyaltyService  = new LoyaltyService();
        $this->stockService    = new StockService();
    }

    public function index()
    {
        return view('loyalty/redemption_index', ['title' => 'Penukaran Poin']);
    }

    public function data()
    {
        $user = $this->currentUser();
        return $this->response->setJSON(['data' => $this->redemptionModel->listWithRelations($user['branch_id'])]);
    }

    public function new()
    {
        return view('loyalty/redemption_form', [
            'title'   => 'Tukar Poin dengan Hadiah',
            'rewards' => $this->rewardModel->aktif(),
        ]);
    }

    /** AJAX: cari customer beserta saldo poin & level saat ini */
    public function cariCustomer()
    {
        $q = trim((string) $this->request->getGet('q'));
        if ($q === '') {
            return $this->response->setJSON(['data' => []]);
        }
        $customers = $this->customerModel
            ->select('customers.id, customers.kode_customer, customers.nama_customer, customers.poin, customer_levels.nama_level')
            ->join('customer_levels', 'customer_levels.id = customers.customer_level_id', 'left')
            ->groupStart()->like('nama_customer', $q)->orLike('kode_customer', $q)->groupEnd()
            ->limit(10)->findAll();
        return $this->response->setJSON(['data' => $customers]);
    }

    public function create()
    {
        $customerId = (int) $this->request->getPost('customer_id');
        $rewardId   = (int) $this->request->getPost('reward_id');
        $user       = $this->currentUser();
        $branchId   = $user['branch_id'];

        if (! $branchId) {
            return redirect()->back()->with('error', 'Super Admin tidak terikat cabang; penukaran poin harus dilakukan oleh user cabang.');
        }

        $reward = $this->rewardModel->find($rewardId);
        if (! $reward || $reward['status'] != 1) {
            return redirect()->back()->with('error', 'Hadiah tidak ditemukan atau sedang nonaktif.');
        }
        if ((int) $reward['stok_hadiah'] <= 0) {
            return redirect()->back()->with('error', 'Stok hadiah habis.');
        }

        $db = \Config\Database::connect();
        $db->transStart();

        try {
            $noPenukaran = $this->redemptionModel->generateNoPenukaran();
            $redemptionId = $this->redemptionModel->insert([
                'no_penukaran' => $noPenukaran,
                'customer_id'  => $customerId,
                'reward_id'    => $rewardId,
                'branch_id'    => $branchId,
                'user_id'      => $user['id'],
                'poin_dipakai' => $reward['poin_dibutuhkan'],
                'tanggal'      => date('Y-m-d H:i:s'),
            ], true);

            $this->loyaltyService->tukarPoin(
                $customerId, (int) $reward['poin_dibutuhkan'], 'loyalty_redemptions', $redemptionId,
                "Tukar poin dengan hadiah: {$reward['nama_hadiah']}"
            );

            $this->rewardModel->update($rewardId, ['stok_hadiah' => (int) $reward['stok_hadiah'] - 1]);

            // Kalau hadiah terhubung ke barang master, stok barang juga otomatis berkurang
            if (! empty($reward['product_id'])) {
                $this->stockService->decrease(
                    (int) $reward['product_id'], $branchId, 1, 'penyesuaian',
                    'loyalty_redemptions', $redemptionId, "Penukaran poin {$noPenukaran}", $user['id']
                );
            }

            $db->transComplete();
            if ($db->transStatus() === false) {
                throw new \RuntimeException('Gagal memproses penukaran poin.');
            }

            return redirect()->to('tukar-poin')->with('success', "Penukaran {$noPenukaran} berhasil diproses.");
        } catch (\Throwable $e) {
            $db->transRollback();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
