<?php

namespace App\Controllers;

use App\Models\BranchModel;
use App\Models\RoleModel;
use App\Models\UserModel;

class UserController extends BaseController
{
    protected UserModel $userModel;
    protected RoleModel $roleModel;
    protected BranchModel $branchModel;

    public function __construct()
    {
        $this->userModel   = new UserModel();
        $this->roleModel   = new RoleModel();
        $this->branchModel = new BranchModel();
    }

    public function index()
    {
        return view('master/user/index', ['title' => 'Pengguna']);
    }

    public function data()
    {
        $users = $this->userModel
            ->select('users.id, users.nama, users.username, users.email, users.is_active, roles.nama_role, branches.nama_cabang')
            ->join('roles', 'roles.id = users.role_id')
            ->join('branches', 'branches.id = users.branch_id', 'left')
            ->orderBy('users.nama', 'ASC')
            ->findAll();

        return $this->response->setJSON(['data' => $users]);
    }

    public function new()
    {
        return view('master/user/form', [
            'title'    => 'Tambah Pengguna',
            'user_row' => null,
            'roles'    => $this->roleModel->findAll(),
            'branches' => $this->branchModel->where('status', 1)->findAll(),
        ]);
    }

    public function create()
    {
        $rules = [
            'nama'     => 'required|min_length[3]|max_length[150]',
            'username' => 'required|min_length[4]|max_length[100]|is_unique[users.username]',
            'password' => 'required|min_length[8]',
            'role_id'  => 'required|integer',
            'email'    => 'permit_empty|valid_email',
        ];
        if (! $this->validateData($this->request->getPost(), $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $role     = $this->roleModel->find($this->request->getPost('role_id'));
        $branchId = $this->request->getPost('branch_id') ?: null;

        // Super Admin tidak terikat ke satu cabang (branch_id null = akses semua cabang)
        if ($role['kode_role'] === 'super_admin') {
            $branchId = null;
        }

        $this->userModel->insert([
            'branch_id' => $branchId,
            'role_id'   => $this->request->getPost('role_id'),
            'nama'      => $this->request->getPost('nama'),
            'username'  => $this->request->getPost('username'),
            'email'     => $this->request->getPost('email'),
            'no_hp'     => $this->request->getPost('no_hp'),
            'password'  => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'is_active' => $this->request->getPost('is_active') ? 1 : 0,
        ]);

        return redirect()->to('user')->with('success', 'Pengguna berhasil ditambahkan.');
    }

    public function edit($id = null)
    {
        $user = $this->userModel->find($id);
        if (! $user) {
            return redirect()->to('user')->with('error', 'Data tidak ditemukan.');
        }
        return view('master/user/form', [
            'title'    => 'Edit Pengguna',
            'user_row' => $user,
            'roles'    => $this->roleModel->findAll(),
            'branches' => $this->branchModel->where('status', 1)->findAll(),
        ]);
    }

    public function update($id = null)
    {
        $rules = [
            'nama'     => 'required|min_length[3]|max_length[150]',
            'username' => "required|min_length[4]|max_length[100]|is_unique[users.username,id,{$id}]",
            'role_id'  => 'required|integer',
            'email'    => 'permit_empty|valid_email',
            'password' => 'permit_empty|min_length[8]',
        ];
        if (! $this->validateData($this->request->getPost(), $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $role     = $this->roleModel->find($this->request->getPost('role_id'));
        $branchId = $this->request->getPost('branch_id') ?: null;
        if ($role['kode_role'] === 'super_admin') {
            $branchId = null;
        }

        $data = [
            'branch_id' => $branchId,
            'role_id'   => $this->request->getPost('role_id'),
            'nama'      => $this->request->getPost('nama'),
            'username'  => $this->request->getPost('username'),
            'email'     => $this->request->getPost('email'),
            'no_hp'     => $this->request->getPost('no_hp'),
            'is_active' => $this->request->getPost('is_active') ? 1 : 0,
        ];

        // Password hanya diupdate kalau diisi (opsional saat edit)
        if ($this->request->getPost('password')) {
            $data['password'] = password_hash($this->request->getPost('password'), PASSWORD_DEFAULT);
        }

        $this->userModel->update($id, $data);
        return redirect()->to('user')->with('success', 'Pengguna berhasil diperbarui.');
    }

    public function delete($id = null)
    {
        // Cegah user menghapus akunnya sendiri yang sedang login
        if ((int) $id === (int) $this->session->get('user_id')) {
            return redirect()->to('user')->with('error', 'Tidak bisa menghapus akun yang sedang digunakan.');
        }
        $this->userModel->delete($id);
        return redirect()->to('user')->with('success', 'Pengguna berhasil dihapus.');
    }
}
