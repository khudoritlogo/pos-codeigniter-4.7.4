<?php

namespace App\Controllers;

use App\Models\ReceivableModel;
use App\Models\ReceivablePaymentModel;

class ReceivableController extends BaseController
{
    protected ReceivableModel $receivableModel;
    protected ReceivablePaymentModel $paymentModel;

    public function __construct()
    {
        $this->receivableModel = new ReceivableModel();
        $this->paymentModel    = new ReceivablePaymentModel();
    }

    public function index()
    {
        // Perbarui status 'menunggak' untuk piutang yang sudah lewat jatuh tempo setiap kali halaman dibuka
        $this->receivableModel->tandaiMenunggak();
        return view('receivable/index', ['title' => 'Piutang']);
    }

    public function data()
    {
        $user = $this->currentUser();
        $onlyMenunggak = $this->request->getGet('menunggak') === '1';
        return $this->response->setJSON(['data' => $this->receivableModel->listWithRelations($user['branch_id'], $onlyMenunggak)]);
    }

    public function detail($id = null)
    {
        $receivable = $this->receivableModel
            ->select('receivables.*, customers.nama_customer, customers.telepon, sales.no_invoice')
            ->join('customers', 'customers.id = receivables.customer_id')
            ->join('sales', 'sales.id = receivables.sale_id')
            ->find($id);

        if (! $receivable) {
            return redirect()->to('piutang')->with('error', 'Data piutang tidak ditemukan.');
        }

        return view('receivable/detail', [
            'title'      => 'Detail Piutang — ' . $receivable['no_invoice'],
            'receivable' => $receivable,
            'payments'   => $this->paymentModel->byReceivable((int) $id),
        ]);
    }

    /** Catat pembayaran cicilan; status otomatis jadi "lunas" begitu sisa piutang mencapai 0 */
    public function bayar($id = null)
    {
        $receivable = $this->receivableModel->find($id);
        if (! $receivable) {
            return redirect()->to('piutang')->with('error', 'Data piutang tidak ditemukan.');
        }

        $jumlah = (float) $this->request->getPost('jumlah_bayar');
        if ($jumlah <= 0) {
            return redirect()->back()->with('error', 'Jumlah bayar harus lebih dari 0.');
        }
        if ($jumlah > (float) $receivable['sisa_piutang']) {
            return redirect()->back()->with('error', 'Jumlah bayar melebihi sisa piutang.');
        }

        $user = $this->currentUser();
        $db   = \Config\Database::connect();
        $db->transStart();

        try {
            $this->paymentModel->insert([
                'receivable_id' => $id,
                'user_id'       => $user['id'],
                'tanggal_bayar' => date('Y-m-d H:i:s'),
                'jumlah_bayar'  => $jumlah,
                'metode_bayar'  => $this->request->getPost('metode_bayar') ?: 'cash',
                'catatan'       => $this->request->getPost('catatan'),
            ]);

            $totalDibayarBaru = (float) $receivable['total_dibayar'] + $jumlah;
            $sisaBaru = (float) $receivable['total_piutang'] - $totalDibayarBaru;

            $this->receivableModel->update($id, [
                'total_dibayar' => $totalDibayarBaru,
                'sisa_piutang'  => max(0, $sisaBaru),
                'status'        => $sisaBaru <= 0 ? 'lunas' : 'cicilan',
            ]);

            $db->transComplete();
            if ($db->transStatus() === false) {
                throw new \RuntimeException('Gagal mencatat pembayaran.');
            }

            return redirect()->to('piutang/' . $id)->with('success', 'Pembayaran cicilan berhasil dicatat.');
        } catch (\Throwable $e) {
            $db->transRollback();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
