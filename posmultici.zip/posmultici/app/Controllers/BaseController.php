<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

abstract class BaseController extends Controller
{
    protected $helpers = ['url', 'form', 'auth_helper'];
    protected $session;

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);
        $this->session = \Config\Services::session();
    }

    /**
     * Data user yang sedang login, dipakai di semua controller turunan.
     */
    protected function currentUser(): array
    {
        return [
            'id'          => $this->session->get('user_id'),
            'nama'        => $this->session->get('nama'),
            'username'    => $this->session->get('username'),
            'role_id'     => $this->session->get('role_id'),
            'role_code'   => $this->session->get('role_code'),
            'role_name'   => $this->session->get('role_name'),
            'branch_id'   => $this->session->get('branch_id'), // null = akses semua cabang
            'branch_name' => $this->session->get('branch_name'),
        ];
    }

    /**
     * Helper cek permission langsung dari controller (selain via filter route).
     */
    protected function can(string $feature): bool
    {
        $authGroups = new \App\Config\AuthGroups();
        return $authGroups->can($this->session->get('role_code'), $feature);
    }
}
