<?php

namespace App\Controllers;

use App\Models\UnitModel;

class UnitController extends BaseController
{
    protected UnitModel $unitModel;

    public function __construct()
    {
        $this->unitModel = new UnitModel();
    }

    public function index()
    {
        return view('master/unit/index', ['title' => 'Satuan Barang']);
    }

    public function data()
    {
        return $this->response->setJSON(['data' => $this->unitModel->orderBy('nama_satuan', 'ASC')->findAll()]);
    }

    public function new()
    {
        return view('master/unit/form', ['title' => 'Tambah Satuan', 'unit' => null]);
    }

    public function create()
    {
        if (! $this->validateData($this->request->getPost(), $this->unitModel->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->unitModel->insert($this->request->getPost(['nama_satuan']));
        return redirect()->to('satuan')->with('success', 'Satuan berhasil ditambahkan.');
    }

    public function edit($id = null)
    {
        $unit = $this->unitModel->find($id);
        if (! $unit) {
            return redirect()->to('satuan')->with('error', 'Data tidak ditemukan.');
        }
        return view('master/unit/form', ['title' => 'Edit Satuan', 'unit' => $unit]);
    }

    public function update($id = null)
    {
        if (! $this->validateData($this->request->getPost(), $this->unitModel->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->unitModel->update($id, $this->request->getPost(['nama_satuan']));
        return redirect()->to('satuan')->with('success', 'Satuan berhasil diperbarui.');
    }

    public function delete($id = null)
    {
        $this->unitModel->delete($id);
        return redirect()->to('satuan')->with('success', 'Satuan berhasil dihapus.');
    }
}
