<?php

namespace App\Controllers;

use App\Models\CashierShiftModel;
use App\Models\SaleModel;

class CashierShiftController extends BaseController
{
    protected CashierShiftModel $shiftModel;
    protected SaleModel $saleModel;

    public function __construct()
    {
        $this->shiftModel = new CashierShiftModel();
        $this->saleModel  = new SaleModel();
    }

    public function index()
    {
        $user = $this->currentUser();
        return view('shift/index', [
            'title'       => 'Shift Kasir',
            'shiftAktif'  => $this->shiftModel->shiftAktif($user['id']),
        ]);
    }

    public function data()
    {
        $user = $this->currentUser();
        // Kasir hanya lihat riwayat shift miliknya sendiri; Admin/Super Admin lihat semua cabang terkait
        $builder = $this->shiftModel->listWithRelations($user['branch_id']);
        if ($user['role_code'] === 'kasir') {
            $builder = array_values(array_filter($builder, fn ($s) => (int) $s['user_id'] === (int) $user['id']));
        }
        return $this->response->setJSON(['data' => $builder]);
    }

    public function formBuka()
    {
        $user = $this->currentUser();
        if ($this->shiftModel->shiftAktif($user['id'])) {
            return redirect()->to('shift-kasir')->with('error', 'Anda masih punya shift yang sedang berjalan. Tutup dulu sebelum membuka shift baru.');
        }
        return view('shift/buka', ['title' => 'Buka Shift Kasir']);
    }

    public function buka()
    {
        $user = $this->currentUser();
        if (! $user['branch_id']) {
            return redirect()->to('shift-kasir')->with('error', 'Super Admin tidak terikat cabang; shift kasir harus dibuka oleh user cabang.');
        }
        if ($this->shiftModel->shiftAktif($user['id'])) {
            return redirect()->to('shift-kasir')->with('error', 'Anda masih punya shift yang sedang berjalan.');
        }

        $modalAwal = (float) $this->request->getPost('modal_awal');
        $this->shiftModel->insert([
            'no_shift'   => $this->shiftModel->generateNoShift(),
            'branch_id'  => $user['branch_id'],
            'user_id'    => $user['id'],
            'modal_awal' => $modalAwal,
            'waktu_buka' => date('Y-m-d H:i:s'),
            'status'     => 'buka',
        ]);

        return redirect()->to('kasir')->with('success', 'Shift dibuka. Selamat berjualan!');
    }

    public function formTutup($id = null)
    {
        $shift = $this->shiftModel->find($id);
        $user  = $this->currentUser();
        if (! $shift || (int) $shift['user_id'] !== (int) $user['id'] || $shift['status'] !== 'buka') {
            return redirect()->to('shift-kasir')->with('error', 'Shift tidak ditemukan atau bukan milik Anda.');
        }

        [$cash, $nonCash] = $this->hitungOmzetShift((int) $id);

        return view('shift/tutup', [
            'title' => 'Tutup Shift Kasir',
            'shift' => $shift,
            'totalCash' => $cash,
            'totalNonCash' => $nonCash,
            'uangSeharusnya' => (float) $shift['modal_awal'] + $cash,
        ]);
    }

    public function tutup($id = null)
    {
        $shift = $this->shiftModel->find($id);
        $user  = $this->currentUser();
        if (! $shift || (int) $shift['user_id'] !== (int) $user['id'] || $shift['status'] !== 'buka') {
            return redirect()->to('shift-kasir')->with('error', 'Shift tidak ditemukan atau bukan milik Anda.');
        }

        [$cash, $nonCash] = $this->hitungOmzetShift((int) $id);
        $uangSeharusnya = (float) $shift['modal_awal'] + $cash;
        $uangFisik = (float) $this->request->getPost('uang_fisik_aktual');
        $selisih = $uangFisik - $uangSeharusnya;

        $this->shiftModel->update($id, [
            'waktu_tutup'              => date('Y-m-d H:i:s'),
            'total_penjualan_cash'     => $cash,
            'total_penjualan_non_cash' => $nonCash,
            'uang_seharusnya'          => $uangSeharusnya,
            'uang_fisik_aktual'        => $uangFisik,
            'selisih'                  => $selisih,
            'catatan_penutupan'        => $this->request->getPost('catatan_penutupan'),
            'status'                   => 'tutup',
        ]);

        $pesan = 'Shift berhasil ditutup.';
        if (abs($selisih) > 0) {
            $pesan .= $selisih > 0
                ? ' Uang fisik LEBIH Rp ' . number_format($selisih, 0, ',', '.') . ' dari seharusnya.'
                : ' Uang fisik KURANG Rp ' . number_format(abs($selisih), 0, ',', '.') . ' dari seharusnya.';
        }

        return redirect()->to('shift-kasir/' . $id)->with('success', $pesan);
    }

    public function detail($id = null)
    {
        $shift = $this->shiftModel
            ->select('cashier_shifts.*, users.nama as nama_kasir, branches.nama_cabang')
            ->join('users', 'users.id = cashier_shifts.user_id')
            ->join('branches', 'branches.id = cashier_shifts.branch_id')
            ->find($id);

        if (! $shift) {
            return redirect()->to('shift-kasir')->with('error', 'Data tidak ditemukan.');
        }

        return view('shift/detail', ['title' => 'Detail Shift ' . $shift['no_shift'], 'shift' => $shift]);
    }

    /** Hitung total penjualan cash & non-cash (transfer/qris/piutang) selama sebuah shift berjalan */
    private function hitungOmzetShift(int $shiftId): array
    {
        $db = \Config\Database::connect();

        $cashRow = $db->table('sales')
            ->selectSum('grand_total')
            ->where('shift_id', $shiftId)
            ->where('metode_bayar', 'cash')
            ->where('status_transaksi', 'selesai')
            ->get()->getRow();
        $cash = (float) ($cashRow->grand_total ?? 0);

        $nonCashRow = $db->table('sales')
            ->selectSum('grand_total')
            ->where('shift_id', $shiftId)
            ->where('metode_bayar !=', 'cash')
            ->where('status_transaksi', 'selesai')
            ->get()->getRow();
        $nonCash = (float) ($nonCashRow->grand_total ?? 0);

        return [$cash, $nonCash];
    }
}
