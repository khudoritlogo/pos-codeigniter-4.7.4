<?php

namespace App\Controllers;

use App\Models\CategoryModel;

class CategoryController extends BaseController
{
    protected CategoryModel $categoryModel;

    public function __construct()
    {
        $this->categoryModel = new CategoryModel();
    }

    public function index()
    {
        return view('master/category/index', [
            'title' => 'Kategori Barang',
            'user'  => $this->currentUser(),
        ]);
    }

    /** Data untuk DataTable client-side (JSON) */
    public function data()
    {
        return $this->response->setJSON([
            'data' => $this->categoryModel->orderBy('nama_kategori', 'ASC')->findAll(),
        ]);
    }

    public function new()
    {
        return view('master/category/form', [
            'title'    => 'Tambah Kategori',
            'category' => null,
        ]);
    }

    public function create()
    {
        if (! $this->validateData($this->request->getPost(), $this->categoryModel->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->categoryModel->insert($this->request->getPost(['kode_kategori', 'nama_kategori']));
        return redirect()->to('kategori')->with('success', 'Kategori berhasil ditambahkan.');
    }

    public function edit($id = null)
    {
        $category = $this->categoryModel->find($id);
        if (! $category) {
            return redirect()->to('kategori')->with('error', 'Data tidak ditemukan.');
        }
        return view('master/category/form', [
            'title'    => 'Edit Kategori',
            'category' => $category,
        ]);
    }

    public function update($id = null)
    {
        $rules = $this->categoryModel->validationRules;
        $rules['kode_kategori'] = "required|max_length[30]|is_unique[categories.kode_kategori,id,{$id}]";

        if (! $this->validateData($this->request->getPost(), $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->categoryModel->update($id, $this->request->getPost(['kode_kategori', 'nama_kategori']));
        return redirect()->to('kategori')->with('success', 'Kategori berhasil diperbarui.');
    }

    public function delete($id = null)
    {
        $this->categoryModel->delete($id);
        return redirect()->to('kategori')->with('success', 'Kategori berhasil dihapus.');
    }
}
