<?php

namespace App\Controllers;

use App\Models\BranchModel;

class BranchController extends BaseController
{
    protected BranchModel $branchModel;
    protected array $fields = ['kode_cabang', 'nama_cabang', 'alamat', 'telepon', 'email', 'is_pusat', 'status'];

    public function __construct()
    {
        $this->branchModel = new BranchModel();
    }

    public function index()
    {
        return view('master/branch/index', ['title' => 'Cabang']);
    }

    public function data()
    {
        return $this->response->setJSON(['data' => $this->branchModel->orderBy('nama_cabang', 'ASC')->findAll()]);
    }

    public function new()
    {
        return view('master/branch/form', ['title' => 'Tambah Cabang', 'branch' => null]);
    }

    public function create()
    {
        if (! $this->validateData($this->request->getPost(), $this->branchModel->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $post = $this->request->getPost($this->fields);
        $post['is_pusat'] = $this->request->getPost('is_pusat') ? 1 : 0;
        $post['status']   = $this->request->getPost('status') ? 1 : 0;
        $this->branchModel->insert($post);
        return redirect()->to('cabang')->with('success', 'Cabang berhasil ditambahkan.');
    }

    public function edit($id = null)
    {
        $branch = $this->branchModel->find($id);
        if (! $branch) {
            return redirect()->to('cabang')->with('error', 'Data tidak ditemukan.');
        }
        return view('master/branch/form', ['title' => 'Edit Cabang', 'branch' => $branch]);
    }

    public function update($id = null)
    {
        $rules = $this->branchModel->validationRules;
        $rules['kode_cabang'] = "required|is_unique[branches.kode_cabang,id,{$id}]";

        if (! $this->validateData($this->request->getPost(), $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $post = $this->request->getPost($this->fields);
        $post['is_pusat'] = $this->request->getPost('is_pusat') ? 1 : 0;
        $post['status']   = $this->request->getPost('status') ? 1 : 0;
        $this->branchModel->update($id, $post);
        return redirect()->to('cabang')->with('success', 'Cabang berhasil diperbarui.');
    }

    public function delete($id = null)
    {
        // Cegah hapus cabang yang masih dipakai user
        $userCount = $this->db()->table('users')->where('branch_id', $id)->countAllResults();
        if ($userCount > 0) {
            return redirect()->to('cabang')->with('error', 'Cabang masih memiliki pengguna terdaftar, tidak bisa dihapus.');
        }
        $this->branchModel->delete($id);
        return redirect()->to('cabang')->with('success', 'Cabang berhasil dihapus.');
    }

    private function db()
    {
        return \Config\Database::connect();
    }
}
