<?php

namespace App\Controllers;

use App\Models\CustomerLevelModel;
use App\Models\CustomerModel;
use App\Models\LoyaltyPointMutationModel;

class CustomerController extends BaseController
{
    protected CustomerModel $customerModel;
    protected CustomerLevelModel $levelModel;
    protected LoyaltyPointMutationModel $mutationModel;
    protected array $fields = ['kode_customer', 'nama_customer', 'tipe_customer', 'customer_level_id', 'telepon', 'email', 'alamat', 'limit_piutang'];

    public function __construct()
    {
        $this->customerModel = new CustomerModel();
        $this->levelModel    = new CustomerLevelModel();
        $this->mutationModel = new LoyaltyPointMutationModel();
    }

    public function index()
    {
        return view('master/customer/index', ['title' => 'Customer']);
    }

    public function data()
    {
        return $this->response->setJSON(['data' => $this->customerModel->listWithLevel()]);
    }

    public function new()
    {
        return view('master/customer/form', [
            'title' => 'Tambah Customer', 'customer' => null,
            'levels' => $this->levelModel->ordered(),
        ]);
    }

    public function create()
    {
        if (! $this->validateData($this->request->getPost(), $this->customerModel->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $post = $this->request->getPost($this->fields);
        $post['customer_level_id'] = $post['customer_level_id'] ?: null;
        $this->customerModel->insert($post);
        return redirect()->to('customer')->with('success', 'Customer berhasil ditambahkan.');
    }

    public function edit($id = null)
    {
        $customer = $this->customerModel->find($id);
        if (! $customer) {
            return redirect()->to('customer')->with('error', 'Data tidak ditemukan.');
        }
        return view('master/customer/form', [
            'title' => 'Edit Customer', 'customer' => $customer,
            'levels' => $this->levelModel->ordered(),
            'poinHistory' => $this->mutationModel->byCustomer((int) $id),
        ]);
    }

    public function update($id = null)
    {
        $rules = $this->customerModel->validationRules;
        $rules['kode_customer'] = "required|max_length[30]|is_unique[customers.kode_customer,id,{$id}]";

        if (! $this->validateData($this->request->getPost(), $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $post = $this->request->getPost($this->fields);
        $post['customer_level_id'] = $post['customer_level_id'] ?: null;
        $this->customerModel->update($id, $post);
        return redirect()->to('customer')->with('success', 'Customer berhasil diperbarui.');
    }

    public function delete($id = null)
    {
        // Cegah hapus customer yang masih punya piutang berjalan
        if ($this->customerModel->totalPiutangAktif((int) $id) > 0) {
            return redirect()->to('customer')->with('error', 'Customer masih memiliki piutang aktif, tidak bisa dihapus.');
        }
        $this->customerModel->delete($id);
        return redirect()->to('customer')->with('success', 'Customer berhasil dihapus.');
    }
}
