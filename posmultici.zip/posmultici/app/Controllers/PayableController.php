<?php

namespace App\Controllers;

use App\Models\PayableModel;
use App\Models\PayablePaymentModel;

class PayableController extends BaseController
{
    protected PayableModel $payableModel;
    protected PayablePaymentModel $paymentModel;

    public function __construct()
    {
        $this->payableModel = new PayableModel();
        $this->paymentModel = new PayablePaymentModel();
    }

    public function index()
    {
        $this->payableModel->tandaiMenunggak();
        return view('payable/index', ['title' => 'Hutang']);
    }

    public function data()
    {
        $user = $this->currentUser();
        $onlyMenunggak = $this->request->getGet('menunggak') === '1';
        return $this->response->setJSON(['data' => $this->payableModel->listWithRelations($user['branch_id'], $onlyMenunggak)]);
    }

    public function detail($id = null)
    {
        $payable = $this->payableModel
            ->select('payables.*, suppliers.nama_supplier, suppliers.telepon, purchases.no_pembelian')
            ->join('suppliers', 'suppliers.id = payables.supplier_id')
            ->join('purchases', 'purchases.id = payables.purchase_id')
            ->find($id);

        if (! $payable) {
            return redirect()->to('hutang')->with('error', 'Data hutang tidak ditemukan.');
        }

        return view('payable/detail', [
            'title'    => 'Detail Hutang — ' . $payable['no_pembelian'],
            'payable'  => $payable,
            'payments' => $this->paymentModel->byPayable((int) $id),
        ]);
    }

    /** Catat pembayaran cicilan hutang ke supplier; status otomatis jadi "lunas" begitu sisa hutang mencapai 0 */
    public function bayar($id = null)
    {
        $payable = $this->payableModel->find($id);
        if (! $payable) {
            return redirect()->to('hutang')->with('error', 'Data hutang tidak ditemukan.');
        }

        $jumlah = (float) $this->request->getPost('jumlah_bayar');
        if ($jumlah <= 0) {
            return redirect()->back()->with('error', 'Jumlah bayar harus lebih dari 0.');
        }
        if ($jumlah > (float) $payable['sisa_hutang']) {
            return redirect()->back()->with('error', 'Jumlah bayar melebihi sisa hutang.');
        }

        $user = $this->currentUser();
        $db   = \Config\Database::connect();
        $db->transStart();

        try {
            $this->paymentModel->insert([
                'payable_id'    => $id,
                'user_id'       => $user['id'],
                'tanggal_bayar' => date('Y-m-d H:i:s'),
                'jumlah_bayar'  => $jumlah,
                'metode_bayar'  => $this->request->getPost('metode_bayar') ?: 'cash',
                'catatan'       => $this->request->getPost('catatan'),
            ]);

            $totalDibayarBaru = (float) $payable['total_dibayar'] + $jumlah;
            $sisaBaru = (float) $payable['total_hutang'] - $totalDibayarBaru;

            $this->payableModel->update($id, [
                'total_dibayar' => $totalDibayarBaru,
                'sisa_hutang'   => max(0, $sisaBaru),
                'status'        => $sisaBaru <= 0 ? 'lunas' : 'cicilan',
            ]);

            $db->transComplete();
            if ($db->transStatus() === false) {
                throw new \RuntimeException('Gagal mencatat pembayaran.');
            }

            return redirect()->to('hutang/' . $id)->with('success', 'Pembayaran cicilan berhasil dicatat.');
        } catch (\Throwable $e) {
            $db->transRollback();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
