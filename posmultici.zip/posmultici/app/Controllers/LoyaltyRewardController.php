<?php

namespace App\Controllers;

use App\Models\LoyaltyRewardModel;
use App\Models\ProductModel;

class LoyaltyRewardController extends BaseController
{
    protected LoyaltyRewardModel $rewardModel;
    protected ProductModel $productModel;

    public function __construct()
    {
        $this->rewardModel  = new LoyaltyRewardModel();
        $this->productModel = new ProductModel();
    }

    public function index()
    {
        return view('loyalty/reward_index', ['title' => 'Katalog Hadiah Poin']);
    }

    public function data()
    {
        $rewards = $this->rewardModel
            ->select('loyalty_rewards.*, products.nama_barang')
            ->join('products', 'products.id = loyalty_rewards.product_id', 'left')
            ->orderBy('poin_dibutuhkan', 'ASC')
            ->findAll();
        return $this->response->setJSON(['data' => $rewards]);
    }

    public function new()
    {
        return view('loyalty/reward_form', [
            'title' => 'Tambah Hadiah', 'reward' => null,
            'products' => $this->productModel->where('status', 1)->orderBy('nama_barang')->findAll(),
        ]);
    }

    public function create()
    {
        if (! $this->validateData($this->request->getPost(), $this->rewardModel->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->rewardModel->insert([
            'product_id'      => $this->request->getPost('product_id') ?: null,
            'nama_hadiah'     => $this->request->getPost('nama_hadiah'),
            'poin_dibutuhkan' => $this->request->getPost('poin_dibutuhkan'),
            'stok_hadiah'     => $this->request->getPost('stok_hadiah') ?: 0,
            'status'          => $this->request->getPost('status') ? 1 : 0,
        ]);
        return redirect()->to('hadiah-poin')->with('success', 'Hadiah berhasil ditambahkan.');
    }

    public function edit($id = null)
    {
        $reward = $this->rewardModel->find($id);
        if (! $reward) {
            return redirect()->to('hadiah-poin')->with('error', 'Data tidak ditemukan.');
        }
        return view('loyalty/reward_form', [
            'title' => 'Edit Hadiah', 'reward' => $reward,
            'products' => $this->productModel->where('status', 1)->orderBy('nama_barang')->findAll(),
        ]);
    }

    public function update($id = null)
    {
        if (! $this->validateData($this->request->getPost(), $this->rewardModel->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->rewardModel->update($id, [
            'product_id'      => $this->request->getPost('product_id') ?: null,
            'nama_hadiah'     => $this->request->getPost('nama_hadiah'),
            'poin_dibutuhkan' => $this->request->getPost('poin_dibutuhkan'),
            'stok_hadiah'     => $this->request->getPost('stok_hadiah') ?: 0,
            'status'          => $this->request->getPost('status') ? 1 : 0,
        ]);
        return redirect()->to('hadiah-poin')->with('success', 'Hadiah berhasil diperbarui.');
    }

    public function delete($id = null)
    {
        $this->rewardModel->delete($id);
        return redirect()->to('hadiah-poin')->with('success', 'Hadiah berhasil dihapus.');
    }
}
