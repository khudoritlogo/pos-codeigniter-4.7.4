<?php

namespace App\Controllers;

use App\Models\CustomerLevelModel;

class CustomerLevelController extends BaseController
{
    protected CustomerLevelModel $levelModel;

    public function __construct()
    {
        $this->levelModel = new CustomerLevelModel();
    }

    public function index()
    {
        return view('master/customer_level/index', ['title' => 'Level Member']);
    }

    public function data()
    {
        return $this->response->setJSON(['data' => $this->levelModel->ordered()]);
    }

    public function new()
    {
        return view('master/customer_level/form', ['title' => 'Tambah Level Member', 'level' => null]);
    }

    public function create()
    {
        if (! $this->validateData($this->request->getPost(), $this->levelModel->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->levelModel->insert($this->request->getPost(['kode_level', 'nama_level', 'diskon_persen', 'min_poin_naik', 'urutan']));
        return redirect()->to('level-member')->with('success', 'Level member berhasil ditambahkan.');
    }

    public function edit($id = null)
    {
        $level = $this->levelModel->find($id);
        if (! $level) {
            return redirect()->to('level-member')->with('error', 'Data tidak ditemukan.');
        }
        return view('master/customer_level/form', ['title' => 'Edit Level Member', 'level' => $level]);
    }

    public function update($id = null)
    {
        $rules = $this->levelModel->validationRules;
        $rules['kode_level'] = "required|max_length[30]|is_unique[customer_levels.kode_level,id,{$id}]";
        if (! $this->validateData($this->request->getPost(), $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->levelModel->update($id, $this->request->getPost(['kode_level', 'nama_level', 'diskon_persen', 'min_poin_naik', 'urutan']));
        return redirect()->to('level-member')->with('success', 'Level member berhasil diperbarui.');
    }

    public function delete($id = null)
    {
        $dipakai = $this->levelModel->db->table('customers')->where('customer_level_id', $id)->countAllResults();
        if ($dipakai > 0) {
            return redirect()->to('level-member')->with('error', 'Level ini masih dipakai oleh customer, tidak bisa dihapus.');
        }
        $this->levelModel->delete($id);
        return redirect()->to('level-member')->with('success', 'Level member berhasil dihapus.');
    }
}
