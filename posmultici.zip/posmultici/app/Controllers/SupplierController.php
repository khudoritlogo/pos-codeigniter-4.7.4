<?php

namespace App\Controllers;

use App\Models\SupplierModel;

class SupplierController extends BaseController
{
    protected SupplierModel $supplierModel;
    protected array $fields = ['kode_supplier', 'nama_supplier', 'penanggung_jawab', 'telepon', 'email', 'alamat'];

    public function __construct()
    {
        $this->supplierModel = new SupplierModel();
    }

    public function index()
    {
        return view('master/supplier/index', ['title' => 'Supplier']);
    }

    public function data()
    {
        return $this->response->setJSON(['data' => $this->supplierModel->orderBy('nama_supplier', 'ASC')->findAll()]);
    }

    public function new()
    {
        return view('master/supplier/form', ['title' => 'Tambah Supplier', 'supplier' => null]);
    }

    public function create()
    {
        if (! $this->validateData($this->request->getPost(), $this->supplierModel->validationRules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->supplierModel->insert($this->request->getPost($this->fields));
        return redirect()->to('supplier')->with('success', 'Supplier berhasil ditambahkan.');
    }

    public function edit($id = null)
    {
        $supplier = $this->supplierModel->find($id);
        if (! $supplier) {
            return redirect()->to('supplier')->with('error', 'Data tidak ditemukan.');
        }
        return view('master/supplier/form', ['title' => 'Edit Supplier', 'supplier' => $supplier]);
    }

    public function update($id = null)
    {
        $rules = $this->supplierModel->validationRules;
        $rules['kode_supplier'] = "required|max_length[30]|is_unique[suppliers.kode_supplier,id,{$id}]";

        if (! $this->validateData($this->request->getPost(), $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        $this->supplierModel->update($id, $this->request->getPost($this->fields));
        return redirect()->to('supplier')->with('success', 'Supplier berhasil diperbarui.');
    }

    public function delete($id = null)
    {
        $this->supplierModel->delete($id);
        return redirect()->to('supplier')->with('success', 'Supplier berhasil dihapus.');
    }
}
