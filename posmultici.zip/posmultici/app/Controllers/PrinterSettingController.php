<?php

namespace App\Controllers;

use App\Models\PrinterSettingModel;

class PrinterSettingController extends BaseController
{
    protected PrinterSettingModel $printerSettingModel;

    public function __construct()
    {
        $this->printerSettingModel = new PrinterSettingModel();
    }

    public function index()
    {
        $user    = $this->currentUser();
        $setting = $this->printerSettingModel->getForBranch($user['branch_id']);

        return view('settings/printer', [
            'title'   => 'Pengaturan Printer',
            'setting' => $setting,
        ]);
    }

    public function update()
    {
        $rules = [
            'ukuran_kertas' => 'required|in_list[58mm,80mm,custom]',
            'font_size'     => 'required|integer|greater_than[0]',
            'jumlah_copy'   => 'required|integer|greater_than[0]',
        ];
        if (! $this->validateData($this->request->getPost(), $rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $user = $this->currentUser();
        $data = [
            'branch_id'       => $user['branch_id'],
            'ukuran_kertas'   => $this->request->getPost('ukuran_kertas'),
            'lebar_custom_mm' => $this->request->getPost('ukuran_kertas') === 'custom' ? $this->request->getPost('lebar_custom_mm') : null,
            'font_size'       => $this->request->getPost('font_size'),
            'tampilkan_logo'  => $this->request->getPost('tampilkan_logo') ? 1 : 0,
            'jumlah_copy'     => $this->request->getPost('jumlah_copy'),
            'updated_at'      => date('Y-m-d H:i:s'),
        ];

        $existing = $this->printerSettingModel->where('branch_id', $user['branch_id'])->first();
        if ($existing) {
            $this->printerSettingModel->update($existing['id'], $data);
        } else {
            $this->printerSettingModel->insert($data);
        }

        return redirect()->to('pengaturan-printer')->with('success', 'Pengaturan printer berhasil disimpan.');
    }
}
