<?php

namespace App\Controllers;

use App\Models\AuditLogModel;

class AuditLogController extends BaseController
{
    protected AuditLogModel $auditLogModel;

    public function __construct()
    {
        $this->auditLogModel = new AuditLogModel();
    }

    public function index()
    {
        return view('audit/index', ['title' => 'Audit Log']);
    }

    public function data()
    {
        $user = $this->currentUser();
        $rows = $this->auditLogModel->listWithRelations($user['branch_id']);
        // Uraikan JSON 'detail' supaya gampang ditampilkan di tabel tanpa parsing di JS
        foreach ($rows as &$r) {
            $detail = json_decode($r['detail'] ?? '{}', true) ?: [];
            $r['detail_text'] = implode(', ', array_map(fn ($k, $v) => "{$k}: {$v}", array_keys($detail), $detail));
        }
        unset($r);
        return $this->response->setJSON(['data' => $rows]);
    }
}
