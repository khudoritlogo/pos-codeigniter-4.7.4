<?php

namespace App\Controllers;

use App\Libraries\StockService;
use App\Models\PayableModel;
use App\Models\ProductBatchModel;
use App\Models\ProductModel;
use App\Models\ProductSerialModel;
use App\Models\PurchaseItemModel;
use App\Models\PurchaseModel;
use App\Models\SupplierModel;

class PurchaseController extends BaseController
{
    protected PurchaseModel $purchaseModel;
    protected PurchaseItemModel $purchaseItemModel;
    protected ProductModel $productModel;
    protected ProductSerialModel $serialModel;
    protected ProductBatchModel $batchModel;
    protected SupplierModel $supplierModel;
    protected PayableModel $payableModel;
    protected StockService $stockService;

    public function __construct()
    {
        $this->purchaseModel     = new PurchaseModel();
        $this->purchaseItemModel = new PurchaseItemModel();
        $this->productModel      = new ProductModel();
        $this->serialModel       = new ProductSerialModel();
        $this->batchModel        = new ProductBatchModel();
        $this->supplierModel     = new SupplierModel();
        $this->payableModel      = new PayableModel();
        $this->stockService      = new StockService();
    }

    public function index()
    {
        return view('purchase/index', ['title' => 'Pembelian']);
    }

    public function data()
    {
        $user = $this->currentUser();
        return $this->response->setJSON(['data' => $this->purchaseModel->listWithRelations($user['branch_id'])]);
    }

    public function new()
    {
        return view('purchase/form', [
            'title'     => 'Pembelian Baru',
            'suppliers' => $this->supplierModel->orderBy('nama_supplier')->findAll(),
            'products'  => $this->productModel->where('status', 1)->orderBy('nama_barang')->findAll(),
        ]);
    }

    public function create()
    {
        $user     = $this->currentUser();
        $branchId = $user['branch_id'];
        if (! $branchId) {
            return redirect()->back()->with('error', 'Super Admin tidak terikat cabang; pembelian harus dilakukan oleh user cabang.');
        }

        $supplierId = (int) $this->request->getPost('supplier_id');
        $productIds = $this->request->getPost('product_id') ?? [];
        $qtys       = $this->request->getPost('qty') ?? [];
        $hargas     = $this->request->getPost('harga') ?? [];
        $serialsRaw = $this->request->getPost('serials') ?? []; // textarea per baris, dipisah baris baru
        $noBatchArr = $this->request->getPost('no_batch') ?? []; // Fitur #8: nomor batch per baris (barang has_expiry)
        $expiredArr = $this->request->getPost('tanggal_kedaluwarsa') ?? []; // Fitur #8: tanggal expired per baris
        $metodeBayar = $this->request->getPost('metode_bayar') ?: 'cash';
        $bayar       = (float) $this->request->getPost('bayar');
        $diskon      = (float) $this->request->getPost('diskon');

        if (empty($productIds)) {
            return redirect()->back()->withInput()->with('error', 'Minimal 1 barang harus diisi.');
        }

        $db = \Config\Database::connect();
        $db->transStart();

        try {
            $subtotal = 0;
            $validItems = [];
            foreach ($productIds as $i => $productId) {
                if (empty($productId) || empty($qtys[$i])) {
                    continue;
                }
                $qty = (float) $qtys[$i];
                $harga = (float) $hargas[$i];
                $itemSubtotal = $qty * $harga;
                $subtotal += $itemSubtotal;
                $validItems[] = [
                    'product_id' => $productId, 'qty' => $qty, 'harga' => $harga,
                    'subtotal' => $itemSubtotal, 'serials' => $serialsRaw[$i] ?? '',
                    'no_batch' => $noBatchArr[$i] ?? '', 'tanggal_kedaluwarsa' => $expiredArr[$i] ?? '',
                ];
            }

            if (empty($validItems)) {
                throw new \RuntimeException('Tidak ada barang valid untuk disimpan.');
            }

            $grandTotal  = max(0, $subtotal - $diskon);
            $statusBayar = 'lunas';
            if ($metodeBayar === 'hutang') {
                $statusBayar = $bayar >= $grandTotal ? 'lunas' : ($bayar > 0 ? 'cicilan' : 'belum_lunas');
            }

            $noPembelian = $this->purchaseModel->generateNoPembelian($branchId);
            $purchaseId = $this->purchaseModel->insert([
                'no_pembelian' => $noPembelian,
                'branch_id'    => $branchId,
                'supplier_id'  => $supplierId,
                'user_id'      => $user['id'],
                'tanggal'      => date('Y-m-d H:i:s'),
                'subtotal'     => $subtotal,
                'diskon'       => $diskon,
                'grand_total'  => $grandTotal,
                'bayar'        => $bayar,
                'metode_bayar' => $metodeBayar,
                'status_bayar' => $statusBayar,
                'catatan'      => $this->request->getPost('catatan'),
            ], true);

            foreach ($validItems as $v) {
                $product = $this->productModel->find($v['product_id']);
                $itemId = $this->purchaseItemModel->insert([
                    'purchase_id' => $purchaseId,
                    'product_id'  => $v['product_id'],
                    'unit_id'     => $product['unit_id'],
                    'qty'         => $v['qty'],
                    'harga'       => $v['harga'],
                    'subtotal'    => $v['subtotal'],
                ], true);

                if ($product['jenis_produk'] === 'sn') {
                    $serialList = array_filter(array_map('trim', explode("\n", $v['serials'])));
                    foreach ($serialList as $sn) {
                        $this->serialModel->insert([
                            'product_id'        => $v['product_id'],
                            'branch_id'         => $branchId,
                            'serial_number'     => $sn,
                            'status'            => 'tersedia',
                            'purchase_item_id'  => $itemId,
                        ]);
                    }
                } else {
                    $this->stockService->increase(
                        (int) $v['product_id'], $branchId, $v['qty'], 'pembelian',
                        'purchases', $purchaseId, "Pembelian {$noPembelian}", $user['id']
                    );

                    // Fitur #8: barang bertanggal kedaluwarsa wajib dicatat batch + expired-nya
                    if ($product['has_expiry'] && ! empty($v['no_batch']) && ! empty($v['tanggal_kedaluwarsa'])) {
                        $this->batchModel->insert([
                            'product_id'          => $v['product_id'],
                            'branch_id'           => $branchId,
                            'no_batch'            => $v['no_batch'],
                            'tanggal_masuk'       => date('Y-m-d'),
                            'tanggal_kedaluwarsa' => $v['tanggal_kedaluwarsa'],
                            'qty_masuk'           => $v['qty'],
                            'qty_sisa'            => $v['qty'],
                            'purchase_item_id'    => $itemId,
                        ]);
                    }
                }

                // Harga beli terbaru otomatis update di master barang (opsional tapi umum di POS)
                $this->productModel->update($v['product_id'], ['harga_beli' => $v['harga']]);
            }

            if ($metodeBayar === 'hutang' && $grandTotal > $bayar) {
                $this->payableModel->insert([
                    'purchase_id'   => $purchaseId,
                    'supplier_id'   => $supplierId,
                    'branch_id'     => $branchId,
                    'total_hutang'  => $grandTotal,
                    'total_dibayar' => $bayar,
                    'sisa_hutang'   => $grandTotal - $bayar,
                    'jatuh_tempo'   => date('Y-m-d', strtotime('+30 days')),
                    'status'        => $statusBayar,
                ]);
            }

            $db->transComplete();
            if ($db->transStatus() === false) {
                throw new \RuntimeException('Gagal menyimpan pembelian.');
            }

            return redirect()->to('pembelian/' . $purchaseId)->with('success', "Pembelian {$noPembelian} berhasil disimpan.");
        } catch (\Throwable $e) {
            $db->transRollback();
            return redirect()->back()->withInput()->with('error', $e->getMessage());
        }
    }

    public function detail($id = null)
    {
        $purchase = $this->purchaseModel->find($id);
        if (! $purchase) {
            return redirect()->to('pembelian')->with('error', 'Data tidak ditemukan.');
        }
        return view('purchase/detail', [
            'title'    => 'Detail Pembelian ' . $purchase['no_pembelian'],
            'purchase' => $purchase,
            'items'    => $this->purchaseItemModel->byPurchase((int) $id),
        ]);
    }
}
