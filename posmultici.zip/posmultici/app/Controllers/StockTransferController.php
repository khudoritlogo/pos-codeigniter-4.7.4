<?php

namespace App\Controllers;

use App\Libraries\StockService;
use App\Models\BranchModel;
use App\Models\ProductModel;
use App\Models\StockTransferItemModel;
use App\Models\StockTransferModel;

class StockTransferController extends BaseController
{
    protected StockTransferModel $stockTransferModel;
    protected StockTransferItemModel $stockTransferItemModel;
    protected ProductModel $productModel;
    protected BranchModel $branchModel;
    protected StockService $stockService;

    public function __construct()
    {
        $this->stockTransferModel     = new StockTransferModel();
        $this->stockTransferItemModel = new StockTransferItemModel();
        $this->productModel           = new ProductModel();
        $this->branchModel            = new BranchModel();
        $this->stockService           = new StockService();
    }

    public function index()
    {
        return view('stock_transfer/index', ['title' => 'Transfer Stok Antar Cabang']);
    }

    public function data()
    {
        $user = $this->currentUser();
        return $this->response->setJSON(['data' => $this->stockTransferModel->listForBranch($user['branch_id'])]);
    }

    public function new()
    {
        return view('stock_transfer/form', [
            'title'    => 'Transfer Stok Baru',
            'branches' => $this->branchModel->where('status', 1)->findAll(),
            'products' => $this->productModel->where('status', 1)->where('jenis_produk', 'non_sn')->orderBy('nama_barang')->findAll(),
        ]);
    }

    public function create()
    {
        $user = $this->currentUser();
        $branchFrom = $user['branch_id'] ?: (int) $this->request->getPost('branch_from_id');
        $branchTo   = (int) $this->request->getPost('branch_to_id');

        if ($branchFrom == $branchTo) {
            return redirect()->back()->withInput()->with('error', 'Cabang asal dan tujuan tidak boleh sama.');
        }

        $productIds = $this->request->getPost('product_id') ?? [];
        $qtys       = $this->request->getPost('qty') ?? [];

        $validItems = [];
        foreach ($productIds as $i => $productId) {
            $qty = (float) ($qtys[$i] ?? 0);
            if (! empty($productId) && $qty > 0) {
                $validItems[] = ['product_id' => $productId, 'qty' => $qty];
            }
        }
        if (empty($validItems)) {
            return redirect()->back()->withInput()->with('error', 'Minimal 1 barang harus diisi.');
        }

        $noTransfer = $this->stockTransferModel->generateNoTransfer();
        $transferId = $this->stockTransferModel->insert([
            'no_transfer'    => $noTransfer,
            'branch_from_id' => $branchFrom,
            'branch_to_id'   => $branchTo,
            'user_id'        => $user['id'],
            'tanggal'        => date('Y-m-d H:i:s'),
            'status'         => 'diajukan',
            'catatan'        => $this->request->getPost('catatan'),
        ], true);

        foreach ($validItems as $v) {
            $this->stockTransferItemModel->insert([
                'stock_transfer_id' => $transferId,
                'product_id'        => $v['product_id'],
                'qty'               => $v['qty'],
            ]);
        }

        return redirect()->to('transfer-stok/' . $transferId)->with('success', "Transfer {$noTransfer} berhasil diajukan.");
    }

    public function detail($id = null)
    {
        $transfer = $this->stockTransferModel->find($id);
        if (! $transfer) {
            return redirect()->to('transfer-stok')->with('error', 'Data tidak ditemukan.');
        }
        return view('stock_transfer/detail', [
            'title'    => 'Detail Transfer ' . $transfer['no_transfer'],
            'transfer' => $transfer,
            'items'    => $this->stockTransferItemModel->byTransfer((int) $id),
        ]);
    }

    /** Cabang asal mengirim: stok cabang asal berkurang saat ini juga */
    public function kirim($id = null)
    {
        $transfer = $this->stockTransferModel->find($id);
        if (! $transfer || $transfer['status'] !== 'diajukan') {
            return redirect()->back()->with('error', 'Transfer tidak bisa dikirim (status tidak valid).');
        }

        $user = $this->currentUser();
        $db = \Config\Database::connect();
        $db->transStart();
        try {
            foreach ($this->stockTransferItemModel->byTransfer((int) $id) as $item) {
                $this->stockService->decrease(
                    (int) $item['product_id'], (int) $transfer['branch_from_id'], (float) $item['qty'],
                    'transfer_keluar', 'stock_transfers', (int) $id, "Transfer {$transfer['no_transfer']} keluar", $user['id']
                );
            }
            $this->stockTransferModel->update($id, ['status' => 'dikirim']);
            $db->transComplete();
            if ($db->transStatus() === false) {
                throw new \RuntimeException('Gagal memproses pengiriman.');
            }
            return redirect()->to('transfer-stok/' . $id)->with('success', 'Barang berhasil ditandai dikirim, stok cabang asal telah dikurangi.');
        } catch (\Throwable $e) {
            $db->transRollback();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /** Cabang tujuan menerima: stok cabang tujuan bertambah */
    public function terima($id = null)
    {
        $transfer = $this->stockTransferModel->find($id);
        if (! $transfer || $transfer['status'] !== 'dikirim') {
            return redirect()->back()->with('error', 'Transfer belum berstatus dikirim.');
        }

        $user = $this->currentUser();
        $db = \Config\Database::connect();
        $db->transStart();
        try {
            foreach ($this->stockTransferItemModel->byTransfer((int) $id) as $item) {
                $this->stockService->increase(
                    (int) $item['product_id'], (int) $transfer['branch_to_id'], (float) $item['qty'],
                    'transfer_masuk', 'stock_transfers', (int) $id, "Transfer {$transfer['no_transfer']} masuk", $user['id']
                );
            }
            $this->stockTransferModel->update($id, ['status' => 'diterima']);
            $db->transComplete();
            if ($db->transStatus() === false) {
                throw new \RuntimeException('Gagal memproses penerimaan.');
            }
            return redirect()->to('transfer-stok/' . $id)->with('success', 'Barang berhasil diterima, stok cabang tujuan telah bertambah.');
        } catch (\Throwable $e) {
            $db->transRollback();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }

    /** Batalkan transfer: jika sudah terlanjur dikirim, stok dikembalikan ke cabang asal */
    public function batal($id = null)
    {
        $transfer = $this->stockTransferModel->find($id);
        if (! $transfer || in_array($transfer['status'], ['diterima', 'batal'], true)) {
            return redirect()->back()->with('error', 'Transfer tidak bisa dibatalkan (status tidak valid).');
        }

        $user = $this->currentUser();
        $db = \Config\Database::connect();
        $db->transStart();
        try {
            if ($transfer['status'] === 'dikirim') {
                foreach ($this->stockTransferItemModel->byTransfer((int) $id) as $item) {
                    $this->stockService->increase(
                        (int) $item['product_id'], (int) $transfer['branch_from_id'], (float) $item['qty'],
                        'transfer_masuk', 'stock_transfers', (int) $id, "Pembatalan transfer {$transfer['no_transfer']}", $user['id']
                    );
                }
            }
            $this->stockTransferModel->update($id, ['status' => 'batal']);
            $db->transComplete();
            if ($db->transStatus() === false) {
                throw new \RuntimeException('Gagal membatalkan transfer.');
            }
            return redirect()->to('transfer-stok/' . $id)->with('success', 'Transfer berhasil dibatalkan.');
        } catch (\Throwable $e) {
            $db->transRollback();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
