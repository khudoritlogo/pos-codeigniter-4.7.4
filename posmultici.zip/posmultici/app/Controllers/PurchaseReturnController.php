<?php

namespace App\Controllers;

use App\Libraries\StockService;
use App\Models\PayableModel;
use App\Models\PurchaseItemModel;
use App\Models\PurchaseModel;
use App\Models\PurchaseReturnItemModel;
use App\Models\PurchaseReturnModel;

class PurchaseReturnController extends BaseController
{
    protected PurchaseReturnModel $purchaseReturnModel;
    protected PurchaseReturnItemModel $purchaseReturnItemModel;
    protected PurchaseModel $purchaseModel;
    protected PurchaseItemModel $purchaseItemModel;
    protected PayableModel $payableModel;
    protected StockService $stockService;

    public function __construct()
    {
        $this->purchaseReturnModel     = new PurchaseReturnModel();
        $this->purchaseReturnItemModel = new PurchaseReturnItemModel();
        $this->purchaseModel           = new PurchaseModel();
        $this->purchaseItemModel       = new PurchaseItemModel();
        $this->payableModel            = new PayableModel();
        $this->stockService            = new StockService();
    }

    public function index()
    {
        return view('purchase_return/index', ['title' => 'Retur Pembelian']);
    }

    public function data()
    {
        $user = $this->currentUser();
        return $this->response->setJSON(['data' => $this->purchaseReturnModel->listWithRelations($user['branch_id'])]);
    }

    public function new()
    {
        return view('purchase_return/form', ['title' => 'Retur Pembelian Baru']);
    }

    public function cariPembelian()
    {
        $noPembelian = trim((string) $this->request->getGet('no_pembelian'));
        $purchase = $this->purchaseModel->where('no_pembelian', $noPembelian)->first();
        if (! $purchase) {
            return $this->response->setJSON(['found' => false]);
        }

        $items = $this->purchaseItemModel->byPurchase((int) $purchase['id']);
        $items = array_map(function ($it) {
            $it['qty_bisa_retur'] = (float) $it['qty'] - (float) $it['qty_retur'];
            return $it;
        }, $items);

        return $this->response->setJSON(['found' => true, 'purchase' => $purchase, 'items' => $items]);
    }

    public function create()
    {
        $purchaseId = (int) $this->request->getPost('purchase_id');
        $itemIds = $this->request->getPost('purchase_item_id') ?? [];
        $qtys    = $this->request->getPost('qty') ?? [];
        $alasan  = $this->request->getPost('alasan');

        $purchase = $this->purchaseModel->find($purchaseId);
        if (! $purchase) {
            return redirect()->back()->with('error', 'Transaksi pembelian asal tidak ditemukan.');
        }

        $user = $this->currentUser();
        $db   = \Config\Database::connect();
        $db->transStart();

        try {
            $totalRetur = 0;
            $validItems = [];
            foreach ($itemIds as $i => $purchaseItemId) {
                $qty = (float) ($qtys[$i] ?? 0);
                if ($qty <= 0) {
                    continue;
                }
                $purchaseItem = $this->purchaseItemModel->find($purchaseItemId);
                $bisaRetur = (float) $purchaseItem['qty'] - (float) $purchaseItem['qty_retur'];
                if ($qty > $bisaRetur) {
                    throw new \RuntimeException('Qty retur melebihi qty yang bisa diretur untuk salah satu barang.');
                }
                $subtotal = $purchaseItem['harga'] * $qty;
                $totalRetur += $subtotal;
                $validItems[] = ['purchase_item' => $purchaseItem, 'qty' => $qty, 'subtotal' => $subtotal];
            }

            if (empty($validItems)) {
                throw new \RuntimeException('Tidak ada barang yang diretur.');
            }

            $noRetur = $this->purchaseReturnModel->generateNoRetur($purchase['branch_id']);
            $returId = $this->purchaseReturnModel->insert([
                'no_retur'    => $noRetur,
                'purchase_id' => $purchaseId,
                'branch_id'   => $purchase['branch_id'],
                'user_id'     => $user['id'],
                'tanggal'     => date('Y-m-d H:i:s'),
                'total_retur' => $totalRetur,
                'alasan'      => $alasan,
            ], true);

            foreach ($validItems as $v) {
                $this->purchaseReturnItemModel->insert([
                    'purchase_return_id' => $returId,
                    'purchase_item_id'   => $v['purchase_item']['id'],
                    'product_id'         => $v['purchase_item']['product_id'],
                    'qty'                => $v['qty'],
                    'subtotal'           => $v['subtotal'],
                ]);

                $this->purchaseItemModel->update($v['purchase_item']['id'], [
                    'qty_retur' => (float) $v['purchase_item']['qty_retur'] + $v['qty'],
                ]);

                // Barang dikembalikan ke supplier -> stok cabang berkurang
                $this->stockService->decrease(
                    (int) $v['purchase_item']['product_id'], (int) $purchase['branch_id'], $v['qty'],
                    'retur_pembelian', 'purchase_returns', $returId, "Retur {$noRetur}", $user['id']
                );
            }

            $payable = $this->payableModel->where('purchase_id', $purchaseId)->first();
            if ($payable) {
                $sisaBaru = max(0, (float) $payable['sisa_hutang'] - $totalRetur);
                $this->payableModel->update($payable['id'], [
                    'sisa_hutang' => $sisaBaru,
                    'status'      => $sisaBaru <= 0 ? 'lunas' : $payable['status'],
                ]);
            }

            $db->transComplete();
            if ($db->transStatus() === false) {
                throw new \RuntimeException('Gagal menyimpan retur.');
            }

            return redirect()->to('retur-pembelian')->with('success', "Retur {$noRetur} berhasil disimpan.");
        } catch (\Throwable $e) {
            $db->transRollback();
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}
