<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class BranchSeeder extends Seeder
{
    public function run()
    {
        $this->db->table('branches')->insert([
            'kode_cabang' => 'PST',
            'nama_cabang' => 'Cabang Pusat',
            'alamat'      => 'Alamat cabang pusat',
            'is_pusat'    => 1,
            'status'      => 1,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
    }
}
