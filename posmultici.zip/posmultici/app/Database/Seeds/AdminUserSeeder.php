<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

/**
 * Membuat akun Super Admin awal.
 * Jalankan setelah RoleSeeder & BranchSeeder:
 *   php spark db:seed RoleSeeder
 *   php spark db:seed BranchSeeder
 *   php spark db:seed AdminUserSeeder
 *
 * Login default -> username: superadmin | password: Admin#12345
 * WAJIB langsung ganti password setelah login pertama kali.
 */
class AdminUserSeeder extends Seeder
{
    public function run()
    {
        $role = $this->db->table('roles')->where('kode_role', 'super_admin')->get()->getRow();

        if (! $role) {
            echo "Jalankan RoleSeeder terlebih dahulu.\n";
            return;
        }

        $this->db->table('users')->insert([
            'branch_id'  => null, // Super Admin akses semua cabang
            'role_id'    => $role->id,
            'nama'       => 'Super Administrator',
            'username'   => 'superadmin',
            'email'      => 'superadmin@example.com',
            'password'   => password_hash('Admin#12345', PASSWORD_DEFAULT),
            'is_active'  => 1,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        echo "Super Admin dibuat. username: superadmin | password: Admin#12345\n";
    }
}
