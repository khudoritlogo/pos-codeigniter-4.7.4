<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class RoleSeeder extends Seeder
{
    public function run()
    {
        $roles = [
            ['kode_role' => 'super_admin', 'nama_role' => 'Super Admin', 'created_at' => date('Y-m-d H:i:s')],
            ['kode_role' => 'admin',       'nama_role' => 'Admin',       'created_at' => date('Y-m-d H:i:s')],
            ['kode_role' => 'kasir',       'nama_role' => 'Kasir',       'created_at' => date('Y-m-d H:i:s')],
            ['kode_role' => 'kurir',       'nama_role' => 'Kurir',       'created_at' => date('Y-m-d H:i:s')],
        ];
        $this->db->table('roles')->insertBatch($roles);
    }
}
