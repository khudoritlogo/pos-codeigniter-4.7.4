<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateStockTransferItems extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'                => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'stock_transfer_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'product_id'        => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'qty'               => ['type' => 'DECIMAL', 'constraint' => '18,2'],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('stock_transfer_id', 'stock_transfers', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('stock_transfer_items');
    }
    public function down() { $this->forge->dropTable('stock_transfer_items'); }
}
