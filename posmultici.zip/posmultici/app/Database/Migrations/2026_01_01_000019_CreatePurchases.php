<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePurchases extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'no_pembelian'=> ['type' => 'VARCHAR', 'constraint' => 50, 'unique' => true],
            'branch_id'   => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'supplier_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'user_id'     => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'tanggal'     => ['type' => 'DATETIME'],
            'subtotal'    => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'diskon'      => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'grand_total' => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'bayar'       => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'metode_bayar'=> ['type' => 'ENUM("cash","transfer","hutang")', 'default' => 'cash'],
            'status_bayar'=> ['type' => 'ENUM("lunas","belum_lunas","cicilan")', 'default' => 'lunas'],
            'catatan'     => ['type' => 'TEXT', 'null' => true],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
            'updated_at'  => ['type' => 'DATETIME', 'null' => true],
            'deleted_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('branch_id', 'branches', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->addForeignKey('supplier_id', 'suppliers', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->createTable('purchases');
    }
    public function down() { $this->forge->dropTable('purchases'); }
}
