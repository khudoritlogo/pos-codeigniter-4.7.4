<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateStockTransfers extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'              => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'no_transfer'     => ['type' => 'VARCHAR', 'constraint' => 50, 'unique' => true],
            'branch_from_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'branch_to_id'    => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'user_id'         => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'tanggal'         => ['type' => 'DATETIME'],
            'status'          => ['type' => 'ENUM("diajukan","dikirim","diterima","batal")', 'default' => 'diajukan'],
            'catatan'         => ['type' => 'TEXT', 'null' => true],
            'created_at'      => ['type' => 'DATETIME', 'null' => true],
            'updated_at'      => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('branch_from_id', 'branches', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->addForeignKey('branch_to_id', 'branches', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->createTable('stock_transfers');
    }
    public function down() { $this->forge->dropTable('stock_transfers'); }
}
