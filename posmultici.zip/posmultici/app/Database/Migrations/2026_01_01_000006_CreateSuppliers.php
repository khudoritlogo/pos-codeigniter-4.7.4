<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateSuppliers extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'             => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'kode_supplier'  => ['type' => 'VARCHAR', 'constraint' => 30, 'unique' => true],
            'nama_supplier'  => ['type' => 'VARCHAR', 'constraint' => 150],
            'penanggung_jawab'=> ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'telepon'        => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => true],
            'email'          => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'alamat'         => ['type' => 'TEXT', 'null' => true],
            'created_at'     => ['type' => 'DATETIME', 'null' => true],
            'updated_at'     => ['type' => 'DATETIME', 'null' => true],
            'deleted_at'     => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('suppliers');
    }
    public function down() { $this->forge->dropTable('suppliers'); }
}
