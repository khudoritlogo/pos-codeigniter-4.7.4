<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Log/histori setiap perubahan stok (kartu stok) - untuk audit trail
class CreateStockMutations extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'product_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'branch_id'   => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'tipe'        => ['type' => 'ENUM("pembelian","retur_pembelian","penjualan","retur_penjualan","transfer_masuk","transfer_keluar","opname","penyesuaian")'],
            'ref_table'   => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'ref_id'      => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'qty_sebelum' => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'qty_mutasi'  => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0], // + masuk, - keluar
            'qty_sesudah' => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'keterangan'  => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'user_id'     => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey(['product_id', 'branch_id']);
        $this->forge->addForeignKey('product_id', 'products', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('branch_id', 'branches', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('stock_mutations');
    }
    public function down() { $this->forge->dropTable('stock_mutations'); }
}
