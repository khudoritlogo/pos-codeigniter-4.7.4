<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Fitur #1 & #2: tambah relasi level member + saldo poin loyalty berjalan ke tabel customers
class AlterCustomersAddLevelAndPoin extends Migration
{
    public function up()
    {
        $this->forge->addColumn('customers', [
            'customer_level_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true, 'after' => 'tipe_customer'],
            'poin'               => ['type' => 'INT', 'constraint' => 11, 'default' => 0, 'after' => 'limit_piutang'],
        ]);
        $this->forge->addForeignKey('customer_level_id', 'customer_levels', 'id', 'SET NULL', 'CASCADE', 'customers');
    }

    public function down()
    {
        $this->forge->dropForeignKey('customers', 'customers_customer_level_id_foreign');
        $this->forge->dropColumn('customers', ['customer_level_id', 'poin']);
    }
}
