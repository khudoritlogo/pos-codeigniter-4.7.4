<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePayablePayments extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'payable_id'    => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'user_id'       => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'tanggal_bayar' => ['type' => 'DATETIME'],
            'jumlah_bayar'  => ['type' => 'DECIMAL', 'constraint' => '18,2'],
            'metode_bayar'  => ['type' => 'ENUM("cash","transfer")', 'default' => 'cash'],
            'catatan'       => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('payable_id', 'payables', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('payable_payments');
    }
    public function down() { $this->forge->dropTable('payable_payments'); }
}
