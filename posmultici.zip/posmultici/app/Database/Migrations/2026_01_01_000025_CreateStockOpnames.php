<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateStockOpnames extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'         => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'no_opname'  => ['type' => 'VARCHAR', 'constraint' => 50, 'unique' => true],
            'branch_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'user_id'    => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'tanggal'    => ['type' => 'DATETIME'],
            'status'     => ['type' => 'ENUM("draft","selesai")', 'default' => 'draft'],
            'catatan'    => ['type' => 'TEXT', 'null' => true],
            'created_at' => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('branch_id', 'branches', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->createTable('stock_opnames');
    }
    public function down() { $this->forge->dropTable('stock_opnames'); }
}
