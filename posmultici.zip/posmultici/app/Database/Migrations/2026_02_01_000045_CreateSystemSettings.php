<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Fitur #5 & #9: pengaturan sistem generik key-value (QRIS statis toko, konfigurasi WA Bot, dll)
// supaya tidak perlu tabel terpisah untuk tiap setting kecil
class CreateSystemSettings extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'branch_id'   => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'setting_key' => ['type' => 'VARCHAR', 'constraint' => 100],
            'setting_value' => ['type' => 'TEXT', 'null' => true],
            'updated_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey(['branch_id', 'setting_key']);
        $this->forge->createTable('system_settings');
    }

    public function down()
    {
        $this->forge->dropTable('system_settings');
    }
}
