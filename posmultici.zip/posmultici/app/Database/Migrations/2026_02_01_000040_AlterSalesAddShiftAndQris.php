<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Fitur #3: kaitkan transaksi penjualan ke shift kasir yang sedang berjalan (untuk hitung omzet per shift)
// Fitur #5: tambah opsi metode bayar QRIS
class AlterSalesAddShiftAndQris extends Migration
{
    public function up()
    {
        $this->forge->addColumn('sales', [
            'shift_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true, 'after' => 'branch_id'],
        ]);
        $this->forge->addForeignKey('shift_id', 'cashier_shifts', 'id', 'SET NULL', 'CASCADE', 'sales');

        // Tambah 'qris' ke enum metode_bayar (MODIFY COLUMN karena ENUM tidak bisa di-addColumn ulang)
        $this->db->query("ALTER TABLE sales MODIFY metode_bayar ENUM('cash','transfer','piutang','qris') DEFAULT 'cash'");
    }

    public function down()
    {
        $this->forge->dropForeignKey('sales', 'sales_shift_id_foreign');
        $this->forge->dropColumn('sales', 'shift_id');
        $this->db->query("ALTER TABLE sales MODIFY metode_bayar ENUM('cash','transfer','piutang') DEFAULT 'cash'");
    }
}
