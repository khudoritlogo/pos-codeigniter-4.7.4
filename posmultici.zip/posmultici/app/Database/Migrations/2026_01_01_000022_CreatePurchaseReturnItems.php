<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePurchaseReturnItems extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'purchase_return_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'purchase_item_id'   => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'product_id'         => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'qty'                => ['type' => 'DECIMAL', 'constraint' => '18,2'],
            'subtotal'           => ['type' => 'DECIMAL', 'constraint' => '18,2'],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('purchase_return_id', 'purchase_returns', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('purchase_return_items');
    }
    public function down() { $this->forge->dropTable('purchase_return_items'); }
}
