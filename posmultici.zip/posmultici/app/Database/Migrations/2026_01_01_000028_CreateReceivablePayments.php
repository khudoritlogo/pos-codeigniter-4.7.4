<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Cicilan pembayaran piutang
class CreateReceivablePayments extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'             => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'receivable_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'user_id'        => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'tanggal_bayar'  => ['type' => 'DATETIME'],
            'jumlah_bayar'   => ['type' => 'DECIMAL', 'constraint' => '18,2'],
            'metode_bayar'   => ['type' => 'ENUM("cash","transfer")', 'default' => 'cash'],
            'catatan'        => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'created_at'     => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('receivable_id', 'receivables', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('receivable_payments');
    }
    public function down() { $this->forge->dropTable('receivable_payments'); }
}
