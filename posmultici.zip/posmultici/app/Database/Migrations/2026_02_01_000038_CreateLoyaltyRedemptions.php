<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Fitur #2: histori penukaran poin dengan hadiah barang
class CreateLoyaltyRedemptions extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'no_penukaran'=> ['type' => 'VARCHAR', 'constraint' => 50, 'unique' => true],
            'customer_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'reward_id'   => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'branch_id'   => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'user_id'     => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true], // kasir/admin yang memproses
            'poin_dipakai'=> ['type' => 'INT', 'constraint' => 11],
            'tanggal'     => ['type' => 'DATETIME'],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('customer_id', 'customers', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->addForeignKey('reward_id', 'loyalty_rewards', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->createTable('loyalty_redemptions');
    }

    public function down()
    {
        $this->forge->dropTable('loyalty_redemptions');
    }
}
