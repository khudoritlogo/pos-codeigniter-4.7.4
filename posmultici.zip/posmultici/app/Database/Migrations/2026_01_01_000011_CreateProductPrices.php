<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Harga bertingkat/dinamis: berdasarkan jumlah pembelian atau tipe customer
class CreateProductPrices extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'           => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'product_id'   => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'unit_id'      => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'min_qty'      => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 1],
            'harga'        => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'tipe_customer'=> ['type' => 'ENUM("semua","retail","grosir")', 'default' => 'semua'],
            'created_at'   => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('product_id', 'products', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('unit_id', 'units', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->createTable('product_prices');
    }
    public function down() { $this->forge->dropTable('product_prices'); }
}
