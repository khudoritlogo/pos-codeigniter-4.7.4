<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Informasi toko (bisa per cabang, atau global jika branch_id null)
class CreateStoreSettings extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'branch_id'     => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'nama_toko'     => ['type' => 'VARCHAR', 'constraint' => 150],
            'alamat'        => ['type' => 'TEXT', 'null' => true],
            'telepon'       => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => true],
            'email'         => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'logo'          => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'npwp'          => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'footer_struk'  => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('store_settings');
    }
    public function down() { $this->forge->dropTable('store_settings'); }
}
