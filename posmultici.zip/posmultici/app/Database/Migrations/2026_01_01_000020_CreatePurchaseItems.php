<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePurchaseItems extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'purchase_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'product_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'unit_id'     => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'qty'         => ['type' => 'DECIMAL', 'constraint' => '18,2'],
            'harga'       => ['type' => 'DECIMAL', 'constraint' => '18,2'],
            'subtotal'    => ['type' => 'DECIMAL', 'constraint' => '18,2'],
            'qty_retur'   => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('purchase_id', 'purchases', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('product_id', 'products', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->createTable('purchase_items');
    }
    public function down() { $this->forge->dropTable('purchase_items'); }
}
