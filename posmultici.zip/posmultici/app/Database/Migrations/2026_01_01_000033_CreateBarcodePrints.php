<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Histori/antrian cetak label barcode custom
class CreateBarcodePrints extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'product_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'user_id'     => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'jumlah_label'=> ['type' => 'INT', 'constraint' => 11, 'default' => 1],
            'ukuran_label'=> ['type' => 'VARCHAR', 'constraint' => 30, 'null' => true], // mis. 40x25mm
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('product_id', 'products', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('barcode_prints');
    }
    public function down() { $this->forge->dropTable('barcode_prints'); }
}
