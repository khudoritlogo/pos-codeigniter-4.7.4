<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateStockOpnameItems extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'               => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'stock_opname_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'product_id'       => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'qty_sistem'       => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'qty_fisik'        => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'selisih'          => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('stock_opname_id', 'stock_opnames', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('stock_opname_items');
    }
    public function down() { $this->forge->dropTable('stock_opname_items'); }
}
