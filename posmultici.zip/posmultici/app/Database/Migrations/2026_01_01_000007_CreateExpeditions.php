<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateExpeditions extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'nama_ekspedisi'=> ['type' => 'VARCHAR', 'constraint' => 150],
            'telepon'       => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => true],
            'keterangan'    => ['type' => 'TEXT', 'null' => true],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
            'deleted_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('expeditions');
    }
    public function down() { $this->forge->dropTable('expeditions'); }
}
