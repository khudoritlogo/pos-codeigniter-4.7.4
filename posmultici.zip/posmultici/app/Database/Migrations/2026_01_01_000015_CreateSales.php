<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateSales extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'              => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'no_invoice'      => ['type' => 'VARCHAR', 'constraint' => 50, 'unique' => true],
            'branch_id'       => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'customer_id'     => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'kasir_id'        => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'kurir_id'        => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'expedition_id'   => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'tipe_transaksi'  => ['type' => 'ENUM("retail","grosir")', 'default' => 'retail'],
            'tanggal'         => ['type' => 'DATETIME'],
            'subtotal'        => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'diskon'          => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'diskon_persen'   => ['type' => 'DECIMAL', 'constraint' => '5,2', 'default' => 0],
            'pajak'           => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'grand_total'     => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'bayar'           => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'kembalian'       => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'metode_bayar'    => ['type' => 'ENUM("cash","transfer","piutang")', 'default' => 'cash'],
            'status_bayar'    => ['type' => 'ENUM("lunas","belum_lunas","cicilan")', 'default' => 'lunas'],
            'status_transaksi'=> ['type' => 'ENUM("pending","selesai","batal")', 'default' => 'selesai'],
            'status_kirim'    => ['type' => 'ENUM("-","menunggu","diproses","dikirim","selesai")', 'default' => '-'],
            'catatan'         => ['type' => 'TEXT', 'null' => true],
            'created_at'      => ['type' => 'DATETIME', 'null' => true],
            'updated_at'      => ['type' => 'DATETIME', 'null' => true],
            'deleted_at'      => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('branch_id', 'branches', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->addForeignKey('customer_id', 'customers', 'id', 'SET NULL', 'CASCADE');
        $this->forge->addForeignKey('kasir_id', 'users', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->createTable('sales');
    }
    public function down() { $this->forge->dropTable('sales'); }
}
