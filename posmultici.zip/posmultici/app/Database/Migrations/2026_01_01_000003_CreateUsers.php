<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateUsers extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'           => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'branch_id'    => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'role_id'      => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'nama'         => ['type' => 'VARCHAR', 'constraint' => 150],
            'username'     => ['type' => 'VARCHAR', 'constraint' => 100, 'unique' => true],
            'email'        => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'no_hp'        => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => true],
            'password'     => ['type' => 'VARCHAR', 'constraint' => 255],
            'foto'         => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'status_kurir' => ['type' => 'ENUM("free","sibuk","off")', 'null' => true, 'default' => 'off'],
            'is_active'    => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'last_login'   => ['type' => 'DATETIME', 'null' => true],
            'created_at'   => ['type' => 'DATETIME', 'null' => true],
            'updated_at'   => ['type' => 'DATETIME', 'null' => true],
            'deleted_at'   => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('branch_id', 'branches', 'id', 'SET NULL', 'CASCADE');
        $this->forge->addForeignKey('role_id', 'roles', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->createTable('users');
    }

    public function down()
    {
        $this->forge->dropTable('users');
    }
}
