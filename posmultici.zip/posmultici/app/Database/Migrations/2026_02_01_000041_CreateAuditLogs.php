<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Fitur #4: Audit Log & Otorisasi Void -- memantau penghapusan item keranjang sebelum struk
// dicetak, dan pembatalan (void) transaksi yang sudah selesai
class CreateAuditLogs extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'branch_id'   => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'user_id'     => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'aksi'        => ['type' => 'ENUM("hapus_item_kasir","void_transaksi","void_ditolak")'],
            'ref_table'   => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'ref_id'      => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'detail'      => ['type' => 'TEXT', 'null' => true], // JSON: nama barang, qty, harga, alasan, otorisator, dll
            'otorisator_id'=> ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true], // supervisor yang menyetujui void
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey(['branch_id', 'created_at']);
        $this->forge->createTable('audit_logs');
    }

    public function down()
    {
        $this->forge->dropTable('audit_logs');
    }
}
