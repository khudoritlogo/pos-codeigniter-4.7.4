<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Multi satuan per barang, misal: 1 Box = 12 Pcs, 1 Karton = 24 Box
class CreateProductUnits extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'product_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'unit_id'     => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'konversi'    => ['type' => 'DECIMAL', 'constraint' => '18,4', 'default' => 1], // nilai konversi ke satuan dasar
            'harga_jual'  => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'harga_grosir'=> ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'is_default'  => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('product_id', 'products', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('unit_id', 'units', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->createTable('product_units');
    }
    public function down() { $this->forge->dropTable('product_units'); }
}
