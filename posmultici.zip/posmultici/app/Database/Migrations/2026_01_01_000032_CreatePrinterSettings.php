<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Pengaturan ukuran kertas printer thermal per cabang (58mm/80mm, custom)
class CreatePrinterSettings extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'           => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'branch_id'    => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'ukuran_kertas'=> ['type' => 'ENUM("58mm","80mm","custom")', 'default' => '58mm'],
            'lebar_custom_mm' => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'font_size'    => ['type' => 'INT', 'constraint' => 3, 'default' => 12],
            'tampilkan_logo'=> ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'jumlah_copy'  => ['type' => 'INT', 'constraint' => 2, 'default' => 1],
            'updated_at'   => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('printer_settings');
    }
    public function down() { $this->forge->dropTable('printer_settings'); }
}
