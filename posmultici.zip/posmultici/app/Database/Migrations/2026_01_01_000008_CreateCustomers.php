<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateCustomers extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'             => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'kode_customer'  => ['type' => 'VARCHAR', 'constraint' => 30, 'unique' => true],
            'nama_customer'  => ['type' => 'VARCHAR', 'constraint' => 150],
            'tipe_customer'  => ['type' => 'ENUM("retail","grosir")', 'default' => 'retail'],
            'telepon'        => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => true],
            'email'          => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'alamat'         => ['type' => 'TEXT', 'null' => true],
            'limit_piutang'  => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'created_at'     => ['type' => 'DATETIME', 'null' => true],
            'updated_at'     => ['type' => 'DATETIME', 'null' => true],
            'deleted_at'     => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('customers');
    }
    public function down() { $this->forge->dropTable('customers'); }
}
