<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Fitur #8: nomor batch + tanggal kedaluwarsa per cabang, dasar untuk peringatan dini & prinsip
// FEFO (First-Expired-First-Out) -- batch dengan expired paling dekat diprioritaskan keluar duluan
class CreateProductBatches extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'product_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'branch_id'   => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'no_batch'    => ['type' => 'VARCHAR', 'constraint' => 50],
            'tanggal_masuk'      => ['type' => 'DATE'],
            'tanggal_kedaluwarsa'=> ['type' => 'DATE'],
            'qty_masuk'   => ['type' => 'DECIMAL', 'constraint' => '18,2'],
            'qty_sisa'    => ['type' => 'DECIMAL', 'constraint' => '18,2'], // berkurang tiap kali batch ini dipakai jual (logika FEFO)
            'purchase_item_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey(['product_id', 'branch_id', 'tanggal_kedaluwarsa']);
        $this->forge->addForeignKey('product_id', 'products', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('branch_id', 'branches', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('product_batches');
    }

    public function down()
    {
        $this->forge->dropTable('product_batches');
    }
}
