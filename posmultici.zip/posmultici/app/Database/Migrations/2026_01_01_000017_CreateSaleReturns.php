<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateSaleReturns extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'no_retur'    => ['type' => 'VARCHAR', 'constraint' => 50, 'unique' => true],
            'sale_id'     => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'branch_id'   => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'user_id'     => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'tanggal'     => ['type' => 'DATETIME'],
            'total_retur' => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'alasan'      => ['type' => 'TEXT', 'null' => true],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('sale_id', 'sales', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->createTable('sale_returns');
    }
    public function down() { $this->forge->dropTable('sale_returns'); }
}
