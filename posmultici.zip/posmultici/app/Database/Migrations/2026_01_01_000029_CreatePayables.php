<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Hutang ke supplier (dari transaksi pembelian dengan metode bayar hutang/cicilan)
class CreatePayables extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'           => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'purchase_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'supplier_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'branch_id'    => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'total_hutang' => ['type' => 'DECIMAL', 'constraint' => '18,2'],
            'total_dibayar'=> ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'sisa_hutang'  => ['type' => 'DECIMAL', 'constraint' => '18,2'],
            'jatuh_tempo'  => ['type' => 'DATE', 'null' => true],
            'status'       => ['type' => 'ENUM("belum_lunas","cicilan","lunas","menunggak")', 'default' => 'belum_lunas'],
            'created_at'   => ['type' => 'DATETIME', 'null' => true],
            'updated_at'   => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('purchase_id', 'purchases', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('supplier_id', 'suppliers', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->createTable('payables');
    }
    public function down() { $this->forge->dropTable('payables'); }
}
