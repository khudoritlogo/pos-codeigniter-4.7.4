<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Fitur #7: lama garansi (bulan) khusus barang jenis SN
// Fitur #8: tandai barang yang punya tanggal kedaluwarsa (untuk FEFO / peringatan expired)
class AlterProductsAddGaransiExpiry extends Migration
{
    public function up()
    {
        $this->forge->addColumn('products', [
            'garansi_bulan' => ['type' => 'INT', 'constraint' => 5, 'null' => true, 'after' => 'jenis_produk'],
            'has_expiry'    => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0, 'after' => 'garansi_bulan'],
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn('products', ['garansi_bulan', 'has_expiry']);
    }
}
