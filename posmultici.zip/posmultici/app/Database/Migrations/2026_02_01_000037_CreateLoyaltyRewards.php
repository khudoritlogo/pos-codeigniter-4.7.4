<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Fitur #2: katalog hadiah barang yang bisa ditukar dengan poin (bisa link ke barang di master, atau hadiah bebas)
class CreateLoyaltyRewards extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'product_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true], // null = hadiah bebas non-barang master
            'nama_hadiah' => ['type' => 'VARCHAR', 'constraint' => 150],
            'poin_dibutuhkan' => ['type' => 'INT', 'constraint' => 11],
            'stok_hadiah' => ['type' => 'INT', 'constraint' => 11, 'default' => 0],
            'status'      => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
            'updated_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('product_id', 'products', 'id', 'SET NULL', 'CASCADE');
        $this->forge->createTable('loyalty_rewards');
    }

    public function down()
    {
        $this->forge->dropTable('loyalty_rewards');
    }
}
