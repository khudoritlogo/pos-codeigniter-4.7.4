<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Fitur #2: kartu poin (ledger) -- setiap transaksi yang menambah/mengurangi poin tercatat di sini
class CreateLoyaltyPointMutations extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'customer_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'tipe'        => ['type' => 'ENUM("belanja","tukar_poin","penyesuaian")'],
            'ref_table'   => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true], // 'sales' atau 'loyalty_redemptions'
            'ref_id'      => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'poin_sebelum'=> ['type' => 'INT', 'constraint' => 11, 'default' => 0],
            'poin_mutasi' => ['type' => 'INT', 'constraint' => 11, 'default' => 0], // + didapat, - ditukar
            'poin_sesudah'=> ['type' => 'INT', 'constraint' => 11, 'default' => 0],
            'keterangan'  => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('customer_id');
        $this->forge->addForeignKey('customer_id', 'customers', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('loyalty_point_mutations');
    }

    public function down()
    {
        $this->forge->dropTable('loyalty_point_mutations');
    }
}
