<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Fitur #3: Manajemen Shift Kasir -- modal awal, hitung selisih uang fisik saat tutup shift
class CreateCashierShifts extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'                 => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'no_shift'           => ['type' => 'VARCHAR', 'constraint' => 50, 'unique' => true],
            'branch_id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'user_id'            => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'modal_awal'         => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'waktu_buka'         => ['type' => 'DATETIME'],
            'waktu_tutup'        => ['type' => 'DATETIME', 'null' => true],
            'total_penjualan_cash'     => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0], // dihitung otomatis saat tutup shift
            'total_penjualan_non_cash' => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'uang_seharusnya'    => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0], // modal_awal + total_penjualan_cash
            'uang_fisik_aktual'  => ['type' => 'DECIMAL', 'constraint' => '18,2', 'null' => true], // dihitung manual oleh kasir saat tutup
            'selisih'            => ['type' => 'DECIMAL', 'constraint' => '18,2', 'null' => true], // uang_fisik_aktual - uang_seharusnya
            'catatan_penutupan'  => ['type' => 'TEXT', 'null' => true],
            'status'             => ['type' => 'ENUM("buka","tutup")', 'default' => 'buka'],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('branch_id', 'branches', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->addForeignKey('user_id', 'users', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->createTable('cashier_shifts');
    }

    public function down()
    {
        $this->forge->dropTable('cashier_shifts');
    }
}
