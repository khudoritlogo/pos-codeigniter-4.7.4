<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Fitur #1: Member/Customer Level (Regular, Silver, Gold) -- untuk hak istimewa harga per level
class CreateCustomerLevels extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'kode_level'    => ['type' => 'VARCHAR', 'constraint' => 30, 'unique' => true],
            'nama_level'    => ['type' => 'VARCHAR', 'constraint' => 100], // Regular, Silver, Gold, dst (bebas ditambah)
            'diskon_persen' => ['type' => 'DECIMAL', 'constraint' => '5,2', 'default' => 0], // diskon otomatis untuk level ini
            'min_poin_naik' => ['type' => 'INT', 'constraint' => 11, 'default' => 0], // poin minimal supaya otomatis naik ke level ini
            'urutan'        => ['type' => 'INT', 'constraint' => 5, 'default' => 0], // urutan tingkatan (Regular < Silver < Gold)
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('customer_levels');

        // Seed 3 level default supaya langsung bisa dipakai
        $this->db->table('customer_levels')->insertBatch([
            ['kode_level' => 'regular', 'nama_level' => 'Regular', 'diskon_persen' => 0, 'min_poin_naik' => 0, 'urutan' => 1, 'created_at' => date('Y-m-d H:i:s')],
            ['kode_level' => 'silver', 'nama_level' => 'Silver', 'diskon_persen' => 3, 'min_poin_naik' => 500, 'urutan' => 2, 'created_at' => date('Y-m-d H:i:s')],
            ['kode_level' => 'gold', 'nama_level' => 'Gold', 'diskon_persen' => 5, 'min_poin_naik' => 2000, 'urutan' => 3, 'created_at' => date('Y-m-d H:i:s')],
        ]);
    }

    public function down()
    {
        $this->forge->dropTable('customer_levels');
    }
}
