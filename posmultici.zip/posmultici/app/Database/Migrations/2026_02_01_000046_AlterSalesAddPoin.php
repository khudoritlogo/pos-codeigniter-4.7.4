<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Fitur #2: catat berapa poin didapat (dari belanja) dan dipakai (redeem saat transaksi yang sama)
// langsung di baris transaksi supaya gampang ditelusuri dari riwayat penjualan
class AlterSalesAddPoin extends Migration
{
    public function up()
    {
        $this->forge->addColumn('sales', [
            'poin_didapat' => ['type' => 'INT', 'constraint' => 11, 'default' => 0, 'after' => 'status_kirim'],
            'poin_dipakai' => ['type' => 'INT', 'constraint' => 11, 'default' => 0, 'after' => 'poin_didapat'],
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn('sales', ['poin_didapat', 'poin_dipakai']);
    }
}
