<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateSaleReturnItems extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'             => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'sale_return_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'sale_item_id'   => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'product_id'     => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'qty'            => ['type' => 'DECIMAL', 'constraint' => '18,2'],
            'subtotal'       => ['type' => 'DECIMAL', 'constraint' => '18,2'],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('sale_return_id', 'sale_returns', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('sale_return_items');
    }
    public function down() { $this->forge->dropTable('sale_return_items'); }
}
