<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Serial number per unit barang (untuk produk jenis SN), per cabang
class CreateProductSerials extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'         => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'product_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'branch_id'  => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'serial_number' => ['type' => 'VARCHAR', 'constraint' => 100],
            'status'     => ['type' => 'ENUM("tersedia","terjual","retur","transfer")', 'default' => 'tersedia'],
            'purchase_item_id' => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'sale_item_id'      => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'created_at' => ['type' => 'DATETIME', 'null' => true],
            'updated_at' => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey(['product_id', 'serial_number']);
        $this->forge->addForeignKey('product_id', 'products', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('branch_id', 'branches', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('product_serials');
    }
    public function down() { $this->forge->dropTable('product_serials'); }
}
