<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Fitur #7: tanggal mulai/berakhir garansi per unit fisik (serial number), diisi otomatis saat terjual
class AlterProductSerialsAddGaransi extends Migration
{
    public function up()
    {
        $this->forge->addColumn('product_serials', [
            'tanggal_mulai_garansi'  => ['type' => 'DATE', 'null' => true, 'after' => 'sale_item_id'],
            'tanggal_akhir_garansi'  => ['type' => 'DATE', 'null' => true, 'after' => 'tanggal_mulai_garansi'],
        ]);
    }

    public function down()
    {
        $this->forge->dropColumn('product_serials', ['tanggal_mulai_garansi', 'tanggal_akhir_garansi']);
    }
}
