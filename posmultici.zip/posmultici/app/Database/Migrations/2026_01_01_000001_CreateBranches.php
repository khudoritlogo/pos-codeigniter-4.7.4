<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateBranches extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'kode_cabang' => ['type' => 'VARCHAR', 'constraint' => 20, 'unique' => true],
            'nama_cabang' => ['type' => 'VARCHAR', 'constraint' => 150],
            'alamat'      => ['type' => 'TEXT', 'null' => true],
            'telepon'     => ['type' => 'VARCHAR', 'constraint' => 30, 'null' => true],
            'email'       => ['type' => 'VARCHAR', 'constraint' => 150, 'null' => true],
            'logo'        => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'is_pusat'    => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 0],
            'status'      => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
            'updated_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('branches');
    }

    public function down()
    {
        $this->forge->dropTable('branches');
    }
}
