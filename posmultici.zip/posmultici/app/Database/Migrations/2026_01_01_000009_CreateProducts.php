<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateProducts extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'             => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'kode_barang'    => ['type' => 'VARCHAR', 'constraint' => 50, 'unique' => true],
            'barcode'        => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'nama_barang'    => ['type' => 'VARCHAR', 'constraint' => 200],
            'category_id'    => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'unit_id'        => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true], // satuan dasar
            'supplier_id'    => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'null' => true],
            'jenis_produk'   => ['type' => 'ENUM("non_sn","sn")', 'default' => 'non_sn'], // support produk SN
            'harga_beli'     => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'harga_jual'     => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0], // harga retail default
            'harga_grosir'   => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'stok_minimal'   => ['type' => 'INT', 'constraint' => 11, 'default' => 0],
            'foto'           => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'status'         => ['type' => 'TINYINT', 'constraint' => 1, 'default' => 1],
            'created_at'     => ['type' => 'DATETIME', 'null' => true],
            'updated_at'     => ['type' => 'DATETIME', 'null' => true],
            'deleted_at'     => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('barcode');
        $this->forge->addForeignKey('category_id', 'categories', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->addForeignKey('unit_id', 'units', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->addForeignKey('supplier_id', 'suppliers', 'id', 'SET NULL', 'CASCADE');
        $this->forge->createTable('products');
    }
    public function down() { $this->forge->dropTable('products'); }
}
