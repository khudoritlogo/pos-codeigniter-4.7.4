<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

// Piutang (dari transaksi penjualan dengan metode bayar piutang/cicilan)
class CreateReceivables extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'            => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'sale_id'       => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'customer_id'   => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'branch_id'     => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'total_piutang' => ['type' => 'DECIMAL', 'constraint' => '18,2'],
            'total_dibayar' => ['type' => 'DECIMAL', 'constraint' => '18,2', 'default' => 0],
            'sisa_piutang'  => ['type' => 'DECIMAL', 'constraint' => '18,2'],
            'jatuh_tempo'   => ['type' => 'DATE', 'null' => true],
            'status'        => ['type' => 'ENUM("belum_lunas","cicilan","lunas","menunggak")', 'default' => 'belum_lunas'],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('sale_id', 'sales', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('customer_id', 'customers', 'id', 'RESTRICT', 'CASCADE');
        $this->forge->createTable('receivables');
    }
    public function down() { $this->forge->dropTable('receivables'); }
}
