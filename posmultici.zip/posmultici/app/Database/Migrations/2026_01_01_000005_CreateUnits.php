<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateUnits extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id'         => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'nama_satuan'=> ['type' => 'VARCHAR', 'constraint' => 50], // pcs, box, karton, dll
            'created_at' => ['type' => 'DATETIME', 'null' => true],
            'updated_at' => ['type' => 'DATETIME', 'null' => true],
            'deleted_at' => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('units');
    }
    public function down() { $this->forge->dropTable('units'); }
}
