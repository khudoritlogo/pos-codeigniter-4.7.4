<?php

namespace App\Commands;

use App\Libraries\TelegramNotifier;
use App\Libraries\WhatsappNotifier;
use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;

/**
 * Kirim ringkasan omzet harian ke Owner/Super Admin lewat channel manapun yang aktif:
 * WhatsApp Bot (gateway pihak ketiga) dan/atau Telegram Bot (API resmi Telegram, gratis).
 * Dijadwalkan lewat cron server, contoh (jalan tiap jam 21:00):
 *   0 21 * * * cd /path/ke/project && php spark kirim:omzet-harian
 */
class KirimOmzetHarian extends BaseCommand
{
    protected $group       = 'POS';
    protected $name        = 'kirim:omzet-harian';
    protected $description = 'Menghitung omzet hari ini per cabang dan mengirim ringkasannya via WhatsApp Bot dan/atau Telegram Bot ke Owner/Super Admin.';

    public function run(array $params)
    {
        $db = \Config\Database::connect();
        $waNotifier = new WhatsappNotifier();
        $tgNotifier = new TelegramNotifier();

        if (! $waNotifier->isEnabled() && ! $tgNotifier->isEnabled()) {
            CLI::write('WA Bot maupun Telegram Bot belum diaktifkan di Pengaturan. Command dibatalkan.', 'yellow');
            return;
        }

        $tanggal = date('Y-m-d');
        $branches = $db->table('branches')->where('status', 1)->get()->getResultArray();

        $totalSemuaCabang = 0;
        $totalTransaksiSemua = 0;
        $rincianCabang = '';

        foreach ($branches as $branch) {
            $row = $db->table('sales')
                ->selectSum('grand_total', 'omzet')
                ->selectCount('id', 'jumlah')
                ->where('branch_id', $branch['id'])
                ->where('status_transaksi', 'selesai')
                ->where('DATE(tanggal)', $tanggal)
                ->get()->getRow();

            $omzet = (float) ($row->omzet ?? 0);
            $jumlah = (int) ($row->jumlah ?? 0);

            $rincianCabang .= "*{$branch['nama_cabang']}*: Rp " . number_format($omzet, 0, ',', '.') . " ({$jumlah} transaksi)\n";
            $totalSemuaCabang += $omzet;
            $totalTransaksiSemua += $jumlah;
        }

        $footer = "\n*Total Semua Cabang*: Rp " . number_format($totalSemuaCabang, 0, ',', '.') . " ({$totalTransaksiSemua} transaksi)"
            . "\n\n_Pesan otomatis dari sistem POS Multi Cabang_";

        // WhatsApp
        if ($waNotifier->isEnabled()) {
            $waConfig = $waNotifier->getConfig();
            $pesanWa = "*Ringkasan Omzet Harian - Semua Cabang*\nTanggal: " . date('d/m/Y') . "\n\n{$rincianCabang}{$footer}";
            $result = $waNotifier->send($waConfig['nomor_owner'], $pesanWa);
            $result['success']
                ? CLI::write('WhatsApp: berhasil dikirim ke ' . $waConfig['nomor_owner'], 'green')
                : CLI::error('WhatsApp: gagal -- ' . $result['message']);
        }

        // Telegram
        if ($tgNotifier->isEnabled()) {
            $pesanTg = "*📊 Ringkasan Omzet Harian - Semua Cabang*\nTanggal: " . date('d/m/Y') . "\n\n{$rincianCabang}{$footer}";
            $result = $tgNotifier->send($pesanTg);
            $result['success']
                ? CLI::write('Telegram: berhasil dikirim.', 'green')
                : CLI::error('Telegram: gagal -- ' . $result['message']);
        }
    }
}
