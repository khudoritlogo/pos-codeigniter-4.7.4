<?php

namespace App\Libraries;

use App\Models\CustomerLevelModel;
use App\Models\CustomerModel;
use App\Models\LoyaltyPointMutationModel;

/**
 * Fitur #1 & #2: Member Level + Loyalty Points.
 * Aturan poin dasar: setiap kelipatan Rp10.000 belanja (transaksi selesai, non-piutang belum
 * lunas) menghasilkan 1 poin. Level member naik otomatis begitu saldo poin menembus ambang
 * batas level di atasnya (lihat customer_levels.min_poin_naik).
 */
class LoyaltyService
{
    private const RUPIAH_PER_POIN = 10000;

    protected CustomerModel $customerModel;
    protected CustomerLevelModel $levelModel;
    protected LoyaltyPointMutationModel $mutationModel;

    public function __construct()
    {
        $this->customerModel = new CustomerModel();
        $this->levelModel    = new CustomerLevelModel();
        $this->mutationModel = new LoyaltyPointMutationModel();
    }

    public function hitungPoinDariBelanja(float $grandTotal): int
    {
        return (int) floor($grandTotal / self::RUPIAH_PER_POIN);
    }

    /** Tambahkan poin ke customer dari transaksi penjualan yang baru selesai, lalu cek kenaikan level */
    public function tambahPoinBelanja(int $customerId, float $grandTotal, string $refTable, int $refId): int
    {
        $poinDidapat = $this->hitungPoinDariBelanja($grandTotal);
        if ($poinDidapat <= 0) {
            return 0;
        }

        $customer = $this->customerModel->find($customerId);
        if (! $customer) {
            return 0;
        }

        $poinSebelum = (int) $customer['poin'];
        $poinSesudah = $poinSebelum + $poinDidapat;

        $this->mutationModel->insert([
            'customer_id'  => $customerId,
            'tipe'         => 'belanja',
            'ref_table'    => $refTable,
            'ref_id'       => $refId,
            'poin_sebelum' => $poinSebelum,
            'poin_mutasi'  => $poinDidapat,
            'poin_sesudah' => $poinSesudah,
            'keterangan'   => 'Poin otomatis dari transaksi belanja',
        ]);

        $this->customerModel->update($customerId, ['poin' => $poinSesudah]);
        $this->cekKenaikanLevel($customerId, $poinSesudah);

        return $poinDidapat;
    }

    /** Kurangi poin saat ditukar dengan hadiah barang; melempar exception kalau poin tidak cukup */
    public function tukarPoin(int $customerId, int $poinDipakai, string $refTable, int $refId, string $keterangan): void
    {
        $customer = $this->customerModel->find($customerId);
        if (! $customer || (int) $customer['poin'] < $poinDipakai) {
            throw new \RuntimeException('Poin customer tidak mencukupi.');
        }

        $poinSebelum = (int) $customer['poin'];
        $poinSesudah = $poinSebelum - $poinDipakai;

        $this->mutationModel->insert([
            'customer_id'  => $customerId,
            'tipe'         => 'tukar_poin',
            'ref_table'    => $refTable,
            'ref_id'       => $refId,
            'poin_sebelum' => $poinSebelum,
            'poin_mutasi'  => -$poinDipakai,
            'poin_sesudah' => $poinSesudah,
            'keterangan'   => $keterangan,
        ]);

        $this->customerModel->update($customerId, ['poin' => $poinSesudah]);
    }

    /** Naikkan customer_level_id otomatis kalau saldo poin sudah menembus ambang level yang lebih tinggi */
    private function cekKenaikanLevel(int $customerId, int $poinSesudah): void
    {
        $levelBaru = $this->levelModel->levelUntukPoin($poinSesudah);
        if (! $levelBaru) {
            return;
        }
        $customer = $this->customerModel->find($customerId);
        if ((int) $customer['customer_level_id'] !== (int) $levelBaru['id']) {
            $this->customerModel->update($customerId, ['customer_level_id' => $levelBaru['id']]);
        }
    }
}
