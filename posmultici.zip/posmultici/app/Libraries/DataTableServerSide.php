<?php

namespace App\Libraries;

use CodeIgniter\Database\BaseBuilder;

/**
 * Helper generik untuk menjawab request DataTable server-side processing (draw/start/length/
 * search/order dikirim otomatis oleh DataTable saat opsi `serverSide: true` diaktifkan).
 * Dipakai untuk tabel yang datanya berpotensi besar (mis. Laporan Penjualan per Periode),
 * supaya query & paging dilakukan di database, bukan memuat semua baris ke browser sekaligus.
 */
class DataTableServerSide
{
    /**
     * @param BaseBuilder $builder      query dasar (select + join + where filter tetap) yang BELUM di-limit/order
     * @param array<int,string> $searchableColumns  nama kolom (dengan alias tabel) yang boleh dicari teks bebas
     * @param array<int,string> $orderableColumns   nama kolom sesuai urutan index kolom di tabel HTML
     * @param array $requestParams  ambil dari $this->request->getGet() di controller
     */
    public static function process(BaseBuilder $builder, array $searchableColumns, array $orderableColumns, array $requestParams): array
    {
        $draw   = (int) ($requestParams['draw'] ?? 1);
        $start  = (int) ($requestParams['start'] ?? 0);
        $length = (int) ($requestParams['length'] ?? 10);
        $searchValue = $requestParams['search']['value'] ?? '';
        $orderColIdx = $requestParams['order'][0]['column'] ?? null;
        $orderDir    = $requestParams['order'][0]['dir'] ?? 'asc';

        // Hitung total sebelum filter pencarian diterapkan
        $recordsTotal = (clone $builder)->countAllResults(false);

        if ($searchValue !== '' && ! empty($searchableColumns)) {
            $builder->groupStart();
            foreach ($searchableColumns as $i => $col) {
                $i === 0 ? $builder->like($col, $searchValue) : $builder->orLike($col, $searchValue);
            }
            $builder->groupEnd();
        }

        $recordsFiltered = (clone $builder)->countAllResults(false);

        if ($orderColIdx !== null && isset($orderableColumns[$orderColIdx])) {
            $builder->orderBy($orderableColumns[$orderColIdx], $orderDir === 'desc' ? 'DESC' : 'ASC');
        }

        if ($length > 0) {
            $builder->limit($length, $start);
        }

        $data = $builder->get()->getResultArray();

        return [
            'draw'            => $draw,
            'recordsTotal'    => $recordsTotal,
            'recordsFiltered' => $recordsFiltered,
            'data'            => $data,
        ];
    }
}
