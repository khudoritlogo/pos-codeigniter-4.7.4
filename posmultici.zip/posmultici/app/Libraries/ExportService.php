<?php

namespace App\Libraries;

/**
 * Helper export data tabular ke file CSV atau TXT, dipakai oleh semua halaman Laporan.
 * Dipanggil langsung dari controller, mengirim response sebagai file download.
 */
class ExportService
{
    /**
     * @param array<string,string> $headers  ['key' => 'Label Kolom', ...]
     * @param array<int,array<string,mixed>> $rows  baris data, key harus cocok dengan $headers
     */
    public static function toCsv(array $headers, array $rows, string $filename): void
    {
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');

        $out = fopen('php://output', 'w');
        fputcsv($out, array_values($headers));
        foreach ($rows as $row) {
            $line = [];
            foreach (array_keys($headers) as $key) {
                $line[] = $row[$key] ?? '';
            }
            fputcsv($out, $line);
        }
        fclose($out);
        exit;
    }

    /**
     * Format TXT sederhana: kolom rata kiri dipisah spasi tetap (fixed-width), mudah dibaca
     * langsung di editor teks biasa maupun untuk keperluan arsip/print di printer dot-matrix lama.
     */
    public static function toTxt(array $headers, array $rows, string $filename, string $title = ''): void
    {
        header('Content-Type: text/plain; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '.txt"');

        $widths = [];
        foreach ($headers as $key => $label) {
            $maxLen = mb_strlen($label);
            foreach ($rows as $row) {
                $maxLen = max($maxLen, mb_strlen((string) ($row[$key] ?? '')));
            }
            $widths[$key] = min($maxLen + 2, 40);
        }

        $lines = [];
        if ($title !== '') {
            $lines[] = $title;
            $lines[] = str_repeat('=', mb_strlen($title));
            $lines[] = '';
        }

        $headerLine = '';
        foreach ($headers as $key => $label) {
            $headerLine .= str_pad($label, $widths[$key]);
        }
        $lines[] = rtrim($headerLine);
        $lines[] = str_repeat('-', mb_strlen(rtrim($headerLine)));

        foreach ($rows as $row) {
            $line = '';
            foreach (array_keys($headers) as $key) {
                $line .= str_pad((string) ($row[$key] ?? ''), $widths[$key]);
            }
            $lines[] = rtrim($line);
        }

        echo implode("\n", $lines);
        exit;
    }
}
