<?php

namespace App\Libraries;

use App\Models\SystemSettingModel;

/**
 * Fitur tambahan: Notifikasi Telegram Bot Otomatis -- pengirim ringkasan omzet harian (dan
 * notifikasi lain di masa depan) ke Telegram Owner/Super Admin.
 *
 * Beda dengan WhatsappNotifier (yang butuh gateway pihak ketiga berbayar), ini memakai
 * **Telegram Bot API resmi** (https://core.telegram.org/bots/api) yang gratis dan terdokumentasi
 * jelas -- jadi begitu Anda buat bot lewat @BotFather dan isi token + chat_id di halaman
 * pengaturan, fitur ini langsung berfungsi tanpa perlu langganan/API key pihak ketiga lain.
 */
class TelegramNotifier
{
    protected SystemSettingModel $settingModel;

    public function __construct()
    {
        $this->settingModel = new SystemSettingModel();
    }

    public function isEnabled(): bool
    {
        return $this->settingModel->get('telegram_bot_enabled', null, '0') === '1';
    }

    public function getConfig(): array
    {
        return [
            'enabled'  => $this->isEnabled(),
            'bot_token'=> $this->settingModel->get('telegram_bot_token', null, ''),
            'chat_id'  => $this->settingModel->get('telegram_chat_id', null, ''),
        ];
    }

    public function saveConfig(bool $enabled, string $botToken, string $chatId): void
    {
        $this->settingModel->set('telegram_bot_enabled', $enabled ? '1' : '0');
        $this->settingModel->set('telegram_bot_token', $botToken);
        $this->settingModel->set('telegram_chat_id', $chatId);
    }

    /**
     * Kirim pesan lewat Telegram Bot API. Mengembalikan ['success' => bool, 'message' => string]
     * supaya pemanggil (command cron ataupun tombol "Kirim Sekarang" di UI) bisa menampilkan hasil.
     */
    public function send(string $pesan): array
    {
        $config = $this->getConfig();

        if (! $config['enabled']) {
            return ['success' => false, 'message' => 'Telegram Bot belum diaktifkan di Pengaturan.'];
        }
        if (empty($config['bot_token']) || empty($config['chat_id'])) {
            return ['success' => false, 'message' => 'Bot Token / Chat ID Telegram belum diisi di Pengaturan.'];
        }

        try {
            $client = \Config\Services::curlrequest();
            $response = $client->post("https://api.telegram.org/bot{$config['bot_token']}/sendMessage", [
                'form_params' => [
                    'chat_id'    => $config['chat_id'],
                    'text'       => $pesan,
                    'parse_mode' => 'Markdown',
                ],
                'timeout'         => 15,
                'http_errors'     => false,
            ]);

            $body = json_decode($response->getBody(), true);
            if (($body['ok'] ?? false) === true) {
                return ['success' => true, 'message' => 'Pesan berhasil dikirim ke Telegram.'];
            }
            return ['success' => false, 'message' => 'Telegram API menolak: ' . ($body['description'] ?? 'error tidak diketahui')];
        } catch (\Throwable $e) {
            return ['success' => false, 'message' => 'Gagal mengirim: ' . $e->getMessage()];
        }
    }

    /** Susun ringkasan omzet harian dalam format Markdown Telegram siap kirim */
    public function formatRingkasanOmzet(string $namaCabang, string $tanggal, float $omzet, int $jumlahTransaksi): string
    {
        return "*📊 Ringkasan Omzet Harian*\n"
            . "Cabang: {$namaCabang}\n"
            . "Tanggal: {$tanggal}\n"
            . "Jumlah Transaksi: {$jumlahTransaksi}\n"
            . 'Total Omzet: Rp ' . number_format($omzet, 0, ',', '.') . "\n\n"
            . '_Pesan otomatis dari sistem POS Multi Cabang_';
    }
}
