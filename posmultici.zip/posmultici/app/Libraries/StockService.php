<?php

namespace App\Libraries;

use App\Models\ProductSerialModel;
use App\Models\StockModel;
use CodeIgniter\Database\BaseConnection;

/**
 * Pusat semua perubahan stok (barang non-SN) + kartu stok (audit trail).
 * Dipakai oleh: Pembelian, Retur Pembelian, Penjualan, Retur Penjualan,
 * Transfer Stok, dan Stock Opname -- supaya logikanya konsisten di satu tempat.
 *
 * PENTING: Barang jenis SN tidak memakai tabel `stocks`; stoknya dihitung dari jumlah
 * baris `product_serials` berstatus 'tersedia' (lihat ProductSerialModel).
 */
class StockService
{
    protected StockModel $stockModel;
    protected ProductSerialModel $serialModel;
    protected BaseConnection $db;

    public function __construct()
    {
        $this->stockModel  = new StockModel();
        $this->serialModel = new ProductSerialModel();
        $this->db          = \Config\Database::connect();
    }

    /**
     * Tambah stok (mis. dari pembelian, retur penjualan, transfer masuk, penyesuaian opname naik).
     */
    public function increase(int $productId, int $branchId, float $qty, string $tipe, ?string $refTable = null, ?int $refId = null, ?string $keterangan = null, ?int $userId = null): void
    {
        $this->mutate($productId, $branchId, $qty, $tipe, $refTable, $refId, $keterangan, $userId);
    }

    /**
     * Kurangi stok (mis. dari penjualan, retur pembelian, transfer keluar, penyesuaian opname turun).
     * Melempar exception jika stok tidak mencukupi supaya transaksi bisa di-rollback oleh caller.
     */
    public function decrease(int $productId, int $branchId, float $qty, string $tipe, ?string $refTable = null, ?int $refId = null, ?string $keterangan = null, ?int $userId = null): void
    {
        $stokSekarang = $this->stockModel->getQty($productId, $branchId);
        if ($stokSekarang < $qty) {
            throw new \RuntimeException("Stok tidak mencukupi untuk salah satu barang (tersedia: {$stokSekarang}, dibutuhkan: {$qty}).");
        }
        $this->mutate($productId, $branchId, -$qty, $tipe, $refTable, $refId, $keterangan, $userId);
    }

    /**
     * Set stok langsung ke nilai tertentu (dipakai stock opname: selisih dihitung otomatis).
     */
    public function setTo(int $productId, int $branchId, float $qtyFisik, string $tipe, ?string $refTable = null, ?int $refId = null, ?string $keterangan = null, ?int $userId = null): void
    {
        $qtySistem = $this->stockModel->getQty($productId, $branchId);
        $selisih   = $qtyFisik - $qtySistem;
        if ($selisih != 0) {
            $this->mutate($productId, $branchId, $selisih, $tipe, $refTable, $refId, $keterangan, $userId);
        }
    }

    private function mutate(int $productId, int $branchId, float $qtyMutasi, string $tipe, ?string $refTable, ?int $refId, ?string $keterangan, ?int $userId): void
    {
        $this->stockModel->ensureRow($productId, $branchId);
        $qtySebelum = $this->stockModel->getQty($productId, $branchId);
        $qtySesudah = $qtySebelum + $qtyMutasi;

        $this->db->table('stocks')
            ->where('product_id', $productId)
            ->where('branch_id', $branchId)
            ->update(['qty' => $qtySesudah, 'updated_at' => date('Y-m-d H:i:s')]);

        $this->db->table('stock_mutations')->insert([
            'product_id'  => $productId,
            'branch_id'   => $branchId,
            'tipe'        => $tipe,
            'ref_table'   => $refTable,
            'ref_id'      => $refId,
            'qty_sebelum' => $qtySebelum,
            'qty_mutasi'  => $qtyMutasi,
            'qty_sesudah' => $qtySesudah,
            'keterangan'  => $keterangan,
            'user_id'     => $userId,
            'created_at'  => date('Y-m-d H:i:s'),
        ]);
    }

    /** Stok tersedia (non-SN: dari tabel stocks; SN: dari jumlah serial berstatus tersedia) */
    public function stokTersedia(int $productId, int $branchId, string $jenisProduk): float
    {
        if ($jenisProduk === 'sn') {
            return (float) $this->serialModel->countTersediaDiCabang($productId, $branchId);
        }
        return $this->stockModel->getQty($productId, $branchId);
    }
}
