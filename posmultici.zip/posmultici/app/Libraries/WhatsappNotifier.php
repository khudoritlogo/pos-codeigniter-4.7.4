<?php

namespace App\Libraries;

use App\Models\SystemSettingModel;

/**
 * Fitur #9: pengirim notifikasi WA Bot -- dipakai untuk kirim ringkasan omzet harian otomatis
 * ke nomor Owner/Super Admin, dan bisa dipakai ulang untuk notifikasi lain di masa depan.
 *
 * Implementasi memakai pola HTTP API gateway WA pihak ketiga generik (mis. Fonnte/Wablas/sejenis)
 * -- endpoint & API key diatur lewat halaman Pengaturan WA Bot (system_settings), bukan
 * di-hardcode, supaya gampang diganti sesuai provider yang dipakai toko.
 */
class WhatsappNotifier
{
    protected SystemSettingModel $settingModel;

    public function __construct()
    {
        $this->settingModel = new SystemSettingModel();
    }

    public function isEnabled(): bool
    {
        return $this->settingModel->get('wa_bot_enabled', null, '0') === '1';
    }

    public function getConfig(): array
    {
        return [
            'enabled'      => $this->isEnabled(),
            'api_endpoint' => $this->settingModel->get('wa_bot_api_endpoint', null, ''),
            'api_key'      => $this->settingModel->get('wa_bot_api_key', null, ''),
            'nomor_owner'  => $this->settingModel->get('wa_bot_nomor_owner', null, ''),
        ];
    }

    public function saveConfig(bool $enabled, string $endpoint, string $apiKey, string $nomorOwner): void
    {
        $this->settingModel->set('wa_bot_enabled', $enabled ? '1' : '0');
        $this->settingModel->set('wa_bot_api_endpoint', $endpoint);
        $this->settingModel->set('wa_bot_api_key', $apiKey);
        $this->settingModel->set('wa_bot_nomor_owner', $nomorOwner);
    }

    /**
     * Kirim pesan WA. Mengembalikan array ['success' => bool, 'message' => string] supaya
     * pemanggil (command cron ataupun tombol "Kirim Sekarang" di UI) bisa menampilkan hasilnya.
     */
    public function send(string $nomorTujuan, string $pesan): array
    {
        $config = $this->getConfig();

        if (! $config['enabled']) {
            return ['success' => false, 'message' => 'WA Bot belum diaktifkan di Pengaturan.'];
        }
        if (empty($config['api_endpoint']) || empty($config['api_key'])) {
            return ['success' => false, 'message' => 'Endpoint / API Key WA Bot belum diisi di Pengaturan.'];
        }

        $normalized = preg_replace('/[^0-9]/', '', $nomorTujuan);
        if (str_starts_with($normalized, '0')) {
            $normalized = '62' . substr($normalized, 1);
        }

        try {
            $client = \Config\Services::curlrequest();
            $response = $client->post($config['api_endpoint'], [
                'headers' => ['Authorization' => $config['api_key']],
                'form_params' => ['target' => $normalized, 'message' => $pesan],
                'timeout' => 15,
            ]);

            $statusCode = $response->getStatusCode();
            if ($statusCode >= 200 && $statusCode < 300) {
                return ['success' => true, 'message' => 'Pesan berhasil dikirim.'];
            }
            return ['success' => false, 'message' => "Gateway WA merespons status {$statusCode}."];
        } catch (\Throwable $e) {
            return ['success' => false, 'message' => 'Gagal mengirim: ' . $e->getMessage()];
        }
    }

    /** Susun ringkasan omzet harian dalam format pesan siap kirim */
    public function formatRingkasanOmzet(string $namaCabang, string $tanggal, float $omzet, int $jumlahTransaksi): string
    {
        return "*Ringkasan Omzet Harian*\n"
            . "Cabang: {$namaCabang}\n"
            . "Tanggal: {$tanggal}\n"
            . "Jumlah Transaksi: {$jumlahTransaksi}\n"
            . 'Total Omzet: Rp ' . number_format($omzet, 0, ',', '.') . "\n\n"
            . '_Pesan otomatis dari sistem POS Multi Cabang_';
    }
}
