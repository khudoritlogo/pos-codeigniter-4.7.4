<?php

namespace App\Libraries;

use CodeIgniter\Database\BaseConnection;

/**
 * Backup & restore database lewat sistem (tanpa perlu akses phpMyAdmin/CLI server).
 *
 * Strategi: coba pakai `mysqldump` via exec() dulu (paling cepat & lengkap, termasuk struktur
 * tabel) -- umum tersedia di VPS/hosting sendiri. Kalau exec() dimatikan (umum di shared hosting
 * murah demi keamanan), otomatis fallback ke native PHP export: query semua tabel lewat Query
 * Builder dan tulis ulang sebagai statement INSERT SQL biasa. Restore selalu lewat native PHP
 * (menjalankan file .sql yang diupload, statement per statement) supaya tidak bergantung pada
 * binary `mysql` CLI juga.
 */
class BackupService
{
    protected BaseConnection $db;
    protected string $backupPath;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
        $this->backupPath = WRITEPATH . 'backups/';
        if (! is_dir($this->backupPath)) {
            mkdir($this->backupPath, 0755, true);
        }
    }

    public function backupDir(): string
    {
        return $this->backupPath;
    }

    /** Buat file backup baru, kembalikan nama file yang dihasilkan */
    public function createBackup(): string
    {
        $filename = 'backup_' . date('Ymd_His') . '.sql';
        $filepath = $this->backupPath . $filename;

        if ($this->canUseMysqldump()) {
            $this->backupWithMysqldump($filepath);
        } else {
            $this->backupNative($filepath);
        }

        return $filename;
    }

    private function canUseMysqldump(): bool
    {
        return function_exists('exec') && ! in_array('exec', array_map('trim', explode(',', (string) ini_get('disable_functions'))), true);
    }

    private function backupWithMysqldump(string $filepath): void
    {
        $config = config('Database')->default;
        $command = sprintf(
            'mysqldump --host=%s --port=%s --user=%s --password=%s %s > %s 2>&1',
            escapeshellarg($config['hostname']),
            escapeshellarg((string) ($config['port'] ?? 3306)),
            escapeshellarg($config['username']),
            escapeshellarg($config['password']),
            escapeshellarg($config['database']),
            escapeshellarg($filepath)
        );
        exec($command, $output, $exitCode);

        // Kalau mysqldump gagal (mis. binary tidak ada di PATH), tetap fallback ke native export
        if ($exitCode !== 0 || ! is_file($filepath) || filesize($filepath) === 0) {
            $this->backupNative($filepath);
        }
    }

    /** Export manual: SHOW TABLES lalu tulis INSERT untuk tiap baris -- portable di semua hosting */
    private function backupNative(string $filepath): void
    {
        $tables = $this->db->listTables();
        $out = fopen($filepath, 'w');

        fwrite($out, "-- Backup POS Multi Cabang\n-- Dibuat: " . date('Y-m-d H:i:s') . "\n-- Metode: native PHP export (mysqldump tidak tersedia)\n\n");
        fwrite($out, "SET FOREIGN_KEY_CHECKS=0;\n\n");

        foreach ($tables as $table) {
            $rows = $this->db->table($table)->get()->getResultArray();
            if (empty($rows)) {
                continue;
            }

            fwrite($out, "-- Data untuk tabel `{$table}`\n");
            fwrite($out, "TRUNCATE TABLE `{$table}`;\n");

            $columns = array_keys($rows[0]);
            $columnList = '`' . implode('`, `', $columns) . '`';

            foreach (array_chunk($rows, 200) as $chunk) {
                $valueLines = [];
                foreach ($chunk as $row) {
                    $values = array_map(function ($v) {
                        if ($v === null) {
                            return 'NULL';
                        }
                        return "'" . str_replace(["\\", "'", "\n", "\r"], ["\\\\", "\\'", "\\n", "\\r"], (string) $v) . "'";
                    }, $row);
                    $valueLines[] = '(' . implode(', ', $values) . ')';
                }
                fwrite($out, "INSERT INTO `{$table}` ({$columnList}) VALUES\n" . implode(",\n", $valueLines) . ";\n");
            }
            fwrite($out, "\n");
        }

        fwrite($out, "SET FOREIGN_KEY_CHECKS=1;\n");
        fclose($out);
    }

    /** Jalankan file .sql (hasil backup sendiri atau mysqldump) statement per statement */
    public function restoreFromFile(string $filepath): void
    {
        $sql = file_get_contents($filepath);
        if ($sql === false) {
            throw new \RuntimeException('Gagal membaca file backup.');
        }

        // Pemisahan statement sederhana berbasis titik-koma di akhir baris (cukup untuk file
        // hasil backup sendiri / mysqldump standar tanpa stored procedure kompleks).
        $statements = array_filter(array_map('trim', explode(";\n", $sql)));

        $this->db->transStart();
        foreach ($statements as $statement) {
            $statement = trim($statement);
            if ($statement === '' || str_starts_with($statement, '--')) {
                continue;
            }
            $this->db->query($statement);
        }
        $this->db->transComplete();

        if ($this->db->transStatus() === false) {
            throw new \RuntimeException('Gagal menjalankan restore -- proses dibatalkan sepenuhnya (tidak ada perubahan sebagian).');
        }
    }

    public function listBackups(): array
    {
        $files = glob($this->backupPath . '*.sql') ?: [];
        rsort($files);
        return array_map(fn ($f) => [
            'filename' => basename($f),
            'size'     => filesize($f),
            'created'  => date('Y-m-d H:i:s', filemtime($f)),
        ], $files);
    }
}
