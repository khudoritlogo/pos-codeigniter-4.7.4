# POS Kasir Multi Cabang — CodeIgniter 4

## Status: SEMUA 7 FASE SELESAI — Fondasi, CRUD, Transaksi, Cetak, Laporan, Kurir, Piutang/Hutang & Backup

Berisi fondasi yang menjadi dasar seluruh fitur di daftar 51-fitur:
- Struktur project CI4 (app/Config, Controllers, Models, Filters, Database, Views, Helpers)
- **Skema database lengkap** (33 file migration) mencakup: cabang, role/user, kategori, satuan,
  supplier, ekspedisi, customer, barang (support multi satuan, multi harga bertingkat, SN/non-SN),
  stok per cabang + kartu stok (audit trail), penjualan + retur, pembelian + retur,
  transfer stok antar cabang, stock opname, piutang + cicilan, hutang + cicilan,
  pengaturan toko, pengaturan printer thermal, dan histori cetak barcode.
- **Auth & RBAC multi-cabang**: login, session, filter `auth` (wajib login) dan filter `role:<fitur>`
  (akses per fitur sesuai role: Super Admin / Admin / Kasir / Kurir — permission map ada di
  `app/Config/AuthGroups.php`, mengikuti persis daftar "Fitur Per Level" yang diberikan).
- Dashboard ringkasan (barang terjual, jumlah barang, customer, invoice, barang terlaris, stok terkecil)
  dengan query yang otomatis terfilter per cabang (Super Admin melihat gabungan semua cabang).
- Layout utama dengan sidebar yang otomatis menyesuaikan menu berdasarkan role yang login.
- Seeder: Role, Cabang Pusat, dan akun Super Admin awal.

## Cara Menjalankan

1. Buat project CodeIgniter 4 baru sebagai basis (jika belum punya):
   ```
   composer create-project codeigniter4/appstarter pos-multicabang
   ```
2. Salin/replace folder `app/` dari paket ini ke dalam project CI4 hasil `composer create-project` di atas
   (folder `app/` di paket ini sudah lengkap dengan Config, Controllers, Models, Filters, Database, Views, Helpers).
3. Copy `.env.example` menjadi `.env`, sesuaikan koneksi database.
4. Buat database MySQL kosong sesuai nama di `.env`, lalu jalankan migration:
   ```
   php spark migrate
   ```
5. Jalankan seeder (urutan penting):
   ```
   php spark db:seed RoleSeeder
   php spark db:seed BranchSeeder
   php spark db:seed AdminUserSeeder
   ```
6. Jalankan server:
   ```
   php spark serve
   ```
7. Login di `http://localhost:8080/login`
   - **Username:** `superadmin`
   - **Password:** `Admin#12345`
   - ⚠️ Segera ganti password setelah login pertama (fitur ganti password dibangun di Fase 2 - CRUD User).

## Struktur Role & Akses (RBAC)

Permission diatur terpusat di `app/Config/AuthGroups.php` (mudah diaudit/diubah tanpa menyentuh
controller). Setiap route di `app/Config/Routes.php` sudah dipasangi filter `role:<nama_fitur>`
sesuai spesifikasi "Fitur Per Level":

- **Super Admin** → semua fitur kecuali fitur Kurir
- **Admin** → master data, transaksi, & laporan operasional (tanpa: user, cabang, hutang/piutang lanjutan, laba bersih, backup)
- **Kasir** → dashboard, customer, transaksi kasir, retur penjualan, piutang, laporan pribadi & cek kurir
- **Kurir** → dashboard kurir, data pengiriman, laporan kurir pribadi

## Fase 2 — CRUD Master Data (baru)

Semua modul di bawah ini sudah punya Controller + Model + View lengkap (list dengan DataTable
client-side, form tambah/edit, hapus), dan sudah dibatasi lewat filter `role:<fitur>` sesuai
level akses masing-masing:

- **Kategori** & **Satuan** — CRUD sederhana
- **Supplier**, **Ekspedisi**, **Customer** (dengan tipe retail/grosir & limit piutang; customer
  yang masih punya piutang aktif tidak bisa dihapus)
- **Cabang** (khusus Super Admin) — kelola daftar cabang, tandai cabang pusat
- **Pengguna** (khusus Super Admin) — kelola user + role + penempatan cabang; Super Admin otomatis
  tidak terikat ke satu cabang (akses semua cabang)
- **Barang** — modul paling lengkap: info dasar, **multi satuan** (konversi ke satuan dasar, mis.
  1 Box = 12 Pcs, dengan harga sendiri per satuan), **harga bertingkat/dinamis** (qty minimal +
  berlaku untuk retail/grosir/semua), pilihan **jenis produk SN / Non-SN**, dan otomatis membuat
  baris stok (qty 0) di semua cabang aktif saat barang baru dibuat
- **Pengaturan Informasi Toko** — bisa diatur per cabang atau secara global oleh Super Admin

Catatan teknis: routing modul-modul di atas memakai GET+POST biasa (bukan resource RESTful
PUT/DELETE) supaya kompatibel dengan form HTML polos tanpa perlu JavaScript tambahan untuk
method-spoofing — lihat helper `crudRoutes()` di `app/Config/Routes.php`.

## Fase 3 — Transaksi Inti (baru)

- **StockService** (`app/Libraries/StockService.php`) — pusat semua mutasi stok + kartu stok
  (audit trail di tabel `stock_mutations`), dipakai konsisten oleh seluruh modul transaksi di bawah.
- **Kasir (POS)** — layar transaksi dengan pencarian barang real-time (mendukung scan barcode:
  hasil exact-match otomatis langsung masuk keranjang), harga otomatis menyesuaikan satuan +
  harga bertingkat/dinamis (qty minimal & tipe retail/grosir), input serial number untuk barang
  SN, diskon per item & per transaksi, 3 metode bayar (cash/transfer/piutang — otomatis membuat
  catatan piutang & mengecek kembalian), dan **transaksi pending** yang bisa dilanjutkan kapan saja
  tanpa memotong stok sampai benar-benar diselesaikan.
- **Retur Penjualan** — cari transaksi via no invoice, pilih barang & qty yang diretur (divalidasi
  terhadap sisa qty yang belum diretur), stok otomatis kembali, dan otomatis mengurangi piutang
  terkait jika transaksi asal berstatus piutang.
- **Pembelian** — input multi barang ke supplier, input serial number untuk barang SN yang baru
  masuk, 3 metode bayar (cash/transfer/hutang — otomatis membuat catatan hutang), harga beli
  master barang otomatis ter-update.
- **Retur Pembelian** — sama seperti retur penjualan tapi mengurangi stok (barang dikembalikan ke
  supplier) dan mengurangi hutang terkait.
- **Transfer Stok Antar Cabang** — alur bertahap *diajukan → dikirim → diterima* (atau *batal*);
  stok cabang asal baru berkurang saat ditandai "dikirim", stok cabang tujuan baru bertambah saat
  ditandai "diterima" — supaya barang dalam perjalanan tidak hilang dari pembukuan dua cabang sekaligus.
- **Stock Opname** — input qty fisik hasil hitung manual dibanding qty sistem, disimpan sebagai
  draft dulu (selisih terlihat), baru diterapkan ke stok sesungguhnya lewat tombol terpisah supaya
  ada jejak konfirmasi sebelum stok benar-benar berubah.
- **Piutang & Hutang** (listing) — dibuat otomatis dari transaksi penjualan/pembelian; halaman
  listing sudah menandai status "menunggak" otomatis untuk yang lewat jatuh tempo. Fitur input
  cicilan pembayaran detail dibangun lengkap di Fase 7.
- Placeholder "segera hadir" ditambahkan untuk seluruh menu Fase 4-7 (Laporan, Cetak Barcode,
  Pengaturan Printer, Kurir, Backup & Restore) supaya sidebar tidak error saat diklik sebelum
  fase terkait selesai dibangun.

## Fase 4 — Cetak Nota Thermal & Cetak Barcode (baru)

- **Pengaturan Printer** — ukuran kertas (58mm/80mm/custom dengan lebar bebas), ukuran font,
  toggle tampilkan logo, jumlah copy cetak, dengan **preview struk real-time** langsung di
  halaman pengaturan sebelum disimpan. Bisa diatur per cabang atau global oleh Super Admin.
- **Cetak Nota Thermal** — dari halaman detail transaksi penjualan, tombol "Cetak Nota" membuka
  tab baru berisi struk yang lebar & fontnya otomatis mengikuti Pengaturan Printer cabang terkait,
  lengkap dengan barcode nomor invoice (CODE128, di-render client-side pakai JsBarcode dari CDN),
  dan otomatis mencetak ulang sejumlah "jumlah copy" yang diatur (bukan sekadar dialog cetak
  browser, tapi struk digandakan langsung di halaman supaya konsisten di semua browser/OS).
- **Cetak Barcode** — cari & pilih barang bebas (bisa banyak sekaligus), atur jumlah label per
  barang, lalu atur sendiri ukuran label (lebar x tinggi mm) dan jumlah kolom per baris sesuai
  ukuran kertas stiker yang dipakai ("sesuai keinginan" seperti di spesifikasi) — hasilnya halaman
  grid barcode siap cetak, dengan opsi tampilkan harga di label atau tidak. Setiap sesi cetak
  otomatis tercatat di histori (`barcode_prints`).

## Fase 5 — Laporan + Export TXT/CSV + DataTable Server-Side (baru)

- **ExportService** (`app/Libraries/ExportService.php`) — helper terpusat export ke CSV (format
  standar, bisa dibuka Excel) dan TXT (fixed-width, mudah dibaca langsung di editor teks), dipakai
  seragam oleh seluruh laporan lewat parameter `?format=csv` / `?format=txt` di URL yang sama.
- **DataTableServerSide** (`app/Libraries/DataTableServerSide.php`) — helper generik untuk
  menjawab request DataTable dengan `serverSide: true` (paging/sorting/searching dieksekusi di
  query database, bukan memuat semua baris ke browser). Diterapkan pada **Laporan Penjualan per
  Periode** sebagai contoh nyata (`app/Views/report/penjualan_periode.php`) — tabel-tabel lain di
  aplikasi ini tetap memakai DataTable client-side biasa (cukup untuk data master/listing yang
  jumlahnya wajar), sesuai permintaan **"DataTable client side & server side"**.
- **12 laporan** lengkap dengan filter tanggal + cabang (Super Admin bisa pilih cabang mana pun
  atau gabungan semua; user cabang otomatis terkunci ke cabangnya) dan tombol Export CSV/TXT di
  setiap laporan:
  1. Laporan Kasir (kasir hanya melihat datanya sendiri — laporan pribadi)
  2. Laporan Customer (jumlah transaksi & total belanja per customer)
  3. Laporan Penjualan per Periode (DataTable server-side, lihat di atas)
  4. Laporan Penjualan Retur
  5. Laporan Data Supplier (jumlah & total pembelian per supplier)
  6. Laporan Pembelian per Periode
  7. Laporan Pembelian Retur
  8. Laporan Barang Terlaris (top 50 berdasarkan qty terjual pada periode)
  9. Laporan Stok Terkecil (barang dengan stok ≤ stok minimal, lintas atau per cabang)
  10. Laporan Kurir (kurir hanya melihat pengirimannya sendiri — laporan pribadi; detail
      integrasi WhatsApp/Maps & penunjukan otomatis dibangun di Fase 6)
  11. Laporan Transaksi Cash & Transfer (rekap per metode bayar)
  12. Laba Bersih per Periode (penjualan dikurangi HPP harian, dengan rincian per hari)

## Fase 6 — Modul Kurir (baru)

- **Dashboard Kurir** — ringkasan pengiriman berjalan & selesai hari ini, plus kontrol status
  ketersediaan (Free/Sibuk/Off) langsung dari dashboard.
- **Data Pengiriman Kurir** (`kurir/pengiriman`) — daftar transaksi yang ditugaskan ke kurir yang
  sedang login (hanya miliknya sendiri, sesuai RBAC), tiap kartu punya:
  - Tombol **WhatsApp** langsung ke nomor customer dengan pesan otomatis berisi nomor invoice
    (format nomor dikonversi otomatis ke 62xxx)
  - Tombol **Google Maps** yang membuka pencarian alamat customer
  - Kontrol update status pengiriman (Diproses → Dikirim → Selesai)
  - Status kurir otomatis berubah jadi "Sibuk" saat mulai memproses/mengirim, dan kembali "Free"
    otomatis setelah pengiriman selesai (kalau tidak ada pengiriman lain yang masih berjalan)
- **Penunjukan kurir saat transaksi kasir** — POS sekarang punya toggle "Pesanan Perlu Dikirim"
  yang memunculkan pilihan Kurir (menampilkan status Free/Sibuk/Off langsung di dropdown supaya
  kasir gampang pilih yang sedang free) dan Ekspedisi opsional.
- **Laporan Kurir** individual sudah tersedia sejak Fase 5 (kurir hanya melihat datanya sendiri).

## Fase 7 — Piutang & Hutang Lengkap + Backup & Restore (baru, fase terakhir)

- **Cicilan Piutang & Hutang** — halaman detail piutang/hutang sekarang punya form input
  pembayaran cicilan (jumlah, metode cash/transfer, catatan) dan riwayat lengkap semua
  pembayaran yang pernah dicatat. Status otomatis berubah: `belum_lunas` → `cicilan` (begitu ada
  pembayaran parsial) → `lunas` (begitu sisa mencapai 0), divalidasi supaya jumlah bayar tidak
  bisa melebihi sisa yang harus dibayar.
- **Fitur "Piutang Menunggak" & "Hutang Menunggak"** — halaman listing piutang/hutang sekarang
  punya toggle Semua / Menunggak untuk langsung menyaring transaksi yang sudah lewat jatuh tempo
  tapi belum lunas.
- **Backup & Restore Database** (`app/Libraries/BackupService.php`) — Super Admin bisa membuat
  backup kapan saja dari menu, otomatis memakai `mysqldump` kalau tersedia di server, atau
  fallback ke metode export native PHP (query semua tabel lalu tulis ulang sebagai `INSERT`)
  supaya tetap jalan di shared hosting yang mematikan `exec()`. Setiap backup tersimpan di
  `writable/backups/`, bisa diunduh, dihapus, atau langsung dipakai untuk **restore** (baik dari
  file yang sudah ada di server maupun upload file `.sql` baru) — restore selalu berjalan dalam
  transaksi database dan wajib konfirmasi checkbox eksplisit karena sifatnya menimpa data yang ada.

## Fitur Tambahan Lanjutan (di luar 51 fitur spesifikasi awal)

Sembilan fitur lanjutan berikut sudah ditambahkan di atas fondasi 7 fase sebelumnya:

1. **Member/Customer Level** (`level-member`) — kelola tingkatan pelanggan (Regular/Silver/Gold,
   bebas ditambah), masing-masing punya diskon otomatis (%) yang diterapkan begitu customer level
   tersebut dipilih di kasir, dan syarat minimal poin untuk naik level otomatis.
2. **Poin Belanja / Loyalty Points** (`hadiah-poin`, `tukar-poin`) — setiap Rp10.000 transaksi
   selesai menghasilkan 1 poin otomatis (`LoyaltyService`), tercatat di kartu poin
   (`loyalty_point_mutations`), bisa dipakai sebagai potongan langsung di kasir (1 poin = Rp1.000)
   atau ditukar hadiah barang lewat katalog terpisah — customer naik level otomatis begitu saldo
   poin menembus ambang batas level di atasnya.
3. **Manajemen Shift Kasir** (`shift-kasir`) — kasir wajib buka shift (isi modal awal) sebelum
   bisa transaksi; saat tutup shift, sistem menghitung otomatis total penjualan cash/non-cash
   selama shift berjalan dan membandingkan dengan uang fisik yang dihitung manual, menampilkan
   selisih (lebih/kurang/pas) secara otomatis.
4. **Audit Log & Otorisasi Void** (`audit-log`) — setiap penghapusan item di keranjang kasir
   SEBELUM struk dicetak otomatis tercatat, dan pembatalan (void) transaksi yang sudah selesai
   wajib diotorisasi login Admin/Super Admin (verifikasi username+password terpisah dari sesi
   kasir yang sedang aktif) sebelum stok dikembalikan & piutang terkait dibatalkan.
5. **QRIS Dynamic & Customer Facing Display** (`kasir/cfd`) — pilihan metode bayar QRIS otomatis
   menampilkan QR code berisi referensi transaksi + nominal (simulasi, siap diganti payload EMV
   QRIS resmi begitu kredensial merchant dari bank/PJSP tersedia), dan bisa dibuka di monitor
   kedua sebagai layar pelanggan yang menampilkan keranjang & total belanja secara real-time
   (sinkronisasi lewat `localStorage` antar tab browser, tanpa perlu server tambahan).
6. **Mode Offline (Offline-First)** — kalau koneksi internet terputus saat kasir menekan "Selesaikan
   & Bayar", transaksi otomatis disimpan ke antrean lokal di browser (`localStorage`) supaya kasir
   tetap bisa lanjut melayani customer berikutnya, lalu otomatis/manual disinkronkan ke server
   begitu koneksi kembali (indikator jumlah transaksi tertunda selalu terlihat di layar kasir).
7. **Manajemen Garansi berbasis SN** (`garansi`) — barang jenis SN bisa diatur lama garansinya
   (bulan); begitu terjual, tanggal mulai & berakhir garansi otomatis tercatat per serial number;
   ada halaman cek status garansi (aktif/expired) by serial number dan cetak lembar klaim garansi
   siap tanda tangan.
8. **Tanggal Kedaluwarsa (FEFO/Expired Date)** (`laporan/kedaluwarsa`) — barang bisa ditandai
   "punya tanggal kedaluwarsa"; setiap pembelian wajib isi nomor batch + tanggal expired; stok
   otomatis dikurangi mengikuti prinsip FEFO (batch dengan expired terdekat keluar duluan) saat
   terjual; ada laporan peringatan dini barang yang mendekati/sudah lewat kedaluwarsa.
9. **Notifikasi WA Bot Otomatis** (`pengaturan-wa-bot`) — ringkasan omzet harian per cabang bisa
   dikirim otomatis ke WhatsApp Owner/Super Admin lewat gateway WA pihak ketiga (endpoint & API
   key dikonfigurasi sendiri sesuai provider yang dipakai, mis. Fonnte/Wablas) — ada tombol "Tes
   Kirim Sekarang" untuk memastikan konfigurasi gateway sudah benar sebelum dijadwalkan otomatis.
10. **Notifikasi Telegram Bot Otomatis** (`pengaturan-telegram-bot`) — versi Telegram dari fitur
    di atas, tapi memakai **Telegram Bot API resmi** (gratis, tanpa gateway pihak ketiga
    berbayar) — cukup buat bot lewat @BotFather, isi Bot Token + Chat ID di halaman pengaturan
    (panduan langkah demi langkah sudah ada di halamannya), lalu aktifkan. Kedua channel notifikasi
    (WA & Telegram) bisa dipakai bersamaan — `php spark kirim:omzet-harian` otomatis mengirim ke
    channel manapun yang sedang aktif.

Kedua channel dijadwalkan lewat spark command yang sama:
`php spark kirim:omzet-harian` (dijalankan cron server tiap malam, lihat komentar di
`app/Commands/KirimOmzetHarian.php` untuk contoh baris crontab).

## Tampilan (UI Theme) — Ink Indigo + Batik Gold

Seluruh aplikasi sudah direstyle mengikuti prototipe visual (bukan Bootstrap default lagi):

- **`public/assets/css/theme.css`** — satu file tema terpusat yang menata ulang warna, font, dan
  komponen Bootstrap yang sudah dipakai konsisten di 200+ halaman (sidebar, topbar, card, button,
  badge, table, form, alert) — jadi seluruh aplikasi ikut berubah tampilan tanpa perlu menyentuh
  tiap file view satu-satu. Pastikan folder `public/` ikut ter-serve sebagai document root saat
  deploy (default CodeIgniter 4) supaya file CSS ini bisa diakses lewat `base_url('assets/css/theme.css')`.
- **Font**: judul & elemen brand pakai 'Sora', teks UI pakai 'Inter', dan **setiap kolom angka
  (kelas `.text-end`)** — harga, qty, subtotal, dsb — otomatis pakai 'IBM Plex Mono' dengan
  tabular numerals supaya kolom uang terasa rapi seperti buku kas, bukan sekadar tabel generik.
- **Warna**: Ink Indigo (`#1B2340`) untuk sidebar & elemen gelap, Batik Gold (`#C9A227`) untuk
  tombol utama & aksen aktif, warna status (sukses/warning/danger/info) diselaraskan supaya
  konsisten di semua badge laporan & listing.
- **Sidebar**: link yang sedang aktif otomatis mendapat garis emas di kiri (dideteksi dari URL
  saat ini lewat JS kecil di `layouts/main.php`, tanpa perlu logic PHP tambahan di tiap link).
- **Halaman yang disentuh langsung** (di luar efek otomatis dari theme.css): halaman Login
  (background indigo penuh, kartu terpusat, ikon brand), panel Total & Bayar di layar Kasir
  (dibuat gelap ala mesin kasir sungguhan, mengikuti gaya panel kanan di prototipe), dan kartu
  statistik Dashboard (ikon berwarna per kartu).
- Halaman cetak (nota thermal, barcode, kartu garansi) sengaja **tidak** ikut direstyle karena
  memang harus tetap polos/ringkas untuk kebutuhan cetak fisik di printer thermal/label.

---

Seluruh 51 fitur + 4 level akses dari spesifikasi awal, ditambah 9 fitur lanjutan di atas, sudah
tercakup di 214 file. Untuk menjalankan project secara nyata, ikuti langkah **Cara Menjalankan**
di atas — buat project CI4 dasar lewat Composer, salin folder `app/` dari paket ini, siapkan
database MySQL, jalankan migration + seeder, lalu `php spark serve`.

Katakan fase mana yang mau dikerjakan berikutnya, atau modul spesifik yang mau diprioritaskan duluan.
