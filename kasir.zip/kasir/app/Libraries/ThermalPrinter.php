<?php
namespace App\Libraries;

/**
 * ThermalPrinter - cetak receipt ke printer thermal (ESC/POS)
 * 
 * Mendukung: Gprinter, Xprinter, Epson TM-T20/T88
 * Protocol: ESC/POS via raw print (stream ke port printer)
 */
class ThermalPrinter
{
    private $port;
    private $baudRate = 9600;
    
    public function __construct(?string $port = null)
    {
        $this->port = $port ?? $this->detectPort();
    }
    
    private function detectPort(): ?string
    {
        // Gunakan port dari config/settings
        $settings = null;
        try {
            $settings = model('StoreSettingModel')->first();
        } catch (\Exception $e) {}
        
        $port = $settings['thermal_printer_port'] ?? env('THERMAL_PRINTER_PORT', null);
        
        // Default port di Windows/Linux
        if (!$port) {
            $port = defined('PHP_OS_FAMILY') && PHP_OS_FAMILY === 'Windows' 
                ? 'USB001' 
                : '/dev/usb/lp0';
        }
        
        return $port ?: null;
    }
    
    /**
     * Cetak receipt untuk transaksi
     * @param int $saleId ID transaksi
     * @return bool
     */
    public function printReceipt(int $saleId): bool
    {
        $db = \Config\Database::connect();
        
        $sale = $db->table('sales s')
            ->select('s.*, u.fullname AS cashier_name, c.name AS customer_name, b.name AS branch_name')
            ->join('users u', 'u.id = s.cashier_id', 'left')
            ->join('customers c', 'c.id = s.customer_id', 'left')
            ->join('branches b', 'b.id = s.branch_id', 'left')
            ->where('s.id', $saleId)
            ->get()
            ->getRowArray();
        
        if (!$sale) return false;
        
        $items = $db->table('sale_items si')
            ->select('si.*, p.name AS product_name')
            ->join('products p', 'p.id = si.product_id', 'left')
            ->where('si.sale_id', $saleId)
            ->orderBy('si.id')
            ->get()
            ->getResultArray();
        
        $receipt = $this->buildReceipt($sale, $items);
        
        if ($this->port) {
            return $this->sendToPrinter($receipt);
        }
        
        // Fallback: simpan ke file untuk dicetak manual
        $dir = WRITEPATH . 'receipts/';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        file_put_contents($dir . "receipt_$saleId.txt", $receipt);
        log_message('info', "ThermalReceipt saved: receipts/receipt_$saleId.txt");
        
        return true;
    }
    
    /**
     * Build receipt text (ESC/POS format)
     */
    private function buildReceipt(array $sale, array $items): string
    {
        $s = $this->escposInit();
        $s .= $this->escposCenter($this->getStoreName() . "\n");
        $s .= $this->escposCenter($this->getStoreAddress() . "\n");
        $s .= $this->escposCenter("-".str_repeat("-", 25)."-");
        $s .= "\n";
        $s .= "No. Invoice : " . $sale['invoice_no'] . "\n";
        $s .= "Tanggal    : " . date('d/m/Y H:i:s', strtotime($sale['sale_date'])) . "\n";
        $s .= "Kasir      : " . ($sale['cashier_name'] ?? '-') . "\n";
        $s .= "Customer   : " . ($sale['customer_name'] ?? 'Umum') . "\n";
        $s .= "\n";
        $s .= $this->escposLeft('-----------------------------');
        $s .= "\n";
        $s .= sprintf(" %-25s %3s %10s %10s\n", "ITEM", "QTY", "HARGA", "TOTAL");
        $s .= $this->escposLeft('-----------------------------');
        $s .= "\n";
        
        $subtotal = 0;
        foreach ($items as $item) {
            $qty = (int)$item['qty'];
            $price = (float)$item['price'];
            $total = $qty * $price;
            $subtotal += $total;
            $name = mb_strimwidth($item['product_name'] ?? 'Produk', 0, 20, '...');
            $s .= sprintf(" %-25s %3d %10s %10s\n", 
                $name,
                $qty,
                number_format($price, 0, ',', '.'),
                number_format($total, 0, ',', '.'));
        }
        
        $s .= $this->escposLeft('-----------------------------');
        $s .= "\n";
        
        $tax = (float)($sale['tax_amount'] ?? 0);
        $discount = (float)($sale['discount_amount'] ?? 0);
        $total = (float)$sale['total'];
        
        if ($discount > 0) {
            $s .= sprintf(" Diskon      : %20s\n", number_format(-$discount, 0, ',', '.'));
        }
        if ($tax > 0) {
            $s .= sprintf(" PPN 11%%    : %20s\n", number_format($tax, 0, ',', '.'));
        }
        $s .= sprintf(" TOTAL      : %20s\n", number_format($total, 0, ',', '.'));
        $s .= "\n";
        
        $paid = (float)($sale['paid'] ?? 0);
        $change = $paid - $total;
        $method = $sale['payment_method'] ?? 'cash';
        
        $s .= sprintf(" Bayar      : %20s\n", number_format($paid, 0, ',', '.'));
        $s .= sprintf(" Kembalian  : %20s\n", number_format(max(0, $change), 0, ',', '.'));
        $s .= "\n";
        $s .= " Metode     : " . $method . "\n";
        if ($method === 'qris' && !empty($sale['qris_order_id'])) {
            $s .= " QRIS Order : " . $sale['qris_order_id'] . "\n";
        }
        $s .= "\n";
        $s .= $this->escposCenter("-".str_repeat("-", 25)."-");
        $s .= "\n";
        $s .= $this->escposCenter(" TERIMA KASIH ");
        $s .= $this->escposCenter(" Silakan Datang Kembali ");
        $s .= "\n\n";
        $s .= " TLOGO SMART - Developed by TLOGO\n";
        
        $s .= $this->escposCut();
        
        return $s;
    }
    
    private function getStoreName(): string
    {
        try {
            $s = model('StoreSettingModel')->first();
            return $s['store_name'] ?? 'TLOGO SMART';
        } catch (\Exception $e) {
            return 'TLOGO SMART';
        }
    }
    
    private function getStoreAddress(): string
    {
        try {
            $s = model('StoreSettingModel')->first();
            $addr = $s['store_address'] ?? '';
            $phone = $s['phone'] ?? '';
            return trim($addr . "\n" . $phone);
        } catch (\Exception $e) {
            return '';
        }
    }
    
    // ESC/POS Commands
    private function escposInit(): string { return "\x1B\x40"; }       // ESC @
    private function escposCut(): string { return "\x0C"; }            // Form Feed
    private function escposCenter(string $text): string { 
        return "\x1B\x61\x01" . $text . "\x1B\x61\x00"; 
    }
    private function escposLeft(string $text): string { 
        return "\x1B\x61\x00" . $text;
    }
    private function escposRight(string $text): string { 
        return "\x1B\x61\x02" . $text . "\x1B\x61\x00"; 
    }
    
    private function sendToPrinter(string $data): bool
    {
        $port = $this->port;
        
        if (DIRECTORY_SEPARATOR === '\\') {
            // Windows: fallback — simpan ke file receipt (tidak perlu printer)
            $dir = WRITEPATH . 'receipts/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            $tmpFile = $dir . 'receipt_' . microtime(true) . '.txt';
            file_put_contents($tmpFile, $data);
        } else {
            // Linux: write ke /dev/usb/lp0 atau CUPS
            $dev = '/dev/usb/lp0';
            if (@is_writable($dev)) {
                file_put_contents($dev, $data, LOCK_EX);
                return true;
            }
            @exec("echo '" . escapeshellarg($data) . "' | lp -d thermal 2>&1", $out, $rc);
            if ($rc === 0) return true;
        }
        
        log_message('warning', "ThermalPrinter: Tidak bisa mengirim ke port $port");
        return false;
    }
}
