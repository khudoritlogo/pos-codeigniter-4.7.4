<?php

namespace App\Libraries;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class MailService
{
    protected array $s;

    public function __construct()
    {
        $settings = model('StoreSettingModel')->first() ?: [];
        $this->s = [
            'host'       => $settings['smtp_host']       ?? env('smtp.host'),
            'port'       => (int) ($settings['smtp_port'] ?? env('smtp.port', 587)),
            'username'   => $settings['smtp_username']   ?? env('smtp.username'),
            'password'   => $settings['smtp_password']   ?? env('smtp.password'),
            'encryption' => $settings['smtp_encryption'] ?? env('smtp.encryption', 'tls'),
            'from_email' => $settings['smtp_from_email'] ?? env('smtp.fromEmail'),
            'from_name'  => $settings['smtp_from_name']  ?? env('smtp.fromName', 'POS Kasir'),
        ];
    }

    /**
     * @param array<array{content:string,name:string,mime?:string}> $attachments
     */
    public function send(string $to, string $subject, string $htmlBody, array $attachments = []): array
    {
        if (! class_exists(PHPMailer::class)) {
            return ['ok'=>false,'msg'=>'PHPMailer belum terinstall. composer require phpmailer/phpmailer'];
        }
        if (empty($this->s['host']) || empty($this->s['username'])) {
            return ['ok'=>false,'msg'=>'SMTP belum dikonfigurasi. Buka Pengaturan → Integrasi.'];
        }

        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host       = $this->s['host'];
            $mail->SMTPAuth   = true;
            $mail->Username   = $this->s['username'];
            $mail->Password   = $this->s['password'];
            $mail->SMTPSecure = $this->s['encryption'] === 'ssl' ? PHPMailer::ENCRYPTION_SMTPS : PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port       = $this->s['port'];
            $mail->CharSet    = 'UTF-8';

            $mail->setFrom($this->s['from_email'] ?: $this->s['username'], $this->s['from_name']);
            $mail->addAddress($to);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $htmlBody;
            $mail->AltBody = strip_tags($htmlBody);

            foreach ($attachments as $a) {
                $mail->addStringAttachment($a['content'], $a['name'], PHPMailer::ENCODING_BASE64, $a['mime'] ?? 'application/pdf');
            }
            $mail->send();
            return ['ok'=>true];
        } catch (Exception $e) {
            return ['ok'=>false,'msg'=>$e->getMessage()];
        }
    }
}
