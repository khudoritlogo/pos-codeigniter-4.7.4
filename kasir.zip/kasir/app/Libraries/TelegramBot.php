<?php

namespace App\Libraries;

/**
 * Telegram Bot Interactive — merespon /omzet /stok /piutang /help
 * Set webhook di Telegram: POST /setWebhook?url=https://your-domain/telegram/webhook
 */
class TelegramBot
{
    protected ?string $token;

    public function __construct()
    {
        $settings = model('StoreSettingModel')->first();
        $this->token = $settings['telegram_bot_token'] ?? env('telegram.botToken');
    }

    public function handleUpdate(array $update): array
    {
        $msg = $update['message'] ?? null;
        if (! $msg) return ['ok'=>true,'skipped'=>true];

        $chatId = (string) ($msg['chat']['id'] ?? '');
        $text   = trim((string) ($msg['text'] ?? ''));
        $from   = $msg['from'] ?? [];

        $this->log('in', $chatId, $text);
        $this->ensureSubscriber($chatId, $from);

        // Parse command
        $cmd = strtolower(explode(' ', ltrim($text, '/'))[0] ?? '');
        $reply = match ($cmd) {
            'start','help'   => $this->cmdHelp(),
            'omzet','sales'  => $this->cmdOmzet(),
            'stok','stock'   => $this->cmdStock(),
            'piutang'        => $this->cmdPiutang(),
            'hutang'         => $this->cmdHutang(),
            'top','terlaris' => $this->cmdTop(),
            'kasir'          => $this->cmdKasir(),
            'kurir'          => $this->cmdKurir(),
            default          => "❓ Command tidak dikenal. Ketik /help untuk daftar perintah.",
        };

        return $this->send($chatId, $reply);
    }

    protected function cmdHelp(): string
    {
        return "<b>🤖 POS Kasir Bot</b>\n\n"
             . "Perintah tersedia:\n"
             . "/omzet - Omzet hari ini & bulan ini\n"
             . "/stok - Ringkasan stok & alert produk menipis\n"
             . "/piutang - Ringkasan piutang customer\n"
             . "/hutang - Ringkasan hutang ke supplier\n"
             . "/top - 5 produk terlaris bulan ini\n"
             . "/kasir - Kinerja kasir hari ini\n"
             . "/kurir - Status pengiriman kurir\n"
             . "/help - Bantuan ini";
    }

    protected function cmdOmzet(): string
    {
        $db = \Config\Database::connect();
        $today = date('Y-m-d'); $monthStart = date('Y-m-01');
        $t = $db->query("SELECT COUNT(*) c, COALESCE(SUM(total),0) o, COALESCE(SUM(CASE WHEN payment_method='cash' THEN total ELSE 0 END),0) cash, COALESCE(SUM(CASE WHEN payment_method='transfer' THEN total ELSE 0 END),0) trf, COALESCE(SUM(CASE WHEN payment_method='qris' THEN total ELSE 0 END),0) qris FROM sales WHERE DATE(sale_date)=? AND status='completed'",[$today])->getRow();
        $m = $db->query("SELECT COUNT(*) c, COALESCE(SUM(total),0) o FROM sales WHERE sale_date>=? AND status='completed'",[$monthStart])->getRow();
        $p = $db->query("SELECT COALESCE(SUM(si.profit),0) p FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE DATE(s.sale_date)=? AND s.status='completed'",[$today])->getRow();

        return "<b>📊 OMZET HARI INI</b>\n"
             . "🗓️ ".date('d M Y')."\n"
             . "━━━━━━━━━━━━━━━━━━\n"
             . "🧾 Transaksi: <b>{$t->c}</b>\n"
             . "💰 Omzet: <b>Rp ".$this->fmt($t->o)."</b>\n"
             . "📈 Laba: <b>Rp ".$this->fmt($p->p)."</b>\n\n"
             . "💵 Cash: Rp ".$this->fmt($t->cash)."\n"
             . "🏦 Transfer: Rp ".$this->fmt($t->trf)."\n"
             . "🔳 QRIS: Rp ".$this->fmt($t->qris)."\n"
             . "━━━━━━━━━━━━━━━━━━\n"
             . "📅 <b>Bulan Ini</b>: {$m->c} trx / Rp ".$this->fmt($m->o);
    }

    protected function cmdStock(): string
    {
        $db = \Config\Database::connect();
        $total = $db->table('products')->where('deleted_at',null)->countAllResults();
        $low = $db->query("SELECT p.name, ps.stock, p.stock_alert, b.name AS branch
            FROM product_stocks ps JOIN products p ON p.id=ps.product_id JOIN branches b ON b.id=ps.branch_id
            WHERE p.deleted_at IS NULL AND ps.stock <= p.stock_alert
            ORDER BY ps.stock ASC LIMIT 10")->getResultArray();

        $msg = "<b>📦 STATUS STOK</b>\n━━━━━━━━━━━━━━━━━━\n";
        $msg .= "Total Produk: <b>$total</b>\n";
        $msg .= "⚠️ Produk Menipis: <b>".count($low)."</b>\n\n";
        if (empty($low)) $msg .= "✅ Semua stok aman!";
        else foreach ($low as $p) {
            $msg .= "• {$p['name']} @ <i>{$p['branch']}</i>: <b>{$p['stock']}</b> (alert: {$p['stock_alert']})\n";
        }
        return $msg;
    }

    protected function cmdPiutang(): string
    {
        $r = \Config\Database::connect()->query("
            SELECT COUNT(*) c, COALESCE(SUM(remaining),0) t,
                   SUM(CASE WHEN due_date<CURDATE() THEN 1 ELSE 0 END) overdue
            FROM receivables WHERE status IN('unpaid','partial')")->getRow();
        return "<b>💳 PIUTANG</b>\n━━━━━━━━━━━━━━━━━━\n"
             . "Jumlah Piutang: <b>{$r->c}</b>\n"
             . "Total Sisa: <b>Rp ".$this->fmt($r->t)."</b>\n"
             . "⚠️ Menunggak: <b>{$r->overdue}</b>";
    }

    protected function cmdHutang(): string
    {
        $r = \Config\Database::connect()->query("
            SELECT COUNT(*) c, COALESCE(SUM(remaining),0) t,
                   SUM(CASE WHEN due_date<CURDATE() THEN 1 ELSE 0 END) overdue
            FROM payables WHERE status IN('unpaid','partial')")->getRow();
        return "<b>💰 HUTANG</b>\n━━━━━━━━━━━━━━━━━━\n"
             . "Jumlah Hutang: <b>{$r->c}</b>\n"
             . "Total Sisa: <b>Rp ".$this->fmt($r->t)."</b>\n"
             . "⚠️ Menunggak: <b>{$r->overdue}</b>";
    }

    protected function cmdTop(): string
    {
        $rows = \Config\Database::connect()->query("
            SELECT p.name, SUM(si.qty) qty, SUM(si.subtotal) rev
            FROM sale_items si JOIN sales s ON s.id=si.sale_id JOIN products p ON p.id=si.product_id
            WHERE s.sale_date>=? AND s.status='completed'
            GROUP BY p.id ORDER BY qty DESC LIMIT 5",[date('Y-m-01')])->getResultArray();
        $msg = "<b>⭐ TOP 5 PRODUK BULAN INI</b>\n━━━━━━━━━━━━━━━━━━\n";
        foreach ($rows as $i=>$r) $msg .= ($i+1).". <b>{$r['name']}</b>\n   ".(int)$r['qty']." pcs / Rp ".$this->fmt($r['rev'])."\n";
        return $msg ?: "Belum ada data";
    }

    protected function cmdKasir(): string
    {
        $rows = \Config\Database::connect()->query("
            SELECT u.fullname, COUNT(s.id) c, COALESCE(SUM(s.total),0) t
            FROM sales s JOIN users u ON u.id=s.cashier_id
            WHERE DATE(s.sale_date)=? AND s.status='completed'
            GROUP BY u.id ORDER BY t DESC",[date('Y-m-d')])->getResultArray();
        $msg = "<b>👤 KASIR HARI INI</b>\n━━━━━━━━━━━━━━━━━━\n";
        if (empty($rows)) return $msg."Belum ada transaksi";
        foreach ($rows as $r) $msg .= "• <b>{$r['fullname']}</b>: {$r['c']} trx / Rp ".$this->fmt($r['t'])."\n";
        return $msg;
    }

    protected function cmdKurir(): string
    {
        $rows = \Config\Database::connect()->query("
            SELECT k.fullname, k.courier_status,
                   SUM(CASE WHEN s.delivery_status='pending' THEN 1 ELSE 0 END) pending,
                   SUM(CASE WHEN s.delivery_status='in_progress' THEN 1 ELSE 0 END) ip,
                   SUM(CASE WHEN s.delivery_status='delivered' AND DATE(s.sale_date)=CURDATE() THEN 1 ELSE 0 END) done
            FROM users k
            LEFT JOIN sales s ON s.courier_id=k.id
            JOIN user_levels l ON l.id=k.level_id
            WHERE l.code='kurir' AND k.is_active=1
            GROUP BY k.id ORDER BY done DESC")->getResultArray();
        $msg = "<b>🏍️ KURIR STATUS</b>\n━━━━━━━━━━━━━━━━━━\n";
        foreach ($rows as $r) {
            $icon = ($r['courier_status']==='free') ? '🟢' : (($r['courier_status']==='busy') ? '🟡' : '⚫');
            $msg .= "$icon <b>{$r['fullname']}</b>\n   Pending: {$r['pending']} | Jalan: {$r['ip']} | Selesai: {$r['done']}\n";
        }
        return $msg ?: "Belum ada kurir";
    }

    public function send(string $chatId, string $text): array
    {
        if (empty($this->token)) return ['ok'=>false,'msg'=>'Token belum diset'];
        $ch = curl_init("https://api.telegram.org/bot{$this->token}/sendMessage");
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query(['chat_id'=>$chatId,'text'=>$text,'parse_mode'=>'HTML']),
            CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10,
        ]);
        $resp = curl_exec($ch); curl_close($ch);
        $this->log('out', $chatId, $text);
        return ['ok'=>$resp !== false];
    }

    public function setWebhook(string $url): array
    {
        if (empty($this->token)) return ['ok'=>false,'msg'=>'Token belum diset'];
        $r = file_get_contents("https://api.telegram.org/bot{$this->token}/setWebhook?url=".urlencode($url));
        return ['ok'=>$r!==false,'response'=>$r];
    }

    protected function ensureSubscriber(string $chatId, array $from): void
    {
        $db = \Config\Database::connect();
        $exists = $db->table('telegram_subscribers')->where('chat_id',$chatId)->countAllResults();
        if (! $exists) {
            $db->table('telegram_subscribers')->insert([
                'chat_id'=>$chatId,
                'username'=>$from['username']??null,
                'full_name'=>trim(($from['first_name']??'').' '.($from['last_name']??'')),
                'role'=>'owner','is_active'=>1,'created_at'=>date('Y-m-d H:i:s'),
            ]);
        }
    }

    protected function log(string $dir, string $chatId, string $text): void
    {
        \Config\Database::connect()->table('telegram_message_logs')->insert([
            'chat_id'=>$chatId,'direction'=>$dir,'text'=>$text,
            'command'=>strtolower(explode(' ',ltrim($text,'/'))[0] ?? ''),
            'created_at'=>date('Y-m-d H:i:s'),
        ]);
    }

    protected function fmt($n): string { return number_format((float) $n, 0, ',', '.'); }
}
