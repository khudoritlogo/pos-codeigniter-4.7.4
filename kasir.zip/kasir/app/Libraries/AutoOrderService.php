<?php

namespace App\Libraries;

/**
 * Generate Draft Purchase Order otomatis untuk produk yang stoknya mendekati habis.
 * Digunakan via CLI (`php spark po:auto-generate`) atau tombol manual di UI.
 */
class AutoOrderService
{
    /**
     * @param int $daysWindow  Analisis penjualan N hari terakhir (default 30)
     * @param int $threshold   Trigger jika prediksi habis dalam <= X hari (default 7)
     */
    public function generateDrafts(int $daysWindow = 30, int $threshold = 7, ?int $branchId = null): array
    {
        $db = \Config\Database::connect();
        $branchFilter = $branchId ? ' AND ps.branch_id = ' . (int) $branchId : '';

        $rows = $db->query("
            SELECT
              p.id AS product_id, p.name, p.default_supplier_id, p.cost_price,
              p.reorder_qty, p.reorder_days_target, p.stock_alert,
              ps.branch_id, ps.stock AS current_stock,
              COALESCE(sd.total_qty, 0) / ? AS avg_daily,
              CASE WHEN COALESCE(sd.total_qty,0)=0 THEN NULL ELSE ps.stock / (COALESCE(sd.total_qty,0)/?) END AS days_remaining
            FROM product_stocks ps
            JOIN products p ON p.id = ps.product_id
            LEFT JOIN (
              SELECT si.product_id, s.branch_id, SUM(si.qty * si.unit_conversion) AS total_qty
              FROM sale_items si JOIN sales s ON s.id = si.sale_id
              WHERE s.sale_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY) AND s.status='completed'
              GROUP BY si.product_id, s.branch_id
            ) sd ON sd.product_id = ps.product_id AND sd.branch_id = ps.branch_id
            WHERE p.deleted_at IS NULL AND p.is_active=1 AND p.default_supplier_id IS NOT NULL
              $branchFilter
            HAVING (days_remaining IS NOT NULL AND days_remaining <= ?) OR current_stock <= p.stock_alert
        ", [$daysWindow, $daysWindow, $daysWindow, $threshold])->getResultArray();

        // Group by supplier + branch
        $groups = [];
        foreach ($rows as $r) {
            $key = $r['default_supplier_id'] . '_' . $r['branch_id'];
            $groups[$key][] = $r;
        }

        $created = [];
        foreach ($groups as $key => $items) {
            [$supplierId, $branchId] = array_map('intval', explode('_', $key));

            // Skip jika sudah ada PO draft untuk supplier ini hari ini (idempotent)
            $existing = $db->table('purchase_orders')
                ->where(['supplier_id'=>$supplierId,'branch_id'=>$branchId,'status'=>'draft','is_auto'=>1])
                ->where('created_at >=', date('Y-m-d 00:00:00'))->countAllResults();
            if ($existing > 0) continue;

            $poNo = 'PO-AUTO-'.date('Ymd').'-'.str_pad((string)$supplierId,3,'0',STR_PAD_LEFT).'-'.random_int(100,999);
            $total = 0.0;
            $preparedItems = [];
            foreach ($items as $it) {
                $qty = $it['reorder_qty'] > 0
                    ? (int) $it['reorder_qty']
                    : max(1, (int) ceil((float) $it['avg_daily'] * (int) $it['reorder_days_target'] - (float) $it['current_stock']));
                $cost = (float) $it['cost_price'];
                $subtotal = $qty * $cost;
                $total += $subtotal;
                $preparedItems[] = [
                    'product_id'=>$it['product_id'],'qty'=>$qty,'cost_price'=>$cost,'subtotal'=>$subtotal,
                    'current_stock'=>$it['current_stock'],
                    'avg_daily_sales'=>$it['avg_daily'],
                    'days_remaining'=>$it['days_remaining'],
                ];
            }
            if (empty($preparedItems)) continue;

            $poId = $db->table('purchase_orders')->insert([
                'po_number'=>$poNo,'supplier_id'=>$supplierId,'branch_id'=>$branchId,
                'status'=>'draft','is_auto'=>1,'total_amount'=>$total,
                'notes'=>'Auto-generated from predictive restock analysis',
                'created_by'=>null,'created_at'=>date('Y-m-d H:i:s'),
            ]);
            $poId = $db->insertID();
            foreach ($preparedItems as $it) {
                $db->table('purchase_order_items')->insert(array_merge(['po_id'=>$poId], $it));
            }
            $created[] = ['po_id'=>$poId,'po_number'=>$poNo,'supplier_id'=>$supplierId,'total'=>$total,'items'=>count($preparedItems)];
        }

        return $created;
    }
}
