<?php

namespace App\Libraries;

/** Backup & Restore Database via `mysqldump` / `mysql` CLI (harus tersedia di PATH server) */
class BackupService
{
    public function backup(string $destinationDir = WRITEPATH . 'backups'): string
    {
        $cfg = config('Database')->default;
        if (! is_dir($destinationDir)) mkdir($destinationDir, 0775, true);
        $file = $destinationDir . '/backup_' . date('Ymd_His') . '.sql';
        $cmd  = sprintf(
            'mysqldump --host=%s --port=%s --user=%s %s %s > %s 2>&1',
            escapeshellarg($cfg['hostname']),
            escapeshellarg((string) ($cfg['port'] ?? 3306)),
            escapeshellarg($cfg['username']),
            empty($cfg['password']) ? '' : '--password=' . escapeshellarg($cfg['password']),
            escapeshellarg($cfg['database']),
            escapeshellarg($file)
        );
        exec($cmd, $out, $code);
        if ($code !== 0) throw new \RuntimeException('Backup gagal: '. implode("\n", $out));
        return $file;
    }

    public function restore(string $sqlFile): void
    {
        $cfg = config('Database')->default;
        $cmd = sprintf(
            'mysql --host=%s --user=%s %s %s < %s 2>&1',
            escapeshellarg($cfg['hostname']),
            escapeshellarg($cfg['username']),
            empty($cfg['password']) ? '' : '--password=' . escapeshellarg($cfg['password']),
            escapeshellarg($cfg['database']),
            escapeshellarg($sqlFile)
        );
        exec($cmd, $out, $code);
        if ($code !== 0) throw new \RuntimeException('Restore gagal: '. implode("\n", $out));
    }
}
