<?php

namespace App\Libraries;

use Picqer\Barcode\BarcodeGeneratorPNG;
use Picqer\Barcode\BarcodeGeneratorHTML;

class BarcodeService
{
    public function pngBase64(string $text, int $height = 60): string
    {
        if (! class_exists(BarcodeGeneratorPNG::class)) {
            throw new \RuntimeException('Install: composer require picqer/php-barcode-generator');
        }
        $g = new BarcodeGeneratorPNG();
        $png = $g->getBarcode($text, $g::TYPE_CODE_128, 2, $height);
        return 'data:image/png;base64,' . base64_encode($png);
    }

    public function html(string $text, int $height = 60): string
    {
        if (! class_exists(BarcodeGeneratorHTML::class)) return '<code>'.esc($text).'</code>';
        $g = new BarcodeGeneratorHTML();
        return $g->getBarcode($text, $g::TYPE_CODE_128, 2, $height);
    }
}
