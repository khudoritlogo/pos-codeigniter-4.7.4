<?php

namespace App\Libraries;

/**
 * Google Gemini API service (REST call langsung — tanpa SDK)
 * Model default: gemini-2.0-flash-exp (Gemini 3 Flash generation)
 * Docs: https://ai.google.dev/gemini-api/docs/
 */
class GeminiService
{
    protected ?string $apiKey;
    protected string $model;

    public function __construct()
    {
        $s = model('StoreSettingModel')->first() ?: [];
        $this->apiKey = $s['gemini_api_key'] ?? env('gemini.apiKey');
        $this->model  = $s['gemini_model']    ?? env('gemini.model', 'gemini-2.0-flash-exp');
    }

    /**
     * Kirim pesan chat multi-turn.
     * @param array<array{role:string,content:string}> $messages history
     * @param string $systemPrompt sistem/context
     * @return array{ok:bool,text?:string,msg?:string}
     */
    public function chat(array $messages, string $systemPrompt = ''): array
    {
        if (empty($this->apiKey)) return ['ok'=>false,'msg'=>'Gemini API Key belum di-set di Pengaturan → Integrasi'];

        $contents = [];
        foreach ($messages as $m) {
            $contents[] = [
                'role'  => $m['role'] === 'assistant' ? 'model' : 'user',
                'parts' => [['text' => $m['content']]],
            ];
        }

        $payload = [
            'contents' => $contents,
            'generationConfig' => ['temperature' => 0.4, 'maxOutputTokens' => 1024],
        ];
        if (! empty($systemPrompt)) {
            $payload['systemInstruction'] = ['parts' => [['text' => $systemPrompt]]];
        }

        $url = "https://generativelanguage.googleapis.com/v1beta/models/{$this->model}:generateContent?key={$this->apiKey}";
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 30,
        ]);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch); curl_close($ch);

        if ($resp === false) return ['ok'=>false,'msg'=>$err];
        $data = json_decode($resp, true) ?: [];
        if ($code >= 400) return ['ok'=>false,'msg'=>$data['error']['message'] ?? "HTTP $code"];

        $text = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
        return ['ok'=>true, 'text'=>$text, 'raw'=>$data];
    }
}

/**
 * Kumpulkan konteks toko dari database untuk AI Assistant.
 */
class StoreContextBuilder
{
    /** Kumpulkan snapshot data toko sebagai teks yang bisa dibaca AI */
    public function build(): string
    {
        $db = \Config\Database::connect();
        $today = date('Y-m-d');
        $monthStart = date('Y-m-01');
        $weekStart = date('Y-m-d', strtotime('monday this week'));

        // Aggregate stats
        $today_stats = $db->query("SELECT COUNT(*) c, COALESCE(SUM(total),0) o FROM sales WHERE DATE(sale_date)=? AND status='completed'",[$today])->getRow();
        $week_stats  = $db->query("SELECT COUNT(*) c, COALESCE(SUM(total),0) o FROM sales WHERE sale_date>=? AND status='completed'",[$weekStart])->getRow();
        $month_stats = $db->query("SELECT COUNT(*) c, COALESCE(SUM(total),0) o FROM sales WHERE sale_date>=? AND status='completed'",[$monthStart])->getRow();
        $profit_month = $db->query("SELECT COALESCE(SUM(profit),0) p FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE s.sale_date>=? AND s.status='completed'",[$monthStart])->getRow();

        $products_count  = $db->table('products')->where('deleted_at',null)->countAllResults();
        $customers_count = $db->table('customers')->where('deleted_at',null)->countAllResults();
        $suppliers_count = $db->table('suppliers')->where('deleted_at',null)->countAllResults();

        // Top 5 products bulan ini
        $top = $db->query("SELECT p.name, SUM(si.qty) qty, SUM(si.subtotal) rev
            FROM sale_items si JOIN sales s ON s.id=si.sale_id JOIN products p ON p.id=si.product_id
            WHERE s.sale_date>=? AND s.status='completed' GROUP BY p.id ORDER BY qty DESC LIMIT 5",[$monthStart])->getResultArray();

        // Low stock
        $low = $db->query("SELECT p.name, ps.stock, p.stock_alert FROM product_stocks ps
            JOIN products p ON p.id=ps.product_id WHERE ps.stock <= p.stock_alert ORDER BY ps.stock ASC LIMIT 10")->getResultArray();

        // Piutang & hutang
        $recv = $db->query("SELECT COUNT(*) c, COALESCE(SUM(remaining),0) t FROM receivables WHERE status IN('unpaid','partial')")->getRow();
        $pay  = $db->query("SELECT COUNT(*) c, COALESCE(SUM(remaining),0) t FROM payables WHERE status IN('unpaid','partial')")->getRow();

        // Cashier per hari ini
        $cashiers = $db->query("SELECT u.fullname, COUNT(s.id) trx, COALESCE(SUM(s.total),0) tot
            FROM sales s JOIN users u ON u.id=s.cashier_id WHERE DATE(s.sale_date)=? AND s.status='completed'
            GROUP BY u.id ORDER BY tot DESC",[$today])->getResultArray();

        $lines = [];
        $lines[] = "=== DATA TOKO REAL-TIME (".date('d M Y H:i').") ===";
        $lines[] = "Total Produk: {$products_count} · Customer: {$customers_count} · Supplier: {$suppliers_count}";
        $lines[] = "";
        $lines[] = "OMZET:";
        $lines[] = "- Hari ini ({$today}): {$today_stats->c} transaksi, Rp " . number_format($today_stats->o,0,',','.');
        $lines[] = "- Minggu ini (sejak {$weekStart}): {$week_stats->c} transaksi, Rp " . number_format($week_stats->o,0,',','.');
        $lines[] = "- Bulan ini: {$month_stats->c} transaksi, Rp " . number_format($month_stats->o,0,',','.');
        $lines[] = "- Laba kotor bulan ini: Rp " . number_format($profit_month->p,0,',','.');
        $lines[] = "";
        $lines[] = "TOP 5 PRODUK BULAN INI:";
        foreach ($top as $i=>$t) $lines[] = ($i+1).". {$t['name']} — ".(int)$t['qty']." pcs, omzet Rp ".number_format($t['rev'],0,',','.');
        $lines[] = "";
        $lines[] = "STOK KRITIS (≤ alert):";
        if (empty($low)) $lines[] = "- Tidak ada, semua stok aman.";
        foreach ($low as $l) $lines[] = "- {$l['name']}: stok {$l['stock']} (alert: {$l['stock_alert']})";
        $lines[] = "";
        $lines[] = "PIUTANG (belum lunas): {$recv->c} entry, sisa Rp ".number_format($recv->t,0,',','.');
        $lines[] = "HUTANG (belum lunas): {$pay->c} entry, sisa Rp ".number_format($pay->t,0,',','.');
        $lines[] = "";
        $lines[] = "KINERJA KASIR HARI INI:";
        if (empty($cashiers)) $lines[] = "- Belum ada transaksi";
        foreach ($cashiers as $c) $lines[] = "- {$c['fullname']}: {$c['trx']} trx, Rp ".number_format($c['tot'],0,',','.');

        return implode("\n", $lines);
    }
}
