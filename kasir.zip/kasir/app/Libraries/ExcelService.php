<?php

namespace App\Libraries;

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

/**
 * Import & Export produk via CSV / XLSX menggunakan PhpSpreadsheet
 */
class ExcelService
{
    public const HEADERS = ['barcode','sku','name','category','unit','cost_price','sell_price','wholesale_price','min_wholesale_qty','stock_alert','has_serial_number','has_expired_date','warranty_months'];

    /** Template kosong untuk didownload */
    public function buildTemplate(string $format = 'xlsx'): array
    {
        if (! class_exists(Spreadsheet::class)) {
            throw new \RuntimeException('composer require phpoffice/phpspreadsheet');
        }
        $sh = new Spreadsheet();
        $ws = $sh->getActiveSheet();
        $ws->setTitle('Produk');
        foreach (self::HEADERS as $i => $h) $ws->setCellValueByColumnAndRow($i+1, 1, $h);
        // Contoh row
        $ws->fromArray([
            ['8991111','SKU-DEMO','Contoh Barang','Minuman','Pieces',5000,7500,7000,12,5,0,0,0],
        ], null, 'A2');
        // Style header
        $ws->getStyle('A1:M1')->getFont()->setBold(true);
        foreach (range('A','M') as $col) $ws->getColumnDimension($col)->setAutoSize(true);

        ob_start();
        if ($format === 'csv') {
            $writer = IOFactory::createWriter($sh, 'Csv');
            $writer->setDelimiter(',');
            $writer->save('php://output');
            return ['content'=>ob_get_clean(),'mime'=>'text/csv','filename'=>'template_produk.csv'];
        }
        (new Xlsx($sh))->save('php://output');
        return ['content'=>ob_get_clean(),'mime'=>'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','filename'=>'template_produk.xlsx'];
    }

    /**
     * Parse file upload jadi array of rows [ [barcode, sku, name, ...], ... ]
     */
    public function parseFile(string $filepath): array
    {
        $reader = IOFactory::createReaderForFile($filepath);
        $reader->setReadDataOnly(true);
        $sh = $reader->load($filepath);
        $rows = $sh->getActiveSheet()->toArray(null, true, true, false);
        if (empty($rows)) return [];
        // buang header
        array_shift($rows);
        // strip empty trailing
        return array_values(array_filter($rows, fn($r)=>! empty(array_filter($r, fn($v)=>$v!==null&&$v!==''))));
    }

    /**
     * Import ke DB. Return summary.
     */
    public function importProducts(array $rows, int $userId): array
    {
        $db = \Config\Database::connect();
        $prodModel = model('ProductModel');
        $catModel  = model('CategoryModel');
        $unitModel = model('UnitModel');

        $imported = 0; $updated = 0; $failed = 0; $errors = [];

        foreach ($rows as $idx => $r) {
            $rowNo = $idx + 2; // header di row 1
            try {
                [$barcode,$sku,$name,$catName,$unitName,$cost,$sell,$wholesale,$minWholesale,$stockAlert,$hasSN,$hasExp,$warranty] = array_pad($r, 13, null);
                if (empty($name)) throw new \Exception("Kolom 'name' kosong");

                // Kategori & satuan auto-create
                $categoryId = null;
                if (! empty($catName)) {
                    $c = $catModel->where('name', trim($catName))->first();
                    if (! $c) $categoryId = $catModel->insert(['name'=>trim($catName),'is_active'=>1], true);
                    else $categoryId = $c['id'];
                }
                $unitId = null;
                if (! empty($unitName)) {
                    $u = $unitModel->where('name', trim($unitName))->first();
                    if (! $u) $unitId = $unitModel->insert(['name'=>trim($unitName)], true);
                    else $unitId = $u['id'];
                }

                $data = [
                    'barcode'=>$barcode ?: null,'sku'=>$sku ?: null,'name'=>trim($name),
                    'category_id'=>$categoryId,'unit_id'=>$unitId,
                    'cost_price'=>(float) $cost,'sell_price'=>(float) $sell,
                    'wholesale_price'=>(float) $wholesale,'min_wholesale_qty'=>(int) $minWholesale,
                    'stock_alert'=>(int) $stockAlert,'has_serial_number'=>(int)!!$hasSN,
                    'has_expired_date'=>(int)!!$hasExp,'warranty_months'=>(int) $warranty,'is_active'=>1,
                ];

                // Cari existing by barcode/sku
                $existing = null;
                if (! empty($barcode)) $existing = $prodModel->where('barcode', $barcode)->first();
                if (! $existing && ! empty($sku)) $existing = $prodModel->where('sku', $sku)->first();
                if ($existing) { $prodModel->update($existing['id'], $data); $updated++; }
                else { $prodModel->insert($data); $imported++; }
            } catch (\Throwable $e) {
                $failed++;
                $errors[] = "Baris $rowNo: ".$e->getMessage();
            }
        }

        $db->table('product_import_logs')->insert([
            'user_id'=>$userId,'total_rows'=>count($rows),'imported'=>$imported,'updated'=>$updated,
            'failed'=>$failed,'errors'=>json_encode($errors),'created_at'=>date('Y-m-d H:i:s'),
        ]);

        return ['imported'=>$imported,'updated'=>$updated,'failed'=>$failed,'errors'=>$errors,'total'=>count($rows)];
    }
}
