<?php

namespace App\Libraries;

use App\Models\SaleModel;

class TelegramService
{
    protected ?string $token;
    protected ?string $chatId;

    public function __construct()
    {
        $settings = model('StoreSettingModel')->first();
        $this->token  = $settings['telegram_bot_token']  ?? env('telegram.botToken');
        $this->chatId = $settings['telegram_chat_id']    ?? env('telegram.chatId');
    }

    public function send(string $message, ?string $chatId = null): array
    {
        if (empty($this->token)) {
            return ['ok'=>false,'msg'=>'Telegram token belum di-set'];
        }
        $target = $chatId ?: $this->chatId;
        if (empty($target)) {
            return ['ok'=>false,'msg'=>'Chat ID kosong'];
        }
        $url = "https://api.telegram.org/bot{$this->token}/sendMessage";
        $data = http_build_query([
            'chat_id'    => $target,
            'text'       => $message,
            'parse_mode' => 'HTML',
        ]);
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 10,
        ]);
        $resp = curl_exec($ch);
        $err  = curl_error($ch);
        curl_close($ch);
        return ['ok' => $resp !== false, 'response' => $resp, 'error' => $err];
    }

    /** Kirim ringkasan omzet harian ke Owner/Super Admin */
    public function sendDailySummary(?string $date = null): array
    {
        $date = $date ?: date('Y-m-d');
        $db = \Config\Database::connect();

        $rows = $db->query("
            SELECT b.name AS branch, COUNT(s.id) AS trx,
                   COALESCE(SUM(s.total),0) AS omzet,
                   COALESCE(SUM(CASE WHEN s.payment_method='cash' THEN s.total ELSE 0 END),0) AS cash,
                   COALESCE(SUM(CASE WHEN s.payment_method='transfer' THEN s.total ELSE 0 END),0) AS transfer,
                   COALESCE(SUM(CASE WHEN s.payment_method='qris' THEN s.total ELSE 0 END),0) AS qris
            FROM branches b
            LEFT JOIN sales s ON s.branch_id=b.id AND DATE(s.sale_date)=? AND s.status='completed'
            GROUP BY b.id, b.name
        ", [$date])->getResultArray();

        $totalOmzet = array_sum(array_column($rows,'omzet'));
        $totalTrx   = array_sum(array_column($rows,'trx'));

        $profitRow = $db->query("
            SELECT COALESCE(SUM(si.profit),0) AS profit
            FROM sale_items si JOIN sales s ON s.id = si.sale_id
            WHERE DATE(s.sale_date)=? AND s.status='completed'
        ", [$date])->getRow();

        $msg  = "<b>📊 RINGKASAN OMZET HARIAN</b>\n";
        $msg .= "🗓️ Tanggal: <b>{$date}</b>\n";
        $msg .= "━━━━━━━━━━━━━━━━━━━━\n";
        foreach ($rows as $r) {
            $msg .= "🏬 <b>{$r['branch']}</b>\n";
            $msg .= "   • Transaksi: {$r['trx']}\n";
            $msg .= "   • Omzet: Rp " . number_format((float) $r['omzet'],0,',','.') . "\n";
            $msg .= "   • Cash: Rp " . number_format((float) $r['cash'],0,',','.') . "\n";
            $msg .= "   • Transfer: Rp " . number_format((float) $r['transfer'],0,',','.') . "\n";
            $msg .= "   • QRIS: Rp " . number_format((float) $r['qris'],0,',','.') . "\n\n";
        }
        $msg .= "━━━━━━━━━━━━━━━━━━━━\n";
        $msg .= "🧾 Total Transaksi: <b>{$totalTrx}</b>\n";
        $msg .= "💰 Total Omzet: <b>Rp " . number_format((float) $totalOmzet,0,',','.') . "</b>\n";
        $msg .= "📈 Laba Kotor: <b>Rp " . number_format((float) $profitRow->profit,0,',','.') . "</b>";

        return $this->send($msg);
    }
}
