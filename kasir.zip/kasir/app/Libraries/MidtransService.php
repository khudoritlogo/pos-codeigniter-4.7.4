<?php
namespace App\Libraries;

/**
 * MidtransService — integrasi Midtrans QRIS
 * Mock mode: jika server key kosong, kembalikan mock response agar flow bisa di-test
 */
class MidtransService
{
    private string $serverKey = '';
    private string $clientKey = '';
    private bool $isProduction = false;
    private bool $mockMode = false;

    public function __construct()
    {
        $this->loadSettings();
    }

    private function loadSettings(): void
    {
        try {
            $s = model('StoreSettingModel')->first();
            $this->serverKey   = $s['midtrans_server_key']  ?? '';
            $this->clientKey   = $s['midtrans_client_key']  ?? '';
            $this->isProduction = (bool)($s['midtrans_production'] ?? false);
        } catch (\Exception $e) {
            // fallback
        }
        $this->mockMode = empty($this->serverKey);
    }

    public function createQris(string $orderId, float $amount, string $customerName = 'Customer'): array
    {
        if ($this->mockMode) {
            return $this->mockCreate($orderId, $amount);
        }

        $payload = [
            'payment_type' => 'qris',
            'transaction_details' => [
                'order_id' => $orderId,
                'gross_amount' => $amount,
            ],
            'item_details' => [
                ['id' => 'item1', 'price' => $amount, 'quantity' => 1, 'name' => 'Pembayaran QRIS'],
            ],
            'customer_details' => ['name' => $customerName],
        ];

        $result = $this->postApi('/v2/charge', $payload);
        if (!($result['ok'] ?? false)) {
            return $result;
        }

        $qrData = $result['data'] ?? [];
        return [
            'ok'        => true,
            'order_id'  => $orderId,
            'qr_string' => $qrData['qr_string'] ?? null,
            'qr_url'    => $qrData['qr_url'] ?? null,
            'amount'    => $amount,
            'raw'       => $qrData,
        ];
    }

    private function mockCreate(string $orderId, float $amount): array
    {
        $qrString = 'MOCK-QRIS-' . $orderId . '-' . substr(base64_encode(random_bytes(16)), 0, 24);
        return [
            'ok'        => true,
            'order_id'  => $orderId,
            'qr_string' => $qrString,
            'qr_url'    => 'data:image/png;base64,MOCK_QR_' . substr(md5($orderId), 0, 16),
            'amount'    => $amount,
            'raw'       => [
                'transaction_id' => 'mock-' . $orderId,
                'transaction_status' => 'pending',
                'qr_string' => $qrString,
            ],
        ];
    }

    public function status(string $orderId): array
    {
        if ($this->mockMode) {
            return ['ok' => true, 'data' => [
                'transaction_id' => 'mock-' . $orderId,
                'transaction_status' => 'settlement',
                'gross_amount' => 15000,
            ]];
        }
        return $this->getApi('/v2/' . $orderId . '/status');
    }

    public function mapStatus(string $midtransStatus): string
    {
        return match ($midtransStatus) {
            'settlement', 'capture' => 'paid',
            'pending' => 'pending',
            'expire', 'expired' => 'expired',
            'cancel', 'deny', 'reject', 'failure', 'refund' => 'failed',
            default => 'unknown',
        };
    }

    public function verifyWebhook(array $payload): bool
    {
        if ($this->mockMode) return true;
        // Implementasi verifikasi signature asli di sini
        return true;
    }

    private function postApi(string $endpoint, array $payload): array
    {
        $baseUrl = $this->isProduction ? 'https://api.midtrans.com' : 'https://app.sandbox.midtrans.com';
        $url = "{$baseUrl}{$endpoint}";

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Accept: application/json',
                'Authorization: Basic ' . base64_encode($this->serverKey . ':'),
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error    = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            return ['ok' => false, 'msg' => 'Curl error: ' . $error];
        }

        if ($httpCode >= 400) {
            $body = json_decode($response, true) ?? [];
            return ['ok' => false, 'msg' => $body['status_message'] ?? "HTTP $httpCode", 'raw' => $body];
        }

        $data = json_decode($response, true) ?? [];
        return ['ok' => true, 'data' => $data];
    }

    private function getApi(string $endpoint): array
    {
        $baseUrl = $this->isProduction ? 'https://api.midtrans.com' : 'https://app.sandbox.midtrans.com';
        $url = "{$baseUrl}{$endpoint}";

        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_HTTPHEADER     => ['Authorization: Basic ' . base64_encode($this->serverKey . ':')],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false) {
            return ['ok' => false, 'msg' => 'Curl error'];
        }

        $data = json_decode($response, true) ?? [];
        return $httpCode >= 400
            ? ['ok' => false, 'msg' => $data['status_message'] ?? "HTTP $httpCode", 'data' => $data]
            : ['ok' => true, 'data' => $data];
    }
}