<?php
namespace App\Libraries;

/**
 * XenditService — integrasi Xendit QRIS
 * Mock mode: jika API key kosong, kembalikan mock response
 */
class XenditService
{
    private string $apiKey = '';
    private bool $isProduction = false;
    private bool $mockMode = false;

    public function __construct()
    {
        $this->loadSettings();
    }

    private function loadSettings(): void
    {
        try {
            $s = model('StoreSettingModel')->first();
            $this->apiKey       = $s['xendit_api_key']   ?? '';
            $this->isProduction  = (bool)($s['xendit_production'] ?? false);
        } catch (\Exception $e) {
            // fallback
        }
        $this->mockMode = empty($this->apiKey);
    }

    public function createQris(string $orderId, float $amount): array
    {
        if ($this->mockMode) {
            return $this->mockCreate($orderId, $amount);
        }

        $url = "https://qrisme-api.xendit.co/v3/quantum/";

        $payload = [
            'reference_id' => $orderId,
            'amount'       => $amount,
            'currency'     => 'IDR',
            'expiry_seconds' => 900,
            'type'         => 'DISCRETIONARY',
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'Authorization: Basic ' . base64_encode($this->apiKey . ':'),
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $response  = curl_exec($ch);
        $httpCode  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error     = curl_error($ch);
        curl_close($ch);

        if ($response === false) {
            return ['ok' => false, 'msg' => 'Curl error: ' . $error];
        }

        if ($httpCode >= 400) {
            $body = json_decode($response, true) ?? [];
            return ['ok' => false, 'msg' => $body['message'] ?? "HTTP $httpCode", 'raw' => $body];
        }

        $data = json_decode($response, true) ?? [];
        $qrString = $data['qr_string'] ?? null;
        $qrUrl    = $data['qr_url'] ?? null;

        return [
            'ok'        => true,
            'order_id'  => $orderId,
            'qr_string' => $qrString,
            'qr_url'    => $qrUrl,
            'amount'    => $amount,
            'provider'  => 'xendit',
            'raw'       => $data,
        ];
    }

    private function mockCreate(string $orderId, float $amount): array
    {
        $qrString = 'MOCK-XND-' . $orderId . '-' . substr(base64_encode(random_bytes(16)), 0, 24);
        return [
            'ok'        => true,
            'order_id'  => $orderId,
            'qr_string' => $qrString,
            'qr_url'    => 'data:image/png;base64,MOCK_XND_QR_' . substr(md5($orderId), 0, 16),
            'amount'    => $amount,
            'provider'  => 'xendit',
            'raw'       => [
                'reference_id' => $orderId,
                'status' => 'PENDING',
                'qr_string' => $qrString,
            ],
        ];
    }

    public function status(string $referenceId): array
    {
        if ($this->mockMode) {
            return ['ok' => true, 'data' => [
                'reference_id' => $referenceId,
                'status' => 'SUCCEEDED',
                'amount' => 15000,
            ]];
        }

        $url = "https://qrisme-api.xendit.co/v3/quantum/{$referenceId}";

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_HTTPHEADER => [
                'Accept: application/json',
                'Authorization: Basic ' . base64_encode($this->apiKey . ':'),
            ],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($response === false) {
            return ['ok' => false, 'msg' => 'Curl error'];
        }

        if ($httpCode >= 400) {
            return ['ok' => false, 'msg' => "HTTP $httpCode"];
        }

        $data = json_decode($response, true) ?? [];
        return ['ok' => true, 'data' => $data];
    }

    public function verifyWebhook(string $token): bool
    {
        if (empty($token)) return false;
        $signature = $_SERVER['HTTP_XENDIT_SIGNATURE'] ?? '';
        if (empty($signature)) return false;

        $body = file_get_contents('php://input');
        $expected = hash_hmac('sha256', $body, $token);
        return hash_equals($expected, $signature);
    }

    public function mapStatus(string $xenditStatus): string
    {
        return match ($xenditStatus) {
            'PAID', 'SUCCEEDED' => 'paid',
            'PENDING' => 'pending',
            'EXPIRED' => 'expired',
            'FAILED' => 'failed',
            default => 'unknown',
        };
    }
}