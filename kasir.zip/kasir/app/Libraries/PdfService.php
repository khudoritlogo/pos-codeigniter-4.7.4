<?php

namespace App\Libraries;

use Dompdf\Dompdf;
use Dompdf\Options;

class PdfService
{
    public function fromHtml(string $html, string $paper = 'A4', string $orient = 'portrait'): string
    {
        if (! class_exists(Dompdf::class)) {
            throw new \RuntimeException('Install: composer require dompdf/dompdf');
        }
        $opt = new Options();
        $opt->set('isRemoteEnabled', true);
        $opt->set('defaultFont', 'DejaVu Sans');
        $dompdf = new Dompdf($opt);
        $dompdf->loadHtml($html, 'UTF-8');
        $dompdf->setPaper($paper, $orient);
        $dompdf->render();
        return $dompdf->output();
    }

    public function fromView(string $view, array $data = [], string $paper = 'A4'): string
    {
        return $this->fromHtml(view($view, $data), $paper);
    }

    public function download(string $pdfBinary, string $filename): \CodeIgniter\HTTP\ResponseInterface
    {
        return response()
            ->setContentType('application/pdf')
            ->setHeader('Content-Disposition', 'attachment; filename="'.$filename.'"')
            ->setBody($pdfBinary);
    }

    public function inline(string $pdfBinary, string $filename): \CodeIgniter\HTTP\ResponseInterface
    {
        return response()
            ->setContentType('application/pdf')
            ->setHeader('Content-Disposition', 'inline; filename="'.$filename.'"')
            ->setBody($pdfBinary);
    }
}
