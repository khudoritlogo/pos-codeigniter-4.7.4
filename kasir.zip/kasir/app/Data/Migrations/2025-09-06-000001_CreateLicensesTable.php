<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateLicensesTable extends Migration
{
    public function up()
    {
        // Tabel licenses
        $this->forge->addField([
            'id'              => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'license_key'     => ['type' => 'VARCHAR', 'constraint' => 100, 'unique' => true],
            'status'          => ['type' => 'VARCHAR', 'constraint' => 20, 'default' => 'inactive'],
            'domain'          => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'ip_address'      => ['type' => 'VARCHAR', 'constraint' => 45, 'null' => true],
            'server_name'     => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'customer_name'   => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'customer_email'  => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'valid_until'     => ['type' => 'DATE', 'null' => true],
            'activated_at'    => ['type' => 'DATETIME', 'null' => true],
            'order_id'        => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'notes'           => ['type' => 'TEXT', 'null' => true],
            'created_at'      => ['type' => 'DATETIME', 'null' => true],
            'updated_at'      => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('licenses');

        // Tabel license_activation_logs
        $this->forge->addField([
            'id'              => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'license_id'      => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'action'          => ['type' => 'VARCHAR', 'constraint' => 50],
            'old_domain'      => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'new_domain'      => ['type' => 'VARCHAR', 'constraint' => 255, 'null' => true],
            'old_ip'          => ['type' => 'VARCHAR', 'constraint' => 45, 'null' => true],
            'new_ip'          => ['type' => 'VARCHAR', 'constraint' => 45, 'null' => true],
            'performed_by'    => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'notes'           => ['type' => 'TEXT', 'null' => true],
            'created_at'      => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('license_id', 'licenses', 'id', 'CASCADE', 'SET NULL');
        $this->forge->createTable('license_activation_logs');

        // Tabel license_notifications
        $this->forge->addField([
            'id'              => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'license_id'      => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true],
            'type'            => ['type' => 'VARCHAR', 'constraint' => 50],
            'recipient'       => ['type' => 'VARCHAR', 'constraint' => 255],
            'subject'         => ['type' => 'VARCHAR', 'constraint' => 255],
            'body'            => ['type' => 'TEXT', 'null' => true],
            'sent_at'         => ['type' => 'DATETIME', 'null' => true],
            'delivery_status' => ['type' => 'VARCHAR', 'constraint' => 20, 'default' => 'pending'],
            'error'           => ['type' => 'TEXT', 'null' => true],
            'created_at'      => ['type' => 'DATETIME', 'null' => true],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('license_id', 'licenses', 'id', 'CASCADE', 'SET NULL');
        $this->forge->createTable('license_notifications');
    }

    public function down()
    {
        $this->forge->dropTable('license_notifications');
        $this->forge->dropTable('license_activation_logs');
        $this->forge->dropTable('licenses');
    }
}
