<?php

defined('APPPATH') || define('APPPATH', realpath(rtrim(__DIR__, '\/ ')) . DIRECTORY_SEPARATOR);
defined('SYSTEMPATH') || define('SYSTEMPATH', realpath(rtrim(__DIR__ . '/../../system', '\/ ')) . DIRECTORY_SEPARATOR);
defined('ROOTPATH') || define('ROOTPATH', realpath(rtrim(__DIR__ . '/../..', '\/ ')) . DIRECTORY_SEPARATOR);
defined('WRITEPATH') || define('WRITEPATH', realpath(rtrim(__DIR__ . '/../../../writable', '\/ ')) . DIRECTORY_SEPARATOR);
defined('FCPATH') || define('FCPATH', realpath(rtrim(__DIR__ . '/../../../public', '\/ ')) . DIRECTORY_SEPARATOR);

defined('COMPOSER_PATH') || define('COMPOSER_PATH', ROOTPATH . 'vendor/autoload.php');
defined('APP_NAMESPACE') || define('APP_NAMESPACE', 'App');
defined('HOMEPATH') || define('HOMEPATH', ROOTPATH);
defined('ENVIRONMENT') || define('ENVIRONMENT', 'production');
defined('EXIT_SUCCESS') || define('EXIT_SUCCESS', 0);
defined('EXIT_ERROR') || define('EXIT_ERROR', 1);
defined('EXIT_CONFIG') || define('EXIT_CONFIG', 3);
defined('EXIT_UNKNOWN') || define('EXIT_UNKNOWN', 5);
defined('EXIT_DATABASE') || define('EXIT_DATABASE', 8);       // database error
defined('CI_DEBUG') || define('CI_DEBUG', true);
defined('LOGPATH') || define('LOGPATH', WRITEPATH . 'logs/');
