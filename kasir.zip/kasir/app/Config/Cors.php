<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

/**
 * Configuration for CORS
 */
class Cors extends BaseConfig
{
    public $enabled = false;

    /**
     * Preflight cache time in seconds
     */
    public $maxAge = 86400;

    /**
     * Allow origin (array or bool)
     */
    public $allowOrigin = ['http://localhost/kasir/'];

    /**
     * Allow methods
     */
    public $allowMethods = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'];

    /**
     * Allow headers
     */
    public $allowHeaders = ['Content-Type', 'Authorization', 'X-Requested-With'];

    /**
     * Allow credentials
     */
    public $allowCredentials = false;

    /**
     * Expose headers
     */
    public $exposeHeaders = [];
}
