<?php

namespace Config;

use CodeIgniter\Modules\Modules as BaseModules;

/**
 * Modules Configuration.
 */
class Modules extends BaseModules
{
    public $enabled = false;
    public $discoverInComposer = false;
    public $composerPackages = [];
    public $aliases = [
        'events',
        'filters',
        'registrars',
        'routes',
        'services',
    ];
}
