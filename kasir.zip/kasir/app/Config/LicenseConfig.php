<?php

namespace App\Services;

use CodeIgniter\Config\BaseConfig;

class LicenseConfig extends BaseConfig
{
    public string $ownerEmail = 'khudoritlogo@gmail.com';
    public string $webhookUrl = '';
    public bool $requireActivation = true;
    public bool $showWarningOnly = false;
    public string $devLicenseKey = '';

    public string $smtpHost = '';
    public int $smtpPort = 587;
    public string $smtpUser = '';
    public string $smtpPass = '';
    public string $smtpCrypto = 'tls';
    public string $smtpFromEmail = '';
    public string $smtpFromName = 'POS Kasir';

    public string $licenseWebhookUrl = '';
}
