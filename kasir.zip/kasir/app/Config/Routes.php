<?php

/**
 * Routes configuration.
 */

// ===========================
// PUBLIC ROUTES (no auth)
// ===========================

$routes->get('/', 'Auth::login');

// Tracking & public pages
$routes->get('v/(:segment)', 'VoucherShare::landing/$1');
$routes->get('app', 'CustomerApp::index');
$routes->get('ref/(:segment)', 'Referrals::landing/$1');
$routes->get('cfd/(:num)', 'Cfd::show/$1');

// Payment callbacks
$routes->post('telegram/webhook', 'TelegramWebhook::receive');
$routes->get('telegram/set-webhook', 'TelegramWebhook::setup');

// License Activation (public — dipanggil LicenseFilter)
$routes->get('activation', 'Activation::index');
$routes->post('activation', 'Activation::activate');
$routes->get('activation/check', 'Activation::checkStatus');
$routes->post('activation/deactivate', 'Activation::deactivate');

// ===========================
// AUTH ROUTES
// ===========================

$routes->group('auth', static function ($routes) {
    $routes->get('login', 'Auth::login');
    $routes->post('attempt', 'Auth::attempt');
    $routes->get('logout', 'Auth::logout');
    $routes->get('forgot', 'PasswordReset::forgot');
    $routes->post('forgot', 'PasswordReset::sendLink');
    $routes->get('reset/(:segment)', 'PasswordReset::form/$1');
    $routes->post('reset/(:segment)', 'PasswordReset::save/$1');
});

// ===========================
// PROTECTED ROUTES (auth filter)
// ===========================

$routes->group('', ['filter' => 'auth'], static function ($routes) {

    // ========================
    // Dashboard & Profile
    // ========================
    $routes->get('dashboard', 'Dashboard::index');
    $routes->get('profile', 'Profile::index');
    $routes->post('profile/change-password', 'Profile::changePassword');

    // ========================
    // Master Data (CRUD)
    // ========================
    $routes->resource('branches', ['controller' => 'Branches']);
    $routes->resource('users', ['controller' => 'Users']);
    $routes->resource('categories', ['controller' => 'Categories']);
    $routes->resource('units', ['controller' => 'Units']);
    $routes->resource('products', ['controller' => 'Products']);
    $routes->get('products/barcode/(:num)', 'Products::printBarcode/$1');
    $routes->resource('customers', ['controller' => 'Customers']);
    $routes->resource('suppliers', ['controller' => 'Suppliers']);
    $routes->resource('expeditions', ['controller' => 'Expeditions']);
    $routes->resource('customer-levels', ['controller' => 'CustomerLevels']);
    $routes->resource('purchases', ['controller' => 'Purchases']);

    // ========================
    // POS Sales
    // ========================
    $routes->group('sales', static function ($routes) {
        $routes->get('/', 'Sales::index');
        $routes->get('pos', 'Sales::pos');
        $routes->post('save', 'Sales::save');
        $routes->get('invoice/(:num)', 'Sales::invoice/$1');
        $routes->get('receipt/(:num)', 'Sales::receipt/$1');
        $routes->get('print/(:num)', 'Sales::printThermal/$1');
        $routes->post('void/(:num)', 'Sales::void/$1');
        $routes->get('pending', 'Sales::pending');
    });

    // ========================
    // Reports
    // ========================
    $routes->get('reports', 'Reports::index');
    $routes->get('reports/sales', 'Reports::sales');
    $routes->get('reports/cashier', 'Reports::cashier');
    $routes->get('reports/purchases', 'Reports::purchases');
    $routes->get('reports/supplier', 'Reports::supplier');
    $routes->get('reports/courier', 'Reports::courier');
    $routes->get('reports/predictive-restock', 'Reports::predictiveRestock');
    $routes->get('reports/cash-transfer', 'Reports::cashTransfer');
    $routes->get('reports/profit', 'Reports::profit');
    $routes->get('reports/top-products', 'Reports::topProducts');
    $routes->get('reports/low-stock', 'Reports::lowStock');

    // ========================
    // Referrals
    // ========================
    $routes->get('referrals', 'Referrals::index');
    $routes->get('referrals/landing/(:segment)', 'Referrals::landing/$1');

    // ========================
    // Courier / Delivery
    // ========================
    $routes->group('courier', static function ($routes) {
        $routes->get('dashboard', 'Courier::dashboard');
        $routes->get('deliveries', 'Courier::deliveries');
        $routes->get('route-planner', 'Courier::routePlanner');
    });

    // ========================
    // Accounting Module
    // ========================
    $routes->group('accounting', static function ($routes) {
        $routes->get('/', 'Accounting::dashboard');
        $routes->get('dashboard', 'Accounting::dashboard');
        $routes->get('coa', 'Accounting::coa');
        $routes->get('journal', 'Accounting::journal');
        $routes->get('ledger', 'Accounting::ledger');
        $routes->get('financial-reports', 'Accounting::financialReports');
        $routes->get('bank-reconciliation', 'Accounting::bankReconciliation');
        $routes->get('fixed-asset', 'Accounting::fixedAsset');
    });

    // ========================
    // Settings & Admin
    // ========================
    $routes->get('settings', 'Settings::index');
    $routes->get('audit-logs', 'AuditLogs::index');
    $routes->get('product-import', 'ProductImport::index');
    $routes->get('sales-payments', 'SalesPayments::index');
    $routes->get('sales-receipts', 'SalesReceipts::index');
    $routes->get('sales-quick-entry', 'SalesQuickEntry::index');
    $routes->get('scanner', 'Scanner::index');

    // Invoice PDF (cetak / download / email)
    $routes->get('invoice/pdf/(:num)', 'InvoicePdf::viewInvoice/$1');
    $routes->get('invoice/pdf/download/(:num)', 'InvoicePdf::download/$1');
    $routes->post('invoice/pdf/email/(:num)', 'InvoicePdf::email/$1');

    // ========================
    // Fitur Tambahan: Voucher, PO, Stock, Retur, Piutang/Hutang, Brands, Shifts
    // ========================
    $routes->resource('vouchers', ['controller' => 'Vouchers']);
    $routes->get('wa-broadcast', 'WaBroadcast::index');
    $routes->resource('purchase-orders', ['controller' => 'PurchaseOrders']);
    $routes->resource('stock-transfers', ['controller' => 'StockTransfers']);
    $routes->resource('stock-opnames', ['controller' => 'StockOpnames']);
    $routes->resource('sale-returns', ['controller' => 'SaleReturns']);
    $routes->resource('purchase-returns', ['controller' => 'PurchaseReturns']);
    $routes->resource('receivables', ['controller' => 'Receivables']);
    $routes->resource('payables', ['controller' => 'Payables']);
    $routes->resource('brands', ['controller' => 'Brands']);
    $routes->resource('shifts', ['controller' => 'Shifts']);

    // ========================
    // License Management
    // ========================
    $routes->get('license', 'LicenseAdmin::index');
    $routes->get('license/create', 'LicenseAdmin::create');
    $routes->post('license/store', 'LicenseAdmin::store');
    $routes->get('license/edit/(:num)', 'LicenseAdmin::edit/$1');
    $routes->post('license/update/(:num)', 'LicenseAdmin::update/$1');
    $routes->post('license/deactivate/(:num)', 'LicenseAdmin::deactivate/$1');
    $routes->get('license/logs/(:num)', 'LicenseAdmin::showActivationLogs/$1');
    $routes->get('license/notifications/(:num)', 'LicenseAdmin::showNotifications/$1');
    $routes->get('license/export', 'LicenseAdmin::exportList');
    $routes->get('license/check/(:segment)', 'LicenseAdmin::checkStatus');

    // ========================
    // AI / Recommender
    // ========================
    $routes->get('ai', 'AiAssistant::index');
    $routes->get('dashboard/tv', 'TvMode::index');
    $routes->get('recommender', 'Recommender::index');
    $routes->post('recommender/rebuild', 'Recommender::rebuild');

    // ========================
    // Franchise
    // ========================
    $routes->get('franchises', 'Franchises::index');
    $routes->get('franchises/(:num)/dashboard', 'Franchises::dashboard/$1');

    // ========================
    // Loyalty
    // ========================
    $routes->resource('loyalty-rewards', ['controller' => 'LoyaltyRewards']);

    // ========================
    // API (JSON)
    // ========================
    $routes->group('api', static function ($routes) {
        $routes->get('products/search', 'Api\ProductApi::search');
        $routes->get('products/by-barcode', 'Api\ProductApi::byBarcode');
        $routes->get('customers/search', 'Api\CustomerApi::search');
        $routes->get('couriers/available', 'Api\CourierApi::available');
        $routes->get('dashboard/stats', 'Api\DashboardApi::stats');

        // POS API endpoints
        $routes->get('pos/products', 'Api\PosApi::list');
        $routes->get('pos/search', 'Api\PosApi::search');
        $routes->get('pos/by-barcode', 'Api\PosApi::byBarcode');
        $routes->post('pos/price', 'Api\PosApi::price');
        $routes->post('pos/transaction', 'Api\PosApi::create');
    });
    // QRIS Payment
    $routes->post('qris/create', 'Qris::create');
    $routes->get('qris/check/(:segment)', 'Qris::check/$1');
    $routes->post('qris/callback', 'Qris::callback');

});

