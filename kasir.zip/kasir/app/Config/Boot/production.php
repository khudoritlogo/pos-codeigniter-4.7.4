<?php

// Production environment bootstrap - minimal setup
// Tidak ada setup khusus untuk production
