<?php

namespace App\Models;

use CodeIgniter\Model;

class FinancialPeriodModel extends Model
{
    protected $table            = 'financial_periods';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps = false;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $allowedFields = [
        'code', 'name', 'period_type', 'start_date', 'end_date',
        'is_open', 'closing_date', 'closed_by', 'notes',
    ];

    protected array $casts = [
        'is_open' => 'boolean',
    ];

    protected $validationRules = [
        'code' => 'required|min_length[3]|max_length[20]',
        'name' => 'required|min_length[3]|max_length[100]',
        'period_type' => 'required|in_list[monthly,quarterly,yearly]',
        'start_date' => 'required|valid_date[Y-m-d]',
        'end_date' => 'required|valid_date[Y-m-d]',
        'is_open' => 'permit_empty|boolean',
    ];

    protected $validationMessages = [
        'code' => [
            'required' => 'Kode periode wajib diisi',
            'min_length' => 'Kode minimal 3 karakter',
        ],
        'name' => [
            'required' => 'Nama periode wajib diisi',
        ],
    ];

    public function getActivePeriod(): ?array
    {
        return $this->where('is_open', 1)->first();
    }

    public function getOpenPeriods(): array
    {
        return $this->where('is_open', 1)->orderBy('start_date', 'ASC')->findAll();
    }

    public function closePeriod(int $periodId, int $userId, string $closedBy): bool
    {
        return $this->update($periodId, [
            'is_open'      => 0,
            'closed_by'    => $userId,
            'closing_date' => date('Y-m-d H:i:s'),
        ]);
    }
}
