<?php
namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $allowedFields    = [
        'branch_id','level_id','username','password','fullname','email','phone','whatsapp',
        'avatar','courier_status','is_active','last_login'
    ];
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';
    protected $deletedField     = 'deleted_at';

    public function authenticate(string $username): ?array
    {
        $row = $this->db->table('users u')
            ->select('u.*, l.code AS level_code, l.name AS level_name, b.name AS branch_name')
            ->join('user_levels l','l.id = u.level_id','left')
            ->join('branches b','b.id = u.branch_id','left')
            ->where('u.username', $username)
            ->where('u.deleted_at', null)
            ->get()->getRowArray();
        if ($row) {
            $branches = $this->db->table('user_branches')->where('user_id',$row['id'])->get()->getResultArray();
            $row['allowed_branch_ids'] = array_column($branches,'branch_id');
            if (empty($row['allowed_branch_ids']) && $row['branch_id']) {
                $row['allowed_branch_ids'] = [(int)$row['branch_id']];
            }
        }
        return $row ?: null;
    }

    public function withLevel()
    {
        return $this->select('users.*, user_levels.name AS level_name, user_levels.code AS level_code, branches.name AS branch_name')
            ->join('user_levels','user_levels.id = users.level_id','left')
            ->join('branches','branches.id = users.branch_id','left');
    }

    public function availableCouriers(int $branchId = null)
    {
        $b = $this->db->table('users u')
            ->select('u.id, u.fullname, u.phone, u.whatsapp, u.courier_status,
                (SELECT COUNT(*) FROM sales s WHERE s.courier_id = u.id AND s.delivery_status IN (\'pending\',\'in_progress\')) AS active_orders')
            ->join('user_levels l','l.id = u.level_id')
            ->where('l.code','kurir')
            ->where('u.is_active',1)
            ->where('u.deleted_at', null);
        if ($branchId) $b->where('u.branch_id', $branchId);
        return $b->get()->getResultArray();
    }
}
