<?php

namespace App\Models;

use CodeIgniter\Model;

/** Generic base wrapping a table with soft delete + timestamps */
abstract class BaseCrudModel extends Model
{
    protected $useAutoIncrement = true;
    protected $returnType    = 'array';
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';
}

class BranchModel extends BaseCrudModel {
    protected $table = 'branches';
    protected $useSoftDeletes = true;
    protected $allowedFields = ['code','name','address','phone','is_active'];
}
class UserLevelModel extends BaseCrudModel {
    protected $table = 'user_levels';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['code','name','permissions'];
}
class CategoryModel extends BaseCrudModel {
    protected $table = 'categories';
    protected $useSoftDeletes = true;
    protected $allowedFields = ['name','description','is_active'];
}
class UnitModel extends BaseCrudModel {
    protected $table = 'units';
    protected $useSoftDeletes = true;
    protected $allowedFields = ['name','symbol'];
}
class ExpeditionModel extends BaseCrudModel {
    protected $table = 'expeditions';
    protected $useSoftDeletes = true;
    protected $allowedFields = ['name','phone','address','is_active'];
}
class SupplierModel extends BaseCrudModel {
    protected $table = 'suppliers';
    protected $useSoftDeletes = true;
    protected $allowedFields = ['code','name','phone','email','address','is_active'];
}
class CustomerLevelModel extends BaseCrudModel {
    protected $table = 'customer_levels';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['name','discount_percent','min_point','use_wholesale_price'];
}
class CustomerModel extends BaseCrudModel {
    protected $table = 'customers';
    protected $useSoftDeletes = true;
    protected $allowedFields = ['code','name','level_id','phone','whatsapp','email','address','latitude','longitude','points','total_spent','is_active'];
    public function withLevel(){
        return $this->select('customers.*, customer_levels.name AS level_name, customer_levels.discount_percent, customer_levels.use_wholesale_price')
            ->join('customer_levels','customer_levels.id = customers.level_id','left');
    }
}
class StoreSettingModel extends BaseCrudModel {
    protected $table = 'store_settings';
    protected $useSoftDeletes = false;
    protected $allowedFields = ['branch_id','store_name','owner','address','phone','email','logo',
        'receipt_header','receipt_footer','receipt_paper_size','receipt_font_size','tax_percent','currency',
        'telegram_bot_token','telegram_chat_id','whatsapp_gateway_url','whatsapp_gateway_token',
        'google_maps_api_key','qris_static_url',
        // v2 - QRIS + SMTP
        'qris_provider','midtrans_server_key','midtrans_client_key','midtrans_mode',
        'xendit_secret_key','xendit_mode',
        'smtp_host','smtp_port','smtp_username','smtp_password','smtp_encryption','smtp_from_email','smtp_from_name',
        'gemini_api_key','gemini_model'];
}
class AuditLogModel extends BaseCrudModel {
    protected $table = 'audit_logs';
    protected $useTimestamps = false;
    protected $useSoftDeletes = false;
    protected $allowedFields = ['user_id','action','table_name','record_id','old_data','new_data','ip_address','user_agent','created_at'];
}
class StockMovementModel extends BaseCrudModel {
    protected $table = 'stock_movements';
    protected $useTimestamps = false;
    protected $useSoftDeletes = false;
    protected $allowedFields = ['product_id','branch_id','type','ref_id','qty_in','qty_out','stock_after','notes','created_at'];
}
class LoyaltyTransactionModel extends BaseCrudModel {
    protected $table = 'loyalty_transactions';
    protected $useTimestamps = false;
    protected $useSoftDeletes = false;
    protected $allowedFields = ['customer_id','sale_id','type','points','notes','created_at'];
}
class CashierShiftModel extends BaseCrudModel {
    protected $table = 'cashier_shifts';
    protected $useTimestamps = false;
    protected $useSoftDeletes = false;
    protected $allowedFields = ['user_id','branch_id','opened_at','closed_at','opening_cash','closing_cash','expected_cash','difference','total_sales','total_cash','total_transfer','total_qris','notes','status'];

    public function currentFor(int $userId): ?array {
        return $this->where(['user_id'=>$userId,'status'=>'open'])->orderBy('id','DESC')->first();
    }
}
