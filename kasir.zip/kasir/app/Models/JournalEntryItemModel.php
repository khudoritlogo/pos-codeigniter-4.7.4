<?php

namespace App\Models;

use CodeIgniter\Model;

class JournalEntryItemModel extends Model
{
    protected $table            = 'journal_entry_items';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = false;

    protected $allowedFields = [
        'entry_id', 'account_id', 'debit', 'credit',
        'description', 'reference_id', 'reference_type', 'order',
    ];

    protected array $casts = [
        'debit'  => 'float',
        'credit' => 'float',
    ];

    public function getByEntry(int $entryId): array
    {
        return $this->where('entry_id', $entryId)
                    ->orderBy('order', 'ASC')
                    ->findAll();
    }

    public function getAccountDebitCredit(int $accountId, ?int $periodId = null): array
    {
        $db = \Config\Database::connect();
        $query = $this->select('account_id, SUM(debit) AS total_debit, SUM(credit) AS total_credit')
            ->join('journal_entries je', 'je.id = journal_entry_items.entry_id')
            ->where('journal_entry_items.account_id', $accountId)
            ->where('je.status', 'posted');

        if ($periodId) {
            $query->where('je.period_id', $periodId);
        }

        $result = $query->get()->getRowArray();
        return [
            'total_debit'  => (float) ($result['total_debit'] ?? 0),
            'total_credit' => (float) ($result['total_credit'] ?? 0),
        ];
    }
}
