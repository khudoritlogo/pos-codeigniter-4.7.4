<?php

namespace App\Models;

use CodeIgniter\Model;

class LicenseModel extends Model
{
    protected $table            = 'licenses';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = false;

    protected $allowedFields = [
        'license_key', 'status', 'domain', 'ip_address',
        'activated_at', 'activated_by_ip', 'activation_meta',
        'valid_until', 'order_id', 'customer_name',
        'customer_email', 'notes',
    ];

    protected $casts = [
        'valid_until'  => 'datetime',
        'activated_at' => 'datetime',
    ];

    public function generateKey(): string
    {
        // Format: PK-XXXXX-XXXXX-XXXXX (25 karakter)
        $parts = [];
        for ($i = 0; $i < 3; $i++) {
            $parts[] = strtoupper(substr(uniqid(), -5));
        }
        return 'PK-' . implode('-', $parts);
    }

    public function findByKey(string $key): ?array
    {
        $key = strtoupper(trim($key));
        return $this->where('license_key', $key)->first();
    }

    public function isKeyValid(string $key): bool
    {
        $license = $this->findByKey($key);
        if (!$license) return false;
        if ($license['status'] !== 'active') return false;
        if ($license['valid_until'] && strtotime($license['valid_until']) < time()) return false;
        return true;
    }

    public function activate(string $key, string $domain, string $ip, array $meta = []): ?array
    {
        $key = strtoupper(trim($key));
        $license = $this->findByKey($key);
        if (!$license) return null;
        if ($license['status'] === 'active' && $license['domain'] !== $domain) {
            // Sudah aktif di domain lain
            return ['error' => 'License sudah digunakan di domain lain: ' . $license['domain']];
        }
        if ($license['status'] === 'inactive' && $license['domain'] !== $domain) {
            // Sudah pernah diactivate di domain lain — nonaktifkan dulu
            $this->update($license['id'], [
                'status'        => 'inactive',
                'domain'        => null,
                'ip_address'    => null,
                'activated_at'  => null,
            ]);
        }

        $this->update($license['id'], [
            'status'         => 'active',
            'domain'         => $domain,
            'ip_address'     => $ip,
            'activated_at'   => date('Y-m-d H:i:s'),
            'activated_by_ip'=> $ip,
            'activation_meta'=> json_encode($meta),
        ]);

        return $this->find($license['id']);
    }

    public function deactivate(int $id): bool
    {
        return $this->update($id, [
            'status'        => 'inactive',
            'domain'        => null,
            'ip_address'    => null,
            'activated_at'  => null,
            'activation_meta'=> null,
        ]);
    }

    public function getActiveLicenses(): array
    {
        return $this->where('status', 'active')
                    ->orderBy('activated_at', 'DESC')
                    ->findAll();
    }

    public function getByDomain(string $domain): ?array
    {
        return $this->where('domain', $domain)->where('status', 'active')->first();
    }

    public function getPendingActivation(): array
    {
        return $this->where('status', 'pending')
                    ->orderBy('created_at', 'DESC')
                    ->findAll();
    }
}
