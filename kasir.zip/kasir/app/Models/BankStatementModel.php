<?php

namespace App\Models;

use CodeIgniter\Model;

class BankStatementModel extends Model
{
    protected $table            = 'bank_statements';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $allowedFields = [
        'period_id', 'statement_date', 'description',
        'amount', 'type', 'balance_after', 'is_matched',
    ];

    protected $casts = [
        'amount'       => 'float',
        'balance_after'=> 'float',
        'is_matched'   => 'boolean',
    ];
}
