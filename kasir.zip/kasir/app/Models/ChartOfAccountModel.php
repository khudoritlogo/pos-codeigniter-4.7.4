<?php
namespace App\Models;

use CodeIgniter\Model;

class ChartOfAccountModel extends Model
{
    protected $table = 'chart_of_accounts';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = true;
    protected $useTimestamps = true;
    protected $dateFormat = 'datetime';
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    protected $deletedField = 'deleted_at';
    protected $allowedFields = ['code', 'name', 'account_type', 'parent_id', 'normal_balance', 'is_active', 'description'];
    
    protected array $casts = [];

    public function findByType(string $type): array
    {
        return $this->where('account_type', $type)->where('is_active', 1)->orderBy('code', 'ASC')->findAll();
    }

    public function getTree(): array
    {
        $accounts = $this->where('is_active', 1)->orderBy('code', 'ASC')->findAll();
        $roots = [];
        $map = [];
        foreach ($accounts as $a) {
            $map[$a['id']] = $a;
            $a['children'] = [];
        }
        foreach ($accounts as $a) {
            if ($a['parent_id'] && isset($map[$a['parent_id']])) {
                $map[$a['parent_id']]['children'][] = &$map[$a['id']];
            } else {
                $roots[] = &$map[$a['id']];
            }
        }
        return $roots;
    }

    public function search(string $q): array
    {
        return $this->groupStart()->like('code', $q)->orLike('name', $q)->groupEnd()->where('is_active', 1)->orderBy('code', 'ASC')->findAll();
    }

    public function getNormalBalance(string $type): string
    {
        $map = ['asset' => 'debit', 'liability' => 'credit', 'equity' => 'credit', 'income' => 'credit', 'expense' => 'debit', 'contra' => 'credit', 'memo' => 'debit'];
        return $map[$type] ?? 'debit';
    }
}
