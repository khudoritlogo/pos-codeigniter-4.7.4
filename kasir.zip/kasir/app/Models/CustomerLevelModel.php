<?php
namespace App\Models;

use CodeIgniter\Model;

class CustomerLevelModel extends Model
{
    protected $table         = 'customer_levels';
    protected $primaryKey    = 'id';
    protected $useAutoIncrement = true;
    protected $returnType    = 'array';
    protected $useTimestamps  = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $allowedFields = ['name', 'description', 'discount', 'credit_limit', 'is_active'];

    public function withCustomersCount()
    {
        return $this->select('cl.*, COUNT(c.id) AS customers_count')
                    ->from('customer_levels cl')
                    ->join('customers c', 'c.level_id = cl.id', 'left')
                    ->groupBy('cl.id');
    }
}