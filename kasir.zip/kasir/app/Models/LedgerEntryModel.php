<?php

namespace App\Models;

use CodeIgniter\Model;

class LedgerEntryModel extends Model
{
    protected $table            = 'ledger_entries';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $allowedFields = [
        'account_id', 'period_id', 'debit_total', 'credit_total',
        'balance_begin', 'balance_end', 'last_entry_id',
    ];

    protected array $casts = [
        'debit_total'   => 'float',
        'credit_total'  => 'float',
        'balance_begin' => 'float',
        'balance_end'   => 'float',
    ];

    public function getBalance(int $accountId, ?int $periodId = null): array
    {
        $account = model(ChartOfAccountModel::class)->find($accountId);
        $normal  = $account ? $account['normal_balance'] : 'debit';

        $db = \Config\Database::connect();
        $query = $db->table('ledger_entries')
            ->select('SUM(debit_total) AS total_debit, SUM(credit_total) AS total_credit')
            ->where('account_id', $accountId);

        if ($periodId) {
            $query->where('period_id', $periodId);
        }

        $row = $query->get()->getRowArray();
        $debitTotal  = (float) ($row['total_debit'] ?? 0);
        $creditTotal = (float) ($row['total_credit'] ?? 0);

        // Balance = debit - credit (signed based on normal balance)
        $rawBalance = $debitTotal - $creditTotal;
        $signedBalance = ($normal === 'debit') ? $rawBalance : -$rawBalance;

        return [
            'account_id'     => $accountId,
            'normal_balance' => $normal,
            'total_debit'    => $debitTotal,
            'total_credit'   => $creditTotal,
            'raw_balance'    => $rawBalance,
            'signed_balance' => $signedBalance,
        ];
    }

    public function getAccountBalanceHistory(int $accountId): array
    {
        return $this->select('ledger_entries.*, fp.code AS period_code, fp.name AS period_name')
            ->join('financial_periods fp', 'fp.id = ledger_entries.period_id', 'left')
            ->where('account_id', $accountId)
            ->orderBy('fp.start_date', 'DESC')
            ->findAll();
    }

    public function getBalancesForPeriod(int $periodId): array
    {
        return $this->select('ledger_entries.*, coa.code, coa.name, coa.account_type, coa.normal_balance')
            ->join('chart_of_accounts coa', 'coa.id = ledger_entries.account_id')
            ->where('period_id', $periodId)
            ->orderBy('coa.code', 'ASC')
            ->findAll();
    }

    public function recomputeLedgerForPeriod(int $periodId): bool
    {
        $db = \Config\Database::connect();

        // Hapus data lama untuk periode ini
        $db->table('ledger_entries')->where('period_id', $periodId)->delete();

        // Hitung ulang dari journal_entry_items
        $items = $db->query("
            SELECT
                jei.account_id,
                SUM(jei.debit)  AS total_debit,
                SUM(jei.credit) AS total_credit,
                MAX(je.id)      AS last_entry_id
            FROM journal_entry_items jei
            JOIN journal_entries je ON je.id = jei.entry_id
            WHERE je.status = 'posted'
              AND je.period_id = ?
            GROUP BY jei.account_id
        ", [$periodId])->getResultArray();

        $insertData = [];
        foreach ($items as $item) {
            $insertData[] = [
                'account_id'     => $item['account_id'],
                'period_id'      => $periodId,
                'debit_total'    => (float) $item['total_debit'],
                'credit_total'   => (float) $item['total_credit'],
                'balance_begin'  => 0,
                'balance_end'    => (float) $item['total_debit'] - (float) $item['total_credit'],
                'last_entry_id'  => $item['last_entry_id'],
                'updated_at'     => date('Y-m-d H:i:s'),
            ];
        }

        if (empty($insertData)) return true;

        $db->table('ledger_entries')->insertBatch($insertData);
        return true;
    }
}
