<?php
namespace App\Models;

use CodeIgniter\Model;

class LoyaltyRewardModel extends Model
{
    protected $table            = 'loyalty_rewards';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $allowedFields    = ['name','points_required','description','stock','is_active','created_at','updated_at'];
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';
}
