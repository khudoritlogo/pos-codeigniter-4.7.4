<?php
namespace App\Models;

use CodeIgniter\Model;

class CategoryModel extends Model
{
    protected $table         = 'categories';
    protected $primaryKey    = 'id';
    protected $useAutoIncrement = true;
    protected $returnType    = 'array';
    protected $useTimestamps  = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $allowedFields = ['name', 'description', 'is_active'];

    public function withProductsCount()
    {
        return $this->select('c.*, COUNT(p.id) AS products_count')
                    ->from('categories c')
                    ->join('products p', 'p.category_id = c.id', 'left')
                    ->groupBy('c.id');
    }
}
