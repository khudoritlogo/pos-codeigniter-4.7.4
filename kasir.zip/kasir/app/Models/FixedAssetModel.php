<?php

namespace App\Models;

use CodeIgniter\Model;

class FixedAssetModel extends Model
{
    protected $table            = 'fixed_asset_register';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $allowedFields = [
        'asset_code', 'name', 'category_id',
        'acquisition_date', 'acquisition_cost',
        'depreciation_method', 'useful_life_years',
        'residual_value', 'accumulated_depreciation',
        'net_book_value', 'is_depreciated',
        'disposed_at', 'disposal_value',
        'disposal_type', 'department', 'location', 'notes',
    ];

    protected array $casts = [
        'acquisition_cost'       => 'float',
        'accumulated_depreciation'=> 'float',
        'net_book_value'         => 'float',
        'residual_value'         => 'float',
        'is_depreciated'         => 'boolean',
        'disposal_value'         => 'float',
    ];

    public function getDepreciationForMonth(int $assetId, int $year, int $month): float
    {
        $asset = $this->find($assetId);
        if (!$asset || $asset['is_depreciated']) return 0;

        $cost       = (float) $asset['acquisition_cost'];
        $residual   = (float) $asset['residual_value'];
        $lifeYears  = (int) $asset['useful_life_years'] ?: 1;
        $lifeMonths = $lifeYears * 12;

        $monthlyDep = ($cost - $residual) / $lifeMonths;

        // Hitung berapa bulan sejak akuisisi
        $acqDate   = new \DateTime($asset['acquisition_date']);
        $periodEnd = new \DateTime("{$year}-{$month}-01");
        $monthsElapsed = $acqDate->diff($periodEnd)->m;

        $totalDep = $monthlyDep * max(0, $monthsElapsed);
        $maxDep   = $cost - $residual;

        return min($totalDep, $maxDep);
    }

    public function calculateNetBookValue(int $assetId): float
    {
        $asset = $this->find($assetId);
        if (!$asset) return 0;

        return (float) $asset['acquisition_cost']
            - (float) $asset['accumulated_depreciation'];
    }
}
