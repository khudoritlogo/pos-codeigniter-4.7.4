<?php
namespace App\Models;

use CodeIgniter\Model;

class ExpeditionModel extends Model
{
    protected $table         = 'expeditions';
    protected $primaryKey    = 'id';
    protected $useAutoIncrement = true;
    protected $returnType    = 'array';
    protected $useTimestamps  = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $allowedFields = ['name', 'phone', 'address', 'is_active'];
    protected $softDelete     = true;
    protected $deleteField    = 'deleted_at';

    public function withCount()
    {
        return $this->select('e.*, COUNT(s.id) AS shipments_count')
                    ->from('expeditions e')
                    ->join('sales s', 's.expedition_id = e.id', 'left')
                    ->groupBy('e.id');
    }
}