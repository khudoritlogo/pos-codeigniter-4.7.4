<?php
namespace App\Models;

use CodeIgniter\Model;

class ProductUnitModel extends Model
{
    protected $table         = 'product_units';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps  = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $allowedFields = [
        'product_id', 'unit_id', 'conversion_factor',
        'is_primary', 'buy_price', 'sell_price',
        'barcode', 'notes'
    ];

    /**
     * Ambil semua satuan untuk produk tertentu
     */
    public function getByProduct(int $productId): array
    {
        return $this->select('pu.*, u.name AS unit_name, u.code AS unit_code')
            ->from('product_units pu')
            ->join('units u', 'u.id = pu.unit_id')
            ->where('pu.product_id', $productId)
            ->orderBy('pu.is_primary', 'DESC')
            ->get()->getResultArray();
    }

    /**
     * Satuan utama produk
     */
    public function getPrimaryUnit(int $productId): ?array
    {
        return $this->select('pu.*, u.name AS unit_name, u.code AS unit_code')
            ->from('product_units pu')
            ->join('units u', 'u.id = pu.unit_id')
            ->where('pu.product_id', $productId)
            ->where('pu.is_primary', 1)
            ->get()->getRowArray();
    }

    /**
     * Konversi stok dari satuan ke satuan utama
     * Contoh: 2 Dus × 40 = 80 PCS
     */
    public function convertToPrimary(int $productId, int $unitId, float $qty): float
    {
        $row = $this->where('product_id', $productId)
            ->where('unit_id', $unitId)
            ->get()->getRowArray();

        if (!$row) {
            return $qty;
        }

        return $qty * (float) ($row['conversion_factor'] ?? 1);
    }

    /**
     * Konversi stok dari satuan utama ke satuan tertentu
     * Contoh: 80 PCS ÷ 40 = 2 Dus
     */
    public function convertFromPrimary(int $productId, int $unitId, float $qty): float
    {
        $row = $this->where('product_id', $productId)
            ->where('unit_id', $unitId)
            ->get()->getRowArray();

        if (!$row || !($row['conversion_factor'] ?? 1)) {
            return $qty;
        }

        return $qty / (float) ($row['conversion_factor']);
    }
}
