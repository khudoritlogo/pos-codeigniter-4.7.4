<?php

namespace App\Models;

use CodeIgniter\Model;

class LicenseNotificationModel extends Model
{
    protected $table = 'license_notifications';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $useTimestamps = false;
    protected $allowedFields = [
        'license_id', 'type', 'recipient', 'subject',
        'body', 'sent_at', 'delivery_status', 'error',
    ];
}
