<?php

namespace App\Models;

use CodeIgniter\Model;

class StoreSettingModel extends Model
{
    protected $table = 'store_settings';
    protected $primaryKey = 'id';
    protected $allowedFields = ['branch_id', 'store_name', 'owner', 'address', 'phone', 'email', 'receipt_header', 'receipt_footer', 'receipt_paper_size', 'receipt_font_size', 'currency', 'is_active', 'created_at', 'updated_at', 'deleted_at'];
    protected $useTimestamps = false;
}
