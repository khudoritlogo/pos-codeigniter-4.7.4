<?php
namespace App\Models;

use CodeIgniter\Model;

class ProductModel extends Model
{
    protected $table         = 'products';
    protected $primaryKey    = 'id';
    protected $useAutoIncrement = true;
    protected $returnType    = 'array';
    protected $useSoftDeletes = true;
    protected $useTimestamps  = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $deletedField  = 'deleted_at';
    protected $allowedFields = [
        'sku', 'barcode', 'name', 'category_id', 'unit_id',
        'cost_price', 'sell_price', 'wholesale_price', 'member_price',
        'min_wholesale_qty', 'min_stock', 'stock_alert',
        'has_serial_number', 'has_expired_date', 'warranty_months',
        'image', 'description', 'is_active',
    ];

    public function withRelations()
    {
        return $this->select('p.*, c.name AS category_name, u.name AS unit_name, u.symbol AS unit_symbol')
                    ->from('products p')
                    ->join('categories c', 'c.id = p.category_id', 'left')
                    ->join('units u', 'u.id = p.unit_id', 'left');
    }

    public function findByBarcode(string $barcode): ?array
    {
        return $this->where('barcode', $barcode)->first();
    }

    public function findBySku(string $sku): ?array
    {
        return $this->where('sku', $sku)->first();
    }

    public function search(string $keyword, ?int $branchId = null, ?int $limit = 20): array
    {
        $db = \Config\Database::connect();

        $builder = $db->table('products p')
            ->select('p.*, c.name AS category_name, u.name AS unit_name,
                (SELECT COALESCE(SUM(ps.stock),0) FROM product_stocks ps
                 WHERE ps.product_id = p.id'
                . ($branchId ? " AND ps.branch_id = $branchId" : '') . ') AS stock')
            ->join('categories c', 'c.id = p.category_id', 'left')
            ->join('units u', 'u.id = p.unit_id', 'left')
            ->groupStart()
                ->like('p.name', $keyword)
                ->orLike('p.sku', $keyword)
                ->orLike('p.barcode', $keyword)
            ->groupEnd()
            ->where('p.is_active', 1)
            ->orderBy('p.name', 'ASC')
            ->limit($limit ?? 20);

        $rows = $builder->get()->getResultArray();
        foreach ($rows as &$r) {
            $r['stock'] = (float) ($r['stock'] ?? 0);
        }
        return $rows;
    }

    public function getUnits(int $productId): array
    {
        return $this->db->table('product_units pu')
            ->select('pu.*, u.name AS unit_name, u.symbol AS unit_symbol')
            ->join('units u', 'u.id = pu.unit_id')
            ->where('pu.product_id', $productId)
            ->orderBy('pu.price', 'ASC')
            ->get()->getResultArray();
    }

    public function getPrice(int $productId, int $unitId, float $qty = 1): float
    {
        $db = \Config\Database::connect();

        // 1. Tiered price
        $tier = $db->table('product_price_tiers')
            ->select('price')
            ->where('product_id', $productId)
            ->where('min_qty <=', $qty)
            ->orderBy('min_qty', 'DESC')
            ->limit(1)
            ->get()->getRowArray();

        if ($tier && $tier['price']) {
            return (float) $tier['price'];
        }

        // 2. Harga per satuan
        $pu = $db->table('product_units')
            ->select('price')
            ->where('product_id', $productId)
            ->where('unit_id', $unitId)
            ->get()->getRowArray();

        if ($pu && $pu['price']) {
            return (float) $pu['price'];
        }

        // 3. Fallback
        $prod = $this->find($productId);
        return (float) ($prod['sell_price'] ?? 0);
    }

    public function getStock(int $productId, int $branchId): float
    {
        $row = $this->db->table('product_stocks')
            ->select('stock')
            ->where('product_id', $productId)
            ->where('branch_id', $branchId)
            ->get()->getRowArray();
        return (float) ($row['stock'] ?? 0);
    }

    public function generateSku(): string
    {
        $last = $this->select('sku')->orderBy('id', 'DESC')->get()->getRowArray();
        $num = 1;
        if ($last && preg_match('/SKU(\d+)/', $last['sku'], $m)) {
            $num = (int)$m[1] + 1;
        }
        return 'SKU' . str_pad($num, 4, '0', STR_PAD_LEFT);
    }

    public function generateBarcode(): string
    {
        $last = $this->select('barcode')->orderBy('id', 'DESC')->get()->getRowArray();
        $num = 1;
        if ($last && preg_match('/(\d+)$/', $last['barcode'], $m)) {
            $num = (int)$m[1] + 1;
        }
        return '820123456789' . str_pad($num, 3, '0', STR_PAD_LEFT);
    }

    public function lowStock(?int $branchId = null): array
    {
        $db = \Config\Database::connect();
        $q = $db->table('product_stocks ps')
            ->select('p.id, p.sku, p.name, p.stock_alert, ps.stock, b.name AS branch_name')
            ->join('products p', 'p.id = ps.product_id')
            ->join('branches b', 'b.id = ps.branch_id')
            ->where('p.is_active', 1)
            ->where('ps.stock < p.min_stock')
            ->orderBy('ps.stock', 'ASC');

        if ($branchId) {
            $q->where('ps.branch_id', $branchId);
        }

        return $q->get()->getResultArray();
    }
}