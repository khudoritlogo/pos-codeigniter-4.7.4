<?php
namespace App\Models;

use CodeIgniter\Model;

class BrandModel extends Model
{
    protected $table         = 'brands';
    protected $primaryKey    = 'id';
    protected $useAutoIncrement = true;
    protected $returnType    = 'array';
    protected $useTimestamps  = true;
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';
    protected $allowedFields = ['name', 'description', 'is_active'];

    public function withProductsCount()
    {
        return $this->select('b.*, COUNT(p.id) AS products_count')
                    ->from('brands b')
                    ->join('products p', 'p.brand_id = b.id', 'left')
                    ->groupBy('b.id');
    }
}