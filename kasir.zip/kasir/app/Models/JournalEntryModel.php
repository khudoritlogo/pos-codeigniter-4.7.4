<?php

namespace App\Models;

use CodeIgniter\Model;

class JournalEntryModel extends Model
{
    protected $table            = 'journal_entries';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    protected $allowedFields = [
        'entry_no', 'entry_date', 'period_id', 'reference',
        'description', 'entry_type', 'status', 'currency',
        'exchange_rate', 'user_id', 'branch_id',
    ];

    protected array $casts = [
        'exchange_rate' => 'float',
    ];

    public function getLastEntryNo(string $year): string
    {
        $last = $this->like('entry_no', "JE-{$year}-%")
                     ->orderBy('entry_no', 'DESC')
                     ->first();
        if ($last) {
            $num = (int) preg_replace('/^JE-\d{4}-(\d+)$/', '$1', $last['entry_no']);
            return sprintf('JE-%d-%04d', $year, $num);
        }
        return sprintf('JE-%d-%04d', $year, 1);
    }

    public function getNextEntryNo(): string
    {
        $year = date('Y');
        return $this->getLastEntryNo($year);
    }

    public function findByReference(string $refType, int $refId): array
    {
        return $this->select('je.*')
            ->join('journal_entry_items jei', 'jei.entry_id = je.id')
            ->where('jei.reference_type', $refType)
            ->where('jei.reference_id', (string) $refId)
            ->where('je.status', 'posted')
            ->findAll();
    }

    public function getDraftEntries(): array
    {
        return $this->where('status', 'draft')
                    ->orderBy('entry_date', 'DESC')
                    ->findAll();
    }

    public function getPeriodEntries(int $periodId): array
    {
        return $this->where('period_id', $periodId)
                    ->orderBy('entry_date', 'DESC')
                    ->findAll();
    }

    public function calculateBalance(): array
    {
        $db = \Config\Database::connect();
        $result = $db->query("
            SELECT SUM(CASE WHEN side = 'debit' THEN amount ELSE 0 END) AS total_debit,
                   SUM(CASE WHEN side = 'credit' THEN amount ELSE 0 END) AS total_credit
            FROM (
                SELECT 'debit' AS side, SUM(debit) AS amount FROM journal_entry_items WHERE debit > 0
                UNION ALL
                SELECT 'credit' AS side, SUM(credit) AS amount FROM journal_entry_items WHERE credit > 0
            ) AS sub
        ")->getRowArray();
        return [
            'total_debit'   => (float) ($result['total_debit'] ?? 0),
            'total_credit'  => (float) ($result['total_credit'] ?? 0),
            'is_balanced'   => abs((float)($result['total_debit'] ?? 0) - (float)($result['total_credit'] ?? 0)) < 0.01,
        ];
    }

    public function postEntry(int $entryId, int $userId): bool
    {
        // Calculate totals untuk ensure balanced
        $entry = $this->find($entryId);
        if (!$entry) return false;

        $items = $this->getItems($entryId);
        $totalDebit  = array_sum(array_column($items, 'debit'));
        $totalCredit = array_sum(array_column($items, 'credit'));

        if (abs($totalDebit - $totalCredit) > 0.01) {
            throw new \RuntimeException('Jurnal tidak seimbang: debit=' . $totalDebit . ', kredit=' . $totalCredit);
        }

        // Generate ledger entries untuk setiap akun + periode
        $periodId = $entry['period_id'] ?? null;

        // POST ke jurnal
        $this->update($entryId, ['status' => 'posted', 'updated_at' => date('Y-m-d H:i:s')]);

        if ($periodId) {
            $db = \Config\Database::connect();
            foreach ($items as $item) {
                // Insert/update ledger_entries
                $db->table('ledger_entries')->insertOrReplace([
                    'account_id'  => $item['account_id'],
                    'period_id'   => $periodId,
                    'debit_total' => $item['debit'],
                    'credit_total'=> $item['credit'],
                    'last_entry_id' => $entryId,
                    'updated_at'  => date('Y-m-d H:i:s'),
                ]);
            }
        }

        // Log audit
        $db->table('audit_logs')->insert([
            'user_id'    => $userId,
            'action'     => 'post_journal',
            'table_name' => 'journal_entries',
            'record_id'  => (string) $entryId,
            'new_data'   => json_encode(['entry_no' => $entry['entry_no']]),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return true;
    }

    public function getItems(int $entryId): array
    {
        return model(JournalEntryItemModel::class)->where('entry_id', $entryId)->findAll();
    }
}
