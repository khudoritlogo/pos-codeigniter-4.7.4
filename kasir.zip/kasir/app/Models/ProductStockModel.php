<?php
namespace App\Models;

use CodeIgniter\Model;

class ProductStockModel extends Model
{
    protected $table            = 'product_stocks';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $allowedFields    = ['product_id','branch_id','stock'];
    protected $useTimestamps    = false;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';

    public function getStock(int $productId, int $branchId): ?array
    {
        return $this->where('product_id', $productId)
            ->where('branch_id', $branchId)
            ->first();
    }

    public function adjustStock(int $productId, int $branchId, float $delta, string $type = 'manual', ?int $refId = null, string $notes = ''): bool
    {
        $stock = $this->getStock($productId, $branchId);
        $newStock = ($stock ? (float)$stock['stock'] : 0) + $delta;
        
        if ($stock) {
            return $this->update($stock['id'], ['stock' => $newStock]);
        } else {
            return $this->insert([
                'product_id' => $productId,
                'branch_id' => $branchId,
                'stock' => $newStock > 0 ? $newStock : 0,
            ], true) !== false;
        }
    }
}
