<?php

namespace App\Models;

use CodeIgniter\Model;

class LicenseActivationLogModel extends Model
{
    protected $table = 'license_logs';
    protected $primaryKey = 'id';
    protected $useAutoIncrement = true;
    protected $returnType = 'array';
    protected $useSoftDeletes = false;
    protected $useTimestamps = false;
    protected $allowedFields = [
        'license_id', 'action', 'domain', 'ip_address',
        'meta', 'notes',
    ];
}
