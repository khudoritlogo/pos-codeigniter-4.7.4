<?php
namespace App\Models;

class SaleModel
{
    protected $db;

    public function __construct()
    {
        $this->db = \Config\Database::connect();
    }

    public function generateInvoiceNo(int $branchId): string
    {
        $dateCode = date('Ymd');
        $sql = "SELECT invoice_no FROM sales WHERE branch_id = $branchId AND invoice_no LIKE '$dateCode-%' ORDER BY id DESC LIMIT 1";
        $row = $this->db->query($sql)->getRowArray();
        $seq = 1;
        if ($row) {
            $parts = explode('-', $row['invoice_no']);
            $seq = (int) end($parts) + 1;
        }
        return 'INV-' . $dateCode . '-' . str_pad($seq, 4, '0', STR_PAD_LEFT);
    }

    /**
     * Dapatkan sale dengan relasi (JOIN customers, users, expeditions, dll).
     */
    public function findWithRelations(int $id): ?array
    {
        $sql = 'SELECT s.*, c.name AS customer_name, u.fullname AS cashier_name,
                       e.name AS expedition_name, cou.fullname AS courier_name
                FROM sales s
                LEFT JOIN customers c ON c.id = s.customer_id
                LEFT JOIN users u ON u.id = s.cashier_id
                LEFT JOIN expeditions e ON e.id = s.expedition_id
                LEFT JOIN users cou ON cou.id = s.courier_id
                WHERE s.id = ' . (int)$id;

        return $this->db->query($sql)->getRowArray() ?: null;
    }

    /**
     * Dapatkan semua sales dengan relasi + filter opsional.
     */
    public function findAllWithRelations(array $wheres = []): array
    {
        $whereClauses = [];
        foreach ($wheres as $key => $val) {
            if (is_int($val)) {
                $whereClauses[] = "$key = $val";
            } else {
                $whereClauses[] = "$key = '" . $this->db->escape($val) . "'";
            }
        }
        $whereSql = $whereClauses ? ' WHERE ' . implode(' AND ', $whereClauses) : '';

        $sql = 'SELECT s.*, c.name AS customer_name, u.fullname AS cashier_name,
                       e.name AS expedition_name, cou.fullname AS courier_name
                FROM sales s
                LEFT JOIN customers c ON c.id = s.customer_id
                LEFT JOIN users u ON u.id = s.cashier_id
                LEFT JOIN expeditions e ON e.id = s.expedition_id
                LEFT JOIN users cou ON cou.id = s.courier_id
                ' . $whereSql . '
                ORDER BY s.id DESC';

        return $this->db->query($sql)->getResultArray();
    }

    /**
     * Dapatkan items untuk sale tertentu.
     */
    public function getItems(int $saleId): array
    {
        $sql = 'SELECT si.*, p.name AS product_name, p.sku, p.barcode
                FROM sale_items si
                LEFT JOIN products p ON p.id = si.product_id
                WHERE si.sale_id = ' . (int)$saleId . '
                ORDER BY si.id ASC';

        return $this->db->query($sql)->getResultArray();
    }

    /**
     * Insert sale baru (digunakan saat transaksi).
     */
    public function insert(array $data): int|string
    {
        return $this->db->table('sales')->insert($data);
    }

    /**
     * Update sale.
     */
    public function update(int $id, array $data): bool
    {
        return $this->db->table('sales')->where('id', $id)->update($data);
    }

    /**
     * Cari sale by ID (tanpa relasi).
     */
    public function find(int $id): ?array
    {
        return $this->db->table('sales')->where('id', $id)->get()->getRowArray() ?: null;
    }
}
