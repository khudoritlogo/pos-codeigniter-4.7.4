<?php

namespace App\Models;

use CodeIgniter\Model;

class VoucherModel extends Model
{
    protected $table = 'vouchers';
    protected $returnType = 'array';
    protected $useSoftDeletes = true;
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    protected $deletedField = 'deleted_at';
    protected $allowedFields = ['code','name','type','value','min_purchase','max_discount',
        'usage_limit','usage_per_customer','used_count','valid_from','valid_until',
        'applicable_customer_levels','is_active'];
}

class LoyaltyRewardModel extends Model
{
    protected $table = 'loyalty_rewards';
    protected $returnType = 'array';
    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    protected $allowedFields = ['name','description','type','points_required','discount_value','product_id','stock','image','is_active','applicable_customer_levels','tier_priority'];
}
