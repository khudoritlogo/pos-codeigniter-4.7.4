<?php
namespace App\Models;

use CodeIgniter\Model;

class CustomerModel extends Model
{
    protected $table            = 'customers';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = true;
    protected $allowedFields    = ['name','phone','email','address','city','province','postal_code','country','notes','loyalty_points','total_spent','first_purchase_date','last_purchase_date','created_at','updated_at'];
    protected $useTimestamps    = true;
    protected $dateFormat       = 'datetime';
    protected $createdField     = 'created_at';
    protected $updatedField     = 'updated_at';
    protected $deletedField     = 'deleted_at';

    public function withLevel()
    {
        return $this->select('customers.*')
            ->join('customer_levels', 'customer_levels.id = customers.level_id', 'left');
    }
}
