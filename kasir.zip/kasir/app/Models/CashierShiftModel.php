<?php
namespace App\Models;

use CodeIgniter\Model;

class CashierShiftModel extends Model
{
    protected $table = 'cashier_shifts';
    protected $primaryKey = 'id';
    protected $allowedFields = ['user_id','branch_id','opened_at','closed_at','opening_cash','closing_cash','expected_cash','difference','total_sales','total_cash','total_transfer','total_qris','notes','status'];
    protected $useTimestamps = false;
    protected $returnType = 'array';

    public function currentFor(int $userId): ?array
    {
        try {
            $now = date('Y-m-d H:i:s');
            $result = $this->db->query("
                SELECT * FROM {$this->table}
                WHERE user_id = ? AND status = 'open'
                AND opened_at <= ? AND (closed_at IS NULL OR closed_at >= ?)
                ORDER BY id DESC LIMIT 1
            ", [$userId, $now, $now])->getRowArray();
            return $result ?: null;
        } catch (\Exception $e) {
            // Fallback: query paling sederhana tanpa kolom waktu
            try {
                return $this->where('user_id', $userId)
                    ->where('status', 'open')
                    ->orderBy('id', 'DESC')
                    ->first();
            } catch (\Exception $e2) {
                // Jika semua gagal, return null
                return null;
            }
        }
    }

    public function createFor(int $userId, int $branchId = 1): array
    {
        $id = $this->insert([
            'user_id' => $userId,
            'branch_id' => $branchId,
            'status' => 'open',
            'opened_at' => date('Y-m-d H:i:s'),
            'notes' => null,
        ], true);
        return $this->find($id) ?: [];
    }
}
