<?php
namespace App\Models;

use CodeIgniter\Model;

class SaleItemModel extends Model
{
    protected $table = 'sale_items';
    protected $primaryKey = 'id';
    protected $allowedFields = ['sale_id','product_id','unit_id','serial_number','qty','unit_conversion','cost_price','price','discount_percent','discount_amount','subtotal','profit'];
    protected $useTimestamps = false;
    protected $returnType = 'array';
}
