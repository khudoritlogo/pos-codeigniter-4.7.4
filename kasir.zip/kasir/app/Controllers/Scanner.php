<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Scanner extends BaseController
{
    public function index()
    {
        return $this->view('scanner/index');
    }

    public function lookup()
    {
        return $this->view('scanner/lookup');
    }
}
