<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\FranchiseModel;

class ProductImport extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();
        
        // Ambil riwayat import
        $logs = [];
        try {
            $logs = $db->table('product_import_logs')
                ->select('product_import_logs.*, u.username AS fullname')
                ->join('users u', 'u.id = product_import_logs.user_id', 'left')
                ->orderBy('product_import_logs.created_at', 'DESC')
                ->limit(20)
                ->get()
                ->getResultArray();
        } catch (\Exception $e) {
            $logs = [];
        }
        
        return $this->view('products/import', [
            'logs' => $logs,
        ]);
    }

    public function upload()
    {
        if ($this->request->getMethod() !== 'post') {
            return redirect()->to(site_url('product-import'))->with('error', 'Metode tidak diizinkan.');
        }

        $file = $this->request->getFile('file');
        if (!$file || $file->getError() !== UPLOAD_ERR_OK) {
            return redirect()->to(site_url('product-import'))->with('error', 'File tidak valid.');
        }

        // Simpan log import (simplifikasi)
        $userId = session()->get('user_id') ?? 1;
        $db = \Config\Database::connect();
        $db->table('product_import_logs')->insert([
            'user_id' => $userId,
            'filename' => $file->getName(),
            'total_rows' => 0,
            'imported' => 0,
            'updated' => 0,
            'failed' => 0,
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to(site_url('product-import'))->with('success', 'File berhasil diunggah. Import akan diproses.');
    }

    public function template()
    {
        $format = $this->request->getGet('format') ?: 'csv';
        
        if ($format === 'xlsx') {
            // Download template XLSX (placeholder)
            return redirect()->to(site_url('product-import'))->with('info', 'Template XLSX akan tersedia segera.');
        }

        // Generate template CSV
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="template_produk.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['barcode', 'sku', 'name', 'category', 'unit', 'cost_price', 'sell_price', 
                          'wholesale_price', 'min_wholesale_qty', 'stock_alert', 'has_serial_number', 
                          'has_expired_date', 'warranty_months']);
        fputcsv($output, ['', 'SKU001', 'Contoh Produk', 'Makanan', 'pcs', '10000', '15000', 
                          '12000', '10', '5', '0', '0', '0']);
        fclose($output);
        exit;
    }
}
