<?php
namespace App\Controllers;

class Reports extends BaseController
{
    public function index()
    {
        return view('reports/index', [
            'page_title' => 'Laporan',
        ]);
    }
    
    public function purchases()
    {
        $db = \Config\Database::connect();
        $from = $this->request->getGet('from');
        $to = $this->request->getGet('to');
        
        $where = [];
        $params = [];
        
        $query = "SELECT p.*, s.name AS supplier_name, u.fullname AS buyer_name 
                  FROM purchases p 
                  JOIN suppliers s ON s.id = p.supplier_id 
                  LEFT JOIN users u ON u.id = p.user_id
                  WHERE p.deleted_at IS NULL";
        
        if ($from) {
            $where[] = "DATE(p.purchase_date) >= ?";
            $params[] = $from;
        }
        if ($to) {
            $where[] = "DATE(p.purchase_date) <= ?";
            $params[] = $to;
        }
        
        if (!empty($where)) {
            $query .= " AND " . implode(" AND ", $where);
        }
        
        $query .= " ORDER BY p.id DESC";
        
        $rows = $db->query($query, $params)->getResultArray();
        
        return view('reports/purchases', [
            'rows' => $rows,
            'from' => $from,
            'to' => $to,
            'page_title' => 'Laporan Pembelian',
        ]);
    }
    
    public function supplier()
    {
        $db = \Config\Database::connect();
        $rows = $db->query("
            SELECT s.*, COUNT(p.id) AS purchase_count, 
                   COALESCE(SUM(p.total),0) AS total_purchases
            FROM suppliers s
            LEFT JOIN purchases p ON p.supplier_id = s.id
            WHERE s.is_active = 1
            GROUP BY s.id
            ORDER BY total_purchases DESC
        ")->getResultArray();
        
        return view('reports/supplier', [
            'rows' => $rows,
            'page_title' => 'Laporan Supplier',
        ]);
    }
    
    public function predictiveRestock()
    {
        $db = \Config\Database::connect();
        
        $rows = $db->query("
            SELECT sub.id, sub.name, sub.sku, sub.stock, sub.total_sold_30d, sub.stock_minimum, sub.need_qty
            FROM (
                SELECT 
                    p.id, p.name, p.sku, 
                    COALESCE(ps.stock, 0) AS stock,
                    COALESCE(SUM(si.qty), 0) AS total_sold_30d,
                    p.min_stock AS stock_minimum,
                    (p.min_stock - COALESCE(ps.stock, 0)) AS need_qty
                FROM products p
                LEFT JOIN product_stocks ps ON ps.product_id = p.id AND ps.branch_id = 1
                LEFT JOIN sale_items si ON si.product_id = p.id
                LEFT JOIN sales s ON s.id = si.sale_id AND s.sale_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
                WHERE p.is_active = 1
                GROUP BY p.id
            ) AS sub
            WHERE sub.stock <= sub.stock_minimum OR sub.total_sold_30d > 0
            ORDER BY sub.need_qty DESC
            LIMIT 50
        ")->getResultArray();
        
        return view('reports/predictive_restock', [
            'rows' => $rows,
            'page_title' => 'Prediksi Restock',
        ]);
    }
    
    public function cashTransfer()
    {
        $db = \Config\Database::connect();
        
        // Cash on hand dari shifts
        $cashOnHand = $db->query("
            SELECT COALESCE(SUM(cs.total_cash), 0) AS total
            FROM cashier_shifts cs
            WHERE cs.status = 'open'
        ")->getRowArray();
        
        $cash_total = (float) ($cashOnHand['total'] ?? 0);
        
        // Recent transfers - check if table exists
        $tables = $db->listTables();
        if (in_array('cash_transfer', $tables)) {
            $recentTransfers = $db->query("
                SELECT ct.*, u.fullname AS transferred_by
                FROM cash_transfer ct
                LEFT JOIN users u ON u.id = ct.user_id
                ORDER BY ct.created_at DESC
                LIMIT 10
            ")->getResultArray();
        } else {
            $recentTransfers = [];
        }
        
        $totalTransfer = array_sum(array_column($recentTransfers, 'amount'));
        
        return view('reports/cash_transfer', [
            'cash_on_hand' => $cash_total,
            'recent_transfers' => $recentTransfers,
            'total_transfer' => $totalTransfer,
            'page_title' => 'Transfer Kas',
        ]);
    }

    public function topProducts()
    {
        $db = \Config\Database::connect();
        $from = $this->request->getGet('from');
        $to = $this->request->getGet('to');

        $where = [];
        $params = [];

        $query = "SELECT p.id, p.name, p.sku, p.barcode, p.sell_price,
                     COALESCE(SUM(si.qty), 0) AS qty,
                     COALESCE(SUM(si.qty * si.price), 0) AS revenue,
                     COALESCE(SUM(si.qty * (si.price - p.cost_price)), 0) AS profit
                  FROM products p
                  LEFT JOIN sale_items si ON si.product_id = p.id
                  LEFT JOIN sales s ON s.id = si.sale_id AND s.status = 'completed'
                  WHERE p.is_active = 1 AND s.sale_date IS NOT NULL";

        if ($from) {
            $where[] = "DATE(s.sale_date) >= ?";
            $params[] = $from;
        }
        if ($to) {
            $where[] = "DATE(s.sale_date) <= ?";
            $params[] = $to;
        }

        if (!empty($where)) {
            $query .= " AND " . implode(" AND ", $where);
        }

        $query .= " GROUP BY p.id ORDER BY revenue DESC LIMIT 20";

        $rows = $db->query($query, $params)->getResultArray();

        return view('reports/top_products', [
            'rows' => $rows,
            'from' => $from,
            'to' => $to,
            'page_title' => 'Barang Terlaris',
        ]);
    }

    public function lowStock()
    {
        $db = \Config\Database::connect();
        $branchId = $this->currentBranchId() ?: 1;

        $rows = $db->query("
            SELECT p.id, p.name, p.sku, p.barcode, p.stock_alert,
                   COALESCE(ps.stock, 0) AS stock,
                   b.name AS branch_name
            FROM products p
            LEFT JOIN product_stocks ps ON ps.product_id = p.id AND ps.branch_id = ?
            LEFT JOIN branches b ON b.id = ps.branch_id
            WHERE p.is_active = 1
              AND (ps.stock <= p.stock_alert OR ps.stock IS NULL)
            ORDER BY ps.stock ASC
            LIMIT 50
        ", [$branchId])->getResultArray();

        return view('reports/low_stock', [
            'rows' => $rows,
            'page_title' => 'Stok Terkecil',
        ]);
    }

    public function profit()
    {
        $db = \Config\Database::connect();
        $from = $this->request->getGet('from');
        $to = $this->request->getGet('to');

        $where = [];
        $params = [];

        $query = "SELECT
                     COALESCE(SUM(s.subtotal), 0) AS revenue,
                     COALESCE(SUM(s.total_cost), 0) AS cogs,
                     COALESCE(SUM(s.subtotal - s.total_cost), 0) AS profit
                  FROM (
                      SELECT si.qty * si.price AS subtotal,
                             si.qty * (SELECT cost_price FROM products WHERE id = si.product_id) AS total_cost
                      FROM sale_items si
                      JOIN sales s ON s.id = si.sale_id
                      WHERE s.status = 'completed' AND s.sale_date IS NOT NULL
                  ) AS s";

        if ($from) {
            $where[] = "DATE(s.sale_date) >= ?";
            $params[] = $from;
        }
        if ($to) {
            $where[] = "DATE(s.sale_date) <= ?";
            $params[] = $to;
        }

        if (!empty($where)) {
            $query = "SELECT
                         COALESCE(SUM(sub.subtotal), 0) AS revenue,
                         COALESCE(SUM(sub.total_cost), 0) AS cogs,
                         COALESCE(SUM(sub.subtotal - sub.total_cost), 0) AS profit
                       FROM (
                           SELECT si.qty * si.price AS subtotal,
                                  si.qty * (SELECT cost_price FROM products WHERE id = si.product_id) AS total_cost
                           FROM sale_items si
                           JOIN sales s ON s.id = si.sale_id
                           WHERE s.status = 'completed' AND s.sale_date IS NOT NULL";
            if (!empty($where)) {
                $query .= " AND " . implode(" AND ", $where);
            }
            $query .= " ) AS sub";
        }

        $result = $db->query($query, $params)->getRowArray();

        return view('reports/profit', [
            'row' => $result ?: ['revenue' => 0, 'cogs' => 0, 'profit' => 0],
            'from' => $from,
            'to' => $to,
            'page_title' => 'Laba Bersih',
        ]);
    }

    public function courier()
    {
        $db = \Config\Database::connect();
        $branchId = $this->currentBranchId() ?: 1;

        $rows = $db->query("
            SELECT u.fullname AS courier,
                   COUNT(s.id) AS trx,
                   SUM(CASE WHEN s.delivery_status = 'delivered' THEN 1 ELSE 0 END) AS delivered,
                   SUM(CASE WHEN s.delivery_status IN ('pending','in_transit') THEN 1 ELSE 0 END) AS pending,
                   COALESCE(SUM(s.total), 0) AS total
            FROM sales s
            LEFT JOIN users u ON u.id = s.courier_id
            WHERE s.courier_id IS NOT NULL
            GROUP BY s.courier_id
            ORDER BY total DESC
            LIMIT 50
        ")->getResultArray();

        return view('reports/courier', [
            'rows' => $rows,
            'from' => null,
            'to' => null,
            'page_title' => 'Laporan Pengiriman',
        ]);
    }
}
