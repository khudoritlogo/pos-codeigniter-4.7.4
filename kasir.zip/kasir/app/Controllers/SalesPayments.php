<?php
namespace App\Controllers;
use App\Controllers\BaseController;
class SalesPayments extends BaseController {
    public function index() {
        $db =\Config\Database::connect();
        $branchId =$this->currentBranchId() ?? 1;
        $sql ="SELECT s.*, u.fullname AS cashier_name, c.name AS customer_name, s.paid AS amount, s.payment_method
                FROM sales s LEFT JOIN users u ON u.id = s.cashier_id LEFT JOIN customers c ON c.id = s.customer_id
                WHERE s.branch_id = $branchId AND s.status = 'completed' ORDER BY s.sale_date DESC LIMIT 50";
        $payments =$db->query($sql)->getResultArray();
        $totalSql ="SELECT COALESCE(SUM(paid),0) AS total FROM sales WHERE branch_id = $branchId AND status = 'completed'";
        $totalRow =$db->query($totalSql)->getRowArray();
        return $this->view("sales/payments", ["payments" => $payments, "total_collected" => (float)($totalRow["total"] ?? 0)]);
    }
}
