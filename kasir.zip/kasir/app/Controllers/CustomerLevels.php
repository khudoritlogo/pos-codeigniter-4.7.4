<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class CustomerLevels extends BaseController
{
    public function index()
    {
        return $this->view('customer-levels/index');
    }

    public function new()
    {
        return $this->view('customer-levels/form');
    }

    public function edit($id = null)
    {
        return $this->view('customer-levels/form');
    }

    public function show($id = null)
    {
        return $this->view('customer-levels/index');
    }
}
