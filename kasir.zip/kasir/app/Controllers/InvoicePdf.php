<?php

namespace App\Controllers;

use App\Libraries\PdfService;
use App\Libraries\MailService;
use App\Models\SaleModel;

class InvoicePdf extends BaseController
{
    public function viewInvoice(int $id)
    {
        [$sale, $items] = $this->loadSale($id);
        $html = view('sales/pdf', ['sale' => $sale, 'items' => $items, 'store' => $this->data['store']]);
        $pdf  = (new PdfService())->fromHtml($html);
        return (new PdfService())->inline($pdf, 'Invoice-' . $sale['invoice_no'] . '.pdf');
    }

    public function download(int $id)
    {
        [$sale, $items] = $this->loadSale($id);
        $html = view('sales/pdf', ['sale' => $sale, 'items' => $items, 'store' => $this->data['store']]);
        $pdf  = (new PdfService())->fromHtml($html);
        return (new PdfService())->download($pdf, 'Invoice-' . $sale['invoice_no'] . '.pdf');
    }

    public function email(int $id)
    {
        $to = trim((string) $this->request->getPost('email'));
        if (! filter_var($to, FILTER_VALIDATE_EMAIL)) {
            return $this->response->setJSON(['ok' => false, 'msg' => 'Email tidak valid'])->setStatusCode(400);
        }
        [$sale, $items] = $this->loadSale($id);
        $html = view('sales/pdf', ['sale' => $sale, 'items' => $items, 'store' => $this->data['store']]);
        $pdf  = (new PdfService())->fromHtml($html);

        $body = view('sales/email_body', ['sale' => $sale, 'store' => $this->data['store']]);
        $res  = (new MailService())->send($to, 'Invoice ' . $sale['invoice_no'] . ' - ' . ($this->data['store']['store_name'] ?? ''), $body,
            [['content' => $pdf, 'name' => 'Invoice-' . $sale['invoice_no'] . '.pdf', 'mime' => 'application/pdf']]);

        $this->audit('email_invoice', 'sales', $id, null, ['to' => $to, 'ok' => $res['ok']]);
        return $this->response->setJSON($res);
    }

    protected function loadSale(int $id): array
    {
        $sale = (new SaleModel())->withRelations()->find($id);
        if (! $sale) throw new \RuntimeException('Transaksi tidak ditemukan');
        $items = model('SaleItemModel')->select('sale_items.*, p.name AS product_name, p.sku')
            ->join('products p', 'p.id = sale_items.product_id', 'left')
            ->where('sale_id', $id)->findAll();
        return [$sale, $items];
    }
}
