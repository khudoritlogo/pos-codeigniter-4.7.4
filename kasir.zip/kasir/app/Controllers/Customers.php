<?php
namespace App\Controllers;

use App\Models\CustomerModel;
use App\Models\CustomerLevelModel;

class Customers extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();
        $branchId = $this->currentBranchId();
        $q = $this->request->getGet('q') ?: '';

        $builder = $db->table('customers c')
            ->select('c.*, cl.name AS level_name')
            ->join('customer_levels cl', 'cl.id = c.level_id', 'left')
            ->groupStart()
                ->like('c.name', $q)
                ->orLike('c.phone', $q)
                ->orLike('c.email', $q)
                ->orLike('c.code', $q)
            ->groupEnd()
            ->where('c.deleted_at', null)
            ->orderBy('c.name', 'ASC')
            ->limit(50);

        // Hanya filter branch jika user bukan superadmin
        // (Tabel customers tidak memiliki kolom branch_id, jadi skip filter)
        if (!$this->isSuperAdmin() && $branchId) {
            // Kolom branch_id tidak ada di tabel customers, skip filter
        }

        $customers = $builder->get()->getResultArray();

        return $this->view('customers/index', [
            'customers' => $customers,
            'search' => $q,
        ]);
    }

    public function new()
    {
        $levels = (new CustomerLevelModel())->where('is_active', 1)->findAll();
        return $this->view('customers/form', [
            'customer' => null,
            'levels' => $levels,
            'title' => 'Tambah Pelanggan',
            'action' => site_url('customers/create'),
        ]);
    }

    public function edit(int $id = null)
    {
        $customer = (new CustomerModel())->withLevel()->find($id);
        if (!$customer) {
            return redirect()->to(site_url('customers'))->with('error', 'Pelanggan tidak ditemukan.');
        }

        $levels = (new CustomerLevelModel())->where('is_active', 1)->findAll();
        return $this->view('customers/form', [
            'customer' => $customer,
            'levels' => $levels,
            'title' => 'Edit Pelanggan',
            'action' => site_url("customers/update/$id"),
        ]);
    }

    public function create()
    {
        if (!$this->validate($this->getValidationRules())) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = $this->request->getPost();
        unset($data['code']);

        (new CustomerModel())->insert($data);
        $this->audit('create_customer', 'customers', null, null, $data);

        return redirect()->to(site_url('customers'))->with('success', 'Pelanggan berhasil ditambahkan.');
    }

    public function update(int $id = null)
    {
        $customer = (new CustomerModel())->find($id);
        if (!$customer) {
            return redirect()->to(site_url('customers'))->with('error', 'Pelanggan tidak ditemukan.');
        }

        if (!$this->validate($this->getValidationRules())) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = $this->request->getPost();
        unset($data['code']);
        unset($data['credit_limit']); // Di-handle terpisah jika perlu

        (new CustomerModel())->update($id, $data);
        $this->audit('update_customer', 'customers', $id, $customer, $data);

        return redirect()->to(site_url('customers'))->with('success', 'Pelanggan berhasil diperbarui.');
    }

    public function delete(int $id = null)
    {
        $customer = (new CustomerModel())->find($id);
        if (!$customer) {
            return redirect()->to(site_url('customers'))->with('error', 'Pelanggan tidak ditemukan.');
        }

        (new CustomerModel())->delete($id);
        $this->audit('delete_customer', 'customers', $id, $customer, null);

        return redirect()->to(site_url('customers'))->with('success', 'Pelanggan berhasil dihapus.');
    }

    private function getValidationRules(): array
    {
        return [
            'name' => 'required|min_length[3]|max_length[100]',
            'phone' => 'permit_empty|min_length[10]|max_length[20]',
            'email' => 'permit_empty|valid_email|max_length[100]',
        ];
    }
}