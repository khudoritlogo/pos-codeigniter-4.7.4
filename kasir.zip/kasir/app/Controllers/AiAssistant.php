<?php

namespace App\Controllers;

use App\Libraries\GeminiService;
use App\Libraries\StoreContextBuilder;

class AiAssistant extends BaseController
{
    public function index()
    {
        $sessions = \Config\Database::connect()->table('ai_chat_sessions')
            ->where('user_id',$this->currentUserId())->orderBy('id','DESC')->get(30)->getResultArray();
        return $this->view('ai/chat', ['sessions'=>$sessions]);
    }

    public function messages(int $sessionId)
    {
        $rows = \Config\Database::connect()->table('ai_chat_messages')
            ->where('session_id',$sessionId)->orderBy('id','ASC')->get()->getResultArray();
        return $this->response->setJSON(['ok'=>true,'messages'=>$rows]);
    }

    public function ask()
    {
        $d = $this->request->getJSON(true) ?: [];
        $question = trim((string) ($d['message'] ?? ''));
        $sessionId = (int) ($d['session_id'] ?? 0);
        if (! $question) return $this->response->setJSON(['ok'=>false,'msg'=>'Pesan kosong'])->setStatusCode(400);

        $db = \Config\Database::connect();
        // Create session kalau baru
        if (! $sessionId) {
            $db->table('ai_chat_sessions')->insert([
                'user_id'=>$this->currentUserId(),
                'title'=>mb_substr($question,0,80),
                'created_at'=>date('Y-m-d H:i:s'),'updated_at'=>date('Y-m-d H:i:s'),
            ]);
            $sessionId = $db->insertID();
        }
        // Simpan pesan user
        $db->table('ai_chat_messages')->insert([
            'session_id'=>$sessionId,'role'=>'user','content'=>$question,'created_at'=>date('Y-m-d H:i:s'),
        ]);

        // Build history (last 10 messages)
        $history = $db->table('ai_chat_messages')->where('session_id',$sessionId)
            ->orderBy('id','DESC')->get(10)->getResultArray();
        $history = array_reverse($history);
        $messages = array_map(fn($m)=>['role'=>$m['role'],'content'=>$m['content']], $history);

        // Build store context
        $context = (new StoreContextBuilder())->build();
        $systemPrompt = "Kamu adalah asisten AI untuk aplikasi POS Kasir '"
            . (($this->data['store']['store_name'] ?? 'Toko')) . "'. "
            . "Jawab pertanyaan owner/admin dengan singkat, jelas, dalam Bahasa Indonesia. "
            . "Gunakan data toko real-time di bawah ini untuk memberi jawaban akurat. "
            . "Jika data tidak cukup, katakan jujur & sarankan cara mengambil data.\n\n" . $context;

        $r = (new GeminiService())->chat($messages, $systemPrompt);
        if (! $r['ok']) return $this->response->setJSON(['ok'=>false,'msg'=>$r['msg']]);

        $answer = trim($r['text']);
        $db->table('ai_chat_messages')->insert([
            'session_id'=>$sessionId,'role'=>'assistant','content'=>$answer,'created_at'=>date('Y-m-d H:i:s'),
        ]);
        $db->table('ai_chat_sessions')->where('id',$sessionId)->update(['updated_at'=>date('Y-m-d H:i:s')]);
        return $this->response->setJSON(['ok'=>true,'answer'=>$answer,'session_id'=>$sessionId]);
    }

    public function deleteSession(int $id)
    {
        \Config\Database::connect()->table('ai_chat_sessions')
            ->where(['id'=>$id,'user_id'=>$this->currentUserId()])->delete();
        return $this->response->setJSON(['ok'=>true]);
    }
}

class Referrals extends BaseController
{
    public function index()
    {
        $config = \Config\Database::connect()->table('referral_config')->orderBy('id','DESC')->get(1)->getRowArray() ?: [];
        $events = \Config\Database::connect()->query("
            SELECT r.*, c1.name AS referrer_name, c1.referral_code, c2.name AS referee_name, s.invoice_no
            FROM referral_events r
            JOIN customers c1 ON c1.id = r.referrer_id
            JOIN customers c2 ON c2.id = r.referee_id
            LEFT JOIN sales s ON s.id = r.sale_id
            ORDER BY r.id DESC LIMIT 100
        ")->getResultArray();

        // Top referrers leaderboard
        $top = \Config\Database::connect()->query("
            SELECT c.name, c.referral_code,
                   COUNT(r.id) AS total_referral,
                   SUM(CASE WHEN r.status='rewarded' THEN 1 ELSE 0 END) AS success,
                   SUM(r.points_awarded_referrer) AS points_earned
            FROM customers c
            LEFT JOIN referral_events r ON r.referrer_id = c.id
            WHERE c.deleted_at IS NULL
            GROUP BY c.id HAVING total_referral > 0
            ORDER BY success DESC, total_referral DESC LIMIT 20
        ")->getResultArray();

        return $this->view('referral/index', ['config'=>$config,'events'=>$events,'top'=>$top]);
    }

    public function saveConfig()
    {
        $d = $this->request->getPost();
        \Config\Database::connect()->table('referral_config')->where('id',1)->update([
            'is_active'=>(int)!empty($d['is_active']),
            'points_referrer'=>(int)$d['points_referrer'],
            'points_referee'=>(int)$d['points_referee'],
            'voucher_referrer_id'=>$d['voucher_referrer_id'] ?: null,
            'min_first_purchase'=>(float)$d['min_first_purchase'],
            'expiry_days'=>(int)$d['expiry_days'],
            'updated_at'=>date('Y-m-d H:i:s'),
        ]);
        return redirect()->back()->with('success','Konfigurasi referral disimpan');
    }

    /** PUBLIC — landing page /ref/{code} */
    public function landing(string $code)
    {
        $ref = model('CustomerModel')->where('referral_code', strtoupper($code))->first();
        if (! $ref) return $this->response->setStatusCode(404)->setBody('Kode referral tidak ditemukan');
        $config = \Config\Database::connect()->table('referral_config')->orderBy('id','DESC')->get(1)->getRowArray();
        $store  = model('StoreSettingModel')->first() ?: [];
        return view('referral/landing', ['ref'=>$ref,'config'=>$config,'store'=>$store]);
    }

    /** PUBLIC — Register referee (customer baru) via referral link */
    public function register(string $code)
    {
        $ref = model('CustomerModel')->where('referral_code', strtoupper($code))->first();
        if (! $ref) return $this->response->setStatusCode(404)->setJSON(['ok'=>false]);

        $name = trim((string) $this->request->getPost('name'));
        $phone = trim((string) $this->request->getPost('phone'));
        if (! $name || ! $phone) return $this->response->setJSON(['ok'=>false,'msg'=>'Nama & HP wajib']);

        // Cek duplikat
        $existing = model('CustomerModel')->where('phone', $phone)->orWhere('whatsapp', $phone)->first();
        if ($existing) return $this->response->setJSON(['ok'=>false,'msg'=>'Nomor sudah terdaftar sebagai customer']);

        $config = \Config\Database::connect()->table('referral_config')->orderBy('id','DESC')->get(1)->getRowArray();

        $db = \Config\Database::connect();
        $db->transStart();
        $newCode = 'REF' . str_pad((string) random_int(10000,99999), 5, '0', STR_PAD_LEFT);
        $customerId = model('CustomerModel')->insert([
            'code'=>'CUS'.str_pad((string) mt_rand(100,999999),6,'0',STR_PAD_LEFT),
            'referral_code'=>$newCode,'referred_by'=>$ref['id'],
            'name'=>$name,'phone'=>$phone,'whatsapp'=>$phone,'level_id'=>1,
            'points'=>0,'is_active'=>1,
        ], true);
        // Buat pending referral event
        $db->table('referral_events')->insert([
            'referrer_id'=>$ref['id'],'referee_id'=>$customerId,
            'status'=>'pending','expires_at'=>date('Y-m-d H:i:s', strtotime('+'.(int)$config['expiry_days'].' days')),
            'created_at'=>date('Y-m-d H:i:s'),
        ]);
        $db->transComplete();
        return $this->response->setJSON(['ok'=>true,'msg'=>'Berhasil daftar! Selamat datang, cek benefit di toko.']);
    }

    /** Dipanggil dari Sales::save() saat transaksi pertama referee */
    public static function checkAndRewardOnSale(int $customerId, int $saleId, float $saleTotal): void
    {
        $db = \Config\Database::connect();
        $event = $db->table('referral_events')->where(['referee_id'=>$customerId,'status'=>'pending'])->get()->getRowArray();
        if (! $event) return;
        $config = $db->table('referral_config')->orderBy('id','DESC')->get(1)->getRowArray();
        if (! $config || ! $config['is_active']) return;
        if ($saleTotal < (float) $config['min_first_purchase']) return;
        if (strtotime($event['expires_at']) < time()) {
            $db->table('referral_events')->where('id',$event['id'])->update(['status'=>'expired']);
            return;
        }

        // Award poin
        $pointsRer = (int) $config['points_referrer'];
        $pointsRee = (int) $config['points_referee'];
        $db->table('customers')->where('id',$event['referrer_id'])->set('points','points+'.$pointsRer,false)->update();
        $db->table('customers')->where('id',$event['referee_id'])->set('points','points+'.$pointsRee,false)->update();
        $db->table('loyalty_transactions')->insert([
            'customer_id'=>$event['referrer_id'],'sale_id'=>$saleId,'type'=>'earn',
            'points'=>$pointsRer,'notes'=>'Referral bonus','created_at'=>date('Y-m-d H:i:s'),
        ]);
        $db->table('loyalty_transactions')->insert([
            'customer_id'=>$event['referee_id'],'sale_id'=>$saleId,'type'=>'earn',
            'points'=>$pointsRee,'notes'=>'Welcome bonus','created_at'=>date('Y-m-d H:i:s'),
        ]);
        $db->table('referral_events')->where('id',$event['id'])->update([
            'status'=>'rewarded','sale_id'=>$saleId,
            'points_awarded_referrer'=>$pointsRer,'points_awarded_referee'=>$pointsRee,
            'rewarded_at'=>date('Y-m-d H:i:s'),
        ]);
    }
}

class Scanner extends BaseController
{
    public function index()
    {
        return $this->view('scanner/index', ['store'=>$this->data['store'] ?? []]);
    }

    public function lookup()
    {
        $code = trim((string) $this->request->getGet('code'));
        $branchId = $this->currentBranchId() ?: 1;
        $row = \Config\Database::connect()->query("
            SELECT p.*, c.name AS category_name, u.name AS unit_name,
                   COALESCE(ps.stock,0) AS stock
            FROM products p
            LEFT JOIN categories c ON c.id = p.category_id
            LEFT JOIN units u ON u.id = p.unit_id
            LEFT JOIN product_stocks ps ON ps.product_id = p.id AND ps.branch_id = ?
            WHERE p.barcode = ? OR p.sku = ?
            LIMIT 1
        ",[$branchId, $code, $code])->getRowArray();
        if (! $row) return $this->response->setJSON(['ok'=>false,'msg'=>'Produk tidak ditemukan']);
        return $this->response->setJSON(['ok'=>true,'product'=>$row]);
    }

    public function adjustStock()
    {
        $d = $this->request->getJSON(true) ?: [];
        $productId = (int) $d['product_id'];
        $qty = (float) $d['qty'];
        $mode = $d['mode'] ?? 'set'; // 'set' atau 'delta'
        $branchId = $this->currentBranchId() ?: 1;

        $prod = model('ProductModel');
        if ($mode === 'set') {
            $current = $prod->stockAt($productId, $branchId);
            $delta = $qty - $current;
        } else {
            $delta = $qty;
        }
        $prod->adjustStock($productId, $branchId, $delta, 'adjustment', null, 'Mobile scanner adjust');
        $this->audit('mobile_stock_adjust','products',$productId,null,['delta'=>$delta,'mode'=>$mode]);
        return $this->response->setJSON(['ok'=>true,'new_stock'=>$prod->stockAt($productId,$branchId)]);
    }
}

class TvMode extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();
        $today = date('Y-m-d');
        $monthStart = date('Y-m-01');
        $branchFilter = $this->isSuperAdmin() ? '' : ' AND branch_id = ' . (int) $this->currentBranchId();

        $todayStats = $db->query("SELECT COUNT(*) c, COALESCE(SUM(total),0) o FROM sales WHERE DATE(sale_date)=? AND status='completed' $branchFilter",[$today])->getRow();
        $monthStats = $db->query("SELECT COUNT(*) c, COALESCE(SUM(total),0) o FROM sales WHERE sale_date>=? AND status='completed' $branchFilter",[$monthStart])->getRow();
        $topProducts = $db->query("SELECT p.name, SUM(si.qty) qty FROM sale_items si JOIN sales s ON s.id=si.sale_id JOIN products p ON p.id=si.product_id WHERE DATE(s.sale_date)=? AND s.status='completed' $branchFilter GROUP BY p.id ORDER BY qty DESC LIMIT 5",[$today])->getResultArray();
        $recentSales = $db->query("SELECT s.invoice_no, s.total, s.sale_date, c.name AS customer_name FROM sales s LEFT JOIN customers c ON c.id=s.customer_id WHERE s.status='completed' $branchFilter ORDER BY s.id DESC LIMIT 8")->getResultArray();

        return $this->view('dashboard/tv', [
            'todayStats'=>$todayStats,'monthStats'=>$monthStats,
            'topProducts'=>$topProducts,'recentSales'=>$recentSales,
        ]);
    }
}
