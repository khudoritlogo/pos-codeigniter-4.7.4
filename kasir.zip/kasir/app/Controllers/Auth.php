<?php

namespace App\Controllers;

use App\Models\UserModel;

class Auth extends BaseController
{
    public function login()
    {
        if (session()->get('is_logged_in')) {
            return redirect()->to(site_url('dashboard'));
        }
        return view('auth/login');
    }

    public function attempt()
    {
        $username = trim((string) $this->request->getPost('username'));
        $password = (string) $this->request->getPost('password');

        $userModel = new UserModel();
        $user = $userModel->authenticate($username);

        if (! $user || ! password_verify($password, $user['password'])) {
            return redirect()->back()->with('error', 'Username atau password salah.')->withInput();
        }
        if ((int) $user['is_active'] !== 1) {
            return redirect()->back()->with('error', 'Akun Anda tidak aktif.');
        }

        session()->set([
            'is_logged_in' => true,
            'user_id'      => $user['id'],
            'username'     => $user['username'],
            'fullname'     => $user['fullname'],
            'level_id'     => $user['level_id'],
            'level_code'   => $user['level_code'],
            'level_name'   => $user['level_name'],
            'branch_id'    => $user['branch_id'],
            'branch_name'  => $user['branch_name'],
            'allowed_branch_ids' => $user['allowed_branch_ids'] ?? [],
        ]);

        $userModel->update($user['id'], ['last_login' => date('Y-m-d H:i:s')]);

        model('AuditLogModel')->insert([
            'user_id' => $user['id'],
            'action'  => 'login',
            'ip_address' => $this->request->getIPAddress(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        // Redirect based on role
        if ($user['level_code'] === 'kurir') {
            return redirect()->to(site_url('courier/dashboard'));
        }
        return redirect()->to(site_url('dashboard'));
    }

    public function logout()
    {
        model('AuditLogModel')->insert([
            'user_id' => session()->get('user_id'),
            'action'  => 'logout',
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        session()->destroy();
        return redirect()->to(site_url('auth/login'))->with('success', 'Anda telah logout.');
    }
}
