<?php
namespace App\Controllers;

use App\Models\BrandModel;

class Brands extends BaseController
{
    public function index()
    {
        $brands = (new BrandModel())>orderBy('name', 'ASC')->findAll();
        return $this->view('brands/index', ['brands' => $brands]);
    }

    public function new()
    {
        return $this->view('brands/form', [
            'brand' => null,
            'action' => site_url('brands/create'),
            'title' => 'Tambah Merek',
        ]);
    }

    public function edit(int $id = null)
    {
        $brand = (new BrandModel())->find($id);
        if (!$brand) {
            return redirect()->to(site_url('brands'))->with('error', 'Merek tidak ditemukan.');
        }
        return $this->view('brands/form', [
            'brand' => $brand,
            'action' => site_url("brands/update/$id"),
            'title' => 'Edit Merek',
        ]);
    }

    public function create()
    {
        if (!$this->validate(['name' => 'required|min_length[2]|max_length[50]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        (new BrandModel())->insert(['name' => $this->request->getPost('name')] + ['is_active' => 1]);
        return redirect()->to(site_url('brands'))->with('success', 'Merek berhasil ditambahkan.');
    }

    public function update(int $id = null)
    {
        (new BrandModel())->update($id, ['name' => $this->request->getPost('name')]);
        return redirect()->to(site_url('brands'))->with('success', 'Merek berhasil diperbarui.');
    }

    public function delete(int $id = null)
    {
        (new BrandModel())->delete($id);
        return redirect()->to(site_url('brands'))->with('success', 'Merek berhasil dihapus.');
    }
}