<?php

namespace App\Controllers;

class Accounting extends BaseController
{
    public function index()
    {
        return view('accounting/index', [
            'page_title' => 'Modul Akuntansi',
        ]);
    }
    
    public function dashboard()
    {
        return $this->index();
    }
    
    public function coa()
    {
        $rows = \Config\Database::connect()
            ->table('chart_of_accounts')
            ->where('is_active', 1)
            ->orderBy('code')
            ->get()
            ->getResultArray();
        
        return view('accounting/coa', [
            'rows' => $rows,
            'page_title' => 'Chart of Accounts',
        ]);
    }
    
    public function journal()
    {
        $rows = \Config\Database::connect()->query("
            SELECT je.*, u.fullname AS entered_by, fp.name AS period_name
            FROM journal_entries je
            LEFT JOIN users u ON u.id = je.user_id
            LEFT JOIN financial_periods fp ON fp.id = je.period_id
            ORDER BY je.entry_date DESC
            LIMIT 100
        ")->getResultArray();
        
        return view('accounting/journal', [
            'rows' => $rows,
            'page_title' => 'Journal Entries',
        ]);
    }
    
    public function ledger()
    {
        $rows = \Config\Database::connect()->query("
            SELECT le.*, coa.code, coa.name
            FROM ledger_entries le
            JOIN chart_of_accounts coa ON coa.id = le.account_id
            ORDER BY coa.code, le.updated_at DESC
            LIMIT 100
        ")->getResultArray();
        
        return view('accounting/ledger', [
            'rows' => $rows,
            'page_title' => 'General Ledger',
        ]);
    }
    
    public function bankReconciliation()
    {
        return view('accounting/bank_rec', [
            'page_title' => 'Bank Reconciliation',
        ]);
    }
    
    public function financialReports()
    {
        $db = \Config\Database::connect();
        
        $income = $db->query("SELECT * FROM vw_income_statement LIMIT 1")->getRowArray() ?? [];
        $balance = $db->query("SELECT * FROM vw_balance_sheet LIMIT 1")->getRowArray() ?? [];
        $cashflow = $db->query("SELECT * FROM vw_cash_flow LIMIT 1")->getRowArray() ?? [];
        
        return view('accounting/financial_reports', [
            'income_statement' => $income,
            'balance_sheet' => $balance,
            'cash_flow' => $cashflow,
            'page_title' => 'Laporan Keuangan',
        ]);
    }
    
    public function fixedAsset()
    {
        return view('accounting/fixed_asset', [
            'page_title' => 'Fixed Asset Register',
        ]);
    }
}
