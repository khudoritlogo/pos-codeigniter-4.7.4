<?php

namespace App\Controllers;

use App\Libraries\BarcodeService;

class VoucherShare extends BaseController
{
    /** Halaman detail voucher untuk share (dengan QR + tombol share WA) */
    public function show(int $id)
    {
        $v = model('VoucherModel')->find($id);
        if (! $v) return redirect()->to('/vouchers');
        $bc = new BarcodeService();
        $publicUrl = site_url('v/'.strtolower($v['code']));
        return $this->view('vouchers/share', [
            'v' => $v,
            'qr_png' => $this->qrDataUri($publicUrl),
            'barcode_html' => $bc->html($v['code']),
            'public_url' => $publicUrl,
        ]);
    }

    /** Cetak QR voucher siap tempel */
    public function printQr(int $id)
    {
        $v = model('VoucherModel')->find($id);
        if (! $v) return redirect()->to('/vouchers');
        $qty = max(1, (int) $this->request->getGet('qty', 1));
        $publicUrl = site_url('v/'.strtolower($v['code']));
        return $this->view('vouchers/qr_print', [
            'v' => $v, 'qty' => $qty,
            'qr_png' => $this->qrDataUri($publicUrl),
        ]);
    }

    /** Log share action */
    public function logShare(int $id)
    {
        $channel = $this->request->getPost('channel') ?: 'link';
        $to = $this->request->getPost('to') ?: null;
        \Config\Database::connect()->table('voucher_shares')->insert([
            'voucher_id'=>$id,'channel'=>$channel,'shared_to'=>$to,
            'user_id'=>$this->currentUserId(),'created_at'=>date('Y-m-d H:i:s'),
        ]);
        return $this->response->setJSON(['ok'=>true]);
    }

    /** PUBLIC landing page /v/{code} — customer scan QR & lihat voucher */
    public function landing(string $code)
    {
        $v = model('VoucherModel')->where('code', strtoupper($code))->first();
        if (! $v) return $this->response->setStatusCode(404)->setBody('Voucher tidak ditemukan');
        $store = model('StoreSettingModel')->first() ?: [];
        return view('vouchers/landing', ['v'=>$v,'store'=>$store]);
    }

    /** Generate QR as data URI using chillerlan/php-qrcode or fallback */
    protected function qrDataUri(string $text): string
    {
        if (class_exists(\chillerlan\QRCode\QRCode::class)) {
            $opt = new \chillerlan\QRCode\QROptions([
                'outputType' => \chillerlan\QRCode\QRCode::OUTPUT_IMAGE_PNG,
                'eccLevel'   => \chillerlan\QRCode\QRCode::ECC_M,
                'scale'      => 8,
            ]);
            return (new \chillerlan\QRCode\QRCode($opt))->render($text);
        }
        // Fallback: gunakan qrserver.com (butuh internet)
        return 'https://api.qrserver.com/v1/create-qr-code/?data=' . urlencode($text) . '&size=300x300';
    }
}

class PredictiveRestock extends BaseController
{
    public function index()
    {
        $days = max(7, (int) $this->request->getGet('window', 30));  // sales window in days
        $threshold = max(1, (int) $this->request->getGet('threshold', 7)); // days until stock out

        $branchFilter = $this->isSuperAdmin() ? '' : ' AND ps.branch_id = ' . (int) $this->currentBranchId();

        $rows = \Config\Database::connect()->query("
            SELECT
              p.id, p.sku, p.name, p.stock_alert, p.min_stock,
              b.name AS branch_name, ps.branch_id, ps.stock AS current_stock,
              COALESCE(sales_data.total_qty, 0) AS sold_qty,
              COALESCE(sales_data.total_qty, 0) / ? AS avg_daily,
              CASE
                WHEN COALESCE(sales_data.total_qty, 0) = 0 THEN NULL
                ELSE ps.stock / (COALESCE(sales_data.total_qty, 0) / ?)
              END AS days_remaining,
              p.cost_price
            FROM product_stocks ps
            JOIN products p ON p.id = ps.product_id
            JOIN branches b ON b.id = ps.branch_id
            LEFT JOIN (
              SELECT si.product_id, s.branch_id, SUM(si.qty * si.unit_conversion) AS total_qty
              FROM sale_items si
              JOIN sales s ON s.id = si.sale_id
              WHERE s.sale_date >= DATE_SUB(CURDATE(), INTERVAL ? DAY) AND s.status='completed'
              GROUP BY si.product_id, s.branch_id
            ) sales_data ON sales_data.product_id = ps.product_id AND sales_data.branch_id = ps.branch_id
            WHERE p.deleted_at IS NULL AND p.is_active = 1 $branchFilter
            HAVING (days_remaining IS NOT NULL AND days_remaining <= ?) OR current_stock <= p.stock_alert
            ORDER BY days_remaining ASC, current_stock ASC
        ", [$days, $days, $days, $threshold])->getResultArray();

        return $this->view('reports/predictive_restock', [
            'rows' => $rows,
            'days' => $days,
            'threshold' => $threshold,
        ]);
    }
}

/** Kurir live tracking */
class CourierTracking extends BaseController
{
    /** Kurir kirim posisi terbaru (polling dari HP) */
    public function update()
    {
        $d = $this->request->getJSON(true) ?: $this->request->getPost();
        $userId = $this->currentUserId();
        if (session()->get('level_code') !== 'kurir' && session()->get('level_code') !== 'super_admin') {
            return $this->response->setStatusCode(403);
        }
        $lat = (float) $d['latitude'];
        $lng = (float) $d['longitude'];
        if (! $lat || ! $lng) return $this->response->setJSON(['ok'=>false,'msg'=>'invalid'])->setStatusCode(400);

        $db = \Config\Database::connect();
        $db->table('users')->where('id',$userId)->update([
            'current_lat'=>$lat,'current_lng'=>$lng,'location_updated_at'=>date('Y-m-d H:i:s'),
        ]);
        $db->table('courier_locations')->insert([
            'courier_id'=>$userId,
            'sale_id'=> $d['sale_id'] ?? null,
            'latitude'=>$lat,'longitude'=>$lng,
            'accuracy'=>$d['accuracy'] ?? null,
            'speed'=>$d['speed'] ?? null,
            'heading'=>$d['heading'] ?? null,
            'battery_level'=>$d['battery'] ?? null,
            'created_at'=>date('Y-m-d H:i:s'),
        ]);
        return $this->response->setJSON(['ok'=>true]);
    }

    /** PUBLIC endpoint - customer polling posisi kurir untuk order tertentu */
    public function trackApi(string $invoice)
    {
        $sale = \Config\Database::connect()->query("
            SELECT s.id, s.invoice_no, s.delivery_status, s.delivery_lat, s.delivery_lng,
                   s.delivery_address, k.fullname AS courier_name, k.phone AS courier_phone,
                   k.whatsapp AS courier_wa, k.current_lat, k.current_lng, k.location_updated_at
            FROM sales s LEFT JOIN users k ON k.id = s.courier_id
            WHERE s.invoice_no = ?
        ", [$invoice])->getRowArray();
        if (! $sale) return $this->response->setStatusCode(404)->setJSON(['ok'=>false]);
        return $this->response->setJSON(['ok'=>true,'sale'=>$sale]);
    }

    /** PUBLIC page - customer buka /track/{invoice_no} */
    public function trackPage(string $invoice)
    {
        $sale = \Config\Database::connect()->query("SELECT invoice_no FROM sales WHERE invoice_no=?",[$invoice])->getRowArray();
        if (! $sale) return $this->response->setStatusCode(404)->setBody('Order tidak ditemukan');
        $store = model('StoreSettingModel')->first() ?: [];
        return view('courier/track', ['invoice'=>$invoice,'store'=>$store]);
    }
}
