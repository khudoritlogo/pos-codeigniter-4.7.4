<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use CodeIgniter\HTTP\CLIRequest;
use CodeIgniter\HTTP\IncomingRequest;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use Psr\Log\LoggerInterface;

class BaseController extends Controller
{
    protected $request;
    protected $helpers = ['form', 'url', 'text', 'number', 'language'];
    protected $data = [];

    public function initController(RequestInterface $request, ResponseInterface $response, LoggerInterface $logger)
    {
        parent::initController($request, $response, $logger);

        $session = session();
        $this->data['user'] = [
            'id'         => $session->get('user_id'),
            'username'   => $session->get('username'),
            'fullname'   => $session->get('fullname'),
            'level_code' => $session->get('level_code'),
            'level_name' => $session->get('level_name'),
            'branch_id'  => $session->get('branch_id'),
            'branch_name'=> $session->get('branch_name'),
        ];

        // Load store settings once (safe guard: jika gagal, jangan crash)
        if ($session->get('is_logged_in')) {
            try {
                $settings = model('StoreSettingModel')->first();
                $this->data['store'] = $settings ?: [];
            } catch (\Exception $e) {
                $this->data['store'] = [];
            }
        }
    }

    protected function view(string $viewPath, array $data = [])
    {
        return view($viewPath, array_merge($this->data, $data));
    }

    protected function currentUserId(): ?int
    {
        return session()->get('user_id');
    }

    protected function currentBranchId(): ?int
    {
        return session()->get('branch_id');
    }

    protected function isSuperAdmin(): bool
    {
        $code = session()->get('level_code');
        // Franchise owner dianggap "super_admin" untuk cabang mereka
        return in_array($code, ['super_admin','franchise'], true);
    }

    protected function audit(string $action, string $table = null, $recordId = null, $old = null, $new = null): void
    {
        model('AuditLogModel')->insert([
            'user_id'    => $this->currentUserId(),
            'action'     => $action,
            'table_name' => $table,
            'record_id'  => $recordId,
            'old_data'   => $old ? json_encode($old) : null,
            'new_data'   => $new ? json_encode($new) : null,
            'ip_address' => $this->request->getIPAddress(),
            'user_agent' => (string) $this->request->getUserAgent(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }
}
