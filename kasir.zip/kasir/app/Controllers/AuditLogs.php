<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class AuditLogs extends BaseController
{
    public function index()
    {
        return $this->view('audit-logs/index');
    }
}
