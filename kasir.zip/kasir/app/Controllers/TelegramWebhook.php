<?php

namespace App\Controllers;

use App\Libraries\TelegramBot;
use CodeIgniter\Controller;

/** PUBLIC endpoint — dipanggil Telegram Bot API */
class TelegramWebhook extends Controller
{
    public function receive()
    {
        $body = $this->request->getBody();
        $update = json_decode($body, true) ?: [];
        log_message('info', 'Telegram Webhook: '.$body);
        (new TelegramBot())->handleUpdate($update);
        return $this->response->setJSON(['ok'=>true]);
    }

    /** Manual setup: /telegram/set-webhook?url=... (butuh login super admin) */
    public function setup()
    {
        if (session()->get('level_code') !== 'super_admin') {
            return $this->response->setStatusCode(403);
        }
        $url = $this->request->getGet('url') ?: (site_url('telegram/webhook'));
        $r = (new TelegramBot())->setWebhook($url);
        return $this->response->setJSON($r);
    }
}
