<?php
namespace App\Controllers;

use App\Models\UnitModel;

class Units extends BaseController
{
    public function index()
    {
        $units = (new UnitModel())->orderBy('name', 'ASC')->findAll();
        return $this->view('units/index', ['units' => $units]);
    }

    public function new()
    {
        return $this->view('units/form', [
            'unit' => null,
            'action' => site_url('units/create'),
            'title' => 'Tambah Satuan',
        ]);
    }

    public function edit(int $id = null)
    {
        $unit = (new UnitModel())->find($id);
        if (!$unit) {
            return redirect()->to(site_url('units'))->with('error', 'Satuan tidak ditemukan.');
        }
        return $this->view('units/form', [
            'unit' => $unit,
            'action' => site_url("units/update/$id"),
            'title' => 'Edit Satuan',
        ]);
    }

    public function create()
    {
        if (!$this->validate(['name' => 'required|min_length[2]|max_length[30]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        (new UnitModel())->insert($this->request->getPost() + ['is_active' => 1]);
        return redirect()->to(site_url('units'))->with('success', 'Satuan berhasil ditambahkan.');
    }

    public function update(int $id = null)
    {
        (new UnitModel())->update($id, $this->request->getPost());
        return redirect()->to(site_url('units'))->with('success', 'Satuan berhasil diperbarui.');
    }

    public function delete(int $id = null)
    {
        (new UnitModel())->delete($id);
        return redirect()->to(site_url('units'))->with('success', 'Satuan berhasil dihapus.');
    }
}