<?php

namespace App\Controllers;

use App\Libraries\MailService;

/**
 * Password Reset via Recovery Email (Option B)
 * Alur:
 *  1. User klik "Lupa Password?" di login -> form input username + recovery_email
 *  2. Sistem cek match + verified -> generate token 1x pakai (expired 30 menit)
 *  3. Kirim email berisi link: /auth/reset/{token}
 *  4. User klik link -> form set password baru
 *  5. Token dipakai -> update password_hash + tandai used_at
 */
class PasswordReset extends BaseController
{
    /** GET /auth/forgot — form input username + email */
    public function forgot()
    {
        if (session()->get('is_logged_in')) return redirect()->to('/dashboard');
        return view('auth/forgot');
    }

    /** POST /auth/forgot — proses & kirim email */
    public function sendLink()
    {
        $username = trim((string) $this->request->getPost('username'));
        $email    = trim((string) $this->request->getPost('email'));
        if (! $username || ! filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return redirect()->back()->with('error', 'Isi username dan email dengan benar.');
        }

        $db = \Config\Database::connect();
        $user = $db->table('users')->where('username', $username)->where('deleted_at', null)->get()->getRowArray();

        // Selalu tampilkan pesan sukses supaya tidak bocor info user mana yg terdaftar
        $genericOk = redirect()->to('/auth/forgot')->with('success',
            'Jika data cocok, link reset password telah dikirim ke email Anda. Cek inbox / spam folder.');

        if (! $user) return $genericOk;
        if (strcasecmp((string) $user['recovery_email'], $email) !== 0) return $genericOk;
        if (empty($user['recovery_email_verified_at'])) {
            return redirect()->back()->with('error', 'Recovery email belum diverifikasi. Minta admin/atasan untuk reset manual.');
        }

        // Generate token
        $token = bin2hex(random_bytes(32));
        $db->table('password_resets')->insert([
            'user_id'    => $user['id'],
            'token'      => $token,
            'expires_at' => date('Y-m-d H:i:s', strtotime('+30 minutes')),
            'ip_address' => $this->request->getIPAddress(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        // Kirim email
        $link = site_url('auth/reset/' . $token);
        $store = model('StoreSettingModel')->first() ?: [];
        $body = view('emails/reset_password', [
            'user'  => $user,
            'link'  => $link,
            'store' => $store,
        ]);
        $mail = (new MailService())->send($email, 'Reset Password — ' . ($store['store_name'] ?? 'POS Kasir'), $body);

        if (! $mail['ok']) {
            log_message('error', 'Reset password email fail: ' . $mail['msg']);
            // Tetap tampilkan generic supaya tidak bocor
        }

        model('AuditLogModel')->insert([
            'user_id'    => $user['id'],
            'action'     => 'password_reset_request',
            'ip_address' => $this->request->getIPAddress(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return $genericOk;
    }

    /** GET /auth/reset/{token} — form set password baru */
    public function form(string $token)
    {
        $reset = $this->validateToken($token);
        if (! $reset) return view('auth/reset_invalid');
        return view('auth/reset', ['token' => $token]);
    }

    /** POST /auth/reset/{token} — simpan password baru */
    public function save(string $token)
    {
        $reset = $this->validateToken($token);
        if (! $reset) return view('auth/reset_invalid');

        $pw  = (string) $this->request->getPost('password');
        $pw2 = (string) $this->request->getPost('password_confirm');
        if (strlen($pw) < 8) return redirect()->back()->with('error', 'Password minimal 8 karakter.');
        if ($pw !== $pw2)    return redirect()->back()->with('error', 'Konfirmasi password tidak sama.');
        if (! preg_match('/[A-Za-z]/', $pw) || ! preg_match('/\d/', $pw)) {
            return redirect()->back()->with('error', 'Password harus mengandung huruf dan angka.');
        }

        $db = \Config\Database::connect();
        $db->transStart();
        $db->table('users')->where('id', $reset['user_id'])->update([
            'password'   => password_hash($pw, PASSWORD_BCRYPT),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
        $db->table('password_resets')->where('id', $reset['id'])->update(['used_at' => date('Y-m-d H:i:s')]);
        // Invalidate token lain milik user ini
        $db->table('password_resets')->where('user_id', $reset['user_id'])->where('used_at', null)
            ->where('id !=', $reset['id'])
            ->update(['used_at' => date('Y-m-d H:i:s')]);
        $db->transComplete();

        model('AuditLogModel')->insert([
            'user_id'    => $reset['user_id'],
            'action'     => 'password_reset_success',
            'ip_address' => $this->request->getIPAddress(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to('/auth/login')->with('success', 'Password berhasil diubah. Silakan login.');
    }

    /** Cek token valid + not expired + not used, return row atau null */
    protected function validateToken(string $token): ?array
    {
        $db = \Config\Database::connect();
        $row = $db->table('password_resets')->where('token', $token)->get()->getRowArray();
        if (! $row) return null;
        if ($row['used_at']) return null;
        if (strtotime($row['expires_at']) < time()) return null;
        return $row;
    }
}
