<?php

namespace App\Controllers;

use App\Libraries\MailService;

/**
 * Profil Saya — user (semua level) bisa update Recovery Email + verify.
 *
 * Kolom baru di users: recovery_email, recovery_email_verified_at
 * Setiap ganti recovery_email:
 *   - Kirim link verifikasi ke email BARU (wajib klik dulu supaya jadi active)
 *   - Kirim notif info ke email LAMA (kalau ada) — cegah hijack akun
 */
class Profile extends BaseController
{
    public function index()
    {
        $userId = (int) session()->get('user_id');
        $user = model('UserModel')->find($userId);
        return view('profile/index', ['user' => $user]);
    }

    /** POST /profile/recovery-email — request update recovery email */
    public function updateRecoveryEmail()
    {
        $userId  = (int) session()->get('user_id');
        $newMail = trim((string) $this->request->getPost('recovery_email'));
        if (! filter_var($newMail, FILTER_VALIDATE_EMAIL)) {
            return redirect()->back()->with('error', 'Format email tidak valid.');
        }

        $db   = \Config\Database::connect();
        $user = $db->table('users')->where('id', $userId)->get()->getRowArray();
        if (! $user) return redirect()->to('/auth/logout');

        // Generate token verifikasi email BARU
        $token = bin2hex(random_bytes(32));
        $db->table('email_verifications')->insert([
            'user_id'    => $userId,
            'email'      => $newMail,
            'token'      => $token,
            'expires_at' => date('Y-m-d H:i:s', strtotime('+24 hours')),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        // Simpan email baru tapi belum verified
        $db->table('users')->where('id', $userId)->update([
            'recovery_email'              => $newMail,
            'recovery_email_verified_at'  => null,
            'updated_at'                  => date('Y-m-d H:i:s'),
        ]);

        // Kirim link verifikasi ke email BARU
        $link  = site_url('profile/verify-email/' . $token);
        $store = model('StoreSettingModel')->first() ?: [];
        $mail  = new MailService();
        $bodyNew = view('emails/verify_email', ['user'=>$user,'link'=>$link,'store'=>$store]);
        $mail->send($newMail, 'Verifikasi Recovery Email — ' . ($store['store_name'] ?? 'POS Kasir'), $bodyNew);

        // Kirim notifikasi ke email LAMA (kalau ada & pernah verified) — anti hijack
        if (! empty($user['recovery_email']) && ! empty($user['recovery_email_verified_at']) &&
            strcasecmp((string) $user['recovery_email'], $newMail) !== 0) {
            $bodyOld = view('emails/recovery_changed', ['user'=>$user,'newEmail'=>$newMail,'store'=>$store]);
            $mail->send($user['recovery_email'], 'Peringatan: Recovery Email Anda diubah', $bodyOld);
        }

        model('AuditLogModel')->insert([
            'user_id'    => $userId,
            'action'     => 'update_recovery_email',
            'ip_address' => $this->request->getIPAddress(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to('/profile')->with('success',
            'Link verifikasi telah dikirim ke email baru. Buka email dan klik link untuk aktivasi (berlaku 24 jam).');
    }

    /** GET /profile/verify-email/{token} */
    public function verifyEmail(string $token)
    {
        $db = \Config\Database::connect();
        $row = $db->table('email_verifications')->where('token', $token)->get()->getRowArray();
        if (! $row || $row['verified_at'] || strtotime($row['expires_at']) < time()) {
            return view('profile/verify_result', ['ok' => false]);
        }

        $db->transStart();
        $db->table('email_verifications')->where('id', $row['id'])->update(['verified_at' => date('Y-m-d H:i:s')]);
        $db->table('users')->where('id', $row['user_id'])->update([
            'recovery_email'             => $row['email'],
            'recovery_email_verified_at' => date('Y-m-d H:i:s'),
            'updated_at'                 => date('Y-m-d H:i:s'),
        ]);
        $db->transComplete();

        model('AuditLogModel')->insert([
            'user_id'    => $row['user_id'],
            'action'     => 'verify_recovery_email',
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return view('profile/verify_result', ['ok' => true, 'email' => $row['email']]);
    }

    /** POST /profile/change-password — user ganti password sendiri */
    public function changePassword()
    {
        $userId  = (int) session()->get('user_id');
        $old     = (string) $this->request->getPost('old_password');
        $new     = (string) $this->request->getPost('new_password');
        $confirm = (string) $this->request->getPost('confirm_password');

        $user = model('UserModel')->find($userId);
        if (! $user || ! password_verify($old, $user['password'])) {
            return redirect()->to('/profile')->with('error', 'Password lama salah.');
        }
        if (strlen($new) < 8) return redirect()->to('/profile')->with('error', 'Password baru minimal 8 karakter.');
        if ($new !== $confirm) return redirect()->to('/profile')->with('error', 'Konfirmasi password tidak sama.');
        if (! preg_match('/[A-Za-z]/', $new) || ! preg_match('/\d/', $new)) {
            return redirect()->to('/profile')->with('error', 'Password harus mengandung huruf dan angka.');
        }

        model('UserModel')->update($userId, [
            'password'   => password_hash($new, PASSWORD_BCRYPT),
            'updated_at' => date('Y-m-d H:i:s'),
        ]);

        model('AuditLogModel')->insert([
            'user_id'    => $userId,
            'action'     => 'change_password_self',
            'ip_address' => $this->request->getIPAddress(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to('/profile')->with('success', 'Password berhasil diubah.');
    }
}
