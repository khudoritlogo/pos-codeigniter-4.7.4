<?php
namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\ProductModel;
use App\Models\SaleModel;
use App\Models\SaleItemModel;
use CodeIgniter\HTTP\ResponseInterface;

class PosApi extends BaseController
{
    public function list()
    {
        $branchId = $this->currentBranchId() ?: 1;
        $db = \Config\Database::connect();

        $builder = $db->table('products p')
            ->select('p.*, c.name AS category_name, u.name AS unit_name, u.symbol AS unit_symbol,
                (SELECT COALESCE(SUM(ps.stock),0) FROM product_stocks ps
                 WHERE ps.product_id = p.id AND ps.branch_id = ' . (int)$branchId . ') AS stock')
            ->join('categories c', 'c.id = p.category_id', 'left')
            ->join('units u', 'u.id = p.unit_id', 'left')
            ->where('p.is_active', 1)
            ->orderBy('p.name', 'ASC');

        $products = $builder->get()->getResultArray();

        foreach ($products as &$p) {
            $p['stock'] = (float) ($p['stock'] ?? 0);
        }

        return $this->response->setJSON(['products' => $products]);
    }

    public function search()
    {
        $q = trim($this->request->getGet('q') ?? '');
        $branchId = $this->currentBranchId() ?: 1;

        if (strlen($q) < 1) {
            return $this->list();
        }

        $db = \Config\Database::connect();

        $builder = $db->table('products p')
            ->select('p.*, c.name AS category_name, u.name AS unit_name,
                (SELECT COALESCE(SUM(ps.stock),0) FROM product_stocks ps
                 WHERE ps.product_id = p.id AND ps.branch_id = ' . (int)$branchId . ') AS stock')
            ->join('categories c', 'c.id = p.category_id', 'left')
            ->join('units u', 'u.id = p.unit_id', 'left')
            ->groupStart()
                ->like('p.name', $q)
                ->orLike('p.sku', $q)
                ->orLike('p.barcode', $q)
            ->groupEnd()
            ->where('p.is_active', 1)
            ->orderBy('p.name', 'ASC')
            ->limit(30);

        $products = $builder->get()->getResultArray();

        foreach ($products as &$p) {
            $p['stock'] = (float) ($p['stock'] ?? 0);
        }

        return $this->response->setJSON(['results' => $products]);
    }

    public function byBarcode()
    {
        $barcode = trim($this->request->getGet('barcode') ?? '');
        $branchId = $this->currentBranchId() ?: 1;

        if (empty($barcode)) {
            return $this->response->setJSON(['product' => null]);
        }

        $db = \Config\Database::connect();

        $builder = $db->table('products p')
            ->select('p.*, c.name AS category_name, u.name AS unit_name,
                (SELECT COALESCE(SUM(ps.stock),0) FROM product_stocks ps
                 WHERE ps.product_id = p.id AND ps.branch_id = ' . (int)$branchId . ') AS stock')
            ->join('categories c', 'c.id = p.category_id', 'left')
            ->join('units u', 'u.id = p.unit_id', 'left')
            ->groupStart()
                ->where('p.barcode', $barcode)
                ->orWhere('p.sku', $barcode)
            ->groupEnd()
            ->where('p.is_active', 1)
            ->limit(1);

        $product = $builder->get()->getRowArray();

        if ($product) {
            $product['stock'] = (float) ($product['stock'] ?? 0);
        }

        return $this->response->setJSON(['product' => $product]);
    }

    public function price()
    {
        $payload = $this->request->getJSON(true) ?? [];
        $productId = (int) ($payload['product_id'] ?? 0);
        $unitId = (int) ($payload['unit_id'] ?? 1);
        $qty = (float) ($payload['qty'] ?? 1);

        if (!$productId) {
            return $this->response->setJSON(['price' => 0]);
        }

        $db = \Config\Database::connect();

        // 1. Cek tiered price berdasarkan qty
        $tier = $db->table('product_price_tiers')
            ->select('price')
            ->where('product_id', $productId)
            ->where('min_qty <=', $qty)
            ->orderBy('min_qty', 'DESC')
            ->limit(1)
            ->get()->getRowArray();

        if ($tier && $tier['price']) {
            return $this->response->setJSON(['price' => (float) $tier['price']]);
        }

        // 2. Harga per satuan di product_units
        $pu = $db->table('product_units')
            ->select('price')
            ->where('product_id', $productId)
            ->where('unit_id', $unitId)
            ->get()->getRowArray();

        if ($pu && $pu['price']) {
            return $this->response->setJSON(['price' => (float) $pu['price']]);
        }

        // 3. Fallback ke harga jual produk
        $product = $db->table('products')
            ->select('sell_price')
            ->where('id', $productId)
            ->get()->getRowArray();

        $price = (float) ($product['sell_price'] ?? 0);
        return $this->response->setJSON(['price' => $price]);
    }

    public function create()
    {
        $payload = $this->request->getJSON(true) ?? [];

        if (empty($payload['items'])) {
            return $this->response->setJSON(['ok' => false, 'msg' => 'Keranjang kosong'])->setStatusCode(400);
        }

        $db = \Config\Database::connect();
        $db->transStart();

        $branchId = (int) ($payload['branch_id'] ?? $this->currentBranchId() ?: 1);
        $cashierId = (int) ($payload['cashier_id'] ?? $this->currentUserId() ?? 1);
        $invoiceNo = $payload['invoice_no'] ?? $this->generateInvoice($branchId);

        $saleModel = new SaleModel();
        $itemModel = new SaleItemModel();

        // Hitung ulang semua harga dari server (anti manipulasi)
        $subtotal = 0;
        $itemsData = [];

        foreach ($payload['items'] as $item) {
            $pid = (int) ($item['product_id'] ?? 0);
            $qty = (int) ($item['qty'] ?? 1);
            $unitId = (int) ($item['unit_id'] ?? 1);

            // Hitung harga dari SERVER
            $price = $this->calculatePrice($pid, $unitId, $qty);

            $lineTotal = $price * $qty;
            $subtotal += $lineTotal;

            // Kurangi stok
            $stockRow = $db->table('product_stocks')
                ->select('stock')
                ->where('product_id', $pid)
                ->where('branch_id', $branchId)
                ->get()->getRowArray();

            $currentStock = (float) ($stockRow['stock'] ?? 0);
            $newStock = max(0, $currentStock - $qty);

            $db->table('product_stocks')
                ->where('product_id', $pid)
                ->where('branch_id', $branchId)
                ->update(['stock' => $newStock]);

            $itemsData[] = [
                'sale_id' => 0, // akan di-update setelah insert
                'product_id' => $pid,
                'qty' => $qty,
                'price' => $price,
                'subtotal' => $lineTotal,
                'unit_id' => $unitId,
            ];
        }

        $total = $subtotal;
        $paid = (float) ($payload['paid'] ?? $total);
        $change = max(0, $paid - $total);
        $paymentMethod = $payload['payment_method'] ?? 'cash';

        $saleId = $saleModel->insert([
            'invoice_no' => $invoiceNo,
            'branch_id' => $branchId,
            'cashier_id' => $cashierId,
            'sale_date' => date('Y-m-d H:i:s'),
            'subtotal' => $subtotal,
            'total' => $total,
            'paid' => $paid,
            'change' => $change,
            'payment_method' => $paymentMethod,
            'status' => 'completed',
        ]);

        // Update sale_id di setiap item
        foreach ($itemsData as $item) {
            $item['sale_id'] = $saleId;
            $itemModel->insert($item);
        }

        $db->transComplete();

        if ($db->transStatus()) {
            return $this->response->setJSON([
                'ok' => true,
                'invoice_no' => $invoiceNo,
                'sale_id' => $saleId,
                'total' => $total,
                'paid' => $paid,
                'change' => $change,
            ]);
        }

        return $this->response->setJSON(['ok' => false, 'msg' => 'Gagal menyimpan transaksi'])->setStatusCode(500);
    }

    private function calculatePrice(int $productId, int $unitId, float $qty): float
    {
        $db = \Config\Database::connect();

        // 1. Tiered price
        $tier = $db->table('product_price_tiers')
            ->select('price')
            ->where('product_id', $productId)
            ->where('min_qty <=', $qty)
            ->orderBy('min_qty', 'DESC')
            ->limit(1)
            ->get()->getRowArray();

        if ($tier && $tier['price']) {
            return (float) $tier['price'];
        }

        // 2. Harga per satuan
        $pu = $db->table('product_units')
            ->select('price')
            ->where('product_id', $productId)
            ->where('unit_id', $unitId)
            ->get()->getRowArray();

        if ($pu && $pu['price']) {
            return (float) $pu['price'];
        }

        // 3. Fallback
        $product = $db->table('products')
            ->select('sell_price')
            ->where('id', $productId)
            ->get()->getRowArray();

        return (float) ($product['sell_price'] ?? 0);
    }

    private function generateInvoice(int $branchId): string
    {
        $y = date('Y');
        $m = str_pad(date('m'), 2, '0', STR_PAD_LEFT);
        $b = str_pad($branchId, 2, '0', STR_PAD_LEFT);
        $rand = str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);
        return sprintf('INV/%s/%s/%s/%s', $y, $m, $b, $rand);
    }
}