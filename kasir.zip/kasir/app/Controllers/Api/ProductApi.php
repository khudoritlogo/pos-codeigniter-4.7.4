<?php

namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\ProductModel;
use App\Models\CustomerModel;
use App\Models\UserModel;

class ProductApi extends BaseController {
    public function search() {
        $q = (string) $this->request->getGet('q');
        $branchId = session()->get('branch_id');
        $rows = (new ProductModel())->withRelations()
            ->select('products.*, COALESCE(ps.stock,0) AS stock')
            ->join("product_stocks ps",'ps.product_id=products.id AND ps.branch_id='.(int)$branchId,'left')
            ->groupStart()->like('products.name',$q)->orLike('products.barcode',$q)->orLike('products.sku',$q)->groupEnd()
            ->where('products.is_active',1)
            ->limit(20)->find();
        return $this->response->setJSON($rows);
    }
    public function byBarcode() {
        $bc = (string) $this->request->getGet('barcode');
        $branchId = session()->get('branch_id');
        $row = (new ProductModel())->withRelations()
            ->select('products.*, COALESCE(ps.stock,0) AS stock')
            ->join("product_stocks ps",'ps.product_id=products.id AND ps.branch_id='.(int)$branchId,'left')
            ->where('products.barcode',$bc)->orWhere('products.sku',$bc)->first();
        return $this->response->setJSON($row);
    }
}

class CustomerApi extends BaseController {
    public function search() {
        $q = (string) $this->request->getGet('q');
        $rows = (new CustomerModel())->withLevel()
            ->groupStart()->like('customers.name',$q)->orLike('customers.code',$q)->orLike('customers.phone',$q)->groupEnd()
            ->where('customers.deleted_at',null)->limit(20)->find();
        return $this->response->setJSON($rows);
    }
}

class CourierApi extends BaseController {
    public function available() {
        return $this->response->setJSON(model('UserModel')->availableCouriers(session()->get('branch_id')));
    }
}

class DashboardApi extends BaseController {
    public function stats() {
        $db = \Config\Database::connect();
        $today = date('Y-m-d');
        $data = $db->query("
            SELECT COALESCE(SUM(total),0) AS omzet, COUNT(*) AS trx
            FROM sales WHERE DATE(sale_date)=? AND status='completed'
        ",[$today])->getRowArray();
        return $this->response->setJSON($data);
    }
}
