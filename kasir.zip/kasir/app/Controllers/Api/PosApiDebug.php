<?php
namespace App\Controllers\Api;

use App\Controllers\BaseController;
use App\Models\ProductModel;
use App\Models\SaleModel;
use App\Models\SaleItemModel;
use CodeIgniter\HTTP\ResponseInterface;

class PosApiDebug extends BaseController
{
    public function testSession()
    {
        return $this->response->setJSON([
            'user_id' => session()->get('user_id'),
            'branch_id' => session()->get('branch_id'),
            'is_logged_in' => session()->get('is_logged_in'),
            'username' => session()->get('username'),
        ]);
    }

    public function create()
    {
        $payload = $this->request->getJSON(true) ?? [];

        if (empty($payload['items'])) {
            return $this->response->setJSON(['ok' => false, 'msg' => 'Keranjang kosong'])->setStatusCode(400);
        }

        $db = \Config\Database::connect();
        $db->transStart();

        $branchId = (int) ($payload['branch_id'] ?? $this->currentBranchId() ?: 1);
        $cashierId = (int) ($payload['cashier_id'] ?? $this->currentUserId() ?? 1);
        $invoiceNo = $payload['invoice_no'] ?? $this->generateInvoice($branchId);

        $saleModel = new SaleModel();
        $itemModel = new SaleItemModel();

        $subtotal = 0;
        $itemsData = [];

        foreach ($payload['items'] as $item) {
            $pid = (int) ($item['product_id'] ?? 0);
            $qty = (int) ($item['qty'] ?? 1);
            $unitId = (int) ($item['unit_id'] ?? 1);

            $price = $this->calculatePrice($pid, $unitId, $qty);
            $lineTotal = $price * $qty;
            $subtotal += $lineTotal;

            $stockRow = $db->table('product_stocks')
                ->select('stock')
                ->where('product_id', $pid)
                ->where('branch_id', $branchId)
                ->get()->getRowArray();

            $currentStock = (float) ($stockRow['stock'] ?? 0);
            $newStock = max(0, $currentStock - $qty);

            $db->table('product_stocks')
                ->where('product_id', $pid)
                ->where('branch_id', $branchId)
                ->update(['stock' => $newStock, 'updated_at' => date('Y-m-d H:i:s')]);

            $itemsData[] = [
                'sale_id' => 0,
                'product_id' => $pid,
                'qty' => $qty,
                'price' => $price,
                'subtotal' => $lineTotal,
                'unit_id' => $unitId,
            ];
        }

        $total = $subtotal;
        $paid = (float) ($payload['paid'] ?? $total);
        $change = max(0, $paid - $total);
        $paymentMethod = $payload['payment_method'] ?? 'cash';

        $saleId = $saleModel->insert([
            'invoice_no' => $invoiceNo,
            'branch_id' => $branchId,
            'cashier_id' => $cashierId,
            'sale_date' => date('Y-m-d H:i:s'),
            'subtotal' => $subtotal,
            'total' => $total,
            'paid' => $paid,
            'change' => $change,
            'payment_method' => $paymentMethod,
            'status' => 'completed',
        ]);

        foreach ($itemsData as $item) {
            $item['sale_id'] = $saleId;
            $itemModel->insert($item);
        }

        $db->transComplete();

        if ($db->transStatus()) {
            return $this->response->setJSON([
                'ok' => true,
                'invoice_no' => $invoiceNo,
                'sale_id' => $saleId,
                'total' => $total,
                'paid' => $paid,
                'change' => $change,
            ]);
        }

        return $this->response->setJSON(['ok' => false, 'msg' => 'Gagal menyimpan transaksi'])->setStatusCode(500);
    }

    private function calculatePrice(int $productId, int $unitId, float $qty): float
    {
        $db = \Config\Database::connect();
        $tier = $db->table('product_price_tiers')
            ->select('price')
            ->where('product_id', $productId)
            ->where('min_qty <=', $qty)
            ->orderBy('min_qty', 'DESC')
            ->limit(1)
            ->get()->getRowArray();

        if ($tier && $tier['price']) {
            return (float) $tier['price'];
        }

        $pu = $db->table('product_units')
            ->select('price')
            ->where('product_id', $productId)
            ->where('unit_id', $unitId)
            ->get()->getRowArray();

        if ($pu && $pu['price']) {
            return (float) $pu['price'];
        }

        $product = $db->table('products')
            ->select('sell_price')
            ->where('id', $productId)
            ->get()->getRowArray();

        return (float) ($product['sell_price'] ?? 0);
    }

    private function generateInvoice(int $branchId): string
    {
        $y = date('Y');
        $m = str_pad(date('m'), 2, '0', STR_PAD_LEFT);
        $b = str_pad($branchId, 2, '0', STR_PAD_LEFT);
        $rand = str_pad(mt_rand(1000, 9999), 4, '0', STR_PAD_LEFT);
        return sprintf('INV/%s/%s/%s/%s', $y, $m, $b, $rand);
    }
}