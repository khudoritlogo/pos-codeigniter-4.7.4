<?php

namespace App\Controllers;

use CodeIgniter\Controller;

/**
 * Customer Facing Display.
 * URL: /cfd/{branchId}/{cashierId?} — buka di monitor kedua.
 * Kasir POS mengirim state via POST /cfd/push, CFD polling GET /cfd/state.
 */
class Cfd extends Controller
{
    protected $helpers = ['form','url','number'];

    public function show(int $branchId, ?int $cashierId = null)
    {
        return view('cfd/display', [
            'branch_id'  => $branchId,
            'cashier_id' => $cashierId,
            'store'      => model('StoreSettingModel')->first() ?: [],
        ]);
    }

    /** Called by POS to update state (auth required) */
    public function push()
    {
        $session = session();
        if (! $session->get('is_logged_in')) return $this->response->setStatusCode(401);

        $state = $this->request->getJSON(true) ?: [];
        $branchId = (int) ($session->get('branch_id') ?: 1);
        $cashierId = (int) $session->get('user_id');

        $db = \Config\Database::connect();
        $row = $db->table('pos_display_states')->where(['branch_id'=>$branchId,'cashier_id'=>$cashierId])->get()->getRowArray();
        $payload = [
            'branch_id'=>$branchId,'cashier_id'=>$cashierId,
            'state'=>json_encode($state),'updated_at'=>date('Y-m-d H:i:s'),
        ];
        if ($row) $db->table('pos_display_states')->where('id',$row['id'])->update($payload);
        else $db->table('pos_display_states')->insert($payload);

        return $this->response->setJSON(['ok'=>true]);
    }

    /** Polled by CFD to get state (public - CFD monitor no login) */
    public function state(int $branchId, ?int $cashierId = null)
    {
        $db = \Config\Database::connect();
        $b = $db->table('pos_display_states')->where('branch_id',$branchId);
        if ($cashierId) $b->where('cashier_id',$cashierId);
        $row = $b->orderBy('updated_at','DESC')->get()->getRowArray();
        $state = $row ? json_decode($row['state'], true) : ['items'=>[],'total'=>0];
        return $this->response->setJSON([
            'ok'=>true,'state'=>$state,'updated_at'=>$row['updated_at'] ?? null,
        ]);
    }
}
