<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class PurchaseReturns extends BaseController
{
    public function index()
    {
        return $this->view('returns/purchase_index');
    }

    public function new()
    {
        return $this->view('returns/purchase_form');
    }

    public function edit($id = null)
    {
        return $this->view('returns/purchase_form');
    }

    public function show($id = null)
    {
        return $this->view('returns/purchase_index');
    }
}
