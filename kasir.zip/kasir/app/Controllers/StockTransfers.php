<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class StockTransfers extends BaseController
{
    public function index()
    {
        return $this->view('transfers/index');
    }

    public function new()
    {
        return $this->view('transfers/form');
    }

    public function edit($id = null)
    {
        return $this->view('transfers/form');
    }

    public function show($id = null)
    {
        return $this->view('transfers/index');
    }
}
