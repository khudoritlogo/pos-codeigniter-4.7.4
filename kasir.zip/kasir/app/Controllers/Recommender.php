<?php

namespace App\Controllers;

/**
 * AI Menu Recommender — co-occurrence based (produk yang sering dibeli bersamaan)
 * Dipakai di POS: setelah kasir scan/pilih 1 produk, tampilkan 3 rekomendasi upsell.
 */
class Recommender extends BaseController
{
    /** Analisis semua sales history & bangun co-occurrence table (jalankan via cron / tombol admin) */
    public function rebuild()
    {
        $db = \Config\Database::connect();
        $db->query("TRUNCATE product_recommendations");
        $db->query("
            INSERT INTO product_recommendations (product_id, recommended_id, score, updated_at)
            SELECT a.product_id, b.product_id, COUNT(*) AS score, NOW()
            FROM sale_items a
            JOIN sale_items b ON a.sale_id = b.sale_id AND a.product_id != b.product_id
            GROUP BY a.product_id, b.product_id
            HAVING score >= 2
            ORDER BY score DESC
        ");
        return $this->response->setJSON(['ok' => true, 'msg' => 'Rekomendasi berhasil dibangun ulang']);
    }

    /** Get top 5 rekomendasi untuk produk tertentu (dipanggil dari POS setelah scan) */
    public function forProduct(int $productId)
    {
        $rows = \Config\Database::connect()->query("
            SELECT p.id, p.name, p.sku, p.sell_price, p.image, r.score
            FROM product_recommendations r
            JOIN products p ON p.id = r.recommended_id
            WHERE r.product_id = ? AND p.is_active = 1 AND p.deleted_at IS NULL
            ORDER BY r.score DESC LIMIT 5
        ", [$productId])->getResultArray();
        return $this->response->setJSON(['ok' => true, 'recommendations' => $rows]);
    }
}
