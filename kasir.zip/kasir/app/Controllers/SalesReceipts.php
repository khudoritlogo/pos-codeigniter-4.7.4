<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class SalesReceipts extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();
        $branchId = $this->currentBranchId() ?? 1;
        
        // Tidak ada tabel sales_receipts terpisah, gunakan data dari sales
        $receipts = $db->table('sales')
            ->select('sales.*, u.fullname AS cashier_name, c.name AS customer_name')
            ->join('users u', 'u.id = sales.cashier_id', 'left')
            ->join('customers c', 'c.id = sales.customer_id', 'left')
            ->where('sales.branch_id', $branchId)
            ->where('sales.status', 'completed')
            ->orderBy('sales.sale_date', 'DESC')
            ->limit(50)
            ->get()
            ->getResultArray();
        
        $totalReceipts = $db->table('sales')
            ->select('COUNT(*) AS cnt, COALESCE(SUM(total), 0) AS total')
            ->where('branch_id', $branchId)
            ->where('status', 'completed')
            ->get()
            ->getRowArray();
        
        return $this->view('sales/receipts', [
            'receipts' => $receipts,
            'total_count' => $totalReceipts['cnt'] ?? 0,
            'total_amount' => $totalReceipts['total'] ?? 0,
        ]);
    }
}
