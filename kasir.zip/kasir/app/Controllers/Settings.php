<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Settings extends BaseController
{
    public function index()
    {
        return $this->view('settings/index');
    }

    public function save()
    {
        return redirect()->to('/settings')->with('success', 'Pengaturan berhasil disimpan.');
    }
}
