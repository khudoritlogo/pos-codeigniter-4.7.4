<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\FranchiseModel;

class Franchises extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();
        
        // Cek apakah user adalah HQ (superadmin/franchise owner)
        $isHq = in_array(session()->get('level_code'), ['super_admin', 'franchise'], true);
        
        // Ambil daftar franchise
        $rows = [];
        try {
            $rows = $db->table('franchises f')
                ->select('f.*, COUNT(c.id) AS total_branches')
                ->join('branches c', 'c.franchise_id = f.id', 'left')
                ->groupBy('f.id')
                ->orderBy('f.name', 'ASC')
                ->get()
                ->getResultArray();
        } catch (\Exception $e) {
            $rows = [];
        }
        
        return $this->view('franchises/index', [
            'isHq' => $isHq,
            'rows' => $rows,
        ]);
    }

    public function dashboard($id = null)
    {
        return $this->view('franchises/dashboard', [
            'franchise_id' => $id,
        ]);
    }
}
