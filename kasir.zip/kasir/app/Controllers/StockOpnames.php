<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class StockOpnames extends BaseController
{
    public function index()
    {
        return $this->view('opname/index');
    }

    public function new()
    {
        return $this->view('opname/form');
    }

    public function edit($id = null)
    {
        return $this->view('opname/form');
    }

    public function show($id = null)
    {
        return $this->view('opname/index');
    }
}
