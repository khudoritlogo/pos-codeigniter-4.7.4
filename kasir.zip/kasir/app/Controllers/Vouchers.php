<?php

namespace App\Controllers;

class Vouchers extends BaseController
{
    public function index() {
        $rows = model('VoucherModel')->orderBy('id','DESC')->findAll();
        return $this->view('vouchers/index', ['rows'=>$rows]);
    }
    public function new() { return $this->view('vouchers/form',['row'=>null]); }
    public function edit($id=null) {
        $row = model('VoucherModel')->find($id);
        return $this->view('vouchers/form',['row'=>$row]);
    }
    public function create() {
        $d = $this->request->getPost();
        model('VoucherModel')->insert($d);
        return redirect()->to('/vouchers')->with('success','Voucher ditambahkan');
    }
    public function update($id=null) {
        model('VoucherModel')->update($id, $this->request->getPost());
        return redirect()->to('/vouchers')->with('success','Voucher diperbarui');
    }
    public function delete($id=null) {
        model('VoucherModel')->delete($id);
        return redirect()->to('/vouchers');
    }

    /** API — validate voucher code, return discount amount */
    public function validateCode()
    {
        $code = strtoupper(trim((string) $this->request->getGet('code')));
        $subtotal = (float) $this->request->getGet('subtotal');
        $customerId = $this->request->getGet('customer_id') ?: null;

        $v = model('VoucherModel')->where('code',$code)->where('is_active',1)->where('deleted_at',null)->first();
        if (! $v) return $this->response->setJSON(['ok'=>false,'msg'=>'Kode voucher tidak ditemukan']);

        $today = date('Y-m-d');
        if (!empty($v['valid_from'])  && $today < $v['valid_from'])  return $this->response->setJSON(['ok'=>false,'msg'=>'Voucher belum berlaku']);
        if (!empty($v['valid_until']) && $today > $v['valid_until']) return $this->response->setJSON(['ok'=>false,'msg'=>'Voucher sudah kedaluwarsa']);
        if ($v['usage_limit'] && $v['used_count'] >= $v['usage_limit']) return $this->response->setJSON(['ok'=>false,'msg'=>'Kuota voucher habis']);
        if ($subtotal < (float) $v['min_purchase']) return $this->response->setJSON(['ok'=>false,'msg'=>'Minimum belanja Rp '.number_format((float)$v['min_purchase'],0,',','.')]);

        if ($customerId && ! empty($v['applicable_customer_levels'])) {
            $c = model('CustomerModel')->find($customerId);
            $levels = array_filter(array_map('trim', explode(',', $v['applicable_customer_levels'])));
            if ($c && $levels && ! in_array((string) $c['level_id'], $levels, true)) {
                return $this->response->setJSON(['ok'=>false,'msg'=>'Voucher tidak berlaku untuk level customer ini']);
            }
        }
        if ($customerId && $v['usage_per_customer']) {
            $used = \Config\Database::connect()->table('voucher_usages')
                ->where(['voucher_id'=>$v['id'],'customer_id'=>$customerId])->countAllResults();
            if ($used >= (int) $v['usage_per_customer']) {
                return $this->response->setJSON(['ok'=>false,'msg'=>'Kamu sudah pakai voucher ini maksimal']);
            }
        }

        // Hitung diskon
        $discount = 0.0; $freeShipping = false;
        if ($v['type'] === 'percent') {
            $discount = $subtotal * ((float)$v['value']) / 100;
            if (!empty($v['max_discount']) && $discount > (float)$v['max_discount']) $discount = (float)$v['max_discount'];
        } elseif ($v['type'] === 'nominal') {
            $discount = (float) $v['value'];
        } elseif ($v['type'] === 'free_shipping') {
            $freeShipping = true;
        }

        return $this->response->setJSON([
            'ok'=>true, 'voucher_id'=>$v['id'], 'code'=>$v['code'], 'name'=>$v['name'],
            'type'=>$v['type'], 'discount'=>round($discount,2), 'free_shipping'=>$freeShipping,
        ]);
    }
}

class LoyaltyRewards extends BaseController
{
    public function index() {
        $rows = model('LoyaltyRewardModel')->select('loyalty_rewards.*, p.name AS product_name')
            ->join('products p','p.id = loyalty_rewards.product_id','left')->findAll();
        return $this->view('loyalty/index',['rows'=>$rows]);
    }
    public function new()  { return $this->view('loyalty/form',['row'=>null,'products'=>model('ProductModel')->findAll()]); }
    public function edit($id=null) {
        $row = model('LoyaltyRewardModel')->find($id);
        return $this->view('loyalty/form',['row'=>$row,'products'=>model('ProductModel')->findAll()]);
    }
    public function create() {
        model('LoyaltyRewardModel')->insert($this->request->getPost());
        return redirect()->to('/loyalty-rewards')->with('success','Reward ditambahkan');
    }
    public function update($id=null) {
        model('LoyaltyRewardModel')->update($id, $this->request->getPost());
        return redirect()->to('/loyalty-rewards')->with('success','Reward diperbarui');
    }
    public function delete($id=null) { model('LoyaltyRewardModel')->delete($id); return redirect()->to('/loyalty-rewards'); }

    /** API - daftar reward yg bisa ditukar customer (points cukup + tier match) */
    public function availableFor()
    {
        $customerId = $this->request->getGet('customer_id');
        if (! $customerId) return $this->response->setJSON([]);
        $c = model('CustomerModel')->find($customerId);
        if (! $c) return $this->response->setJSON([]);
        $levelId = (int) ($c['level_id'] ?? 0);
        $rows = \Config\Database::connect()->query("
            SELECT r.*, p.name AS product_name FROM loyalty_rewards r
            LEFT JOIN products p ON p.id = r.product_id
            WHERE r.is_active=1 AND r.stock>0 AND r.points_required <= ?
              AND (r.applicable_customer_levels IS NULL OR r.applicable_customer_levels = ''
                   OR FIND_IN_SET(?, r.applicable_customer_levels) > 0)
            ORDER BY r.tier_priority DESC, r.points_required ASC
        ",[(int)$c['points'], $levelId])->getResultArray();
        return $this->response->setJSON(['customer_points'=>(int)$c['points'],'level_id'=>$levelId,'rewards'=>$rows]);
    }
}

class RoutePlanner extends BaseController
{
    public function index()
    {
        $userId = $this->currentUserId();
        $deliveries = \Config\Database::connect()->query("
            SELECT s.id, s.invoice_no, s.delivery_address, s.delivery_lat, s.delivery_lng,
                   c.name AS customer_name, c.phone AS customer_phone, s.total
            FROM sales s LEFT JOIN customers c ON c.id=s.customer_id
            WHERE s.courier_id=? AND s.delivery_status IN ('pending','in_progress')
              AND s.delivery_lat IS NOT NULL AND s.delivery_lng IS NOT NULL
            ORDER BY s.sale_date ASC
        ",[$userId])->getResultArray();
        return $this->view('courier/route_planner', ['deliveries'=>$deliveries]);
    }

    public function save()
    {
        $d = $this->request->getJSON(true) ?: [];
        \Config\Database::connect()->table('courier_routes')->insert([
            'courier_id'=>$this->currentUserId(),
            'route_date'=>date('Y-m-d'),
            'optimized_order'=>json_encode($d['order'] ?? []),
            'total_distance_km'=>$d['distance_km'] ?? null,
            'total_duration_min'=>$d['duration_min'] ?? null,
            'starting_point'=>$d['starting_point'] ?? null,
            'created_at'=>date('Y-m-d H:i:s'),
        ]);
        return $this->response->setJSON(['ok'=>true]);
    }
}
