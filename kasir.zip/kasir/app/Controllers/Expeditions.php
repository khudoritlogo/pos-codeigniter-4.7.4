<?php
namespace App\Controllers;

use App\Models\ExpeditionModel;

class Expeditions extends BaseController
{
    public function index()
    {
        $rows = (new ExpeditionModel())->orderBy('name', 'ASC')->findAll();
        return $this->view('expeditions/index', [
            'rows' => $rows,
            'title' => 'Ekspedisi',
        ]);
    }

    public function new()
    {
        return $this->view('expeditions/form', [
            'row' => null,
            'title' => 'Ekspedisi',
            'action' => site_url('expeditions/create'),
        ]);
    }

    public function edit(int $id = null)
    {
        $row = (new ExpeditionModel())->find($id);
        if (!$row) {
            return redirect()->to(site_url('expeditions'))->with('error', 'Ekspedisi tidak ditemukan.');
        }
        return $this->view('expeditions/form', [
            'row' => $row,
            'title' => 'Ekspedisi',
            'action' => site_url("expeditions/update/$id"),
        ]);
    }

    public function create()
    {
        if (!$this->validate(['name' => 'required|min_length[2]|max_length[100]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        (new ExpeditionModel())->insert([
            'name' => $this->request->getPost('name'),
            'phone' => $this->request->getPost('phone'),
            'address' => $this->request->getPost('address'),
            'is_active' => 1,
        ]);
        return redirect()->to(site_url('expeditions'))->with('success', 'Ekspedisi berhasil ditambahkan.');
    }

    public function update(int $id = null)
    {
        (new ExpeditionModel())->update($id, [
            'name' => $this->request->getPost('name'),
            'phone' => $this->request->getPost('phone'),
            'address' => $this->request->getPost('address'),
            'is_active' => $this->request->getPost('is_active') ?? 1,
        ]);
        return redirect()->to(site_url('expeditions'))->with('success', 'Ekspedisi berhasil diperbarui.');
    }

    public function delete(int $id = null)
    {
        (new ExpeditionModel())->delete($id);
        return redirect()->to(site_url('expeditions'))->with('success', 'Ekspedisi berhasil dihapus.');
    }
}