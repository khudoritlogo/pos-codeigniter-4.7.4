<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class SaleReturns extends BaseController
{
    public function index()
    {
        return $this->view('returns/sale_index');
    }

    public function new()
    {
        return $this->view('returns/sale_form');
    }

    public function edit($id = null)
    {
        return $this->view('returns/sale_form');
    }

    public function show($id = null)
    {
        return $this->view('returns/sale_index');
    }
}
