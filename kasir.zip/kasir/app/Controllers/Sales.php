<?php

namespace App\Controllers;

use App\Models\ProductModel;
use App\Models\SaleItemModel;
use App\Models\SaleModel;
use App\Models\ReceivableModel;
use App\Models\CustomerModel;
use App\Libraries\TelegramService;
use App\Libraries\ThermalPrinter;
use Config\Database;

class Sales extends BaseController
{
    public function index()
    {
        $db = Database::connect();
        $branchFilter = $this->isSuperAdmin() ? '' : ' AND s.branch_id = ' . (int) $this->currentBranchId();
        $rows = $db->query("
            SELECT s.*, c.name AS customer_name, u.fullname AS cashier_name
            FROM sales s
            LEFT JOIN customers c ON c.id = s.customer_id
            LEFT JOIN users u ON u.id = s.cashier_id
            WHERE 1=1 $branchFilter
            ORDER BY s.id DESC LIMIT 200
        ")->getResultArray();
        return $this->view('sales/index', ['rows' => $rows]);
    }

    public function pos()
    {
        $userId = $this->currentUserId();
        $branchId = $this->currentBranchId() ?: 1;

        $shift = model('CashierShiftModel')->currentFor($userId);
        if (! $shift && session()->get('level_code') === 'kasir') {
            $shift = model('CashierShiftModel')->createFor($userId, $branchId);
        }

        $customers = (new CustomerModel())->withLevel()->where('customers.deleted_at', null)->findAll();
        $couriers  = model('UserModel')->availableCouriers($branchId);
        $expeditions = model('ExpeditionModel')->where('is_active',1)->findAll();
        return $this->view('sales/pos', [
            'customers' => $customers,
            'couriers'  => $couriers,
            'expeditions' => $expeditions,
            'shift'     => $shift,
            'branch_id' => $branchId,
            'user_id' => $userId,
        ]);
    }

    public function save()
    {
        $payload = $this->request->getJSON(true);
        if (empty($payload['items'])) {
            return $this->response->setJSON(['ok'=>false,'msg'=>'Keranjang kosong'])->setStatusCode(400);
        }

        $db = Database::connect();
        $db->transStart();

        $branchId = $this->currentBranchId() ?: 1;
        $userId   = $this->currentUserId();
        $shift    = model('CashierShiftModel')->currentFor($userId);

        $saleModel = new SaleModel();
        $itemModel = new SaleItemModel();
        $prodModel = new ProductModel();

        $subtotal = 0.0;
        $totalCost = 0.0;
        foreach ($payload['items'] as $it) {
            $subtotal += (float) $it['subtotal'];
            $totalCost += (float) $it['qty'] * (float) ($it['cost_price'] ?? 0);
        }
        $discountAmount = (float) ($payload['discount_amount'] ?? 0);
        $voucherId = $payload['voucher_id'] ?? null;
        $voucherDiscount = (float) ($payload['voucher_discount'] ?? 0);
        $freeShipping = ! empty($payload['voucher_free_shipping']);
        $rewardId = $payload['reward_id'] ?? null;
        $rewardDiscount = (float) ($payload['reward_discount'] ?? 0);
        $totalDiscount = $discountAmount + $voucherDiscount + $rewardDiscount;
        $taxAmount      = (float) ($payload['tax_amount'] ?? 0);
        $shippingCost   = $freeShipping ? 0 : (float) ($payload['shipping_cost'] ?? 0);
        $total = $subtotal - $totalDiscount + $taxAmount + $shippingCost;
        $paid = (float) ($payload['paid'] ?? $total);
        $debt = $paid < $total ? ($total - $paid) : 0;
        $change = $paid > $total ? ($paid - $total) : 0;

        $invoiceNo = $saleModel->generateInvoiceNo($branchId);
        $saleId = $saleModel->insert([
            'invoice_no' => $invoiceNo,
            'branch_id'  => $branchId,
            'cashier_id' => $userId,
            'shift_id'   => $shift['id'] ?? null,
            'courier_id' => $payload['courier_id'] ?? null,
            'expedition_id' => $payload['expedition_id'] ?? null,
            'customer_id'=> $payload['customer_id'] ?? null,
            'sale_date'  => date('Y-m-d H:i:s'),
            'sale_type'  => $payload['sale_type'] ?? 'retail',
            'subtotal'   => $subtotal,
            'discount_percent' => $payload['discount_percent'] ?? 0,
            'discount_amount'  => $totalDiscount,
            'voucher_id' => $voucherId,
            'voucher_discount' => $voucherDiscount,
            'tax_amount' => $taxAmount,
            'shipping_cost'=> $shippingCost,
            'total'      => $total,
            'paid'       => $paid,
            'change_amount' => $change,
            'debt_amount'=> $debt,
            'payment_method' => $payload['payment_method'] ?? 'cash',
            'payment_note'   => $payload['payment_note'] ?? null,
            'status'     => ($payload['status'] ?? 'completed'),
            'delivery_status' => !empty($payload['courier_id']) ? 'pending' : null,
            'delivery_address'=> $payload['delivery_address'] ?? null,
            'delivery_lat'    => $payload['delivery_lat'] ?? null,
            'delivery_lng'    => $payload['delivery_lng'] ?? null,
            'earned_points'   => (int) floor($total / 10000),  // 1 poin / 10rb
            'used_points'     => (int) ($payload['used_points'] ?? 0),
            'notes'      => $payload['notes'] ?? null,
        ], true);

        foreach ($payload['items'] as $it) {
            $profit = ((float) $it['price'] - (float) ($it['cost_price'] ?? 0)) * (float) $it['qty'] - (float) ($it['discount_amount'] ?? 0);
            $itemModel->insert([
                'sale_id'    => $saleId,
                'product_id' => $it['product_id'],
                'unit_id'    => $it['unit_id'] ?? null,
                'serial_number' => $it['serial_number'] ?? null,
                'qty'        => $it['qty'],
                'unit_conversion' => $it['unit_conversion'] ?? 1,
                'cost_price' => $it['cost_price'] ?? 0,
                'price'      => $it['price'],
                'discount_percent' => $it['discount_percent'] ?? 0,
                'discount_amount'  => $it['discount_amount'] ?? 0,
                'subtotal'   => $it['subtotal'],
                'profit'     => $profit,
            ]);
            // Kurangi stok
            $qtyBase = (float) $it['qty'] * (float) ($it['unit_conversion'] ?? 1);
            $prodModel->adjustStock((int) $it['product_id'], $branchId, -$qtyBase, 'sale', $saleId, $invoiceNo);

            // Tandai SN sebagai sold
            if (! empty($it['serial_number'])) {
                $db->table('product_serials')
                   ->where(['product_id'=>$it['product_id'],'serial_number'=>$it['serial_number']])
                   ->update(['status'=>'sold','sale_id'=>$saleId]);
            }
        }

        // Piutang
        if ($debt > 0 && ! empty($payload['customer_id'])) {
            (new ReceivableModel())->insert([
                'sale_id'   => $saleId,
                'customer_id'=> $payload['customer_id'],
                'amount'    => $debt,
                'paid_amount'=> 0,
                'remaining' => $debt,
                'due_date'  => $payload['due_date'] ?? date('Y-m-d', strtotime('+30 days')),
                'status'    => 'unpaid',
            ]);
        }

        // Loyalty
        if (! empty($payload['customer_id'])) {
            $earned = (int) floor($total / 10000);
            $used   = (int) ($payload['used_points'] ?? 0);
            if ($earned > 0) {
                $db->table('loyalty_transactions')->insert([
                    'customer_id'=>$payload['customer_id'],'sale_id'=>$saleId,'type'=>'earn',
                    'points'=>$earned,'notes'=>'Earn from '.$invoiceNo,'created_at'=>date('Y-m-d H:i:s'),
                ]);
            }
            if ($used > 0) {
                $db->table('loyalty_transactions')->insert([
                    'customer_id'=>$payload['customer_id'],'sale_id'=>$saleId,'type'=>'redeem',
                    'points'=>-$used,'notes'=>'Redeem on '.$invoiceNo,'created_at'=>date('Y-m-d H:i:s'),
                ]);
            }
            $db->table('customers')->where('id',$payload['customer_id'])
               ->set('points','points + '.($earned - $used), false)
               ->set('total_spent','total_spent + '.$total, false)
               ->update();
        }

        $this->audit('create_sale','sales',$saleId,null,['invoice'=>$invoiceNo,'total'=>$total]);

        // Referral reward on first purchase
        if (! empty($payload['customer_id'])) {
            \App\Controllers\Referrals::checkAndRewardOnSale((int) $payload['customer_id'], $saleId, $total);
        }

        // Voucher usage
        if ($voucherId && $voucherDiscount > 0) {
            $db->table('voucher_usages')->insert([
                'voucher_id'=>$voucherId,'sale_id'=>$saleId,'customer_id'=>$payload['customer_id']??null,
                'discount_applied'=>$voucherDiscount,'created_at'=>date('Y-m-d H:i:s'),
            ]);
            $db->table('vouchers')->where('id',$voucherId)->set('used_count','used_count+1',false)->update();
        }

        // Loyalty redemption
        if ($rewardId && ! empty($payload['customer_id'])) {
            $reward = model('LoyaltyRewardModel')->find($rewardId);
            if ($reward) {
                $db->table('loyalty_redemptions')->insert([
                    'customer_id'=>$payload['customer_id'],'reward_id'=>$rewardId,'sale_id'=>$saleId,
                    'points_used'=>$reward['points_required'],'notes'=>'Redeem: '.$reward['name'],
                    'created_at'=>date('Y-m-d H:i:s'),
                ]);
                if ((int) $reward['stock'] < 999) {
                    $db->table('loyalty_rewards')->where('id',$rewardId)->set('stock','stock-1',false)->update();
                }
            }
        }

        $db->transComplete();

        if (! $db->transStatus()) {
            return $this->response->setJSON(['ok'=>false,'msg'=>'Gagal menyimpan transaksi'])->setStatusCode(500);
        }

        return $this->response->setJSON([
            'ok'=>true,'sale_id'=>$saleId,'invoice_no'=>$invoiceNo,
            'total'=>$total,'change'=>$change,'debt'=>$debt,
        ]);
    }

    public function invoice(int $id)
    {
        $sale = (new SaleModel())->findWithRelations($id);
        if (! $sale) return redirect()->to('/sales');
        $items = model('SaleItemModel')->select('sale_items.*, p.name AS product_name, p.sku')
            ->join('products p','p.id = sale_items.product_id','left')
            ->where('sale_id',$id)->findAll();
        return $this->view('sales/invoice', ['sale'=>$sale,'items'=>$items]);
    }

    public function receipt(int $id)
    {
        $sale = (new SaleModel())->findWithRelations($id);
        if (! $sale) return redirect()->to('/sales');
        $items = model('SaleItemModel')->select('sale_items.*, p.name AS product_name')
            ->join('products p','p.id = sale_items.product_id','left')
            ->where('sale_id',$id)->findAll();
        // Data store sudah tersedia di $this->data dari BaseController, cukup referensi
        $store = $this->data['store'] ?? [];
        return $this->view('sales/receipt', [
            'sale'  => $sale,
            'items' => $items,
            'store' => $store,
        ]);
    }

    public function printThermal(int $id)
    {
        try {
            $printer = new ThermalPrinter();
            $printer->printReceipt($id);
            return $this->response->setJSON(['ok'=>true]);
        } catch (\Throwable $e) {
            log_message('error', $e->getMessage());
            return $this->response->setJSON(['ok'=>false,'msg'=>$e->getMessage()])->setStatusCode(500);
        }
    }

    public function void(int $id)
    {
        if (! in_array(session()->get('level_code'), ['super_admin','admin'], true)) {
            return $this->response->setJSON(['ok'=>false,'msg'=>'Butuh otorisasi Admin'])->setStatusCode(403);
        }
        $reason = (string) $this->request->getPost('reason');
        $sale = (new SaleModel())->find($id);
        if (! $sale) return $this->response->setJSON(['ok'=>false])->setStatusCode(404);

        $db = Database::connect();
        $db->transStart();
        (new SaleModel())->update($id, [
            'status'=>'void','void_by'=>$this->currentUserId(),
            'void_reason'=>$reason,'void_at'=>date('Y-m-d H:i:s'),
        ]);
        // Kembalikan stok
        $items = model('SaleItemModel')->where('sale_id',$id)->findAll();
        $prod = new ProductModel();
        foreach ($items as $it) {
            $qty = (float) $it['qty'] * (float) $it['unit_conversion'];
            $prod->adjustStock((int) $it['product_id'], (int) $sale['branch_id'], $qty, 'adjustment', $id, 'Void '.$sale['invoice_no']);
        }
        $this->audit('void_sale','sales',$id,$sale,['reason'=>$reason]);
        $db->transComplete();

        return $this->response->setJSON(['ok'=>$db->transStatus()]);
    }

    public function pending()
    {
        $branchFilter = $this->isSuperAdmin() ? [] : ['s.branch_id' => $this->currentBranchId()];
        $rows = (new SaleModel())->findAllWithRelations($branchFilter);
        return $this->view('sales/pending', ['rows' => $rows]);
    }
}
