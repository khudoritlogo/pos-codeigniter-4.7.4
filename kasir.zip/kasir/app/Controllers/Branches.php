<?php
namespace App\Controllers;

class Branches extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();
        $rows = $db->table('branches')
            ->select('branches.id, branches.name, branches.address, branches.phone, branches.is_active')
            ->where('branches.is_active', 1)
            ->orderBy('branches.name')
            ->get()
            ->getResultArray();
        
        return view('branches/index', [
            'rows' => $rows,
            'page_title' => 'Data Cabang',
        ]);
    }
    
    public function create()
    {
        return view('branches/form', [
            'page_title' => 'Tambah Cabang',
        ]);
    }
    
    public function store()
    {
        $db = \Config\Database::connect();
        $name = trim($this->request->getPost('name'));
        $address = trim($this->request->getPost('address'));
        $phone = trim($this->request->getPost('phone'));
        
        if (empty($name)) {
            return redirect()->back()->withInput()->with('error', 'Nama cabang wajib diisi');
        }
        
        $db->table('branches')->insert([
            'name' => $name,
            'address' => $address,
            'phone' => $phone,
            'is_active' => 1,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        
        return redirect()->to('/branches')->with('success', 'Cabang berhasil ditambahkan');
    }
    
    public function edit($id = null)
    {
        $db = \Config\Database::connect();
        $row = $db->table('branches')->where('id', $id)->get()->getRowArray();
        
        if (!$row) {
            return redirect()->to('/branches')->with('error', 'Cabang tidak ditemukan');
        }
        
        return view('branches/form', [
            'row' => $row,
            'page_title' => 'Edit Cabang',
        ]);
    }
    
    public function update($id = null)
    {
        $db = \Config\Database::connect();
        $name = trim($this->request->getPost('name'));
        $address = trim($this->request->getPost('address'));
        $phone = trim($this->request->getPost('phone'));
        
        if (empty($name)) {
            return redirect()->back()->withInput()->with('error', 'Nama cabang wajib diisi');
        }
        
        $db->table('branches')
            ->where('id', $id)
            ->update([
                'name' => $name,
                'address' => $address,
                'phone' => $phone,
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
        
        return redirect()->to('/branches')->with('success', 'Cabang berhasil diupdate');
    }
    
    public function destroy($id = null)
    {
        $db = \Config\Database::connect();
        $db->table('branches')
            ->where('id', $id)
            ->update([
                'is_active' => 0,
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
        
        return redirect()->to('/branches')->with('success', 'Cabang dinonaktifkan');
    }
}
