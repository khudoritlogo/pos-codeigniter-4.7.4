<?php

namespace App\Controllers;

use App\Libraries\TelegramService;

class Courier extends BaseController
{
    public function dashboard()
    {
        $userId = $this->currentUserId();
        $db = \Config\Database::connect();
        $today = date('Y-m-d');

        $stats = $db->query("
            SELECT
              SUM(CASE WHEN delivery_status='pending' THEN 1 ELSE 0 END) AS pending,
              SUM(CASE WHEN delivery_status='in_progress' THEN 1 ELSE 0 END) AS in_progress,
              SUM(CASE WHEN delivery_status='delivered' AND DATE(sale_date)=? THEN 1 ELSE 0 END) AS delivered_today,
              COUNT(*) AS total
            FROM sales WHERE courier_id=?
        ",[$today,$userId])->getRowArray();

        $deliveries = $db->query("
            SELECT s.*, c.name AS customer_name, c.phone AS customer_phone, c.whatsapp AS customer_wa
            FROM sales s LEFT JOIN customers c ON c.id=s.customer_id
            WHERE s.courier_id=? AND s.delivery_status IN ('pending','in_progress')
            ORDER BY s.sale_date DESC
        ",[$userId])->getResultArray();

        return $this->view('courier/dashboard', ['stats'=>$stats,'deliveries'=>$deliveries]);
    }

    public function deliveries()
    {
        $userId = $this->currentUserId();
        $rows = \Config\Database::connect()->query("
            SELECT s.*, c.name AS customer_name FROM sales s LEFT JOIN customers c ON c.id=s.customer_id
            WHERE s.courier_id=? ORDER BY s.sale_date DESC LIMIT 200
        ",[$userId])->getResultArray();
        return $this->view('courier/deliveries', ['rows'=>$rows]);
    }

    public function updateStatus(int $saleId)
    {
        $status = $this->request->getPost('delivery_status');
        model('SaleModel')->update($saleId, ['delivery_status'=>$status]);
        $this->audit('update_delivery','sales',$saleId,null,['delivery_status'=>$status]);
        return $this->response->setJSON(['ok'=>true]);
    }

    public function routePlanner()
    {
        $db = \Config\Database::connect();
        $pendingDeliveries = $db->query("
            SELECT s.*, c.name AS customer_name, c.phone AS customer_phone, c.whatsapp AS customer_wa
            FROM sales s LEFT JOIN customers c ON c.id=s.customer_id
            WHERE s.delivery_status IN ('pending','in_progress')
            ORDER BY s.sale_date ASC
            LIMIT 100
        ")->getResultArray() ?? [];
        
        return $this->view('courier/route_planner', [
            'deliveries' => $pendingDeliveries,
            'page_title' => 'Route Planner',
        ]);
    }

    public function sendWa(int $saleId)
    {
        $sale = model('SaleModel')->withRelations()->find($saleId);
        if (! $sale) return $this->response->setJSON(['ok'=>false])->setStatusCode(404);
        $customer = model('CustomerModel')->find($sale['customer_id']);
        $wa = $customer['whatsapp'] ?? $customer['phone'] ?? '';
        if (! $wa) return $this->response->setJSON(['ok'=>false,'msg'=>'Nomor WA customer tidak tersedia']);

        $text = urlencode("Halo *{$customer['name']}*, pesanan Anda dengan nomor invoice *{$sale['invoice_no']}* sedang dalam perjalanan. Terima kasih.");
        $link = "https://wa.me/{$wa}?text={$text}";
        return $this->response->setJSON(['ok'=>true,'link'=>$link]);
    }
}

class Shifts extends BaseController {
    public function index() {
        $userId = $this->currentUserId();
        $current = model('CashierShiftModel')->currentFor($userId);
        $history = model('CashierShiftModel')->where('user_id',$userId)->orderBy('id','DESC')->findAll(30);
        return $this->view('shifts/index',['current'=>$current,'history'=>$history]);
    }
    public function open() {
        $userId = $this->currentUserId();
        if (model('CashierShiftModel')->currentFor($userId)) {
            return redirect()->back()->with('warning','Anda sudah memiliki shift aktif');
        }
        model('CashierShiftModel')->insert([
            'user_id'=>$userId,'branch_id'=>$this->currentBranchId() ?? 1,
            'opened_at'=>date('Y-m-d H:i:s'),
            'opening_cash'=>(float)$this->request->getPost('opening_cash'),
            'status'=>'open',
        ]);
        return redirect()->to('/shifts')->with('success','Shift dibuka');
    }
    public function close() {
        $userId = $this->currentUserId();
        $shift = model('CashierShiftModel')->currentFor($userId);
        if (! $shift) return redirect()->to('/shifts')->with('error','Tidak ada shift aktif');

        $db = \Config\Database::connect();
        $row = $db->query("SELECT
            COALESCE(SUM(total),0) AS total,
            COALESCE(SUM(CASE WHEN payment_method='cash' THEN total ELSE 0 END),0) AS cash,
            COALESCE(SUM(CASE WHEN payment_method='transfer' THEN total ELSE 0 END),0) AS transfer,
            COALESCE(SUM(CASE WHEN payment_method='qris' THEN total ELSE 0 END),0) AS qris
            FROM sales WHERE shift_id=? AND status='completed'",[$shift['id']])->getRowArray();

        $closingCash = (float) $this->request->getPost('closing_cash');
        $expected    = (float) $shift['opening_cash'] + (float) $row['cash'];
        model('CashierShiftModel')->update($shift['id'], [
            'closed_at'=>date('Y-m-d H:i:s'),
            'closing_cash'=>$closingCash,
            'expected_cash'=>$expected,
            'difference'=>$closingCash - $expected,
            'total_sales'=>$row['total'],
            'total_cash'=>$row['cash'],
            'total_transfer'=>$row['transfer'],
            'total_qris'=>$row['qris'],
            'notes'=>$this->request->getPost('notes'),
            'status'=>'closed',
        ]);
        return redirect()->to('/shifts')->with('success','Shift ditutup');
    }
    public function current() {
        return $this->response->setJSON(model('CashierShiftModel')->currentFor($this->currentUserId()));
    }
}

class Settings extends BaseController {
    public function index() {
        return $this->view('settings/index',['row'=>model('StoreSettingModel')->first()]);
    }
    public function save() {
        $d = $this->request->getPost();
        $existing = model('StoreSettingModel')->first();
        if ($existing) model('StoreSettingModel')->update($existing['id'],$d);
        else model('StoreSettingModel')->insert($d);
        // Handle logo upload
        $logo = $this->request->getFile('logo');
        if ($logo && $logo->isValid() && ! $logo->hasMoved()) {
            $name = $logo->getRandomName();
            $logo->move(FCPATH.'assets/uploads', $name);
            model('StoreSettingModel')->update($existing['id'] ?? model('StoreSettingModel')->getInsertID(), ['logo'=>'assets/uploads/'.$name]);
        }
        return redirect()->to('/settings')->with('success','Pengaturan disimpan');
    }
    public function backup() {
        try {
            $file = (new \App\Libraries\BackupService())->backup();
            return $this->response->download($file, null);
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
    public function restore() {
        $file = $this->request->getFile('sql_file');
        if (! $file || ! $file->isValid()) return redirect()->back()->with('error','File tidak valid');
        $path = WRITEPATH . 'uploads/' . $file->getRandomName();
        $file->move(WRITEPATH.'uploads');
        try {
            (new \App\Libraries\BackupService())->restore($path);
            return redirect()->to('/settings')->with('success','Restore selesai');
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }
    }
}

class AuditLogs extends BaseController {
    public function index() {
        $rows = \Config\Database::connect()->query("
            SELECT a.*, u.fullname FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id
            ORDER BY a.id DESC LIMIT 500
        ")->getResultArray();
        return $this->view('reports/audit_logs',['rows'=>$rows]);
    }
}
