<?php
namespace App\Controllers;

use App\Models\CategoryModel;

class Categories extends BaseController
{
    public function index()
    {
        $model = new CategoryModel();
        $categories = $model->withProductsCount()->orderBy('name', 'ASC')->findAll();

        return $this->view('categories/index', [
            'categories' => $categories,
        ]);
    }

    public function new()
    {
        return $this->view('categories/form', [
            'category' => null,
            'action' => site_url('categories/create'),
            'title' => 'Tambah Kategori',
        ]);
    }

    public function edit(int $id = null)
    {
        $category = (new CategoryModel())->find($id);
        if (!$category) {
            return redirect()->to(site_url('categories'))->with('error', 'Kategori tidak ditemukan.');
        }

        return $this->view('categories/form', [
            'category' => $category,
            'action' => site_url("categories/update/$id"),
            'title' => 'Edit Kategori',
        ]);
    }

    public function create()
    {
        if (!$this->validate(['name' => 'required|min_length[3]|max_length[100]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        (new CategoryModel())->insert([
            'name' => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
            'is_active' => 1,
        ]);

        $this->audit('create_category', 'categories', null, null, $this->request->getPost());
        return redirect()->to(site_url('categories'))->with('success', 'Kategori berhasil ditambahkan.');
    }

    public function update(int $id = null)
    {
        $category = (new CategoryModel())->find($id);
        if (!$category) {
            return redirect()->to(site_url('categories'))->with('error', 'Kategori tidak ditemukan.');
        }

        if (!$this->validate(['name' => 'required|min_length[3]|max_length[100]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        (new CategoryModel())->update($id, [
            'name' => $this->request->getPost('name'),
            'description' => $this->request->getPost('description'),
        ]);

        $this->audit('update_category', 'categories', $id, $category, $this->request->getPost());
        return redirect()->to(site_url('categories'))->with('success', 'Kategori berhasil diperbarui.');
    }

    public function delete(int $id = null)
    {
        $category = (new CategoryModel())->find($id);
        if (!$category) {
            return redirect()->to(site_url('categories'))->with('error', 'Kategori tidak ditemukan.');
        }

        (new CategoryModel())->delete($id);
        $this->audit('delete_category', 'categories', $id, $category, null);

        return redirect()->to(site_url('categories'))->with('success', 'Kategori berhasil dihapus.');
    }
}