<?php

namespace App\Controllers;

use App\Libraries\MidtransService;
use App\Libraries\XenditService;

class Qris extends BaseController
{
    public function create()
    {
        $saleId = (int) $this->request->getPost('sale_id');
        $amount = (float) $this->request->getPost('amount');
        if ($amount <= 0) return $this->response->setJSON(['ok'=>false,'msg'=>'Amount invalid'])->setStatusCode(400);

        $settings = model('StoreSettingModel')->first();
        $provider = strtolower($this->request->getPost('provider') ?: ($settings['qris_provider'] ?? 'midtrans'));

        $orderId = 'QR-' . date('YmdHis') . '-' . random_int(1000,9999);
        $customer = $this->request->getPost('customer_name') ?: 'Customer';

        $result = $provider === 'xendit'
            ? (new XenditService())->createQris($orderId, $amount)
            : (new MidtransService())->createQris($orderId, $amount, $customer);

        if (! $result['ok']) return $this->response->setJSON(['ok'=>false,'msg'=>$result['msg']??'Gagal buat QRIS'])->setStatusCode(500);

        // Save to payment_transactions
        $db = \Config\Database::connect();
        $db->table('payment_transactions')->insert([
            'sale_id'          => $saleId ?: 0,
            'provider'         => $provider,
            'order_id'         => $orderId,
            'amount'           => $amount,
            'status'           => 'pending',
            'qr_string'        => $result['qr_string'] ?? null,
            'qr_url'           => $result['qr_url'] ?? null,
            'payload_response' => json_encode($result['raw'] ?? []),
            'expired_at'       => date('Y-m-d H:i:s', strtotime('+15 minutes')),
            'created_at'       => date('Y-m-d H:i:s'),
        ]);

        // Update sale if given
        if ($saleId) {
            try {
                model('SaleModel')->update($saleId, [
                    'qris_provider'     => $provider,
                    'qris_order_id'     => $orderId,
                    'qris_status'       => 'pending',
                    'qris_raw_response' => json_encode($result['raw'] ?? []),
                ]);
            } catch (\Throwable $e) {
                log_message('warning', 'QRIS: gagal update sale ' . $saleId . ': ' . $e->getMessage());
            }
        }

        return $this->response->setJSON([
            'ok'        => true,
            'order_id'  => $orderId,
            'qr_string' => $result['qr_string'] ?? null,
            'qr_url'    => $result['qr_url'] ?? null,
            'provider'  => $provider,
        ]);
    }

    /** Cek status QR (polling dari frontend POS) */
    public function check(string $orderId)
    {
        $db = \Config\Database::connect();
        $tx = $db->table('payment_transactions')->where('order_id', $orderId)->get()->getRowArray();
        if (! $tx) return $this->response->setJSON(['ok'=>false])->setStatusCode(404);

        // Real-time check to provider only if still pending
        if ($tx['status'] === 'pending') {
            if ($tx['provider'] === 'midtrans') {
                $r = (new MidtransService())->status($orderId);
                if ($r['ok']) {
                    $st = (new MidtransService())->mapStatus($r['data']['transaction_status'] ?? '');
                    if ($st !== 'pending') $this->markStatus($orderId, $st, $r['data']);
                    $tx['status'] = $st;
                }
            }
        }
        return $this->response->setJSON(['ok'=>true,'status'=>$tx['status']]);
    }

    /** Webhook: /qris/callback (public - No auth filter) */
    public function callback()
    {
        $raw = $this->request->getBody();
        $payload = json_decode($raw, true) ?: [];
        $provider = $this->request->getGet('provider') ?: 'midtrans';

        log_message('info', 'QRIS Webhook '.$provider.': '.$raw);

        $orderId = $payload['order_id'] ?? $payload['reference_id'] ?? null;
        if (! $orderId) return $this->response->setStatusCode(400);

        // Verifikasi
        if ($provider === 'midtrans') {
            if (! (new MidtransService())->verifyWebhook($payload)) {
                return $this->response->setStatusCode(403)->setJSON(['ok'=>false,'msg'=>'Invalid signature']);
            }
            $status = (new MidtransService())->mapStatus($payload['transaction_status'] ?? '');
        } else {
            $token = (string) (model('StoreSettingModel')->first()['xendit_callback_token'] ?? '');
            if ($token && ! (new XenditService())->verifyWebhook($token)) {
                return $this->response->setStatusCode(403);
            }
            $status = (new XenditService())->mapStatus($payload['status'] ?? '');
        }

        $this->markStatus($orderId, $status, $payload);
        return $this->response->setJSON(['ok'=>true]);
    }

    protected function markStatus(string $orderId, string $status, array $raw = []): void
    {
        $db = \Config\Database::connect();
        $db->table('payment_transactions')->where('order_id',$orderId)->update([
            'status'         => $status,
            'webhook_payload'=> json_encode($raw),
            'paid_at'        => $status === 'paid' ? date('Y-m-d H:i:s') : null,
            'updated_at'     => date('Y-m-d H:i:s'),
        ]);
        // Update sale
        $tx = $db->table('payment_transactions')->where('order_id',$orderId)->get()->getRowArray();
        if ($tx && $tx['sale_id']) {
            model('SaleModel')->update($tx['sale_id'], ['qris_status'=>$status]);
        }
    }
}
