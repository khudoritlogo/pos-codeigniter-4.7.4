<?php

namespace App\Controllers;

use App\Services\LicenseService;
use App\Filters\LicenseFilter;

class Activation extends BaseController
{
    protected LicenseService $licenseService;
    protected $licenseConfig;

    public function __construct()
    {
        $this->licenseService = new LicenseService();
        $this->licenseConfig = config(LicenseConfig::class);
    }

    /**
     * Halaman aktivasi
     */
    public function index()
    {
        // Cek apakah sudah ada lisensi aktif
        $license = $this->licenseService->getActiveLicense();

        if ($license && $this->licenseConfig->requireActivation) {
            // Redirect ke dashboard jika sudah aktif
            return redirect()->to(base_url('dashboard') ?: base_url('/'));
        }

        // Dapatkan info server
        $serverInfo = $this->getServerInfo();

        return view('activation/index', [
            'serverInfo'       => $serverInfo,
            'licenseKey'       => old('license_key'),
            'customerName'     => old('customer_name'),
            'customerEmail'    => old('customer_email'),
            'orderId'          => old('order_id'),
            'validUntil'       => old('valid_until'),
            'error'            => session()->getFlashdata('error') ?: null,
            'success'          => session()->getFlashdata('success') ?: null,
            'currentDomain'    => $this->getCurrentDomain(),
            'requireActivation' => $this->licenseConfig->requireActivation,
        ]);
    }

    /**
     * Proses aktivasi
     */
    public function activate()
    {
        if ($this->request->getMethod() === 'post') {
            $licenseKey     = $this->request->getPost('license_key');
            $customerName   = $this->request->getPost('customer_name');
            $customerEmail  = $this->request->getPost('customer_email');
            $orderId        = $this->request->getPost('order_id');
            $validUntil     = $this->request->getPost('valid_until');
            $notes          = $this->request->getPost('notes');

            // Validasi
            if (empty($licenseKey)) {
                return redirect()->back()->withInput()->with('error', 'License Key wajib diisi');
            }

            $licenseKey = strtoupper(trim($licenseKey));

            // Dapatkan info server
            $serverInfo = $this->getServerInfo();
            $domain    = $this->getCurrentDomain();
            $ipAddress = $this->getServerIp();

            // Aktivasi
            $result = $this->licenseService->activateLicense(
                $licenseKey,
                $domain,
                $ipAddress,
                array_merge($serverInfo, [
                    'customer_name' => $customerName,
                    'customer_email' => $customerEmail,
                    'order_id' => $orderId,
                    'valid_until' => $validUntil,
                    'notes' => $notes,
                ])
            );

            if ($result['success']) {
                // Simpan di session
                session()->set('license_activated', true);
                session()->set('license_key', $licenseKey);

                return redirect()->to(base_url('dashboard') ?: base_url('/'))
                    ->with('success', 'Lisensi berhasil diaktivasi!');

            } else {
                return redirect()->back()->withInput()
                    ->with('error', $result['error']);
            }
        }

        return redirect()->to(base_url('activation'));
    }

    /**
     * Cek status lisensi (API untuk frontend)
     */
    public function checkStatus()
    {
        $status = $this->licenseService->getLicenseStatus();

        return $this->response->setJSON($status);
    }

    /**
     * Deaktivasi lisensi (hanya admin)
     */
    public function deactivate()
    {
        // Hanya admin yang boleh deaktivasi
        if (!$this->isAdmin()) {
            return $this->response->setJSON([
                'success' => false,
                'error' => 'Unauthorized',
            ])->setStatusCode(403);
        }

        $license = $this->licenseService->getActiveLicense();

        if (!$license) {
            return $this->response->setJSON([
                'success' => false,
                'error' => 'Tidak ada lisensi aktif',
            ]);
        }

        $this->licenseService->deactivateLicense($license['id'], $this->getCurrentUserId());

        return $this->response->setJSON([
            'success' => true,
            'message' => 'Lisensi berhasil dideaktivasi. Halaman akan di-refresh.',
        ]);
    }

    /**
     * Dapatkan info server untuk ditampilkan di halaman aktivasi
     */
    protected function getServerInfo(): array
    {
        return [
            'domain'        => $this->getCurrentDomain(),
            'ip_address'    => $this->getServerIp(),
            'server_name'   => gethostname() ?: 'unknown',
            'php_version'   => PHP_VERSION,
            'mysql_version' => $this->getMySqlVersion(),
            'os'            => PHP_OS,
            'document_root' => $_SERVER['DOCUMENT_ROOT'] ?? '',
            'script_filename'=> $_SERVER['SCRIPT_FILENAME'] ?? '',
        ];
    }

    /**
     * Dapatkan domain saat ini
     */
    protected function getCurrentDomain(): string
    {
        $request = \Config\Services::request();
        $host    = $request->getServer('HTTP_HOST') ?? '';
        // Hilangkan www.
        return preg_replace('/^www\./i', '', $host);
    }

    /**
     * Dapatkan IP server
     */
    protected function getServerIp(): string
    {
        // Coba dapatkan IP dari network interface
        $ip = gethostbyname(gethostname());
        if ($ip && !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_PRIVATE)) {
            return $ip;
        }

        // Fallback: ambil dari external service
        try {
            $ch = curl_init('https://api.ipify.org?format=json');
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 5,
                CURLOPT_USERAGENT => 'POS-Kasir-LICENSE',
            ]);
            $response = curl_exec($ch);
            curl_close($ch);

            if ($response) {
                $data = json_decode($response, true);
                if (isset($data['ip'])) {
                    return $data['ip'];
                }
            }
        } catch (\Exception $e) {
            // Ignore
        }

        // Fallback terakhir
        return $_SERVER['SERVER_ADDR'] ?? gethostbyname(gethostname()) ?: 'unknown';
    }

    /**
     * Dapatkan versi MySQL
     */
    protected function getMySqlVersion(): string
    {
        try {
            $db = \Config\Database::connect();
            $result = $db->query("SELECT VERSION() as version")->getRowArray();
            return $result['version'] ?? 'unknown';
        } catch (\Exception $e) {
            return 'unknown';
        }
    }

    /**
     * Cek apakah user adalah admin
     */
    protected function isAdmin(): bool
    {
        $userLevel = session()->get('user_level') ?? 0;
        return $userLevel === 1 || $userLevel === 2; // super_admin atau admin
    }

    protected function getCurrentUserId(): ?int
    {
        return session()->get('user_id');
    }
}
