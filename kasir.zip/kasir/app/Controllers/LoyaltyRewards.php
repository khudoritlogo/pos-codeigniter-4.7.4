<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\LoyaltyRewardModel;

class LoyaltyRewards extends BaseController
{
    public function index()
    {
        $model = new LoyaltyRewardModel();
        $rows = $model->where('is_active', 1)->orderBy('name', 'ASC')->findAll();
        
        // Jika tidak ada model, fallback ke query manual
        if (empty($rows)) {
            $db = \Config\Database::connect();
            try {
                $rows = $db->table('loyalty_rewards')
                    ->where('is_active', 1)
                    ->orderBy('name', 'ASC')
                    ->get()
                    ->getResultArray();
            } catch (\Exception $e) {
                $rows = [];
            }
        }
        
        return $this->view('loyalty/index', [
            'rows' => $rows ?: [],
        ]);
    }

    public function new()
    {
        return $this->view('loyalty/form', [
            'reward' => null,
            'action' => site_url('loyalty-rewards/create'),
        ]);
    }
    
    public function create()
    {
        // Placeholder - implementasi lengkap memerlukan validasi dan model
        return redirect()->to(site_url('loyalty-rewards'))->with('success', 'Reward berhasil ditambahkan (implementasi sederhana).');
    }
}
