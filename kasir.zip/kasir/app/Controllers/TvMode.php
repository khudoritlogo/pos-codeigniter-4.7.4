<?php
namespace App\Controllers;
use App\Controllers\BaseController;
class TvMode extends BaseController {
    public function index() {
        $db = \Config\Database::connect();
        
        // Omzet hari ini
        $today = date('Y-m-d');
        $todaySales = $db->table('sales')
            ->where('DATE(created_at)', $today)
            ->select('SUM(total) as o, COUNT(*) as c')
            ->get()->getRow();
        $todayStats = (object)['o' => $todaySales->o ?? 0, 'c' => $todaySales->c ?? 0];
        
        // Omzet bulan ini
        $month = date('Y-m');
        $monthSales = $db->table('sales')
            ->like('created_at', $month, 'after')
            ->select('SUM(total) as o, COUNT(*) as c')
            ->get()->getRow();
        $monthStats = (object)['o' => $monthSales->o ?? 0, 'c' => $monthSales->c ?? 0];
        
        // Top produk hari ini
        $topProducts = $db->table('sale_items')
            ->join('products', 'products.id = sale_items.product_id')
            ->join('sales', 'sales.id = sale_items.sale_id')
            ->where('DATE(sales.created_at)', $today)
            ->select('products.name, SUM(sale_items.qty) as qty')
            ->groupBy('sale_items.product_id')
            ->orderBy('qty', 'DESC')
            ->limit(5)
            ->get()->getResultArray();
        
        // Transaksi terbaru
        $recentSales = $db->table('sales')
            ->select('sales.id, sales.invoice_no, sales.total, customers.name as customer_name')
            ->join('customers', 'customers.id = sales.customer_id', 'left')
            ->orderBy('sales.id', 'DESC')
            ->limit(8)
            ->get()->getResultArray();
        
        return $this->view('dashboard/tv', [
            'page_title'    => 'TV Mode',
            'todayStats'    => $todayStats,
            'monthStats'    => $monthStats,
            'topProducts'   => $topProducts,
            'recentSales'   => $recentSales,
        ]);
    }
}
