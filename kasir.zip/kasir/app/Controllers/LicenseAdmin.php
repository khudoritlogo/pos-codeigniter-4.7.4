<?php

namespace App\Controllers;

use App\Models\LicenseModel;
use App\Models\LicenseActivationLogModel;
use App\Models\LicenseNotificationModel;
use App\Services\LicenseService;
use CodeIgniter\HTTP\Response;

class LicenseAdmin extends BaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->licenseModel = new LicenseModel();
        $this->logModel = new LicenseActivationLogModel();
        $this->notifModel = new LicenseNotificationModel();
        $this->service = new LicenseService();
    }

    public function index()
    {
        if (!authCheck()) return redirect()->to('/auth/login');

        $page = $this->request->getGet('page') ?? 1;
        $perPage = 20;

        $query = $this->licenseModel->orderBy('created_at', 'DESC');
        $licenses = $query->paginate($perPage, 'license_page');
        $pager = $query->pager;

        return view('license/index', [
            'licenses' => $licenses,
            'pager'    => $pager,
        ]);
    }

    public function create()
    {
        if (!authCheck()) return redirect()->to('/auth/login');
        return view('license/create');
    }

    public function store()
    {
        if (!authCheck()) return $this->response->setJSON(['success' => false, 'error' => 'Unauthorized']);

        $count = (int)($this->request->getPost('count') ?? 1);
        $count = min($count, 10);

        $keys = [];
        for ($i = 0; $i < $count; $i++) {
            $key = $this->service->generateLicenseKey();

            $data = [
                'license_key'     => $key,
                'status'          => 'inactive',
                'customer_name'   => $this->request->getPost('customer_name'),
                'customer_email'  => $this->request->getPost('customer_email'),
                'domain'          => $this->request->getPost('domain') ?: null,
                'valid_until'     => $this->request->getPost('valid_until'),
                'order_id'        => $this->request->getPost('order_id') ?: null,
                'notes'           => $this->request->getPost('notes') ?: null,
                'created_by'      => auth()->userId() ?? 1,
            ];

            if ($this->licenseModel->insert($data)) {
                $keys[] = $key;
            } else {
                log_message('error', 'Gagal menyimpan license key: ' . json_encode($this->licenseModel->errors()));
            }
        }

        if ($keys) {
            session()->setFlashdata('success', count($keys) . ' license key berhasil dibuat');
            return redirect()->to('/license');
        }

        session()->setFlashdata('error', 'Gagal membuat license key');
        return redirect()->back()->withInput();
    }

    public function edit($id = null)
    {
        if (!authCheck()) return redirect()->to('/auth/login');

        $license = $this->licenseModel->find($id);
        if (!$license) {
            session()->setFlashdata('error', 'Lisensi tidak ditemukan');
            return redirect()->to('/license');
        }

        return view('license/edit', ['license' => $license]);
    }

    public function update($id = null)
    {
        if (!authCheck()) return $this->response->setJSON(['success' => false, 'error' => 'Unauthorized']);

        $data = [
            'customer_name'  => $this->request->getPost('customer_name'),
            'customer_email' => $this->request->getPost('customer_email'),
            'domain'         => $this->request->getPost('domain') ?: null,
            'valid_until'    => $this->request->getPost('valid_until'),
            'status'         => $this->request->getPost('status'),
            'notes'          => $this->request->getPost('notes') ?: null,
            'updated_by'     => auth()->userId() ?? 1,
        ];

        if ($this->licenseModel->update($id, $data)) {
            session()->setFlashdata('success', 'Lisensi berhasil diupdate');
            return redirect()->to('/license');
        }

        session()->setFlashdata('error', 'Gagal update lisensi');
        return redirect()->back()->withInput();
    }

    public function deactivate($id = null)
    {
        if (!authCheck()) return $this->response->setJSON(['success' => false, 'error' => 'Unauthorized']);

        $license = $this->licenseModel->find($id);
        if (!$license) {
            return $this->response->setJSON(['success' => false, 'error' => 'Lisensi tidak ditemukan']);
        }

        $this->logModel->insert([
            'license_id'   => $id,
            'action'       => 'deactivate',
            'old_status'   => $license['status'],
            'new_status'   => 'inactive',
            'performed_by' => auth()->userId() ?? 1,
            'notes'        => 'Deactivate manual oleh admin',
        ]);

        $this->licenseModel->update($id, ['status' => 'inactive', 'domain' => null, 'ip_address' => null]);
        return $this->response->setJSON(['success' => true]);
    }

    public function showActivationLogs($id = null)
    {
        if (!authCheck()) return redirect()->to('/auth/login');

        $logs = $this->logModel
            ->where('license_id', $id)
            ->orderBy('created_at', 'DESC')
            ->findAll();

        return view('license/logs', ['logs' => $logs]);
    }

    public function showNotifications($id = null)
    {
        if (!authCheck()) return redirect()->to('/auth/login');

        $notifs = $this->notifModel
            ->where('license_id', $id)
            ->orderBy('created_at', 'DESC')
            ->findAll();

        return view('license/notifications', ['notifications' => $notifs]);
    }

    public function exportList()
    {
        if (!authCheck()) return redirect()->to('/auth/login');

        $licenses = $this->licenseModel->findAll();
        $csv = "ID,Key,Status,Domain,IP,Customer,Email,Valid Until,Created At\n";
        foreach ($licenses as $l) {
            $csv .= implode(',', [
                $l['id'],
                $l['license_key'],
                $l['status'],
                $l['domain'] ?? '',
                $l['ip_address'] ?? '',
                $l['customer_name'] ?? '',
                $l['customer_email'] ?? '',
                $l['valid_until'] ?? '',
                $l['created_at'] ?? '',
            ]) . "\n";
        }

        return $this->response
            ->setContentType('text/csv')
            ->setBody($csv)
            ->setHeader('Content-Disposition', 'attachment; filename="licenses.csv"');
    }

    public function checkStatus()
    {
        $key = $this->request->getGet('key');
        if (!$key) {
            return $this->response->setJSON(['error' => 'Key tidak diberikan']);
        }

        $license = $this->licenseModel->where('license_key', $key)->first();
        if (!$license) {
            return $this->response->setJSON(['error' => 'Key tidak valid']);
        }

        return $this->response->setJSON([
            'license_key'  => $license['license_key'],
            'status'       => $license['status'],
            'domain'       => $license['domain'],
            'valid_until'  => $license['valid_until'],
        ]);
    }
}
