<?php
namespace App\Controllers;

use App\Models\SupplierModel;

class Suppliers extends BaseController
{
    public function index()
    {
        $q = $this->request->getGet('q') ?: '';
        $builder = (new SupplierModel())->builder()
            ->groupStart()
                ->like('name', $q)
                ->orLike('code', $q)
                ->orLike('phone', $q)
            ->groupEnd()
            ->where('is_active', 1)
            ->orderBy('name', 'ASC');

        $suppliers = $builder->get()->getResultArray();
        return $this->view('suppliers/index', [
            'suppliers' => $suppliers,
            'search' => $q,
        ]);
    }

    public function new()
    {
        return $this->view('suppliers/form', [
            'supplier' => null,
            'title' => 'Tambah Supplier',
            'action' => site_url('suppliers/create'),
        ]);
    }

    public function edit(int $id = null)
    {
        $supplier = (new SupplierModel())->find($id);
        if (!$supplier) {
            return redirect()->to(site_url('suppliers'))->with('error', 'Supplier tidak ditemukan.');
        }
        return $this->view('suppliers/form', [
            'supplier' => $supplier,
            'title' => 'Edit Supplier',
            'action' => site_url("suppliers/update/$id"),
        ]);
    }

    public function create()
    {
        if (!$this->validate(['name' => 'required|min_length[3]|max_length[100]'])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        (new SupplierModel())->insert($this->request->getPost() + ['is_active' => 1]);
        $this->audit('create_supplier', 'suppliers', null, null, $this->request->getPost());
        return redirect()->to(site_url('suppliers'))->with('success', 'Supplier berhasil ditambahkan.');
    }

    public function update(int $id = null)
    {
        $supplier = (new SupplierModel())->find($id);
        if (!$supplier) {
            return redirect()->to(site_url('suppliers'))->with('error', 'Supplier tidak ditemukan.');
        }
        (new SupplierModel())->update($id, $this->request->getPost());
        $this->audit('update_supplier', 'suppliers', $id, $supplier, $this->request->getPost());
        return redirect()->to(site_url('suppliers'))->with('success', 'Supplier berhasil diperbarui.');
    }

    public function delete(int $id = null)
    {
        (new SupplierModel())->delete($id);
        return redirect()->to(site_url('suppliers'))->with('success', 'Supplier berhasil dihapus.');
    }
}