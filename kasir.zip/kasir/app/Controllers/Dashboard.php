<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();
        $branchId = $this->currentBranchId();
        $branchFilter = $this->isSuperAdmin() ? '' : ' AND s.branch_id = ' . (int) $branchId;

        $today = date('Y-m-d');
        $monthStart = date('Y-m-01');

        // Barang terjual hari ini
        $soldToday = $db->query("
            SELECT COALESCE(SUM(si.qty),0) AS total
            FROM sale_items si
            JOIN sales s ON s.id = si.sale_id
            WHERE DATE(s.sale_date) = ? AND s.status='completed' $branchFilter
        ", [$today])->getRow()->total;

        $productsCount  = $db->table('products')->where('deleted_at', null)->countAllResults();
        $customersCount = $db->table('customers')->where('deleted_at', null)->countAllResults();
        $suppliersCount = $db->table('suppliers')->where('deleted_at', null)->countAllResults();

        $invoicesToday = $db->query("
            SELECT COUNT(*) AS c, COALESCE(SUM(s.total),0) AS omzet
            FROM sales s WHERE DATE(s.sale_date)=? AND s.status='completed' $branchFilter
        ", [$today])->getRow();

        $invoicesMonth = $db->query("
            SELECT COUNT(*) AS c, COALESCE(SUM(s.total),0) AS omzet
            FROM sales s WHERE s.sale_date >= ? AND s.status='completed' $branchFilter
        ", [$monthStart])->getRow();

        // Top 10 Produk terlaris (bulan berjalan)
        $topProducts = $db->query("
            SELECT p.name, SUM(si.qty) AS qty_sold, SUM(si.subtotal) AS revenue
            FROM sale_items si
            JOIN sales s ON s.id = si.sale_id
            JOIN products p ON p.id = si.product_id
            WHERE s.sale_date >= ? AND s.status='completed' $branchFilter
            GROUP BY p.id, p.name ORDER BY qty_sold DESC LIMIT 10
        ", [$monthStart])->getResultArray();

        // Stok terkecil
        $lowStock = $db->query("
            SELECT p.name, ps.stock, p.stock_alert, b.name AS branch_name
            FROM product_stocks ps
            JOIN products p ON p.id = ps.product_id
            JOIN branches b ON b.id = ps.branch_id
            WHERE p.deleted_at IS NULL " . ($branchId && !$this->isSuperAdmin() ? "AND ps.branch_id=$branchId" : "") . "
            ORDER BY ps.stock ASC LIMIT 10
        ")->getResultArray();

        // Recent invoices
        $recentInvoices = $db->query("
            SELECT s.invoice_no, s.sale_date, s.total, s.payment_method, c.name AS customer_name, u.fullname AS cashier
            FROM sales s
            LEFT JOIN customers c ON c.id = s.customer_id
            LEFT JOIN users u ON u.id = s.cashier_id
            WHERE s.status='completed' $branchFilter
            ORDER BY s.id DESC LIMIT 10
        ")->getResultArray();

        // Chart 7 hari
        $chart = $db->query("
            SELECT DATE(s.sale_date) AS d, COALESCE(SUM(s.total),0) AS omzet
            FROM sales s WHERE s.sale_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
              AND s.status='completed' $branchFilter
            GROUP BY DATE(s.sale_date) ORDER BY d ASC
        ")->getResultArray();

        return $this->view('dashboard/index', [
            'soldToday' => (int) $soldToday,
            'productsCount'  => $productsCount,
            'customersCount' => $customersCount,
            'suppliersCount' => $suppliersCount,
            'invoicesToday' => $invoicesToday,
            'invoicesMonth' => $invoicesMonth,
            'topProducts' => $topProducts,
            'lowStock'    => $lowStock,
            'recentInvoices' => $recentInvoices,
            'chart' => $chart,
        ]);
    }
}
