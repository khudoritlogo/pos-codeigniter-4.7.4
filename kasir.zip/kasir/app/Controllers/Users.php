<?php
namespace App\Controllers;

class Users extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();
        $rows = $db->table('users')
            ->select('users.id, users.username, users.fullname, users.email, users.level_id, users.is_active, users.last_login')
            ->where('users.is_active', 1)
            ->orderBy('users.username')
            ->get()
            ->getResultArray();
        
        return view('users/index', [
            'rows' => $rows,
            'page_title' => 'Data Pengguna',
        ]);
    }
    
    public function create()
    {
        return view('users/form', [
            'page_title' => 'Tambah Pengguna',
        ]);
    }
    
    public function store()
    {
        $db = \Config\Database::connect();
        $username = trim($this->request->getPost('username'));
        $password = $this->request->getPost('password');
        
        if (empty($username) || empty($password)) {
            return redirect()->back()->withInput()->with('error', 'Username dan password wajib diisi');
        }
        
        $exists = $db->table('users')->where('username', $username)->countAllResults();
        if ($exists > 0) {
            return redirect()->back()->withInput()->with('error', 'Username sudah digunakan');
        }
        
        $db->table('users')->insert([
            'username' => $username,
            'password' => password_hash($password, PASSWORD_BCRYPT),
            'is_active' => 1,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        
        return redirect()->to('/users')->with('success', 'Pengguna berhasil ditambahkan');
    }
    
    public function edit($id = null)
    {
        $db = \Config\Database::connect();
        $row = $db->table('users')->where('id', $id)->get()->getRowArray();
        
        if (!$row) {
            return redirect()->to('/users')->with('error', 'Pengguna tidak ditemukan');
        }
        
        return view('users/form', [
            'row' => $row,
            'page_title' => 'Edit Pengguna',
        ]);
    }
    
    public function update($id = null)
    {
        $db = \Config\Database::connect();
        $username = trim($this->request->getPost('username'));
        $password = $this->request->getPost('password');
        
        if (empty($username)) {
            return redirect()->back()->withInput()->with('error', 'Username wajib diisi');
        }
        
        $data = ['username' => $username, 'updated_at' => date('Y-m-d H:i:s')];
        
        if (!empty($password)) {
            $data['password'] = password_hash($password, PASSWORD_BCRYPT);
        }
        
        $db->table('users')->where('id', $id)->update($data);
        
        return redirect()->to('/users')->with('success', 'Pengguna berhasil diupdate');
    }
    
    public function destroy($id = null)
    {
        $db = \Config\Database::connect();
        $db->table('users')->where('id', $id)->update(['is_active' => 0, 'updated_at' => date('Y-m-d H:i:s')]);
        
        return redirect()->to('/users')->with('success', 'Pengguna dinonaktifkan');
    }
}
