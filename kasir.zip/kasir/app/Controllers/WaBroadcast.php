<?php

namespace App\Controllers;

class WaBroadcast extends BaseController
{
    public function index()
    {
        $rows = \Config\Database::connect()->query("
            SELECT b.*, v.code AS voucher_code, v.name AS voucher_name, u.fullname
            FROM wa_broadcasts b
            LEFT JOIN vouchers v ON v.id = b.voucher_id
            LEFT JOIN users u ON u.id = b.created_by
            ORDER BY b.id DESC LIMIT 50
        ")->getResultArray();
        return $this->view('broadcast/index', ['rows' => $rows]);
    }

    public function newForm()
    {
        return $this->view('broadcast/form', [
            'vouchers' => model('VoucherModel')->where('is_active',1)->findAll(),
            'levels'   => model('CustomerLevelModel')->findAll(),
        ]);
    }

    /** Preview daftar target berdasarkan filter */
    public function preview()
    {
        $filter = $this->request->getJSON(true) ?: [];
        $q = $this->buildQuery($filter);
        $customers = $q->get(200)->getResultArray();
        $total = $this->buildQuery($filter)->countAllResults();
        return $this->response->setJSON(['ok'=>true,'total'=>$total,'sample'=>array_slice($customers,0,20)]);
    }

    public function create()
    {
        $d = $this->request->getJSON(true) ?: [];
        $filter = $d['filter'] ?? [];
        $customers = $this->buildQuery($filter)->get()->getResultArray();
        if (empty($customers)) return $this->response->setJSON(['ok'=>false,'msg'=>'Tidak ada customer sesuai filter'])->setStatusCode(400);

        $db = \Config\Database::connect();
        $db->table('wa_broadcasts')->insert([
            'voucher_id'       => $d['voucher_id'] ?? null,
            'campaign_name'    => $d['campaign_name'] ?? 'Blast '.date('Y-m-d H:i'),
            'message_template' => $d['message_template'],
            'target_filter'    => json_encode($filter),
            'total_target'     => count($customers),
            'status'           => 'draft',
            'created_by'       => $this->currentUserId(),
            'created_at'       => date('Y-m-d H:i:s'),
        ]);
        $broadcastId = $db->insertID();

        foreach ($customers as $c) {
            $phone = preg_replace('/\D/','',$c['whatsapp'] ?: $c['phone']);
            if (! $phone) continue;
            $db->table('wa_broadcast_recipients')->insert([
                'broadcast_id'=>$broadcastId,'customer_id'=>$c['id'],
                'phone'=>$phone,'status'=>'pending',
            ]);
        }
        return $this->response->setJSON(['ok'=>true,'broadcast_id'=>$broadcastId,'total'=>count($customers)]);
    }

    /** Manual mode: user klik satu-satu buka wa.me — tapi backend siapkan link list */
    public function links(int $id)
    {
        $b = \Config\Database::connect()->table('wa_broadcasts')->where('id',$id)->get()->getRowArray();
        if (! $b) return $this->response->setStatusCode(404);
        $recs = \Config\Database::connect()->table('wa_broadcast_recipients as r')
            ->select('r.*, c.name AS customer_name, c.points')->join('customers c','c.id = r.customer_id','left')
            ->where('r.broadcast_id',$id)->get()->getResultArray();

        $voucher = $b['voucher_id'] ? model('VoucherModel')->find($b['voucher_id']) : null;
        return $this->view('broadcast/links', ['b'=>$b,'recs'=>$recs,'voucher'=>$voucher]);
    }

    public function markSent(int $recipientId)
    {
        $db = \Config\Database::connect();
        $db->table('wa_broadcast_recipients')->where('id',$recipientId)->update([
            'status'=>'sent','sent_at'=>date('Y-m-d H:i:s'),
        ]);
        // Update stats broadcast
        $r = $db->table('wa_broadcast_recipients')->where('id',$recipientId)->get()->getRowArray();
        if ($r) {
            $db->table('wa_broadcasts')->where('id',$r['broadcast_id'])
                ->set('total_sent','total_sent+1',false)->update();
        }
        return $this->response->setJSON(['ok'=>true]);
    }

    /** Kirim via WhatsApp Gateway API (Fonnte/Wablas) — jika di-set di settings */
    public function sendViaGateway(int $id)
    {
        $settings = model('StoreSettingModel')->first();
        $url   = $settings['whatsapp_gateway_url']   ?? null;
        $token = $settings['whatsapp_gateway_token'] ?? null;
        if (! $url || ! $token) return $this->response->setJSON(['ok'=>false,'msg'=>'WA Gateway belum di-set di Pengaturan'])->setStatusCode(400);

        $db = \Config\Database::connect();
        $b = $db->table('wa_broadcasts')->where('id',$id)->get()->getRowArray();
        if (! $b) return $this->response->setStatusCode(404);
        $recs = $db->table('wa_broadcast_recipients')->where('broadcast_id',$id)->where('status','pending')->get()->getResultArray();

        $db->table('wa_broadcasts')->where('id',$id)->update(['status'=>'sending']);
        $sent = 0; $failed = 0;

        foreach ($recs as $r) {
            $customer = $db->table('customers')->where('id',$r['customer_id'])->get()->getRowArray();
            $msg = $this->fillTemplate($b['message_template'], $customer ?: []);

            $ch = curl_init($url);
            curl_setopt_array($ch, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => http_build_query([
                    'target' => $r['phone'],
                    'message' => $msg,
                ]),
                CURLOPT_HTTPHEADER => ['Authorization: '.$token],
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 15,
            ]);
            $resp = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
            $ok = $code >= 200 && $code < 300;
            $db->table('wa_broadcast_recipients')->where('id',$r['id'])->update([
                'status'=>$ok?'sent':'failed',
                'error_message'=>$ok?null:substr((string)$resp,0,240),
                'sent_at'=>$ok?date('Y-m-d H:i:s'):null,
            ]);
            $ok ? $sent++ : $failed++;
            usleep(500000); // 0.5s delay antar kirim
        }
        $db->table('wa_broadcasts')->where('id',$id)->update([
            'status'=>'completed','total_sent'=>$sent,'total_failed'=>$failed,
            'completed_at'=>date('Y-m-d H:i:s'),
        ]);
        return $this->response->setJSON(['ok'=>true,'sent'=>$sent,'failed'=>$failed]);
    }

    protected function buildQuery(array $filter): \CodeIgniter\Database\BaseBuilder
    {
        $b = \Config\Database::connect()->table('customers')->where('deleted_at',null)->where('is_active',1);
        // Filter by phone/WA harus ada
        $b->groupStart()->where('whatsapp IS NOT NULL',null,false)->orWhere('phone IS NOT NULL',null,false)->groupEnd();

        if (! empty($filter['level_ids'])) $b->whereIn('level_id', $filter['level_ids']);
        if (! empty($filter['min_spent'])) $b->where('total_spent >=', (float) $filter['min_spent']);
        if (! empty($filter['min_points'])) $b->where('points >=', (int) $filter['min_points']);
        if (! empty($filter['active_since_days'])) $b->where("id IN (SELECT DISTINCT customer_id FROM sales WHERE sale_date >= DATE_SUB(NOW(), INTERVAL " . (int) $filter['active_since_days'] . " DAY))",null,false);
        return $b;
    }

    protected function fillTemplate(string $tpl, array $customer): string
    {
        return strtr($tpl, [
            '{nama}'   => $customer['name'] ?? 'Pelanggan',
            '{poin}'   => (string) ($customer['points'] ?? 0),
            '{spent}'  => number_format((float) ($customer['total_spent'] ?? 0), 0, ',', '.'),
        ]);
    }
}

class CourierLeaderboard extends BaseController
{
    public function index()
    {
        $month = $this->request->getGet('month') ?: date('Y-m');
        $from = $month . '-01';
        $to   = date('Y-m-t', strtotime($from));

        $rows = \Config\Database::connect()->query("
            SELECT k.id, k.fullname, k.avatar, k.whatsapp,
                   COUNT(s.id) AS deliveries,
                   SUM(CASE WHEN s.delivery_status='delivered' THEN 1 ELSE 0 END) AS delivered,
                   SUM(s.total) AS total_omzet,
                   AVG(s.customer_rating) AS avg_rating,
                   COUNT(s.customer_rating) AS rating_count,
                   COALESCE((
                     SELECT SUM(
                       6371 * ACOS(
                         COS(RADIANS(prev.latitude)) * COS(RADIANS(cl.latitude)) *
                         COS(RADIANS(cl.longitude) - RADIANS(prev.longitude)) +
                         SIN(RADIANS(prev.latitude)) * SIN(RADIANS(cl.latitude))
                       )
                     )
                     FROM courier_locations cl
                     JOIN courier_locations prev ON prev.courier_id = cl.courier_id
                       AND prev.id = (SELECT MAX(p.id) FROM courier_locations p WHERE p.courier_id=cl.courier_id AND p.id < cl.id AND p.created_at >= ?)
                     WHERE cl.courier_id = k.id AND cl.created_at BETWEEN ? AND ?
                   ), 0) AS distance_km
            FROM users k
            JOIN user_levels l ON l.id = k.level_id
            LEFT JOIN sales s ON s.courier_id = k.id AND DATE(s.sale_date) BETWEEN ? AND ? AND s.status='completed'
            WHERE l.code = 'kurir' AND k.is_active = 1
            GROUP BY k.id
            ORDER BY delivered DESC, avg_rating DESC, distance_km DESC
        ", [$from, $from.' 00:00:00', $to.' 23:59:59', $from, $to])->getResultArray();

        // Calculate points (weighted)
        foreach ($rows as &$r) {
            $r['points'] = (int) (
                ((int)$r['delivered']) * 10
                + (float)($r['avg_rating'] ?? 0) * 20
                + (float)$r['distance_km'] * 0.5
            );
        }
        unset($r);
        // Re-sort by points
        usort($rows, fn($a,$b) => $b['points'] - $a['points']);

        // Save monthly achievements (optional cache)
        $db = \Config\Database::connect();
        foreach ($rows as $i => $r) {
            $badge = null;
            if ($i === 0 && $r['deliveries'] > 0) $badge = 'gold';
            elseif ($i === 1 && $r['deliveries'] > 0) $badge = 'silver';
            elseif ($i === 2 && $r['deliveries'] > 0) $badge = 'bronze';
            $rows[$i]['rank_position'] = $i + 1;
            $rows[$i]['badge'] = $badge;
            $existing = $db->table('courier_achievements')->where(['courier_id'=>$r['id'],'month'=>$month])->countAllResults();
            $payload = [
                'courier_id'=>$r['id'],'month'=>$month,
                'deliveries'=>(int)$r['delivered'],'distance_km'=>(float)$r['distance_km'],
                'avg_rating'=>(float)($r['avg_rating']??0),'points'=>$r['points'],
                'rank_position'=>$i+1,'badge'=>$badge,'updated_at'=>date('Y-m-d H:i:s'),
            ];
            if ($existing) $db->table('courier_achievements')->where(['courier_id'=>$r['id'],'month'=>$month])->update($payload);
            else $db->table('courier_achievements')->insert($payload);
        }

        return $this->view('courier/leaderboard', ['rows'=>$rows,'month'=>$month]);
    }
}

class LiveTicker extends BaseController
{
    /** Polled by dashboard every 5s — returns latest sales since last_id */
    public function feed()
    {
        $sinceId = (int) $this->request->getGet('since', 0);
        $branchFilter = $this->isSuperAdmin() ? '' : ' AND s.branch_id = ' . (int) $this->currentBranchId();
        $rows = \Config\Database::connect()->query("
            SELECT s.id, s.invoice_no, s.total, s.payment_method, s.sale_date,
                   c.name AS customer_name, u.fullname AS cashier_name, b.name AS branch_name,
                   (SELECT COUNT(*) FROM sale_items WHERE sale_id=s.id) AS items
            FROM sales s
            LEFT JOIN customers c ON c.id = s.customer_id
            LEFT JOIN users u ON u.id = s.cashier_id
            LEFT JOIN branches b ON b.id = s.branch_id
            WHERE s.id > ? AND s.status='completed' $branchFilter
            ORDER BY s.id DESC LIMIT 20
        ", [$sinceId])->getResultArray();

        $today = \Config\Database::connect()->query("
            SELECT COUNT(*) c, COALESCE(SUM(total),0) omzet FROM sales
            WHERE DATE(sale_date)=? AND status='completed' $branchFilter
        ", [date('Y-m-d')])->getRowArray();

        return $this->response->setJSON(['ok'=>true,'rows'=>$rows,'today'=>$today,'server_time'=>date('c')]);
    }
}

class SaleRating extends BaseController
{
    /** PUBLIC — customer beri rating via link di WA */
    public function form(string $invoice)
    {
        $sale = \Config\Database::connect()->query("SELECT id, invoice_no, courier_id, customer_rating FROM sales WHERE invoice_no=?",[$invoice])->getRowArray();
        if (! $sale) return $this->response->setStatusCode(404);
        return view('sales/rate', ['sale'=>$sale, 'store'=>model('StoreSettingModel')->first()?:[]]);
    }

    public function submit(string $invoice)
    {
        $rating = (int) $this->request->getPost('rating');
        $review = (string) $this->request->getPost('review');
        if ($rating < 1 || $rating > 5) return $this->response->setJSON(['ok'=>false,'msg'=>'Rating 1-5'])->setStatusCode(400);

        \Config\Database::connect()->table('sales')->where('invoice_no',$invoice)->update([
            'customer_rating'=>$rating,'customer_review'=>$review,'rated_at'=>date('Y-m-d H:i:s'),
        ]);
        return $this->response->setJSON(['ok'=>true]);
    }
}
