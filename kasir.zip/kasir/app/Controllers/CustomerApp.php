<?php

namespace App\Controllers;

use CodeIgniter\Controller;

/** PUBLIC — Customer Mobile PWA login & self-service */
class CustomerApp extends Controller
{
    protected $helpers = ['form','url','number'];

    /** Halaman PWA (single page) */
    public function index()
    {
        return view('customer_app/index', ['store' => model('StoreSettingModel')->first() ?: []]);
    }

    /** Request OTP (dummy — kirim OTP ke WA/console log) */
    public function requestOtp()
    {
        $phone = preg_replace('/\D/','', (string) $this->request->getPost('phone'));
        $customer = model('CustomerModel')->groupStart()
            ->where('phone', $phone)->orWhere('whatsapp', $phone)->groupEnd()
            ->where('deleted_at', null)->first();
        if (! $customer) return $this->response->setJSON(['ok'=>false,'msg'=>'Nomor belum terdaftar sebagai customer. Silakan daftar di toko dulu.']);

        $otp = str_pad((string) random_int(0,999999), 6, '0', STR_PAD_LEFT);
        $token = bin2hex(random_bytes(24));
        \Config\Database::connect()->table('customer_tokens')->insert([
            'customer_id'=>$customer['id'],'token'=>$token,'otp_code'=>$otp,
            'otp_expires_at'=>date('Y-m-d H:i:s', strtotime('+10 minutes')),
            'created_at'=>date('Y-m-d H:i:s'),
        ]);

        // Kirim OTP via WA Gateway kalau ada
        $s = model('StoreSettingModel')->first();
        if (! empty($s['whatsapp_gateway_url']) && ! empty($s['whatsapp_gateway_token'])) {
            $ch = curl_init($s['whatsapp_gateway_url']);
            curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>http_build_query([
                'target'=>$phone,'message'=>"Kode OTP Anda: *$otp*\nBerlaku 10 menit.",
            ]),CURLOPT_HTTPHEADER=>['Authorization: '.$s['whatsapp_gateway_token']],
            CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>10]);
            curl_exec($ch); curl_close($ch);
        }
        log_message('info', "OTP for $phone: $otp"); // fallback debug
        return $this->response->setJSON(['ok'=>true,'token'=>$token,'msg'=>'OTP dikirim ke WhatsApp. Cek pesan Anda.']);
    }

    public function verifyOtp()
    {
        $token = (string) $this->request->getPost('token');
        $otp = (string) $this->request->getPost('otp');
        $db = \Config\Database::connect();
        $t = $db->table('customer_tokens')->where('token', $token)->get()->getRowArray();
        if (! $t || $t['otp_code'] !== $otp) return $this->response->setJSON(['ok'=>false,'msg'=>'OTP salah']);
        if (strtotime($t['otp_expires_at']) < time()) return $this->response->setJSON(['ok'=>false,'msg'=>'OTP kadaluarsa']);
        $db->table('customer_tokens')->where('id',$t['id'])->update(['verified'=>1,'last_used_at'=>date('Y-m-d H:i:s')]);
        return $this->response->setJSON(['ok'=>true,'token'=>$token]);
    }

    /** Semua data customer via token */
    public function me()
    {
        $token = (string) $this->request->getGet('token');
        $customer = $this->authByToken($token);
        if (! $customer) return $this->response->setJSON(['ok'=>false])->setStatusCode(401);

        $db = \Config\Database::connect();
        $vouchers = $db->query("
            SELECT v.* FROM vouchers v WHERE v.is_active=1 AND v.deleted_at IS NULL
              AND (v.valid_from IS NULL OR CURDATE() >= v.valid_from)
              AND (v.valid_until IS NULL OR CURDATE() <= v.valid_until)
              AND (v.usage_limit IS NULL OR v.used_count < v.usage_limit)
            LIMIT 20
        ")->getResultArray();
        $orders = $db->table('sales')->where('customer_id',$customer['id'])->orderBy('id','DESC')->limit(20)->get()->getResultArray();
        $recentLoyalty = $db->table('loyalty_transactions')->where('customer_id',$customer['id'])->orderBy('id','DESC')->limit(10)->get()->getResultArray();

        return $this->response->setJSON([
            'ok'=>true,
            'customer'=>$customer,
            'vouchers'=>$vouchers,
            'orders'=>$orders,
            'loyalty'=>$recentLoyalty,
            'referral_link'=>site_url('ref/'.$customer['referral_code']),
        ]);
    }

    protected function authByToken(string $token): ?array
    {
        if (! $token) return null;
        $db = \Config\Database::connect();
        $t = $db->table('customer_tokens')->where(['token'=>$token,'verified'=>1])->get()->getRowArray();
        if (! $t) return null;
        $db->table('customer_tokens')->where('id',$t['id'])->update(['last_used_at'=>date('Y-m-d H:i:s')]);
        return model('CustomerModel')->find($t['customer_id']);
    }
}


