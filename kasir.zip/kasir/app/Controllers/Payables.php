<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Payables extends BaseController
{
    public function index()
    {
        return $this->view('hutang/index');
    }

    public function detail($id = null)
    {
        return $this->view('hutang/detail');
    }

    public function pay($id = null)
    {
        return redirect()->to('/payables');
    }
}
