<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class PurchaseOrders extends BaseController
{
    public function index()
    {
        return $this->view('purchase_orders/index');
    }

    public function show($id = null)
    {
        return $this->view('purchase_orders/detail');
    }

    public function autoGenerate()
    {
        return redirect()->to('/purchase-orders');
    }
}
