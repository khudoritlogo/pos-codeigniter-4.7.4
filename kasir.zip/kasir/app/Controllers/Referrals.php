<?php
namespace App\Controllers;

class Referrals extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();
        
        // Periksa apakah tabel referral_events ada di database
        $tables = $db->listTables();
        $hasReferralTable = in_array('referral_events', $tables);
        
        if ($hasReferralTable) {
            // Fetch referral events with related data
            $events = $db->query("
                SELECT re.*, 
                       c1.name AS referrer_name,
                       c2.name AS referee_name,
                       s.invoice_no AS sale_invoice
                FROM referral_events re
                LEFT JOIN customers c1 ON c1.id = re.referrer_id
                LEFT JOIN customers c2 ON c2.id = re.referee_id
                LEFT JOIN sales s ON s.id = re.sale_id
                ORDER BY re.created_at DESC
                LIMIT 100
            ")->getResultArray();
            
            $totalEvents = count($events);
            $rewardedCount = count(array_filter($events, fn($e) => $e['status'] === 'rewarded'));
            $pendingCount = count(array_filter($events, fn($e) => $e['status'] === 'pending'));
            
            return view('referrals/index', [
                'events' => $events,
                'totalEvents' => $totalEvents,
                'rewardedCount' => $rewardedCount,
                'pendingCount' => $pendingCount,
            ]);
        } else {
            // Tabel belum ada — tampilkan info
            return view('referrals/index', [
                'events' => [],
                'totalEvents' => 0,
                'rewardedCount' => 0,
                'pendingCount' => 0,
                'info' => 'Tabel referral_events belum ada. Program referral aktif secara terprogram (logic ada di SaleModel::save dan Referrals::checkAndRewardOnSale).',
            ]);
        }
    }
}
