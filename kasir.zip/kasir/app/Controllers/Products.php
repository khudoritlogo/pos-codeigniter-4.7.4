<?php
namespace App\Controllers;

use App\Models\ProductModel;
use App\Models\UnitModel;
use App\Models\CategoryModel;
use App\Models\ProductUnitModel;
use App\Models\ProductPriceTierModel;

class Products extends BaseController
{
    public function index()
    {
        $branchId = $this->currentBranchId() ?: 1;
        $db = \Config\Database::connect();
        $search = $this->request->getGet('q') ?: '';

        $builder = $db->table('products p')
            ->select('p.*, c.name AS category_name,
                (SELECT COALESCE(SUM(ps.stock),0) FROM product_stocks ps 
                 WHERE ps.product_id = p.id'
                . ($branchId && !$this->isSuperAdmin() ? " AND ps.branch_id = $branchId" : "")
                . ') AS stock')
            ->join('categories c', 'c.id = p.category_id', 'left')
            ->groupStart()
                ->like('p.name', $search)
                ->orLike('p.sku', $search)
                ->orLike('p.barcode', $search)
            ->groupEnd()
            ->where('p.is_active', 1)
            ->orderBy('p.name', 'ASC');

        $perPage = 20;
        $page = (int) ($this->request->getGet('page') ?: 1);
        $offset = ($page - 1) * $perPage;

        $total = (int) $builder->countAllResults(false);
        $products = $builder->limit($perPage, $offset)->get()->getResultArray();

        // Build pager links
        $pager = service('pager');
        $pager->store('products', $page, $perPage, $total);

        return $this->view('products/index', [
            'products' => $products,
            'pager'    => $pager,
            'pagerGroup' => 'products',
            'search'   => $search,
            'branch'   => $branchId,
            'totalRecords' => $total,
            'perPage'      => $perPage,
        ]);
    }

    // ... rest of the controller (new, create, edit, update, delete, apiSearch) tetap sama
    public function new()
    {
        $units = (new UnitModel())->findAll();
        $categories = (new CategoryModel())->where('is_active', 1)->findAll();

        return $this->view('products/form', [
            'product' => null,
            'units' => $units,
            'categories' => $categories,
            'is_new' => true,
            'action' => site_url('products/create'),
        ]);
    }

    public function create()
    {
        if (!$this->validate([
            'name' => 'required|min_length[3]|max_length[200]',
            'sku'  => 'required|min_length[3]|max_length[50]|is_unique[products.sku,id]',
            'category_id' => 'required|is_natural_no_zero',
            'unit_id' => 'required|is_natural_no_zero',
            'sell_price' => 'required|numeric|greater_than_equal_to[0]',
            'cost_price' => 'permit_empty|numeric|greater_than_equal_to[0]',
            'stock' => 'permit_empty|integer|greater_than_equal_to[0]',
        ])) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $db = \Config\Database::connect();
        $db->transStart();

        $productData = [
            'name' => $this->request->getPost('name'),
            'sku' => $this->request->getPost('sku'),
            'category_id' => (int) $this->request->getPost('category_id'),
            'unit_id' => (int) $this->request->getPost('unit_id'),
            'default_supplier_id' => $this->request->getPost('supplier_id') ?: null,
            'cost_price' => (float) ($this->request->getPost('cost_price') ?: 0),
            'sell_price' => (float) $this->request->getPost('sell_price'),
            'wholesale_price' => (float) ($this->request->getPost('wholesale_price') ?: 0),
            'member_price' => (float) ($this->request->getPost('member_price') ?: 0),
            'min_wholesale_qty' => (int) ($this->request->getPost('min_wholesale_qty') ?: 1),
            'min_stock' => (int) ($this->request->getPost('min_stock') ?: 0),
            'stock_alert' => (int) ($this->request->getPost('stock_alert') ?: 10),
            'reorder_qty' => (int) ($this->request->getPost('reorder_qty') ?: 50),
            'reorder_days_target' => (int) ($this->request->getPost('reorder_days_target') ?: 14),
            'has_serial_number' => $this->request->getPost('has_serial_number') ? 1 : 0,
            'has_expired_date' => $this->request->getPost('has_expired_date') ? 1 : 0,
            'warranty_months' => (int) ($this->request->getPost('warranty_months') ?: 0),
            'description' => $this->request->getPost('description'),
            'is_active' => 1,
        ];

        $productId = (new ProductModel())->insert($productData);

        if ($this->request->getPost('stock')) {
            (new \App\Models\ProductStockModel())->insert([
                'product_id' => $productId,
                'branch_id' => $this->currentBranchId() ?: 1,
                'stock' => (int) $this->request->getPost('stock'),
                'updated_at' => date('Y-m-d H:i:s'),
            ]);
        }

        // Multi satuan
        if ($this->request->getPost('product_units')) {
            $unitRows = $this->request->getPost('product_units');
            $defaultUnitId = (int) $this->request->getPost('unit_id');
            foreach ($unitRows as $row) {
                $unitId = (int) ($row['unit_id'] ?? 0);
                if ($unitId < 1) continue;
                (new ProductUnitModel())->insert([
                    'product_id' => $productId,
                    'unit_id' => $unitId,
                    'factor' => (float) ($row['factor'] ?: 1),
                    'price' => (float) ($row['price'] ?: 0),
                    'is_default' => ($unitId === $defaultUnitId) ? 1 : 0,
                ]);
            }
        }

        // Multi harga tiered
        if ($this->request->getPost('price_tiers')) {
            $tiers = $this->request->getPost('price_tiers');
            foreach ($tiers as $row) {
                $minQty = (int) ($row['min_qty'] ?? 0);
                if ($minQty < 1) continue;
                (new ProductPriceTierModel())->insert([
                    'product_id' => $productId,
                    'min_qty' => $minQty,
                    'price' => (float) ($row['price'] ?: 0),
                ]);
            }
        }

        $db->transComplete();

        if ($db->transStatus()) {
            return redirect()->to(site_url('products'))->with('success', 'Produk berhasil ditambahkan.');
        }

        return redirect()->back()->withInput()->with('error', 'Gagal menyimpan produk.');
    }

    public function edit($id = null)
    {
        $product = (new ProductModel())->withUnits()->withTiers()->find($id);
        if (!$product) {
            return redirect()->to(site_url('products'))->with('error', 'Produk tidak ditemukan.');
        }

        $units = (new UnitModel())->where('is_active', 1)->findAll();
        $categories = (new CategoryModel())->where('is_active', 1)->findAll();

        return $this->view('products/form', [
            'product' => $product,
            'units' => $units,
            'categories' => $categories,
            'is_new' => false,
        ]);
    }

    public function update($id = null)
    {
        $product = (new ProductModel())->find($id);
        if (!$product) {
            return redirect()->to(site_url('products'))->with('error', 'Produk tidak ditemukan.');
        }

        $rules = [
            'name' => 'required|min_length[3]|max_length[200]',
            'sku'  => 'required|min_length[3]|max_length[50]|is_unique[products.sku,id,' . $id . ']',
            'category_id' => 'required|is_natural_no_zero',
            'sell_price' => 'required|numeric|greater_than_equal_to[0]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $db = \Config\Database::connect();
        $db->transStart();

        $updateData = [
            'name' => $this->request->getPost('name'),
            'sku' => $this->request->getPost('sku'),
            'category_id' => (int) $this->request->getPost('category_id'),
            'unit_id' => (int) $this->request->getPost('unit_id'),
            'default_supplier_id' => $this->request->getPost('supplier_id') ?: null,
            'cost_price' => (float) ($this->request->getPost('cost_price') ?: 0),
            'sell_price' => (float) $this->request->getPost('sell_price'),
            'wholesale_price' => (float) ($this->request->getPost('wholesale_price') ?: 0),
            'member_price' => (float) ($this->request->getPost('member_price') ?: 0),
            'min_wholesale_qty' => (int) ($this->request->getPost('min_wholesale_qty') ?: 1),
            'min_stock' => (int) ($this->request->getPost('min_stock') ?: 0),
            'stock_alert' => (int) ($this->request->getPost('stock_alert') ?: 10),
            'reorder_qty' => (int) ($this->request->getPost('reorder_qty') ?: 50),
            'reorder_days_target' => (int) ($this->request->getPost('reorder_days_target') ?: 14),
            'has_serial_number' => $this->request->getPost('has_serial_number') ? 1 : 0,
            'has_expired_date' => $this->request->getPost('has_expired_date') ? 1 : 0,
            'warranty_months' => (int) ($this->request->getPost('warranty_months') ?: 0),
            'description' => $this->request->getPost('description'),
        ];

        (new ProductModel())->update($id, $updateData);

        // Update default unit
        if ($this->request->getPost('unit_id')) {
            (new ProductUnitModel())->where('product_id', $id)->set('is_default', 0)->update();
            (new ProductUnitModel())->updateOrCreate(
                ['product_id' => $id, 'unit_id' => (int) $this->request->getPost('unit_id')],
                ['factor' => 1, 'price' => (float) ($this->request->getPost('sell_price') ?: 0), 'is_default' => 1]
            );
        }

        // Hapus & insert ulang tiered price
        (new ProductPriceTierModel())->where('product_id', $id)->delete();
        if ($this->request->getPost('price_tiers')) {
            $tiers = $this->request->getPost('price_tiers');
            foreach ($tiers as $row) {
                $minQty = (int) ($row['min_qty'] ?? 0);
                if ($minQty < 1) continue;
                (new ProductPriceTierModel())->insert([
                    'product_id' => $id,
                    'min_qty' => $minQty,
                    'price' => (float) ($row['price'] ?: 0),
                ]);
            }
        }

        $db->transComplete();

        if ($db->transStatus()) {
            return redirect()->to(site_url('products'))->with('success', 'Produk berhasil diperbarui.');
        }

        return redirect()->back()->withInput()->with('error', 'Gagal memperbarui produk.');
    }

    public function delete($id = null)
    {
        $product = (new ProductModel())->find($id);
        if (!$product) {
            return redirect()->to(site_url('products'))->with('error', 'Produk tidak ditemukan.');
        }

        (new ProductModel())->delete($id);
        (new ProductUnitModel())->where('product_id', $id)->delete();
        (new ProductPriceTierModel())->where('product_id', $id)->delete();
        (new \App\Models\ProductStockModel())->where('product_id', $id)->delete();

        return redirect()->to(site_url('products'))->with('success', 'Produk berhasil dihapus.');
    }

    public function apiSearch()
    {
        $q = $this->request->getGet('q') ?: '';
        $branchId = $this->currentBranchId() ?: 1;
        $limit = (int) ($this->request->getGet('limit') ?: 30);

        if (strlen($q) < 1) {
            return $this->response->setJSON(['products' => []]);
        }

        $db = \Config\Database::connect();

        $products = $db->table('products p')
            ->select('p.*, c.name AS category_name,
                (SELECT COALESCE(SUM(ps.stock),0) FROM product_stocks ps 
                 WHERE ps.product_id = p.id AND ps.branch_id = ' . (int) $branchId . ') AS stock')
            ->join('categories c', 'c.id = p.category_id', 'left')
            ->groupStart()
                ->like('p.name', $q)
                ->orLike('p.sku', $q)
                ->orLike('p.barcode', $q)
            ->groupEnd()
            ->where('p.is_active', 1)
            ->orderBy('p.name', 'ASC')
            ->limit($limit)
            ->get()->getResultArray();

        foreach ($products as &$p) {
            $p['stock'] = (float) ($p['stock'] ?? 0);
        }

        return $this->response->setJSON(['products' => $products]);
    }
}