<?php

namespace App\Controllers;

/**
 * Trait/base helper untuk CRUD sederhana (categories, units, expeditions, dll).
 * Setiap controller turunan cukup mendefinisikan $modelClass, $viewPath, $title, $rules.
 */
abstract class SimpleCrudController extends BaseController
{
    protected string $modelClass = '';
    protected string $viewPath   = '';   // ex: 'categories'
    protected string $title      = '';
    protected array  $rules      = [];

    public function index()
    {
        $model = new ($this->modelClass)();
        $rows = method_exists($model, 'withLevel') ? $model->withLevel()->findAll() : $model->findAll();
        return $this->view($this->viewPath . '/index', ['rows'=>$rows,'title'=>$this->title]);
    }

    public function new()
    {
        return $this->view($this->viewPath . '/form', ['row'=>null,'title'=>$this->title]);
    }

    public function create()
    {
        $data = $this->request->getPost();
        if ($this->rules && ! $this->validate($this->rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        (new ($this->modelClass)())->insert($data);
        $this->audit('create', (new ($this->modelClass)())->table, null, null, $data);
        return redirect()->to('/'.$this->viewPath)->with('success', $this->title.' berhasil ditambahkan');
    }

    public function edit($id = null)
    {
        $row = (new ($this->modelClass)())->find($id);
        if (! $row) return redirect()->to('/'.$this->viewPath);
        return $this->view($this->viewPath . '/form', ['row'=>$row,'title'=>$this->title]);
    }

    public function update($id = null)
    {
        $data = $this->request->getPost();
        if ($this->rules && ! $this->validate($this->rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        (new ($this->modelClass)())->update($id, $data);
        $this->audit('update', (new ($this->modelClass)())->table, $id, null, $data);
        return redirect()->to('/'.$this->viewPath)->with('success', $this->title.' berhasil diperbarui');
    }

    public function delete($id = null)
    {
        (new ($this->modelClass)())->delete($id);
        $this->audit('delete', (new ($this->modelClass)())->table, $id);
        return redirect()->to('/'.$this->viewPath)->with('success', $this->title.' berhasil dihapus');
    }
}

class Categories extends SimpleCrudController {
    protected string $modelClass = \App\Models\CategoryModel::class;
    protected string $viewPath   = 'categories';
    protected string $title      = 'Kategori';
    protected array  $rules      = ['name'=>'required|min_length[2]'];
}
class Units extends SimpleCrudController {
    protected string $modelClass = \App\Models\UnitModel::class;
    protected string $viewPath   = 'units';
    protected string $title      = 'Satuan';
    protected array  $rules      = ['name'=>'required|min_length[1]'];
}
class Expeditions extends SimpleCrudController {
    protected string $modelClass = \App\Models\ExpeditionModel::class;
    protected string $viewPath   = 'expeditions';
    protected string $title      = 'Ekspedisi';
    protected array  $rules      = ['name'=>'required'];
}
class Suppliers extends SimpleCrudController {
    protected string $modelClass = \App\Models\SupplierModel::class;
    protected string $viewPath   = 'suppliers';
    protected string $title      = 'Supplier';
    protected array  $rules      = ['name'=>'required'];
}
class Branches extends SimpleCrudController {
    protected string $modelClass = \App\Models\BranchModel::class;
    protected string $viewPath   = 'branches';
    protected string $title      = 'Cabang';
    protected array  $rules      = ['code'=>'required','name'=>'required'];
}
class CustomerLevels extends SimpleCrudController {
    protected string $modelClass = \App\Models\CustomerLevelModel::class;
    protected string $viewPath   = 'customer-levels';
    protected string $title      = 'Level Customer';
    protected array  $rules      = ['name'=>'required'];
}
class Customers extends SimpleCrudController {
    protected string $modelClass = \App\Models\CustomerModel::class;
    protected string $viewPath   = 'customers';
    protected string $title      = 'Customer';
    protected array  $rules      = ['name'=>'required'];
}
