<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class Receivables extends BaseController
{
    public function index()
    {
        return $this->view('piutang/index');
    }

    public function detail($id = null)
    {
        return $this->view('piutang/detail');
    }

    public function pay($id = null)
    {
        return redirect()->to('/receivables');
    }
}
