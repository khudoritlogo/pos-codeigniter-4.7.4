<?php

namespace App\Controllers;

use App\Models\PurchaseModel;
use App\Models\PurchaseItemModel;
use App\Models\PayableModel;
use App\Models\ProductModel;

class Purchases extends BaseController
{
    public function index() {
        $rows = \Config\Database::connect()->query("
            SELECT p.*, s.name AS supplier_name, u.fullname AS user_name
            FROM purchases p JOIN suppliers s ON s.id=p.supplier_id LEFT JOIN users u ON u.id=p.user_id
            WHERE p.deleted_at IS NULL ORDER BY p.id DESC LIMIT 200
        ")->getResultArray();
        return $this->view('purchases/index',['rows'=>$rows]);
    }

    public function new() {
        return $this->view('purchases/form',[
            'suppliers'=>model('SupplierModel')->where('is_active',1)->findAll(),
            'products' =>model('ProductModel')->where('is_active',1)->findAll(),
        ]);
    }

    public function create() {
        $payload = $this->request->getJSON(true) ?: $this->request->getPost();
        $items   = $payload['items'] ?? [];
        if (empty($items)) return $this->response->setJSON(['ok'=>false,'msg'=>'Item kosong'])->setStatusCode(400);

        $db = \Config\Database::connect();
        $db->transStart();
        $branchId = $this->currentBranchId() ?? 1;
        $model = new PurchaseModel();
        $subtotal = array_sum(array_column($items,'subtotal'));
        $total = $subtotal - (float) ($payload['discount_amount'] ?? 0) + (float) ($payload['tax_amount'] ?? 0);
        $paid  = (float) ($payload['paid'] ?? $total);
        $debt  = $paid < $total ? ($total - $paid) : 0;
        $inv = $model->generateInvoiceNo($branchId);
        $id = $model->insert([
            'invoice_no'=>$inv,'branch_id'=>$branchId,'supplier_id'=>$payload['supplier_id'],
            'user_id'=>$this->currentUserId(),'purchase_date'=>date('Y-m-d H:i:s'),
            'subtotal'=>$subtotal,'discount_amount'=>$payload['discount_amount']??0,
            'tax_amount'=>$payload['tax_amount']??0,'total'=>$total,'paid'=>$paid,'debt_amount'=>$debt,
            'payment_method'=>$payload['payment_method']??'cash','status'=>'completed','notes'=>$payload['notes']??null,
        ], true);

        $itemModel = new PurchaseItemModel();
        $prod = new ProductModel();
        foreach ($items as $it) {
            $itemModel->insert([
                'purchase_id'=>$id,'product_id'=>$it['product_id'],
                'serial_number'=>$it['serial_number']??null,'qty'=>$it['qty'],
                'cost_price'=>$it['cost_price'],'subtotal'=>$it['subtotal'],
                'expired_date'=>$it['expired_date']??null,'batch_code'=>$it['batch_code']??null,
            ]);
            $prod->adjustStock((int)$it['product_id'],$branchId,(float)$it['qty'],'purchase',$id,$inv);
            $prod->update((int)$it['product_id'],['cost_price'=>$it['cost_price']]);
            // SN
            if (! empty($it['serial_number'])) {
                $db->table('product_serials')->insert([
                    'product_id'=>$it['product_id'],'branch_id'=>$branchId,
                    'serial_number'=>$it['serial_number'],'status'=>'in_stock',
                    'purchase_id'=>$id,'created_at'=>date('Y-m-d H:i:s'),
                ]);
            }
            // Batch
            if (! empty($it['expired_date'])) {
                $db->table('product_batches')->insert([
                    'product_id'=>$it['product_id'],'branch_id'=>$branchId,
                    'batch_code'=>$it['batch_code']??null,'qty'=>$it['qty'],
                    'expired_date'=>$it['expired_date'],'created_at'=>date('Y-m-d H:i:s'),
                ]);
            }
        }
        if ($debt > 0) {
            (new PayableModel())->insert([
                'purchase_id'=>$id,'supplier_id'=>$payload['supplier_id'],
                'amount'=>$debt,'paid_amount'=>0,'remaining'=>$debt,
                'due_date'=>date('Y-m-d',strtotime('+30 days')),'status'=>'unpaid',
            ]);
        }
        $this->audit('create_purchase','purchases',$id,null,['invoice'=>$inv,'total'=>$total]);
        $db->transComplete();
        return $this->response->setJSON(['ok'=>$db->transStatus(),'id'=>$id,'invoice_no'=>$inv]);
    }

    public function show($id=null) {
        $p = model('PurchaseModel')->find($id);
        $items = \Config\Database::connect()->query("SELECT pi.*, p.name AS product_name FROM purchase_items pi JOIN products p ON p.id=pi.product_id WHERE purchase_id=?",[$id])->getResultArray();
        return $this->view('purchases/detail',['p'=>$p,'items'=>$items]);
    }
}

class SaleReturns extends BaseController {
    public function index() {
        $rows = \Config\Database::connect()->query("
            SELECT r.*, s.invoice_no, u.fullname FROM sale_returns r JOIN sales s ON s.id=r.sale_id
            LEFT JOIN users u ON u.id=r.user_id ORDER BY r.id DESC LIMIT 200
        ")->getResultArray();
        return $this->view('returns/sale_index',['rows'=>$rows]);
    }
    public function new() {
        return $this->view('returns/sale_form',['row'=>null]);
    }
    public function create() {
        $d = $this->request->getJSON(true) ?: $this->request->getPost();
        $items = $d['items'] ?? [];
        $db = \Config\Database::connect(); $db->transStart();
        $rNo = 'SR-'.date('Ymd-His');
        $total = array_sum(array_column($items,'subtotal'));
        $db->table('sale_returns')->insert([
            'return_no'=>$rNo,'sale_id'=>$d['sale_id'],'branch_id'=>$this->currentBranchId()??1,
            'user_id'=>$this->currentUserId(),'return_date'=>date('Y-m-d H:i:s'),
            'total'=>$total,'reason'=>$d['reason']??null,'created_at'=>date('Y-m-d H:i:s'),
        ]);
        $id = $db->insertID();
        $prod = new \App\Models\ProductModel();
        foreach ($items as $it) {
            $db->table('sale_return_items')->insert([
                'return_id'=>$id,'product_id'=>$it['product_id'],
                'serial_number'=>$it['serial_number']??null,
                'qty'=>$it['qty'],'price'=>$it['price'],'subtotal'=>$it['subtotal'],
            ]);
            $prod->adjustStock((int)$it['product_id'],$this->currentBranchId()??1,(float)$it['qty'],'sale_return',$id,$rNo);
        }
        $db->transComplete();
        return $this->response->setJSON(['ok'=>$db->transStatus(),'return_no'=>$rNo]);
    }
}

class PurchaseReturns extends BaseController {
    public function index() {
        $rows = \Config\Database::connect()->query("
            SELECT r.*, p.invoice_no FROM purchase_returns r JOIN purchases p ON p.id=r.purchase_id
            ORDER BY r.id DESC LIMIT 200
        ")->getResultArray();
        return $this->view('returns/purchase_index',['rows'=>$rows]);
    }
    public function new() { return $this->view('returns/purchase_form',['row'=>null]); }
    public function create() {
        $d = $this->request->getJSON(true) ?: $this->request->getPost();
        $items = $d['items'] ?? [];
        $db = \Config\Database::connect(); $db->transStart();
        $rNo='PR-'.date('Ymd-His');
        $total = array_sum(array_column($items,'subtotal'));
        $db->table('purchase_returns')->insert([
            'return_no'=>$rNo,'purchase_id'=>$d['purchase_id'],'branch_id'=>$this->currentBranchId()??1,
            'user_id'=>$this->currentUserId(),'return_date'=>date('Y-m-d H:i:s'),
            'total'=>$total,'reason'=>$d['reason']??null,'created_at'=>date('Y-m-d H:i:s'),
        ]);
        $id=$db->insertID();
        $prod = new \App\Models\ProductModel();
        foreach ($items as $it) {
            $db->table('purchase_return_items')->insert([
                'return_id'=>$id,'product_id'=>$it['product_id'],
                'qty'=>$it['qty'],'cost_price'=>$it['cost_price'],'subtotal'=>$it['subtotal'],
            ]);
            $prod->adjustStock((int)$it['product_id'],$this->currentBranchId()??1,-(float)$it['qty'],'purchase_return',$id,$rNo);
        }
        $db->transComplete();
        return $this->response->setJSON(['ok'=>$db->transStatus(),'return_no'=>$rNo]);
    }
}

class Receivables extends BaseController {
    public function index() {
        $rows = \Config\Database::connect()->query("
            SELECT r.*, c.name AS customer_name, s.invoice_no FROM receivables r
            JOIN customers c ON c.id=r.customer_id JOIN sales s ON s.id=r.sale_id
            ORDER BY r.status ASC, r.due_date ASC LIMIT 500
        ")->getResultArray();
        return $this->view('piutang/index',['rows'=>$rows]);
    }
    public function overdue() {
        $rows = \Config\Database::connect()->query("
            SELECT r.*, c.name AS customer_name, s.invoice_no FROM receivables r
            JOIN customers c ON c.id=r.customer_id JOIN sales s ON s.id=r.sale_id
            WHERE r.status IN ('unpaid','partial') AND r.due_date < CURDATE()
            ORDER BY r.due_date ASC
        ")->getResultArray();
        return $this->view('piutang/overdue',['rows'=>$rows]);
    }
    public function detail(int $id) {
        $r = model('ReceivableModel')->find($id);
        $payments = \Config\Database::connect()->query("SELECT * FROM receivable_payments WHERE receivable_id=? ORDER BY id DESC",[$id])->getResultArray();
        return $this->view('piutang/detail',['r'=>$r,'payments'=>$payments]);
    }
    public function pay(int $id) {
        $amount = (float) $this->request->getPost('amount');
        $r = model('ReceivableModel')->find($id);
        if (! $r) return redirect()->back();
        $db = \Config\Database::connect(); $db->transStart();
        $db->table('receivable_payments')->insert([
            'receivable_id'=>$id,'user_id'=>$this->currentUserId(),
            'payment_date'=>date('Y-m-d H:i:s'),'amount'=>$amount,
            'method'=>$this->request->getPost('method')?:'cash',
            'notes'=>$this->request->getPost('notes'),
        ]);
        $paid = $r['paid_amount'] + $amount;
        $remaining = $r['amount'] - $paid;
        $status = $remaining <= 0 ? 'paid' : ($paid > 0 ? 'partial' : 'unpaid');
        model('ReceivableModel')->update($id, ['paid_amount'=>$paid,'remaining'=>max(0,$remaining),'status'=>$status]);
        $db->transComplete();
        return redirect()->to('/receivables/'.$id)->with('success','Pembayaran cicilan tercatat');
    }
}

class Payables extends BaseController {
    public function index() {
        $rows = \Config\Database::connect()->query("
            SELECT p.*, s.name AS supplier_name, pu.invoice_no FROM payables p
            JOIN suppliers s ON s.id=p.supplier_id JOIN purchases pu ON pu.id=p.purchase_id
            ORDER BY p.status ASC, p.due_date ASC LIMIT 500
        ")->getResultArray();
        return $this->view('hutang/index',['rows'=>$rows]);
    }
    public function overdue() {
        $rows = \Config\Database::connect()->query("
            SELECT p.*, s.name AS supplier_name, pu.invoice_no FROM payables p
            JOIN suppliers s ON s.id=p.supplier_id JOIN purchases pu ON pu.id=p.purchase_id
            WHERE p.status IN ('unpaid','partial') AND p.due_date < CURDATE()
            ORDER BY p.due_date ASC
        ")->getResultArray();
        return $this->view('hutang/overdue',['rows'=>$rows]);
    }
    public function detail(int $id) {
        $p = model('PayableModel')->find($id);
        $payments = \Config\Database::connect()->query("SELECT * FROM payable_payments WHERE payable_id=? ORDER BY id DESC",[$id])->getResultArray();
        return $this->view('hutang/detail',['p'=>$p,'payments'=>$payments]);
    }
    public function pay(int $id) {
        $amount = (float) $this->request->getPost('amount');
        $p = model('PayableModel')->find($id);
        if (! $p) return redirect()->back();
        $db = \Config\Database::connect(); $db->transStart();
        $db->table('payable_payments')->insert([
            'payable_id'=>$id,'user_id'=>$this->currentUserId(),
            'payment_date'=>date('Y-m-d H:i:s'),'amount'=>$amount,
            'method'=>$this->request->getPost('method')?:'cash','notes'=>$this->request->getPost('notes'),
        ]);
        $paid = $p['paid_amount'] + $amount;
        $remaining = $p['amount'] - $paid;
        $status = $remaining <= 0 ? 'paid' : ($paid > 0 ? 'partial' : 'unpaid');
        model('PayableModel')->update($id, ['paid_amount'=>$paid,'remaining'=>max(0,$remaining),'status'=>$status]);
        $db->transComplete();
        return redirect()->to('/payables/'.$id)->with('success','Pembayaran cicilan tercatat');
    }
}

class StockTransfers extends BaseController {
    public function index() {
        $rows = \Config\Database::connect()->query("
            SELECT t.*, b1.name AS from_name, b2.name AS to_name, u.fullname
            FROM stock_transfers t
            JOIN branches b1 ON b1.id=t.from_branch_id JOIN branches b2 ON b2.id=t.to_branch_id
            LEFT JOIN users u ON u.id=t.user_id ORDER BY t.id DESC LIMIT 200
        ")->getResultArray();
        return $this->view('transfers/index',['rows'=>$rows]);
    }
    public function new() {
        return $this->view('transfers/form',[
            'branches'=>model('BranchModel')->findAll(),
            'products'=>model('ProductModel')->findAll(),
        ]);
    }
    public function create() {
        $d = $this->request->getJSON(true) ?: $this->request->getPost();
        $items = $d['items'] ?? [];
        $db = \Config\Database::connect(); $db->transStart();
        $tNo = 'TRF-'.date('Ymd-His');
        $db->table('stock_transfers')->insert([
            'transfer_no'=>$tNo,'from_branch_id'=>$d['from_branch_id'],'to_branch_id'=>$d['to_branch_id'],
            'user_id'=>$this->currentUserId(),'transfer_date'=>date('Y-m-d H:i:s'),
            'status'=>'completed','notes'=>$d['notes']??null,'created_at'=>date('Y-m-d H:i:s'),
        ]);
        $id = $db->insertID();
        $prod = new \App\Models\ProductModel();
        foreach ($items as $it) {
            $db->table('stock_transfer_items')->insert(['transfer_id'=>$id,'product_id'=>$it['product_id'],'qty'=>$it['qty']]);
            $prod->adjustStock((int)$it['product_id'],(int)$d['from_branch_id'],-(float)$it['qty'],'transfer_out',$id,$tNo);
            $prod->adjustStock((int)$it['product_id'],(int)$d['to_branch_id'], (float)$it['qty'],'transfer_in', $id,$tNo);
        }
        $db->transComplete();
        return $this->response->setJSON(['ok'=>$db->transStatus(),'transfer_no'=>$tNo]);
    }
}

class StockOpnames extends BaseController {
    public function index() {
        $rows = \Config\Database::connect()->query("
            SELECT o.*, b.name AS branch_name, u.fullname FROM stock_opnames o
            JOIN branches b ON b.id=o.branch_id LEFT JOIN users u ON u.id=o.user_id
            ORDER BY o.id DESC LIMIT 200
        ")->getResultArray();
        return $this->view('opname/index',['rows'=>$rows]);
    }
    public function new() {
        $branchId = $this->currentBranchId() ?? 1;
        $products = \Config\Database::connect()->query("
            SELECT p.id,p.sku,p.name,COALESCE(ps.stock,0) AS system_qty
            FROM products p LEFT JOIN product_stocks ps ON ps.product_id=p.id AND ps.branch_id=?
            WHERE p.deleted_at IS NULL AND p.is_active=1
        ",[$branchId])->getResultArray();
        return $this->view('opname/form',['products'=>$products]);
    }
    public function create() {
        $d = $this->request->getJSON(true) ?: $this->request->getPost();
        $items = $d['items'] ?? [];
        $db = \Config\Database::connect(); $db->transStart();
        $no = 'SO-'.date('Ymd-His');
        $branchId = $this->currentBranchId() ?? 1;
        $db->table('stock_opnames')->insert([
            'opname_no'=>$no,'branch_id'=>$branchId,'user_id'=>$this->currentUserId(),
            'opname_date'=>date('Y-m-d H:i:s'),'notes'=>$d['notes']??null,'status'=>'completed',
        ]);
        $id = $db->insertID();
        $prod = new \App\Models\ProductModel();
        foreach ($items as $it) {
            $diff = (float) $it['physical_qty'] - (float) $it['system_qty'];
            $db->table('stock_opname_items')->insert([
                'opname_id'=>$id,'product_id'=>$it['product_id'],
                'system_qty'=>$it['system_qty'],'physical_qty'=>$it['physical_qty'],
                'difference'=>$diff,'notes'=>$it['notes']??null,
            ]);
            if ($diff != 0) {
                $prod->adjustStock((int)$it['product_id'],$branchId,$diff,'opname',$id,'Opname '.$no);
            }
        }
        $db->transComplete();
        return $this->response->setJSON(['ok'=>$db->transStatus(),'opname_no'=>$no]);
    }
}
