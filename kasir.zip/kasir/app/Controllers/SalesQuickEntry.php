<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class SalesQuickEntry extends BaseController
{
    public function index()
    {
        $db = \Config\Database::connect();
        $branchId = $this->currentBranchId() ?? 1;
        
        // Produk untuk quick entry
        $products = $db->table('products')
            ->select('products.*, c.name AS category_name')
            ->join('categories c', 'c.id = products.category_id', 'left')
            ->where('products.is_active', 1)
            ->orderBy('products.name', 'ASC')
            ->limit(100)
            ->get()
            ->getResultArray();
        
        // Customer aktif untuk quick entry
        $customers = $db->table('customers')
            ->select('customers.*, cl.name AS level_name')
            ->join('customer_levels cl', 'cl.id = customers.level_id', 'left')
            ->where('customers.is_active', 1)
            ->orderBy('customers.name', 'ASC')
            ->limit(20)
            ->get()
            ->getResultArray();
        
        return $this->view('sales/quick_entry', [
            'products' => $products,
            'customers' => $customers,
        ]);
    }
}
