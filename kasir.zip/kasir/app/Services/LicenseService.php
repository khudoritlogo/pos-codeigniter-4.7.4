<?php

namespace App\Services;

use App\Models\LicenseModel;
use CodeIgniter\Config\Services as BaseServices;

class LicenseService
{
    protected LicenseModel $licenseModel;

    public function __construct()
    {
        $this->licenseModel = model(LicenseModel::class);
    }

    public function generateKey(): string
    {
        do {
            $key = 'PK-' . strtoupper(substr(md5(uniqid() . random_bytes(16)), 0, 5))
                      . '-' . strtoupper(substr(md5(uniqid() . random_bytes(16)), 5, 5))
                      . '-' . strtoupper(substr(md5(uniqid() . random_bytes(16)), 10, 5));
        } while ($this->licenseModel->findByKey($key));

        return $key;
    }

    public function createLicense(string $key, ?string $customerName = null, ?string $customerEmail = null, ?string $orderId = null): array
    {
        $data = [
            'license_key'   => $key,
            'status'        => 'pending',
            'customer_name' => $customerName,
            'customer_email'=> $customerEmail,
            'order_id'      => $orderId,
            'created_at'    => date('Y-m-d H:i:s'),
        ];

        $this->licenseModel->insert($data);
        $id = $this->licenseModel->getInsertID();

        return $this->licenseModel->find($id);
    }

    public function findById(int $id): ?array
    {
        return $this->licenseModel->find($id);
    }

    public function findByKey(string $key): ?array
    {
        return $this->licenseModel->findByKey($key);
    }

    public function getActiveLicense(): ?array
    {
        return $this->licenseModel->getActiveLicense();
    }

    public function getAllLicenses(): array
    {
        return $this->licenseModel->getAll();
    }

    public function activateLicense(string $key, string $domain, string $ipAddress, string $serverName): ?array
    {
        $license = $this->licenseModel->findByKey($key);
        if (!$license) return null;

        $oldDomain = $license['domain'];
        $oldIp     = $license['ip_address'];

        $data = [
            'status'        => 'active',
            'domain'        => $domain,
            'ip_address'    => $ipAddress,
            'server_name'   => $serverName,
            'activated_at'  => date('Y-m-d H:i:s'),
            'updated_at'    => date('Y-m-d H:i:s'),
        ];

        $this->licenseModel->update($license['id'], $data);

        // Log aktivasi
        $this->logActivation($license['id'], 'activate', $oldDomain, $domain, $oldIp, $ipAddress);

        // Kirim notifikasi ke owner
        $this->sendActivationNotification($license);

        return $this->licenseModel->find($license['id']);
    }

    public function deactivateLicense(int $id, ?int $performedBy = null, string $reason = ''): bool
    {
        $license = $this->licenseModel->find($id);
        if (!$license) return false;

        $oldDomain = $license['domain'];
        $oldIp     = $license['ip_address'];

        $data = [
            'status'      => 'revoked',
            'domain'      => null,
            'ip_address'  => null,
            'server_name' => null,
            'updated_at'  => date('Y-m-d H:i:s'),
        ];

        $this->licenseModel->update($id, $data);

        $this->logActivation($id, 'deactivate', $oldDomain, null, $oldIp, null, $reason, $performedBy);

        return true;
    }

    public function transferLicense(int $id, string $newDomain, string $newIp, string $newServer, ?int $performedBy = null): ?array
    {
        $license = $this->licenseModel->find($id);
        if (!$license || $license['status'] !== 'active') return null;

        $oldDomain = $license['domain'];
        $oldIp     = $license['ip_address'];

        // Deaktivasi di domain lama
        $this->licenseModel->update($id, [
            'domain'       => $newDomain,
            'ip_address'   => $newIp,
            'server_name'  => $newServer,
            'status'       => 'active',
            'activated_at' => date('Y-m-d H:i:s'),
            'updated_at'   => date('Y-m-d H:i:s'),
        ]);

        $this->logActivation($id, 'transfer', $oldDomain, $newDomain, $oldIp, $newIp, 'Transfer lisensi ke domain baru', $performedBy);

        $this->sendTransferNotification($license);

        return $this->licenseModel->find($id);
    }

    public function revokeLicense(int $id, ?int $performedBy = null, string $reason = ''): bool
    {
        return $this->deactivateLicense($id, $performedBy, $reason);
    }

    protected function logActivation(int $licenseId, string $action, ?string $oldDomain, ?string $newDomain, ?string $oldIp, ?string $newIp, string $notes = '', ?int $performedBy = null)
    {
        $db = \Config\Database::connect();
        $db->table('license_activation_logs')->insert([
            'license_id' => $licenseId,
            'action'     => $action,
            'old_domain' => $oldDomain,
            'new_domain' => $newDomain,
            'old_ip'     => $oldIp,
            'new_ip'     => $newIp,
            'performed_by'=> $performedBy,
            'notes'      => $notes,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    protected function sendActivationNotification(array $license): void
    {
        $ownerEmail = env('license.owner_email', 'khudoritlogo@gmail.com');
        if (empty($ownerEmail)) return;

        $subject = "🔔 Aktivasi Lisensi Baru - {$license['license_key']}";
        $body = $this->buildActivationEmailBody($license);

        $this->sendNotification($ownerEmail, $subject, $body, 'activation', $license['id']);
    }

    protected function sendTransferNotification(array $license): void
    {
        $ownerEmail = env('license.owner_email', 'khudoritlogo@gmail.com');
        if (empty($ownerEmail)) return;

        $subject = "🔄 Transfer Lisensi - {$license['license_key']}";
        $body = $this->buildTransferEmailBody($license);

        $this->sendNotification($ownerEmail, $subject, $body, 'transfer', $license['id']);
    }

    protected function sendNotification(string $to, string $subject, string $body, string $type, int $licenseId): void
    {
        // Coba kirim via SMTP jika tersedia
        $smtpHost = env('smtp.host');
        if (!empty($smtpHost)) {
            $this->sendSmtpEmail($to, $subject, $body);
            $this->logNotification($licenseId, $type, $to, $subject, $body, 'sent');
            return;
        }

        // Fallback: kirim via HTTP webhook
        $webhookUrl = env('license.webhook_url');
        if (!empty($webhookUrl)) {
            $this->sendWebhook($webhookUrl, [
                'type'          => $type,
                'to'            => $to,
                'subject'       => $subject,
                'body'          => $body,
                'license_key'   => $licenseId,
                'sent_at'       => date('Y-m-d H:i:s'),
            ]);
            $this->logNotification($licenseId, $type, $to, $subject, $body, 'pending');
            return;
        }

        // Fallback terakhir: log saja
        log_message('info', "[LICENSE] Tidak ada SMTP/webhook yang dikonfigurasi. Email tidak terkirim.\nSubject: {$subject}\nBody: {$body}");
        $this->logNotification($licenseId, $type, $to, $subject, $body, 'failed', 'Tidak ada SMTP/webhook yang dikonfigurasi');
    }

    protected function sendSmtpEmail(string $to, string $subject, string $body): void
    {
        $smtp = \Config\Services::email();
        $smtp->setTo($to);
        $smtp->setFrom(env('smtp.fromEmail', 'noreply@poskasir.app'), env('smtp.fromName', 'POS Kasir'));
        $smtp->setSubject($subject);
        $smtp->setMessage($body);
        $smtp->send();
    }

    protected function sendWebhook(string $url, array $payload): void
    {
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL            => $url,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 10,
        ]);
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        log_message('info', "[LICENSE WEBHOOK] URL: {$url} | HTTP: {$httpCode} | Response: " . substr($response ?? '', 0, 500));
    }

    protected function logNotification(int $licenseId, string $type, string $to, string $subject, string $body, string $status, string $error = ''): void
    {
        $db = \Config\Database::connect();
        $db->table('license_notifications')->insert([
            'license_id'      => $licenseId,
            'type'            => $type,
            'recipient'       => $to,
            'subject'         => $subject,
            'body'            => $body,
            'sent_at'         => date('Y-m-d H:i:s'),
            'delivery_status' => $status,
            'error'           => $error,
            'created_at'      => date('Y-m-d H:i:s'),
        ]);
    }

    protected function buildActivationEmailBody(array $license): string
    {
        $customerName = $license['customer_name'] ?? 'Tidak diketahui';
        $customerEmail = $license['customer_email'] ?? 'Tidak diketahui';
        $orderId = $license['order_id'] ?? '-';

        return "
PENGUMUMAN AKTIVASI LISENSI
=============================

License Key   : {$license['license_key']}
Status        : AKTIF
Domain        : {$license['domain']}
IP Server     : {$license['ip_address']}
Server Name   : {$license['server_name']}
Customer      : {$customerName}
Email Customer: {$customerEmail}
Order ID      : {$orderId}
Aktivasi Pada : {$license['activated_at']}

OTOMATIS DARI SISTEM POS KASIR
Jika ini bukan aktivasi yang kamu harapkan, segera kontak admin.
        ";
    }

    protected function buildTransferEmailBody(array $license): string
    {
        return "
INFORMASI TRANFFER LISENSI
===========================

License Key   : {$license['license_key']}
Status        : AKTIF (Ditransfer)
Domain Baru   : {$license['domain']}
IP Server Baru: {$license['ip_address']}
Server Name   : {$license['server_name']}
Aktivasi Pada : {$license['activated_at']}

Lisensi ini telah ditransfer ke domain baru.
        ";
    }

    public function validateLicense(string $key): array
    {
        $license = $this->licenseModel->findByKey($key);

        if (!$license) {
            return ['valid' => false, 'error' => 'License key tidak ditemukan'];
        }

        switch ($license['status']) {
            case 'active':
                return ['valid' => true, 'license' => $license];
            case 'pending':
                return ['valid' => false, 'error' => 'License belum diaktivasi. Lakukan aktivasi terlebih dahulu.'];
            case 'expired':
                return ['valid' => false, 'error' => 'Lisensi telah kedaluwarsa. Harap perpanjang.'];
            case 'revoked':
                return ['valid' => false, 'error' => 'Lisensi telah dicabut/dibatalkan admin.'];
            case 'transferred':
                return ['valid' => false, 'error' => 'Lisensi telah ditransfer ke domain lain.'];
            default:
                return ['valid' => false, 'error' => 'Status lisensi tidak diketahui.'];
        }
    }
}
