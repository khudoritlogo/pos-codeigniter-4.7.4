<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Purchase Orders'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <div class="mb-3 d-flex justify-content-between">
    <h5>Daftar PO</h5>
    <form method="post" action="/purchase-orders/auto-generate" onsubmit="return confirm('Generate PO otomatis untuk produk yang stoknya kritis?')">
      <?= csrf_field() ?>
      <button class="btn btn-warning"><i class="fas fa-magic"></i> Auto-Generate dari Predictive Restock</button>
    </form>
  </div>
  <table class="table datatable table-striped">
    <thead><tr><th>No. PO</th><th>Tanggal</th><th>Supplier</th><th>Cabang</th><th class="text-end">Total</th><th>Auto?</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= esc($r['po_number']) ?></td>
        <td><?= date('d/m/Y H:i', strtotime($r['created_at'])) ?></td>
        <td><?= esc($r['supplier_name']) ?></td>
        <td><?= esc($r['branch_name']) ?></td>
        <td class="text-end">Rp <?= number_format((float)$r['total_amount'],0,',','.') ?></td>
        <td><?= $r['is_auto'] ? '<span class="badge bg-info">AUTO</span>' : '<span class="badge bg-secondary">MANUAL</span>' ?></td>
        <td><span class="badge bg-<?= match($r['status']){'draft'=>'warning','sent'=>'primary','received'=>'success','cancelled'=>'danger',default=>'secondary'} ?>"><?= strtoupper($r['status']) ?></span></td>
         <a class="btn btn-sm btn-primary" href="<?= site_url('purchase-orders/' . $r['id']) ?>"><i class="fas fa-eye"></i></a>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
