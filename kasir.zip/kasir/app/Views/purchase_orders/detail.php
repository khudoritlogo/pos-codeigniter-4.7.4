<?= $this->extend('layouts/main') ?>
<?php $pageTitle='PO '.$po['po_number']; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <div class="d-flex justify-content-between mb-3">
    <div>
      <h4><?= esc($po['po_number']) ?> <?= $po['is_auto'] ? '<span class="badge bg-info">AUTO</span>' : '' ?></h4>
      <div><b>Supplier:</b> <?= esc($po['supplier_name']) ?> · <?= esc($po['supplier_phone']) ?></div>
      <div><b>Cabang:</b> <?= esc($po['branch_name']) ?></div>
      <div><b>Status:</b> <span class="badge bg-secondary"><?= strtoupper($po['status']) ?></span></div>
    </div>
    <div class="text-end">
      <?php if ($po['status'] === 'draft'): ?>
        <button class="btn btn-success" onclick="sharePo()"><i class="fab fa-whatsapp"></i> Kirim ke Supplier via WA</button>
        <form method="post" action="/purchase-orders/<?= $po['id'] ?>/send" class="d-inline"><?= csrf_field() ?><button class="btn btn-primary"><i class="fas fa-paper-plane"></i> Tandai Sudah Dikirim</button></form>
      <?php endif; ?>
      <?php if (in_array($po['status'], ['sent','draft'])): ?>
        <form method="post" action="/purchase-orders/<?= $po['id'] ?>/convert" class="d-inline" onsubmit="return confirm('Convert PO ini ke transaksi pembelian?')"><?= csrf_field() ?><button class="btn btn-success"><i class="fas fa-check"></i> Convert ke Pembelian</button></form>
        <form method="post" action="/purchase-orders/<?= $po['id'] ?>/cancel" class="d-inline" onsubmit="return confirm('Batalkan PO?')"><?= csrf_field() ?><button class="btn btn-danger"><i class="fas fa-times"></i> Batal</button></form>
      <?php endif; ?>
    </div>
  </div>

  <?php if (!empty($po['notes'])): ?><div class="alert alert-info small"><?= esc($po['notes']) ?></div><?php endif; ?>

  <table class="table table-bordered">
    <thead><tr><th>#</th><th>Produk</th><th>SKU</th><th class="text-end">Stok Skrg</th><th class="text-end">Rata2/hari</th><th class="text-end">Sisa Hari</th><th class="text-end">Qty Order</th><th class="text-end">Harga</th><th class="text-end">Subtotal</th></tr></thead>
    <tbody>
      <?php foreach ($items as $i => $it): ?>
      <tr>
        <td><?= $i+1 ?></td>
        <td><?= esc($it['product_name']) ?></td>
        <td><small><?= esc($it['sku']) ?></small></td>
        <td class="text-end"><?= (float)$it['current_stock'] ?></td>
        <td class="text-end"><?= number_format((float)$it['avg_daily_sales'],2) ?></td>
        <td class="text-end"><?= $it['days_remaining'] !== null ? number_format((float)$it['days_remaining'],1) : '-' ?></td>
        <td class="text-end fw-bold"><?= (float)$it['qty'] ?></td>
        <td class="text-end">Rp <?= number_format((float)$it['cost_price'],0,',','.') ?></td>
        <td class="text-end">Rp <?= number_format((float)$it['subtotal'],0,',','.') ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
    <tfoot><tr class="table-primary"><th colspan="8" class="text-end">TOTAL</th><th class="text-end">Rp <?= number_format((float)$po['total_amount'],0,',','.') ?></th></tr></tfoot>
  </table>
</div></div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
async function sharePo(){
  const r = await fetch('/purchase-orders/<?= $po['id'] ?>/share');
  const j = await r.json();
  if (j.ok) window.open(j.link, '_blank');
}
</script>
<?= $this->endSection() ?>
