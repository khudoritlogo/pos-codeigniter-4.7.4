<?= $this->extend('layouts/main') ?>
<?php $pageTitle = $page_title ?? 'Prediksi Restock'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <h5 class="mb-0"><?= esc($page_title) ?></h5>
  <table class="table datatable table-striped mt-2">
    <thead><tr><th>Produk</th><th>SKU</th><th>Stok Saat Ini</th><th>Minimum</th><th class="text-end">Butuh</th></tr></thead>
    <tbody>
    <?php if (!empty($rows)): ?>
      <?php foreach ($rows as $r): ?>
      <tr class="<?= ($r['need_qty'] > 0) ? 'table-danger' : '' ?>">
        <td><?= esc($r['name']) ?></td>
        <td><small><?= esc($r['sku']) ?></small></td>
        <td class="text-center"><?= (int)$r['stock'] ?></td>
        <td class="text-center"><?= (int)$r['stock_minimum'] ?></td>
        <td class="text-end"><strong><?= (int)$r['need_qty'] ?></strong></td>
      </tr>
      <?php endforeach; ?>
    <?php else: ?>
      <tr><td colspan="5" class="text-center text-muted">Tidak ada produk yang perlu restock</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
