<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Laporan Kasir'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <?= view('partials/date_filter',['from'=>$from,'to'=>$to]) ?>
  <table class="table datatable table-striped">
    <thead><tr><th>Kasir</th><th class="text-end">Transaksi</th><th class="text-end">Omzet</th><th class="text-end">Cash</th><th class="text-end">Transfer</th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr><td><?= esc($r['cashier']) ?></td><td class="text-end"><?= (int)$r['trx'] ?></td><td class="text-end">Rp <?= number_format((float)$r['omzet'],0,',','.') ?></td><td class="text-end">Rp <?= number_format((float)$r['cash'],0,',','.') ?></td><td class="text-end">Rp <?= number_format((float)$r['transfer'],0,',','.') ?></td></tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
