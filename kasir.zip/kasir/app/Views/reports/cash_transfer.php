<?= $this->extend('layouts/main') ?>
<?php $pageTitle = $page_title ?? 'Cash & Transfer'; ?>
<?= $this->section('content') ?>
<div class="row g-3">
  <div class="col-md-3"><div class="stat-card bg-success"><small>Cash</small><h3>Rp <?= number_format($cash_on_hand,0,',','.') ?></h3></div></div>
  <div class="col-md-3"><div class="stat-card bg-primary"><small>Transfer</small><h3>Rp <?= number_format($total_transfer,0,',','.') ?></h3></div></div>
  <div class="col-md-3"><div class="stat-card bg-warning"><small>QRIS</small><h3>Rp 0</h3></div></div>
  <div class="col-md-3"><div class="stat-card bg-danger"><small>Piutang</small><h3>Rp 0</h3></div></div>
</div>
<div class="card mt-3"><div class="card-body">
  <table class="table datatable table-striped">
    <thead><tr><th>Metode Pembayaran</th><th class="text-end">Total</th><th class="text-end">%</th></tr></thead>
    <tbody>
      <tr><td><i class="fas fa-money-bill-wave text-success"></i> Cash</td><td class="text-end">Rp <?= number_format($cash_on_hand,0,',','.') ?></td><td class="text-end"><?= $cash_on_hand>0 ? number_format($cash_on_hand/($cash_on_hand+$total_transfer)*100,1,',','.').'%' : '0%' ?></td></tr>
      <tr><td><i class="fas fa-university text-primary"></i> Transfer Bank</td><td class="text-end">Rp <?= number_format($total_transfer,0,',','.') ?></td><td class="text-end"><?= $total_transfer>0 ? number_format($total_transfer/($cash_on_hand+$total_transfer)*100,1,',','.').'%' : '0%' ?></td></tr>
      <tr class="table-primary"><th>TOTAL</th><th class="text-end">Rp <?= number_format($cash_on_hand+$total_transfer,0,',','.') ?></th><th class="text-end">100%</th></tr>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
