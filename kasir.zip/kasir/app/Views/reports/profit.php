<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Laba Bersih'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <?= view('partials/date_filter',['from'=>$from,'to'=>$to]) ?>
  <div class="row g-3">
    <div class="col-md-4"><div class="stat-card bg-info"><small>Omzet</small><h3>Rp <?= number_format((float)$row['revenue'],0,',','.') ?></h3></div></div>
    <div class="col-md-4"><div class="stat-card bg-warning"><small>HPP (Modal)</small><h3>Rp <?= number_format((float)$row['cogs'],0,',','.') ?></h3></div></div>
    <div class="col-md-4"><div class="stat-card bg-success"><small>Laba Bersih</small><h3>Rp <?= number_format((float)$row['profit'],0,',','.') ?></h3></div></div>
  </div>
</div></div>
<?= $this->endSection() ?>
