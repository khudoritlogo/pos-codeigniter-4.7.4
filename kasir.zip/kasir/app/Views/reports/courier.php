<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Laporan Kurir'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <?= view('partials/date_filter',['from'=>$from,'to'=>$to]) ?>
  <table class="table datatable table-striped">
    <thead><tr><th>Kurir</th><th class="text-end">Order</th><th class="text-end">Selesai</th><th class="text-end">Pending</th><th class="text-end">Total Omzet</th></tr></thead>
    <tbody><?php foreach ($rows as $r): ?><tr><td><?= esc($r['courier']) ?></td><td class="text-end"><?= $r['trx'] ?></td><td class="text-end"><?= $r['delivered'] ?></td><td class="text-end"><?= $r['pending'] ?></td><td class="text-end">Rp <?= number_format((float)$r['total'],0,',','.') ?></td></tr><?php endforeach; ?></tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
