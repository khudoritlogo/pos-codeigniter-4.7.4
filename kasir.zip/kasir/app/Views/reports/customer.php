<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Laporan Penjualan'; $exportType='sales'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <?= view('partials/date_filter',['from'=>$from,'to'=>$to,'exportType'=>$exportType]) ?>
  <table class="table datatable table-striped table-sm">
    <thead><tr><th>Invoice</th><th>Tanggal</th><th>Customer</th><th>Kasir</th><th>Metode</th><th class="text-end">Total</th></tr></thead>
    <tbody>
      <?php $sum=0; foreach ($rows as $r): $sum += $r['total']; ?>
      <tr><td><?= esc($r['invoice_no']) ?></td><td><?= date('d/m/Y H:i',strtotime($r['sale_date'])) ?></td><td><?= esc($r['customer_name'] ?? '-') ?></td><td><?= esc($r['cashier_name']) ?></td><td><?= esc($r['payment_method']) ?></td><td class="text-end">Rp <?= number_format((float)$r['total'],0,',','.') ?></td></tr>
      <?php endforeach; ?>
    </tbody>
    <tfoot><tr class="table-primary"><th colspan="5" class="text-end">TOTAL</th><th class="text-end">Rp <?= number_format($sum,0,',','.') ?></th></tr></tfoot>
  </table>
</div></div>
<?= $this->endSection() ?>
