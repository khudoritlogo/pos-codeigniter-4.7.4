<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Laporan Barang Terlaris'; $exportType='top-products'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <?= view('partials/date_filter',['from'=>$from,'to'=>$to,'exportType'=>$exportType]) ?>
  <table class="table datatable table-striped table-sm">
    <thead><tr><th>#</th><th>Produk</th><th class="text-end">Qty</th><th class="text-end">Omzet</th><th class="text-end">Laba</th></tr></thead>
    <tbody><?php foreach ($rows as $i=>$r): ?><tr><td><?= $i+1 ?></td><td><?= esc($r['name']) ?></td><td class="text-end"><?= number_format((float)$r['qty']) ?></td><td class="text-end">Rp <?= number_format((float)$r['revenue'],0,',','.') ?></td><td class="text-end">Rp <?= number_format((float)$r['profit'],0,',','.') ?></td></tr><?php endforeach; ?></tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
