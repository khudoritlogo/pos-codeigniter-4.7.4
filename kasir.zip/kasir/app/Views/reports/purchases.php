<?= $this->extend('layouts/main') ?>
<?php $pageTitle = 'Laporan Pembelian'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <div class="mb-3 d-flex justify-content-between">
    <h5 class="mb-0"><?= esc($page_title ?? $pageTitle) ?></h5>
  </div>
  <table class="table datatable table-striped">
    <thead><tr><th>Invoice</th><th>Tanggal</th><th>Supplier</th><th class="text-end">Total</th></tr></thead>
    <tbody>
    <?php $sum = 0; ?>
    <?php if (!empty($rows)): ?>
      <?php foreach ($rows as $r): $sum += (float)$r['total']; ?>
      <tr>
        <td><small><?= esc($r['invoice_no']) ?></small></td>
        <td><?= date('d/m/Y', strtotime($r['purchase_date'])) ?></td>
        <td><?= esc($r['supplier_name'] ?? '-') ?></td>
        <td class="text-end">Rp <?= number_format((float)$r['total'], 0, ',', '.') ?></td>
      </tr>
      <?php endforeach; ?>
    <?php else: ?>
      <tr><td colspan="4" class="text-center text-muted">Belum ada data</td></tr>
    <?php endif; ?>
    </tbody>
    <tfoot><tr class="table-primary"><th colspan="3" class="text-end">TOTAL</th><th class="text-end">Rp <?= number_format($sum, 0, ',', '.') ?></th></tr></tfoot>
  </table>
</div></div>
<?= $this->endSection() ?>
