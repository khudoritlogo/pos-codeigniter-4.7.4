<?= $this->extend('layouts/main') ?>
<?php $pageTitle = $page_title ?? 'Laporan Supplier'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <h5 class="mb-0"><?= esc($page_title) ?></h5>
  <table class="table datatable table-striped mt-2">
    <thead><tr><th>Supplier</th><th class="text-center">Jumlah Pembelian</th><th class="text-end">Total Belanja</th></tr></thead>
    <tbody>
    <?php $totalBeli = 0; ?>
    <?php if (!empty($rows)): ?>
      <?php foreach ($rows as $r): $totalBeli += (float)$r['total_purchases']; ?>
      <tr>
        <td><?= esc($r['name']) ?></td>
        <td class="text-center"><?= (int)$r['purchase_count'] ?></td>
        <td class="text-end">Rp <?= number_format((float)$r['total_purchases'], 0, ',', '.') ?></td>
      </tr>
      <?php endforeach; ?>
    <?php else: ?>
      <tr><td colspan="3" class="text-center text-muted">Belum ada data supplier</td></tr>
    <?php endif; ?>
    </tbody>
    <tfoot><tr class="table-primary"><th>TOTAL</th><th></th><th class="text-end">Rp <?= number_format($totalBeli, 0, ',', '.') ?></th></tr></tfoot>
  </table>
</div></div>
<?= $this->endSection() ?>
