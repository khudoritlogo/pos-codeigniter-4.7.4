<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Laporan Stok Terkecil'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <table class="table datatable table-striped">
    <thead><tr><th>SKU</th><th>Produk</th><th>Cabang</th><th class="text-end">Stok</th><th class="text-end">Alert</th></tr></thead>
    <tbody><?php foreach ($rows as $r): ?><tr><td><?= esc($r['sku']) ?></td><td><?= esc($r['name']) ?></td><td><?= esc($r['branch_name']) ?></td><td class="text-end text-danger fw-bold"><?= (float)$r['stock'] ?></td><td class="text-end"><?= (float)$r['stock_alert'] ?></td></tr><?php endforeach; ?></tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
