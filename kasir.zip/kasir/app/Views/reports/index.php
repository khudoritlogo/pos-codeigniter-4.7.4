<?= $this->extend('layouts/main') ?>
<?php $pageTitle = $page_title ?? 'Laporan'; ?>
<?= $this->section('content') ?>
<style>
  .report-card {
    display:flex;
    align-items:center;
    gap:1rem;
    padding:1.25rem;
    border:1px solid #e2e8f0;
    border-radius:1rem;
    background:#fff;
    transition:.2s;
    text-decoration:none;
    color:inherit;
  }
  .report-card:hover {
    border-color:#2563eb;
    box-shadow:0 4px 16px rgba(37,99,235,.1);
    transform:translateY(-2px);
    color:inherit;
  }
  .report-card .icon-box {
    width:52px;
    height:52px;
    border-radius:1rem;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:1.4rem;
    flex-shrink:0;
  }
  .report-card .info h5 {
    font-weight:700;
    font-size:1rem;
    margin-bottom:.15rem;
  }
  .report-card .info p {
    font-size:.8rem;
    color:#64748b;
    margin:0;
  }
</style>

<div class="row g-3">
  <div class="col-md-6 col-xl-4">
    <a href="<?= site_url('reports/purchases') ?>" class="report-card">
      <div class="icon-box bg-blue-100 text-primary" style="background:#eff6ff;color:#2563eb">
        <i class="fas fa-file-invoice"></i>
      </div>
      <div class="info">
        <h5>Laporan Pembelian</h5>
        <p>Riwayat pembelian dari supplier</p>
      </div>
    </a>
  </div>
  <div class="col-md-6 col-xl-4">
    <a href="<?= site_url('reports/supplier') ?>" class="report-card">
      <div class="icon-box bg-orange-100 text-warning" style="background:#fff7ed;color:#ea580c">
        <i class="fas fa-truck"></i>
      </div>
      <div class="info">
        <h5>Laporan Supplier</h5>
        <p>Performa & aktivitas supplier</p>
      </div>
    </a>
  </div>
  <div class="col-md-6 col-xl-4">
    <a href="<?= site_url('reports/predictive-restock') ?>" class="report-card">
      <div class="icon-box bg-purple-100 text-purple" style="background:#f5f3ff;color:#7c3aed">
        <i class="fas fa-box"></i>
      </div>
      <div class="info">
        <h5>Prediksi Restock</h5>
        <p>Prediksi kebutuhan stok bulanan</p>
      </div>
    </a>
  </div>
  <div class="col-md-6 col-xl-4">
    <a href="<?= site_url('reports/cash-transfer') ?>" class="report-card">
      <div class="icon-box bg-green-100 text-success" style="background:#ecfdf5;color:#059669">
        <i class="fas fa-money-bill-wave"></i>
      </div>
      <div class="info">
        <h5>Transfer Kas</h5>
        <p>Rekam jejak transfer & kas</p>
      </div>
    </a>
  </div>
  <div class="col-md-6 col-xl-4">
    <a href="<?= site_url('reports/sales') ?>" class="report-card">
      <div class="icon-box bg-red-100 text-danger" style="background:#fef2f2;color:#dc2626">
        <i class="fas fa-shopping-cart"></i>
      </div>
      <div class="info">
        <h5>Laporan Penjualan</h5>
        <p>Ringkasan penjualan & omzet</p>
      </div>
    </a>
  </div>
  <div class="col-md-6 col-xl-4">
    <a href="<?= site_url('reports/profit') ?>" class="report-card">
      <div class="icon-box bg-indigo-100 text-indigo" style="background:#eef2ff;color:#4f46e5">
        <i class="fas fa-chart-line"></i>
      </div>
      <div class="info">
        <h5>Laporan Profit</h5>
        <p>Analisis keuntungan bersih</p>
      </div>
    </a>
  </div>
  <div class="col-md-6 col-xl-4">
    <a href="<?= site_url('reports/top-products') ?>" class="report-card">
      <div class="icon-box bg-yellow-100 text-warning" style="background:#fefce8;color:#a16207">
        <i class="fas fa-star"></i>
      </div>
      <div class="info">
        <h5>Barang Terlaris</h5>
        <p>Produk dengan penjualan tertinggi</p>
      </div>
    </a>
  </div>
  <div class="col-md-6 col-xl-4">
    <a href="<?= site_url('reports/low-stock') ?>" class="report-card">
      <div class="icon-box bg-red-100 text-danger" style="background:#fef2f2;color:#e11d48">
        <i class="fas fa-exclamation-triangle"></i>
      </div>
      <div class="info">
        <h5>Stok Terkecil</h5>
        <p>Peringatan stok menipis</p>
      </div>
    </a>
  </div>
  <div class="col-md-6 col-xl-4">
    <a href="<?= site_url('reports/courier') ?>" class="report-card">
      <div class="icon-box bg-teal-100 text-teal" style="background:#f0fdfa;color:#0d9488">
        <i class="fas fa-motorcycle"></i>
      </div>
      <div class="info">
        <h5>Laporan Kurir</h5>
        <p>Aktivitas & deliveri kurir</p>
      </div>
    </a>
  </div>
</div>

<?= $this->endSection() ?>