<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Retur Penjualan'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <a class="btn btn-primary" href="<?= site_url('sale-returns/new') ?>"><i class="fas fa-plus"></i> Retur Baru</a></div>
  <table class="table datatable table-striped">
    <thead><tr><th>No. Retur</th><th>Invoice</th><th>Tanggal</th><th class="text-end">Total</th><th>Alasan</th></tr></thead>
    <tbody><?php foreach ($rows as $r): ?><tr><td><?= esc($r['return_no']) ?></td><td><?= esc($r['invoice_no']) ?></td><td><?= date('d/m/Y H:i',strtotime($r['return_date'])) ?></td><td class="text-end">Rp <?= number_format((float)$r['total'],0,',','.') ?></td><td><?= esc($r['reason']) ?></td></tr><?php endforeach; ?></tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
