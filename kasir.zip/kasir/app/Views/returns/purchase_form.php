<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Retur Penjualan Baru'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <div class="row g-3 mb-3">
    <div class="col-md-4"><label>No. Invoice Penjualan</label><input class="form-control" id="invoice" placeholder="Cari invoice..."><button class="btn btn-sm btn-primary mt-2" onclick="loadSale()">Cari</button></div>
  </div>
  <div id="saleInfo"></div>
  <table class="table table-bordered" id="itemsTable" style="display:none">
    <thead><tr><th>Produk</th><th class="text-end">Qty Beli</th><th class="text-end">Qty Retur</th><th class="text-end">Harga</th><th class="text-end">Subtotal</th></tr></thead>
    <tbody id="items"></tbody>
    <tfoot><tr><th colspan="4" class="text-end">Total Retur</th><th class="text-end" id="tTotal">Rp 0</th></tr></tfoot>
  </table>
  <textarea id="reason" class="form-control mb-2" placeholder="Alasan retur..."></textarea>
  <button class="btn btn-success" onclick="save()"><i class="fas fa-save"></i> Simpan Retur</button>
  <a href="<?= site_url('sale-returns') ?>" class="btn btn-secondary">Batal</a>
</div></div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
let currentSale=null, items=[];
async function loadSale(){
  const q = $('#invoice').val();
  // Simple search: adjust API on backend if needed
  Swal.fire('Info','Fitur pencarian invoice dapat dikembangkan lebih lanjut. Silakan buat endpoint /api/sales/find','info');
}
function save(){ /* TODO POST to /sale-returns */ }
</script>
<?= $this->endSection() ?>
