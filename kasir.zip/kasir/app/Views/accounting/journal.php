<?= $this->extend('layouts/main') ?>
<?php $pageTitle = 'Journal Entries'; ?>
<?= $this->section('content') ?>
<style>
  .journal-card {
    border:1px solid #e2e8f0;
    border-radius:1rem;
    overflow:hidden;
  }
  .journal-card .card-header-custom {
    background:linear-gradient(135deg,#1e293b,#0f172a);
    color:#fff;
    padding:.75rem 1.25rem;
    display:flex;align-items:center;justify-content:space-between;
    flex-wrap:wrap;gap:.5rem;
  }
  .journal-card .card-header-custom h5 {
    margin:0;font-weight:600;font-size:1rem;
    display:flex;align-items:center;gap:.5rem;
  }
  .journal-table {
    margin:0;
  }
  .journal-table thead th {
    background:#f8fafc;
    color:#475569;
    font-weight:600;
    font-size:.78rem;
    text-transform:uppercase;
    letter-spacing:.3px;
    padding:.55rem .85rem;
    border-bottom:2px solid #e2e8f0;
  }
  .journal-table tbody td {
    padding:.5rem .85rem;
    vertical-align:middle;
    border-bottom:1px solid #f1f5f9;
    font-size:.88rem;
  }
  .journal-table tbody tr:hover { background:#f8fafc; }
  .journal-table tbody tr:last-child td { border-bottom:none; }
  .badge-status {
    font-size:.75rem;
    padding:.2rem .55rem;
    border-radius:999px;
    font-weight:500;
    display:inline-flex;align-items:center;gap:.25rem;
  }
  .badge-draft { background:#fffbeb; color:#92400e; }
  .badge-posted { background:#d1fae5; color:#065f46; }
  .entry-no {
    font-family:'Courier New',monospace;
    font-weight:600;
    color:#2563eb;
    font-size:.9rem;
  }
  .entry-date {
    font-size:.85rem;
    color:#64748b;
  }
  .entry-desc {
    max-width:300px;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
    color:#475569;
  }
  .empty-state {
    text-align:center;padding:3rem 1rem;
    color:#94a3b8;
  }
  .empty-state i { font-size:2.5rem;margin-bottom:.75rem;opacity:.4;display:block; }
  .empty-state p { margin:0;font-size:.9rem; }
</style>

<div class="journal-card">
  <div class="card-header-custom">
    <h5><i class="fas fa-book text-primary me-2"></i>Journal Entries</h5>
    <div class="d-flex gap-2">
      <button class="btn btn-sm btn-outline-light"><i class="fas fa-plus me-1"></i>Jurnal Baru</button>
      <button class="btn btn-sm btn-outline-light"><i class="fas fa-filter me-1"></i>Filter</button>
    </div>
  </div>
  <div class="table-responsive">
    <table class="table journal-table">
      <thead>
        <tr>
          <th style="width:90px">Entry No</th>
          <th style="width:100px">Tanggal</th>
          <th style="width:100px">Period</th>
          <th style="width:100px">Status</th>
          <th>Description</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($rows)): ?>
          <?php foreach ($rows as $r): ?>
          <tr>
            <td>
              <span class="entry-no"><?= esc($r['entry_no'] ?? $r['id']) ?></span>
            </td>
            <td>
              <span class="entry-date"><?= date('d/m/Y', strtotime($r['entry_date'] ?? date('Y-m-d'))) ?></span>
              <small class="text-muted d-block" style="font-size:.7rem">
                <i class="fas fa-clock me-1"></i><?= date('H:i', strtotime($r['entry_date'] ?? date('Y-m-d H:i:s'))) ?>
              </small>
            </td>
            <td>
              <span class="badge bg-light text-dark border px-2 py-1" style="font-size:.78rem">
                <?= esc($r['period_name'] ?? '-') ?>
              </span>
            </td>
            <td>
              <span class="badge-status <?= $r['status'] === 'posted' ? 'badge-posted' : 'badge-draft' ?>">
                <i class="fas <?= $r['status'] === 'posted' ? 'fa-check-circle' : 'fa-pen' ?>"></i>
                <?= esc(ucfirst($r['status'])) ?>
              </span>
            </td>
            <td>
              <div class="entry-desc" title="<?= esc($r['description'] ?? '') ?>">
                <?= esc($r['description'] ?? '-') ?>
              </div>
              <small class="text-muted d-block" style="font-size:.72rem">
                Masuk: <?= esc($r['entered_by'] ?? '-') ?>
              </small>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php else: ?>
        <tr>
          <td colspan="5">
            <div class="empty-state">
              <i class="fas fa-book"></i>
              <p>Belum ada jurnal</p>
              <small class="text-muted">Buat jurnal pertama untuk mencatat transaksi</small>
            </div>
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?= $this->endSection() ?>
