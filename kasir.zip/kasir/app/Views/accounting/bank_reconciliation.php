<?= $this->extend('layouts/main') ?>
<?php $pageTitle = 'Bank Reconciliation'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <h5 class="mb-0"><?= esc($page_title ?? $pageTitle) ?></h5>
  <p class="text-muted mt-2">Modul rekonsiliasi bank.</p>
</div></div>
<?= $this->endSection() ?>
