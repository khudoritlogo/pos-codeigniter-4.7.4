<?= $this->extend('layouts/main') ?>
<?php $pageTitle = 'General Ledger'; ?>
<?= $this->section('content') ?>
<style>
  .ledger-card {
    border:1px solid #e2e8f0;
    border-radius:1rem;
    overflow:hidden;
  }
  .ledger-card .card-header-custom {
    background:linear-gradient(135deg,#1e293b,#0f172a);
    color:#fff;
    padding:.75rem 1.25rem;
    display:flex;align-items:center;justify-content:space-between;
    flex-wrap:wrap;gap:.5rem;
  }
  .ledger-card .card-header-custom h5 {
    margin:0;font-weight:600;font-size:1rem;
    display:flex;align-items:center;gap:.5rem;
  }
  .ledger-table {
    margin:0;
  }
  .ledger-table thead th {
    background:#f8fafc;
    color:#475569;
    font-weight:600;
    font-size:.75rem;
    text-transform:uppercase;
    letter-spacing:.3px;
    padding:.5rem .75rem;
    border-bottom:2px solid #e2e8f0;
    white-space:nowrap;
  }
  .ledger-table tbody td {
    padding:.4rem .75rem;
    vertical-align:middle;
    border-bottom:1px solid #f1f5f9;
    font-size:.82rem;
  }
  .ledger-table tbody tr:hover { background:#f8fafc; }
  .ledger-table tbody tr:last-child td { border-bottom:none; }
  .ledger-table tbody tr.account-header {
    background:#f1f5f9;
    font-weight:700;
    color:#1e293b;
  }
  .ledger-table tbody tr.account-header td {
    padding:.55rem .75rem;
    border-bottom:2px solid #e2e8f0;
    font-size:.85rem;
  }
  .ledger-table .coa-code {
    font-family:'Courier New',monospace;
    font-weight:600;
    color:#2563eb;
    font-size:.85rem;
  }
  .ledger-table .coa-name {
    font-weight:500;
    color:#1e293b;
  }
  .amount-debit {
    text-align:right;
    font-family:'Courier New',monospace;
    color:#2563eb;
    font-weight:500;
  }
  .amount-credit {
    text-align:right;
    font-family:'Courier New',monospace;
    color:#dc2626;
    font-weight:500;
  }
  .amount-total {
    text-align:right;
    font-family:'Courier New',monospace;
    font-weight:700;
    color:#1e293b;
    font-size:.9rem;
  }
  .section-total {
    font-weight:700;
    color:#1e293b;
    border-top:1px solid #e2e8f0;
  }
  .grand-total {
    background:#1e293b;
    color:#fff;
    font-weight:700;
    padding:.55rem .75rem;
    font-size:.9rem;
  }
  .empty-state {
    text-align:center;padding:3rem 1rem;
    color:#94a3b8;
  }
  .empty-state i { font-size:2.5rem;margin-bottom:.75rem;opacity:.4;display:block; }
  .empty-state p { margin:0;font-size:.9rem; }
</style>

<div class="ledger-card">
  <div class="card-header-custom">
    <h5><i class="fas fa-book-open text-primary me-2"></i>General Ledger</h5>
    <div class="d-flex gap-2">
      <select class="form-select form-select-sm" style="width:auto">
        <option value="">Semua Akun</option>
      </select>
      <button class="btn btn-sm btn-outline-light"><i class="fas fa-search me-1"></i>Cari</button>
    </div>
  </div>
  <div class="table-responsive">
    <table class="table ledger-table">
      <thead>
        <tr>
          <th style="width:100px">Tanggal</th>
          <th style="width:80px">No. Ref</th>
          <th style="width:35%">Keterangan</th>
          <th style="width:120px;text-align:right">Debit (Rp)</th>
          <th style="width:120px;text-align:right">Kredit (Rp)</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $currentAccount = null;
        $runningDebit = 0;
        $runningCredit = 0;
        $grandDebit = 0;
        $grandCredit = 0;
        $firstRow = true;

        if (!empty($rows)):
          foreach ($rows as $r):
            $accId = $r['account_id'] ?? null;
            $accCode = $r['code'] ?? null;
            $accName = $r['name'] ?? null;

            // Tampilkan header akun jika ganti akun
            if ($currentAccount !== $accId):
              // Tampilkan total running sebelum ganti akun
              if (!$firstRow):
                ?>
                <tr class="section-total">
                  <td colspan="3" style="text-align:right">Subtotal</td>
                  <td class="amount-total text-end"><?= number_format($runningDebit, 0, ',', '.') ?></td>
                  <td class="amount-total text-end"><?= number_format($runningCredit, 0, ',', '.') ?></td>
                </tr>
                <?php
                $runningDebit = 0;
                $runningCredit = 0;
              endif;
              $firstRow = false;

              // Header akun baru
              $currentAccount = $accId;
              $grandDebit += $runningDebit;
              $grandCredit += $runningCredit;
              ?>
              <tr class="account-header">
                <td colspan="5">
                  <span class="coa-code"><?= esc($accCode ?? '') ?></span>
                  <span class="coa-name"><?= esc($accName ?? '') ?></span>
                </td>
              </tr>
              <?php
            endif;

            $dr = (float)($r['debit'] ?? 0);
            $cr = (float)($r['credit'] ?? 0);
            $runningDebit += $dr;
            $runningCredit += $cr;
            ?>
            <tr>
              <td style="white-space:nowrap;color:#64748b">
                <?= date('d/m/Y', strtotime($r['transaction_date'] ?? date('Y-m-d'))) ?>
              </td>
              <td style="font-family:monospace;color:#64748b;font-size:.8rem">
                <?= esc($r['reference_no'] ?? '-') ?>
              </td>
              <td>
                <span style="color:#475569"><?= esc($r['description'] ?? '-') ?></span>
                <?php if (!empty($r['entered_by'])): ?>
                  <small class="text-muted d-block" style="font-size:.7rem">oleh: <?= esc($r['entered_by']) ?></small>
                <?php endif; ?>
              </td>
              <?php if ($dr > 0): ?>
                <td class="amount-debit"><?= number_format($dr, 0, ',', '.') ?></td>
                <td class="amount-credit">-</td>
              <?php elseif ($cr > 0): ?>
                <td class="amount-debit">-</td>
                <td class="amount-credit"><?= number_format($cr, 0, ',', '.') ?></td>
              <?php else: ?>
                <td class="amount-debit">-</td>
                <td class="amount-credit">-</td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>

          <?php
          // Tampilkan total akun terakhir
          if (!$firstRow):
            ?>
            <tr class="section-total">
              <td colspan="3" style="text-align:right">Subtotal Akun</td>
              <td class="amount-total text-end"><?= number_format($runningDebit, 0, ',', '.') ?></td>
              <td class="amount-total text-end"><?= number_format($runningCredit, 0, ',', '.') ?></td>
            </tr>
            <?php
            $grandDebit += $runningDebit;
            $grandCredit += $runningCredit;
          endif;
        else:
          ?>
          <tr>
            <td colspan="5">
              <div class="empty-state">
                <i class="fas fa-book-open"></i>
                <p>Belum ada data Buku Besar</p>
                <small class="text-muted">Posting jurnal untuk melihat detail ledger</small>
              </div>
            </td>
          </tr>
          <?php
        endif;
        ?>
      </tbody>
    </table>
  </div>
</div>

<?= $this->endSection() ?>