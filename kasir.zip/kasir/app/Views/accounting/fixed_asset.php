<?= $this->extend('layouts/main') ?>
<?php $pageTitle = 'Fixed Asset Register'; ?>
<?= $this->section('content') ?>
<style>
  .fa-card {
    border:1px solid #e2e8f0;
    border-radius:1rem;
    overflow:hidden;
  }
  .fa-card .card-header-custom {
    background:linear-gradient(135deg,#1e293b,#0f172a);
    color:#fff;
    padding:.75rem 1.25rem;
    display:flex;align-items:center;justify-content:space-between;
    flex-wrap:wrap;gap:.5rem;
  }
  .fa-card .card-header-custom h5 {
    margin:0;font-weight:600;font-size:1rem;
    display:flex;align-items:center;gap:.5rem;
  }
  .fa-summary {
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:.75rem;
    padding:1rem 1.25rem;
    background:#f8fafc;
    border-bottom:1px solid #e2e8f0;
  }
  .fa-summary .fa-stat {
    text-align:center;
    background:#fff;
    padding:.65rem;
    border-radius:.75rem;
    border:1px solid #e2e8f0;
  }
  .fa-summary .fa-stat .fa-label {
    font-size:.7rem;
    text-transform:uppercase;
    letter-spacing:.4px;
    color:#64748b;
    margin-bottom:.2rem;
  }
  .fa-summary .fa-stat .fa-value {
    font-size:1.05rem;
    font-weight:700;
    color:#1e293b;
  }
  .fa-table {
    margin:0;
  }
  .fa-table thead th {
    background:#f1f5f9;
    color:#475569;
    font-weight:600;
    font-size:.75rem;
    text-transform:uppercase;
    letter-spacing:.3px;
    padding:.5rem .7rem;
    border-bottom:2px solid #e2e8f0;
    white-space:nowrap;
  }
  .fa-table tbody td {
    padding:.45rem .7rem;
    border-bottom:1px solid #f1f5f9;
    font-size:.85rem;
    vertical-align:middle;
  }
  .fa-table tbody tr:hover { background:#f8fafc; }
  .fa-table tbody tr:last-child td { border-bottom:none; }
  .fa-table tbody tr.depreciable td { background:#fef9c3; }
  .badge-category {
    font-size:.72rem;
    padding:.2rem .5rem;
    border-radius:999px;
    font-weight:500;
  }
  .badge-building { background:#dbeafe; color:#1d4ed8; }
  .badge-vehicle { background:#d1fae5; color:#065f46; }
  .badge-equipment { background:#f3e8ff; color:#6b21a8; }
  .badge-furniture { background:#fef3c7; color:#92400e; }
  .arrow-right {
    color:#94a3b8;
    margin:0 .2rem;
  }
  .depreciation-progress {
    height:6px;
    background:#e2e8f0;
    border-radius:999px;
    overflow:hidden;
    margin-top:.3rem;
  }
  .depreciation-progress .bar {
    height:100%;
    background:linear-gradient(90deg,#2563eb,#7c3aed);
    border-radius:999px;
  }
  .empty-state {
    text-align:center;padding:3rem 1rem;
    color:#94a3b8;
  }
  .empty-state i { font-size:2.5rem;margin-bottom:.75rem;opacity:.4;display:block; }
  .empty-state p { margin:0;font-size:.9rem; }
</style>

<div class="fa-card">
  <div class="card-header-custom">
    <h5><i class="fas fa-building text-primary me-2"></i>Fixed Asset Register</h5>
    <div class="d-flex gap-2">
      <button class="btn btn-sm btn-outline-light"><i class="fas fa-plus me-1"></i>Aset Baru</button>
      <button class="btn btn-sm btn-outline-light"><i class="fas fa-file-export me-1"></i>Export</button>
    </div>
  </div>

  <!-- Summary -->
  <div class="fa-summary">
    <div class="fa-stat">
      <div class="fa-label">Total Aset</div>
      <div class="fa-value">Rp 12.500.000</div>
      <small class="text-muted" style="font-size:.7rem">4 aset terdaftar</small>
    </div>
    <div class="fa-stat">
      <div class="fa-label">Total Depreciable</div>
      <div class="fa-value">Rp 11.200.000</div>
      <small class="text-muted" style="font-size:.7rem">Bisa di-depresiasi</small>
    </div>
    <div class="fa-stat">
      <div class="fa-label">Total Akumulasi Dep.</div>
      <div class="fa-value" style="color:#dc2626">Rp 3.400.000</div>
      <small class="text-muted" style="font-size:.7rem">Telah dikurangi</small>
    </div>
    <div class="fa-stat">
      <div class="fa-label">Nilai Buku (Net)</div>
      <div class="fa-value" style="color:#1e293b">Rp 8.100.000</div>
      <small class="text-muted" style="font-size:.7rem">Aset - Akumulasi Dep.</small>
    </div>
  </div>

  <div class="table-responsive">
    <table class="table fa-table">
      <thead>
        <tr>
          <th style="width:40px">#</th>
          <th>Nama Aset</th>
          <th style="width:100px">Kategori</th>
          <th style="width:100px">Tanggal Beli</th>
          <th style="width:130px;text-align:right">Biaya Asums. (Rp)</th>
          <th style="width:100px;text-align:right">Umur Ekonomis</th>
          <th style="width:110px;text-align:right">Akumulasi Dep.</th>
          <th style="width:130px;text-align:right">Nilai Buku</th>
          <th style="width:100px">Status</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td style="color:#94a3b8;text-align:center;font-size:.8rem">1</td>
          <td>
            <div class="fw-medium" style="color:#1e293b">Ruang Komputer</div>
            <small class="text-muted" style="font-size:.72rem"> gedung: A-101</small>
          </td>
          <td><span class="badge-category badge-building">Gedung</span></td>
          <td style="white-space:nowrap;color:#64748b;font-size:.8rem">15/03/2024</td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">Rp 8.000.000</td>
          <td style="text-align:center;color:#64748b;font-size:.8rem">10 tahun</td>
          <td style="text-align:right;font-family:monospace;color:#dc2626;font-weight:500">Rp 1.600.000</td>
          <td style="text-align:right;font-family:monospace;font-weight:700;color:#1e293b">Rp 6.400.000</td>
          <td>
            <span class="badge-category badge-building"><i class="fas fa-circle me-1" style="font-size:.5rem"></i>Active</span>
            <div class="depreciation-progress mt-1" style="max-width:80px">
              <div class="bar" style="width:16%"></div>
            </div>
          </td>
        </tr>
        <tr class="depreciable">
          <td style="color:#94a3b8;text-align:center;font-size:.8rem">2</td>
          <td>
            <div class="fw-medium" style="color:#1e293b">Laptop Kantor</div>
            <small class="text-muted" style="font-size:.72rem"> Unit: 5</small>
          </td>
          <td><span class="badge-category badge-equipment">Peralatan</span></td>
          <td style="white-space:nowrap;color:#64748b;font-size:.8rem">01/06/2026</td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">Rp 2.500.000</td>
          <td style="text-align:center;color:#64748b;font-size:.8rem">3 tahun</td>
          <td style="text-align:right;font-family:monospace;color:#dc2626;font-weight:500">Rp 500.000</td>
          <td style="text-align:right;font-family:monospace;font-weight:700;color:#1e293b">Rp 2.000.000</td>
          <td>
            <span class="badge-category badge-equipment"><i class="fas fa-circle me-1" style="font-size:.5rem"></i>Depreciable</span>
            <div class="depreciation-progress mt-1" style="max-width:80px">
              <div class="bar" style="width:17%"></div>
            </div>
          </td>
        </tr>
        <tr>
          <td style="color:#94a3b8;text-align:center;font-size:.8rem">3</td>
          <td>
            <div class="fw-medium" style="color:#1e293b">Mobil Pickup</div>
            <small class="text-muted" style="font-size:.72rem"> Plat: B-1234</small>
          </td>
          <td><span class="badge-category badge-vehicle">Kendaraan</span></td>
          <td style="white-space:nowrap;color:#64748b;font-size:.8rem">10/01/2025</td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">Rp 500.000</td>
          <td style="text-align:center;color:#64748b;font-size:.8rem">5 tahun</td>
          <td style="text-align:right;font-family:monospace;color:#dc2626;font-weight:500">Rp 100.000</td>
          <td style="text-align:right;font-family:monospace;font-weight:700;color:#1e293b">Rp 400.000</td>
          <td>
            <span class="badge-category badge-vehicle"><i class="fas fa-circle me-1" style="font-size:.5rem"></i>Depreciable</span>
            <div class="depreciation-progress mt-1" style="max-width:80px">
              <div class="bar" style="width:20%"></div>
            </div>
          </td>
        </tr>
        <tr>
          <td style="color:#94a3b8;text-align:center;font-size:.8rem">4</td>
          <td>
            <div class="fw-medium" style="color:#1e293b">Meja & Kursi</div>
            <small class="text-muted" style="font-size:.72rem"> 20 sets</small>
          </td>
          <td><span class="badge-category badge-furniture">Furnitur</span></td>
          <td style="white-space:nowrap;color:#64748b;font-size:.8rem">15/06/2026</td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">Rp 200.000</td>
          <td style="text-align:center;color:#64748b;font-size:.8rem">4 tahun</td>
          <td style="text-align:right;font-family:monospace;color:#dc2626;font-weight:500">Rp 0</td>
          <td style="text-align:right;font-family:monospace;font-weight:700;color:#1e293b">Rp 200.000</td>
          <td>
            <span class="badge-category badge-furniture"><i class="fas fa-circle me-1" style="font-size:.5rem"></i>Depreciable</span>
            <div class="depreciation-progress mt-1" style="max-width:80px">
              <div class="bar" style="width:0%"></div>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

<?= $this->endSection() ?>