<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0"><i class="fas fa-calendar-plus"></i> <?= esc($page_title) ?></h5>
                <a href="<?= base_url('accounting/periods') ?>" class="btn btn-secondary btn-sm">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
            <div class="card-body">
                <form action="<?= base_url($action) ?>" method="post">
                    <input type="hidden" name="id" value="<?= $period['id'] ?? '' ?>">

                    <div class="row g-3">
                        <div class="col-md-4">
                            <label class="form-label">Kode Periode <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="code" value="<?= old('code', $period['code'] ?? '') ?>" required placeholder="Contoh: 2025-01">
                            <small class="text-muted">Format: YYYY-MM (bulanan) atau YYYY (tahunan)</small>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Nama Periode <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="name" value="<?= old('name', $period['name'] ?? '') ?>" required placeholder="Contoh: Januari 2025">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Tipe Periode <span class="text-danger">*</span></label>
                            <select class="form-select" name="period_type" required>
                                <option value="monthly" <?= old('period_type', $period['period_type'] ?? '') === 'monthly' ? 'selected' : '' ?>>Bulanan</option>
                                <option value="yearly" <?= old('period_type', $period['period_type'] ?? '') === 'yearly' ? 'selected' : '' ?>>Tahunan</option>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">Mulai <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="start_date" value="<?= old('start_date', $period['start_date'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Selesai <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="end_date" value="<?= old('end_date', $period['end_date'] ?? '') ?>" required>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <div class="form-check mt-3">
                                <input class="form-check-input" type="checkbox" name="is_open" id="is_open" value="1" <?= old('is_open', $period['is_open'] ?? true) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="is_open">Buka (bisa entry jurnal)</label>
                            </div>
                        </div>

                        <div class="col-12">
                            <label class="form-label">Catatan</label>
                            <textarea class="form-control" name="notes" rows="2"><?= old('notes', $period['notes'] ?? '') ?></textarea>
                        </div>

                        <div class="col-12 d-flex justify-content-end gap-2 mt-3">
                            <a href="<?= base_url('accounting/periods') ?>" class="btn btn-secondary">Batal</a>
                            <button type="submit" class="btn btn-primary">
                                <?= $period ? 'Update Periode' : 'Simpan Periode' ?>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
