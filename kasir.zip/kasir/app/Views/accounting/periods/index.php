<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="fas fa-calendar-alt"></i> <?= esc($page_title) ?></h4>
    <div>
        <a href="<?= base_url('accounting/periods/create') ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Tambah Periode
        </a>
    </div>
</div>

<?php if (session()->getFlashdata('message')): ?>
    <div class="alert alert-<?= session()->getFlashdata('message_type') === 'error' ? 'danger' : 'success' ?> alert-dismissible fade show">
        <?= session()->getFlashdata('message') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="card">
    <div class="card-body table-responsive">
        <table class="table table-striped table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>Kode</th>
                    <th>Nama</th>
                    <th>Tipe</th>
                    <th>Periode</th>
                    <th style="min-width:120px">Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($periods)): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">Belum ada periode</td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($periods as $p): ?>
                <tr>
                    <td><span class="badge bg-secondary"><?= esc($p['code']) ?></span></td>
                    <td class="fw-semibold"><?= esc($p['name']) ?></td>
                    <td><?= $p['period_type'] === 'monthly' ? 'Bulanan' : 'Tahunan' ?></td>
                    <td>
                        <small><?= date('d M Y', strtotime($p['start_date'])) ?></small><br>
                        <small class="text-muted">s.d. <?= date('d M Y', strtotime($p['end_date'])) ?></small>
                    </td>
                    <td>
                        <?php if ($p['is_open']): ?>
                            <span class="badge bg-success"><i class="fas fa-check"></i> Open</span>
                        <?php else: ?>
                            <span class="badge bg-secondary"><i class="fas fa-lock"></i> Closed</span>
                            <small class="text-muted ms-1">oleh <?= esc($p['closing_date'] ?? '') ?></small>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="btn-group btn-group-sm">
                            <?php if ($p['is_open']): ?>
                                <a href="<?= base_url('accounting/periods/' . $p['id'] . '/close') ?>"
                                   class="btn btn-danger"
                                   onclick="return confirm('Tutup periode ini? Semua jurnal draft akan otomatis di-post. Lanjutkan?')">
                                    <i class="fas fa-lock"></i> Tutup
                                </a>
                            <?php else: ?>
                                <a href="<?= base_url('accounting/periods/' . $p['id'] . '/open') ?>"
                                   class="btn btn-success"
                                   onclick="return confirm('Buka kembali periode ini?')">
                                    <i class="fas fa-unlock"></i> Buka
                                </a>
                            <?php endif; ?>
                            <a href="<?= base_url('accounting/periods/' . $p['id'] . '/edit') ?>"
                               class="btn btn-secondary">
                                <i class="fas fa-pen"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?= $this->endSection() ?>
