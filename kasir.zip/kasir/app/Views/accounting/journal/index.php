<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>

<div class="d-flex justify-content-between align-items-center mb-3">
    <div>
        <h4 class="mb-0"><i class="fas fa-book"></i> <?= esc($page_title) ?></h4>
        <small class="text-muted">Jurnal Umum — pengakuan transaksi keuangan</small>
    </div>
    <div>
        <a href="<?= base_url('accounting/journal/create') ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Buat Jurnal
        </a>
        <a href="<?= base_url('accounting/reports') ?>" class="btn btn-outline-secondary btn-sm">
            <i class="fas fa-file"></i> Laporan
        </a>
    </div>
</div>

<?php if (session()->getFlashdata('message')): ?>
    <div class="alert alert-<?= session()->getFlashdata('message_type') === 'error' ? 'danger' : 'success' ?> alert-dismissible fade show">
        <?= session()->getFlashdata('message') ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<div class="row mb-3">
    <div class="col-md-3">
        <select class="form-select" onchange="window.location.href='<?= base_url('accounting/journal') ?>?status='+this.value"
                class="form-select">
            <option value="posted" <?= $status === 'posted' ? 'selected' : '' ?>>Semua Posted</option>
            <option value="draft" <?= $status === 'draft' ? 'selected' : '' ?>>Draft</option>
        </select>
    </div>
    <div class="col-md-3">
        <select class="form-select" onchange="window.location.href='<?= base_url('accounting/journal') ?>?period_id='+this.value"
                class="form-select">
            <option value="">-- Semua Periode --</option>
            <?php foreach ($periods as $p): ?>
                <option value="<?= $p['id'] ?>" <?= $period_filter == $p['id'] ? 'selected' : '' ?>>
                    <?= esc($p['code'] . ' - ' . $p['name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
</div>

<div class="card">
    <div class="card-body table-responsive">
        <table class="table table-striped table-hover align-middle">
            <thead class="table-light">
                <tr>
                    <th>No. Jurnal</th>
                    <th>Tanggal</th>
                    <th>Periode</th>
                    <th>Referensi</th>
                    <th>Keterangan</th>
                    <th>Tipe</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($entries)): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted py-4">Belum ada jurnal</td>
                    </tr>
                <?php endif; ?>
                <?php foreach ($entries as $e): ?>
                <tr>
                    <td><span class="badge bg-primary"><?= esc($e['entry_no']) ?></span></td>
                    <td><?= date('d/m/Y H:i', strtotime($e['entry_date'])) ?></td>
                    <td>
                        <?php if ($e['period_id']): ?>
                            <?php $p = model(\App\Models\FinancialPeriodModel::class)->find($e['period_id']); ?>
                            <?php if ($p): ?>
                                <small><?= esc($p['code']) ?></small>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                    <td><?= esc($e['reference'] ?? '-') ?></td>
                    <td><?= esc($e['description'] ?? '-') ?></td>
                    <td>
                        <span class="badge bg-<?= $e['entry_type'] === 'adjustment' ? 'warning' : ($e['entry_type'] === 'reversal' ? 'danger' : 'info') ?>">
                            <?= ucfirst($e['entry_type']) ?>
                        </span>
                    </td>
                    <td>
                        <?php if ($e['status'] === 'posted'): ?>
                            <span class="badge bg-success"><i class="fas fa-check-circle"></i> Posted</span>
                        <?php else: ?>
                            <span class="badge bg-warning"><i class="fas fa-pen"></i> Draft</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <div class="btn-group btn-group-sm">
                            <?php if ($e['status'] === 'draft'): ?>
                                <a href="<?= base_url('accounting/journal/' . $e['id'] . '/edit') ?>" class="btn btn-secondary">
                                    <i class="fas fa-pen"></i>
                                </a>
                                <a href="<?= base_url('accounting/journal/' . $e['id'] . '/post') ?>"
                                   class="btn btn-success"
                                   onclick="return confirm('Post jurnal ini? Item akan masuk ke Buku Besar.')">
                                    <i class="fas fa-check"></i> Post
                                </a>
                                <a href="<?= base_url('accounting/journal/' . $e['id'] . '/delete') ?>"
                                   class="btn btn-danger"
                                   onclick="return confirm('Hapus jurnal draft ini?')">
                                    <i class="fas fa-trash"></i>
                                </a>
                            <?php else: ?>
                                <a href="<?= base_url('accounting/journal/' . $e['id'] . '/reverse') ?>"
                                   class="btn btn-outline-danger"
                                   onclick="return confirm('Buat jurnal reversal dari ini? Transaksi asli akan dikompensasi.')">
                                    <i class="fas fa-undo"></i> Reverse
                                </a>
                            <?php endif; ?>
                            <a href="<?= base_url('accounting/journal/' . $e['id'] . '/detail') ?>"
                               class="btn btn-info text-white">
                                <i class="fas fa-eye"></i>
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="card-footer d-flex justify-content-between align-items-center">
        <small class="text-muted">Page <?= $pager->getPage() ?> dari <?= $pager->getTotal() ?></small>
        <?= $pager->links('accounting_journal', 'accounting_pagination') ?>
    </div>
</div>

<?= $this->endSection() ?>
