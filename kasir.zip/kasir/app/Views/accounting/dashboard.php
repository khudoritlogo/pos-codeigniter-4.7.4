<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="row">
    <div class="col-12 col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-balance-scale"></i> Trial Balance
                </h5>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted">Total Debit</span>
                    <span class="fw-bold">Rp <?= number_format($total_debit, 0, ',', '.') ?></span>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-2">
                    <span class="text-muted">Total Kredit</span>
                    <span class="fw-bold">Rp <?= number_format($total_credit, 0, ',', '.') ?></span>
                </div>
                <hr class="my-2">
                <div class="d-flex justify-content-between align-items-center">
                    <span class="text-muted">Status</span>
                    <?php if ($is_balanced): ?>
                        <span class="badge bg-success"><i class="fas fa-check"></i> Seimbang</span>
                    <?php else: ?>
                        <span class="badge bg-danger"><i class="fas fa-exclamation-triangle"></i> Tidak Seimbang</span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="col-12 col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-calendar-alt"></i> Periode Aktif
                </h5>
            </div>
            <div class="card-body">
                <?php if ($period): ?>
                    <div class="mb-1 text-muted">Kode</div>
                    <div class="fw-bold"><?= esc($period['code']) ?></div>
                    <div class="mb-1 text-muted mt-2">Nama</div>
                    <div class="fw-bold"><?= esc($period['name']) ?></div>
                    <div class="mb-1 text-muted mt-2">Status</div>
                    <?php if ($period['is_open']): ?>
                        <span class="badge bg-success"><i class="fas fa-check"></i> Open</span>
                    <?php else: ?>
                        <span class="badge bg-secondary"><i class="fas fa-lock"></i> Closed</span>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="text-muted">Tidak ada periode aktif</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-12 col-md-4">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-book"></i> Jurnal
                </h5>
            </div>
            <div class="card-body">
                <a href="<?= site_url('accounting/journal?status=draft') ?>" class="card-link">
                    <i class="fas fa-pen"></i> Jurnal Draft
                </a>
                <a href="<?= site_url('accounting/journal?status=posted') ?>" class="card-link">
                    <i class="fas fa-check-circle"></i> Jurnal Posted
                </a>
                <hr class="my-2">
                <a href="<?= site_url('accounting/coa') ?>" class="card-link">
                    <i class="fas fa-code-branch"></i> Chart of Accounts
                </a>
                <a href="<?= site_url('accounting/ledger') ?>" class="card-link">
                    <i class="fas fa-book-open"></i> Buku Besar
                </a>
                <hr class="my-2">
                <a href="<?= site_url('accounting/financial-reports') ?>" class="card-link">
                    <i class="fas fa-file-invoice"></i> Laporan Keuangan
                </a>
                <a href="<?= site_url('accounting/bank-reconciliation') ?>" class="card-link">
                    <i class="fas fa-university"></i> Bank Rec
                </a>
                <a href="<?= site_url('accounting/fixed-asset') ?>" class="card-link">
                    <i class="fas fa-building"></i> Aset Tetap
                </a>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
