<?= $this->extend('layouts/main') ?>
<?php $pageTitle = $page_title ?? 'Modul Akuntansi'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <h5 class="mb-0"><?= esc($page_title) ?></h5>
  <div class="row mt-3">
    <div class="col-md-6">
      <a class="btn btn-primary" href="<?= site_url('accounting/coa') ?>">
        <i class="fas fa-book"></i> Chart of Accounts
      </a>
    </div>
    <div class="col-md-6">
      <a class="btn btn-primary" href="<?= site_url('accounting/journal') ?>">
        <i class="fas fa-file-invoice"></i> Journal Entries
      </a>
    </div>
    <div class="col-md-6 mt-2">
      <a class="btn btn-primary" href="<?= site_url('accounting/ledger') ?>">
        <i class="fas fa-list"></i> Ledger
      </a>
    </div>
    <div class="col-md-6 mt-2">
      <a class="btn btn-primary" href="<?= site_url('accounting/bank-reconciliation') ?>">
        <i class="fas fa-university"></i> Bank Reconciliation
      </a>
    </div>
    <div class="col-md-6 mt-2">
      <a class="btn btn-primary" href="<?= site_url('accounting/fixed-asset') ?>">
        <i class="fas fa-building"></i> Fixed Assets
      </a>
    </div>
  </div>
</div></div>
<?= $this->endSection() ?>
