<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>

<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0"><i class="fas fa-code-branch"></i> <?= esc($page_title) ?></h5>
                <a href="<?= base_url('accounting/coa') ?>" class="btn btn-secondary btn-sm">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
            <div class="card-body">
                <form action="<?= base_url($action) ?>" method="post">
                    <input type="hidden" name="id" value="<?= $account['id'] ?? '' ?>">

                    <div class="row g-3">
                        <div class="col-md-3">
                            <label class="form-label">Kode Akun <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="code" value="<?= old('code', $account['code'] ?? '') ?>" required placeholder="Contoh: 1101">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Nama Akun <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="name" value="<?= old('name', $account['name'] ?? '') ?>" required placeholder="Contoh: Uang Kas">
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Tipe Akun <span class="text-danger">*</span></label>
                            <select class="form-select" name="account_type" required>
                                <option value="">-- Pilih --</option>
                                <?php foreach ($types as $type): ?>
                                    <option value="<?= $type['value'] ?>" <?= old('account_type', $account['account_type'] ?? '') == $type['value'] ? 'selected' : '' ?>>
                                        <?= $type['label'] ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Saldo Normal</label>
                            <select class="form-select" name="normal_balance" required>
                                <option value="debit" <?= old('normal_balance', $account['normal_balance'] ?? '') == 'debit' ? 'selected' : '' ?>>Debit</option>
                                <option value="credit" <?= old('normal_balance', $account['normal_balance'] ?? '') == 'credit' ? 'selected' : '' ?>>Kredit</option>
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Akun Induk</label>
                            <select class="form-select" name="parent_id">
                                <option value="">-- Tanpa Induk --</option>
                                <?php foreach ($parents as $parent): ?>
                                    <option value="<?= $parent['id'] ?>" <?= old('parent_id', $account['parent_id'] ?? '') == $parent['id'] ? 'selected' : '' ?>>
                                        <?= esc($parent['code'] . ' - ' . $parent['name']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3 d-flex align-items-end">
                            <div class="form-check mt-3">
                                <input class="form-check-input" type="checkbox" name="is_active" id="is_active" value="1" <?= old('is_active', $account['is_active'] ?? true) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="is_active">Aktif</label>
                            </div>
                        </div>

                        <div class="col-12">
                            <label class="form-label">Deskripsi</label>
                            <textarea class="form-control" name="description" rows="2"><?= old('description', $account['description'] ?? '') ?></textarea>
                        </div>

                        <div class="col-12 d-flex justify-content-end gap-2 mt-3">
                            <a href="<?= base_url('accounting/coa') ?>" class="btn btn-secondary">Batal</a>
                            <button type="submit" class="btn btn-primary">
                                <?= $account ? 'Update Akun' : 'Simpan Akun' ?>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
