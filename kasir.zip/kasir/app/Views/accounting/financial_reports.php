<?= $this->extend('layouts/main') ?>
<?php $pageTitle = $page_title ?? 'Laporan Keuangan'; ?>
<?= $this->section('content') ?>
<style>
  .fin-header {
    display:flex;align-items:center;justify-content:space-between;
    flex-wrap:wrap;gap:.75rem;margin-bottom:1.25rem;
  }
  .fin-header h2 {
    font-weight:700;font-size:1.35rem;color:#1e293b;margin:0;
    display:flex;align-items:center;gap:.5rem;
  }
  .period-badge {
    background:#f1f5f9;border:1px solid #e2e8f0;
    padding:.35rem .75rem;border-radius:999px;
    font-size:.8rem;color:#475569;
    display:inline-flex;align-items:center;gap:.35rem;
  }
  .stat-grid {
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
    gap:1rem;
    margin-bottom:1.5rem;
  }
  .fin-stat {
    background:#fff;
    border-radius:1rem;
    padding:1.25rem;
    border:1px solid #e2e8f0;
    box-shadow:0 1px 2px rgba(0,0,0,.03);
    position:relative;
    overflow:hidden;
  }
  .fin-stat .stat-icon {
    position:absolute;
    right:1rem;top:1rem;
    opacity:.12;
    font-size:2.5rem;
  }
  .fin-stat .stat-label {
    font-size:.78rem;
    text-transform:uppercase;
    letter-spacing:.5px;
    color:#64748b;
    font-weight:500;
    margin-bottom:.4rem;
  }
  .fin-stat .stat-value {
    font-size:1.5rem;
    font-weight:800;
    color:#1e293b;
  }
  .fin-stat .stat-sub {
    font-size:.75rem;
    color:#94a3b8;
    margin-top:.3rem;
  }
  .section-card {
    background:#fff;
    border-radius:1rem;
    border:1px solid #e2e8f0;
    margin-bottom:1.25rem;
    overflow:hidden;
  }
  .section-card .section-head {
    padding:.75rem 1.25rem;
    background:#f8fafc;
    border-bottom:1px solid #e2e8f0;
    font-weight:600;
    font-size:.95rem;
    color:#1e293b;
    display:flex;align-items:center;gap:.5rem;
  }
  .section-card .section-body {
    padding:.75rem 1.25rem;
  }
  .fin-table {
    margin:0;
    font-size:.88rem;
  }
  .fin-table thead th {
    background:#f1f5f9;
    color:#475569;
    font-weight:600;
    font-size:.78rem;
    text-transform:uppercase;
    letter-spacing:.3px;
    padding:.5rem .85rem;
    border-bottom:1px solid #e2e8f0;
    text-align:right;
  }
  .fin-table thead th:first-child {
    text-align:left;
  }
  .fin-table tbody td {
    padding:.45rem .85rem;
    border-bottom:1px solid #f1f5f9;
    color:#475569;
  }
  .fin-table tbody td:first-child {
    font-weight:500;
    color:#1e293b;
  }
  .fin-table tbody td:last-child {
    text-align:right;
    font-weight:600;
    font-family:'Courier New',monospace;
    color:#1e293b;
  }
  .fin-table tbody tr:last-child td {
    border-bottom:none;
    border-top:2px solid #e2e8f0;
    font-weight:700;
    background:#f8fafc;
  }
  .total-row td {
    font-weight:700 !important;
    background:#f1f5f9 !important;
    color:#1e293b !important;
  }
  .highlight-positive {
    color:#059669;
    font-weight:700;
  }
  .highlight-negative {
    color:#dc2626;
    font-weight:700;
  }
</style>

<div class="fin-header">
  <h2><i class="fas fa-file-invoice text-primary me-2"></i><?= esc($pageTitle) ?></h2>
  <div class="period-badge">
    <i class="fas fa-calendar-alt"></i>
    Periode: <?= esc($period_name ?? 'Tidak ada') ?>
  </div>
</div>

<!-- Stat Cards -->
<div class="stat-grid">
  <div class="fin-stat" style="border-left:4px solid #2563eb">
    <i class="fas fa-chart-line text-primary stat-icon"></i>
    <div class="stat-label">Total Pendapatan</div>
    <div class="stat-value"><?= 'Rp ' . number_format((float)($income_statement['total_revenue'] ?? 0), 0, ',', '.') ?></div>
    <div class="stat-sub"> Dari semua akun pendapatan</div>
  </div>
  <div class="fin-stat" style="border-left:4px solid #059669">
    <i class="fas fa-wallet text-success stat-icon"></i>
    <div class="stat-label">Laba Bersih</div>
    <div class="stat-value highlight-positive">
      <?= 'Rp ' . number_format((float)(($income_statement['total_revenue'] ?? 0) - ($income_statement['total_expenses'] ?? 0)), 0, ',', '.') ?>
    </div>
    <div class="stat-sub"> Pendapatan - Biaya</div>
  </div>
  <div class="fin-stat" style="border-left:4px solid #7c3aed">
    <i class="fas fa-building text-purple stat-icon"></i>
    <div class="stat-label">Total Aset</div>
    <div class="stat-value"><?= 'Rp ' . number_format((float)($balance_sheet['total_assets'] ?? 0), 0, ',', '.') ?></div>
    <div class="stat-sub"> Dari neraca</div>
  </div>
  <div class="fin-stat" style="border-left:4px solid #d97706">
    <i class="fas fa-money-bill-wave text-warning stat-icon"></i>
    <div class="stat-label">Arus Kas</div>
    <div class="stat-value <?= ($cash_flow['net_cash_flow'] ?? 0) >= 0 ? 'highlight-positive' : 'highlight-negative' ?>">
      <?= 'Rp ' . number_format((float)($cash_flow['net_cash_flow'] ?? 0), 0, ',', '.') ?>
    </div>
    <div class="stat-sub">
      <?= ($cash_flow['net_cash_flow'] ?? 0) >= 0 ? 'Peningkatan kas' : 'Penurunan kas' ?>
    </div>
  </div>
</div>

<div class="row">
  <!-- Laba Rugi -->
  <div class="col-lg-6">
    <div class="section-card">
      <div class="section-head">
        <i class="fas fa-chart-simple text-primary"></i>
        Ringkasan Laba Rugi
      </div>
      <div class="section-body">
        <table class="table fin-table">
          <thead>
            <tr><th>Item</th><th style="width:130px">Jumlah</th></tr>
          </thead>
          <tbody>
            <tr>
              <td><i class="fas fa-arrow-up text-success me-1"></i>Total Pendapatan</td>
              <td class="highlight-positive"><?= 'Rp ' . number_format((float)($income_statement['total_revenue'] ?? 0), 0, ',', '.') ?></td>
            </tr>
            <tr>
              <td><i class="fas fa-arrow-down text-danger me-1"></i>Total Biaya</td>
              <td class="highlight-negative"><?= 'Rp ' . number_format((float)($income_statement['total_expenses'] ?? 0), 0, ',', '.') ?></td>
            </tr>
            <tr class="total-row">
              <td><i class="fas fa-check-circle text-primary me-1"></i>Laba Bersih</td>
              <td><?= 'Rp ' . number_format((float)(($income_statement['total_revenue'] ?? 0) - ($income_statement['total_expenses'] ?? 0)), 0, ',', '.') ?></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Neraca -->
  <div class="col-lg-6">
    <div class="section-card">
      <div class="section-head">
        <i class="fas fa-balance-scale text-primary"></i>
        Ringkasan Neraca
      </div>
      <div class="section-body">
        <table class="table fin-table">
          <thead>
            <tr><th>Item</th><th style="width:130px">Jumlah</th></tr>
          </thead>
          <tbody>
            <tr>
              <td><i class="fas fa-arrow-up text-success me-1"></i>Aset</td>
              <td><?= 'Rp ' . number_format((float)($balance_sheet['total_assets'] ?? 0), 0, ',', '.') ?></td>
            </tr>
            <tr>
              <td><i class="fas fa-arrow-down text-danger me-1"></i>Liabilitas</td>
              <td><?= 'Rp ' . number_format((float)($balance_sheet['total_liabilities'] ?? 0), 0, ',', '.') ?></td>
            </tr>
            <tr>
              <td><i class="fas fa-arrow-up text-primary me-1"></i>Ekuitas</td>
              <td><?= 'Rp ' . number_format((float)($balance_sheet['total_equity'] ?? 0), 0, ',', '.') ?></td>
            </tr>
            <tr class="total-row">
              <td><i class="fas fa-balance-scale me-1"></i>Total Liabilitas + Ekuitas</td>
              <td><?= 'Rp ' . number_format((float)(( $balance_sheet['total_liabilities'] ?? 0) + ($balance_sheet['total_equity'] ?? 0)), 0, ',', '.') ?></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- Cash Flow -->
<div class="col-lg-12">
  <div class="section-card">
    <div class="section-head">
      <i class="fas fa-money-bill-transfer text-primary"></i>
      Ringkasan Arus Kas
    </div>
    <div class="section-body">
      <table class="table fin-table">
        <thead>
          <tr><th>Item</th><th style="width:130px">Jumlah</th></tr>
        </thead>
        <tbody>
          <tr>
            <td><i class="fas fa-arrow-up text-success me-1"></i>Kas Awal</td>
            <td><?= 'Rp ' . number_format((float)($cash_flow['opening_balance'] ?? 0), 0, ',', '.') ?></td>
          </tr>
          <tr>
            <td><i class="fas fa-arrow-down text-danger me-1"></i>Pengeluaran</td>
            <td class="highlight-negative"><?= 'Rp ' . number_format((float)($cash_flow['cash_outflow'] ?? 0), 0, ',', '.') ?></td>
          </tr>
          <tr>
            <td><i class="fas fa-arrow-up text-success me-1"></i>Pendapatan</td>
            <td class="highlight-positive"><?= 'Rp ' . number_format((float)($cash_flow['cash_inflow'] ?? 0), 0, ',', '.') ?></td>
          </tr>
          <tr class="total-row">
            <td><i class="fas fa-check-circle text-primary me-1"></i>Arus Kas Bersih</td>
            <td class="<?= ($cash_flow['net_cash_flow'] ?? 0) >= 0 ? 'highlight-positive' : 'highlight-negative' ?>">
              <?= 'Rp ' . number_format((float)($cash_flow['net_cash_flow'] ?? 0), 0, ',', '.') ?>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>

<?= $this->endSection() ?>