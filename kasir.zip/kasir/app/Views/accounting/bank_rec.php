<?= $this->extend('layouts/main') ?>
<?php $pageTitle = 'Bank Reconciliation'; ?>
<?= $this->section('content') ?>
<style>
  .bank-card {
    border:1px solid #e2e8f0;
    border-radius:1rem;
    overflow:hidden;
  }
  .bank-card .card-header-custom {
    background:linear-gradient(135deg,#1e293b,#0f172a);
    color:#fff;
    padding:.75rem 1.25rem;
    display:flex;align-items:center;justify-content:space-between;
    flex-wrap:wrap;gap:.5rem;
  }
  .bank-card .card-header-custom h5 {
    margin:0;font-weight:600;font-size:1rem;
    display:flex;align-items:center;gap:.5rem;
  }
  .stat-row {
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:.75rem;
    padding:1rem 1.25rem;
    background:#f8fafc;
    border-bottom:1px solid #e2e8f0;
  }
  .stat-item {
    text-align:center;
  }
  .stat-item .stat-label {
    font-size:.72rem;
    text-transform:uppercase;
    letter-spacing:.4px;
    color:#64748b;
    margin-bottom:.2rem;
  }
  .stat-item .stat-value {
    font-size:1.1rem;
    font-weight:700;
    color:#1e293b;
  }
  .stat-item .stat-value.match {
    color:#059669;
  }
  .stat-item .stat-value.mismatch {
    color:#dc2626;
  }
  .bank-table {
    margin:0;
  }
  .bank-table thead th {
    background:#f1f5f9;
    color:#475569;
    font-weight:600;
    font-size:.78rem;
    text-transform:uppercase;
    letter-spacing:.3px;
    padding:.5rem .75rem;
    border-bottom:2px solid #e2e8f0;
    white-space:nowrap;
  }
  .bank-table tbody td {
    padding:.45rem .75rem;
    border-bottom:1px solid #f1f5f9;
    font-size:.85rem;
    vertical-align:middle;
  }
  .bank-table tbody tr:hover { background:#f8fafc; }
  .bank-table tbody tr:last-child td { border-bottom:none; }
  .badge-booked {
    background:#d1fae5;
    color:#065f46;
    font-size:.72rem;
    padding:.15rem .45rem;
    border-radius:999px;
    font-weight:500;
  }
  .badge-unmatched {
    background:#fef3c7;
    color:#92400e;
    font-size:.72rem;
    padding:.15rem .45rem;
    border-radius:999px;
    font-weight:500;
  }
  .badge-pending {
    background:#f1f5f9;
    color:#64748b;
    font-size:.72rem;
    padding:.15rem .45rem;
    border-radius:999px;
    font-weight:500;
  }
  .empty-state {
    text-align:center;padding:3rem 1rem;
    color:#94a3b8;
  }
  .empty-state i { font-size:2.5rem;margin-bottom:.75rem;opacity:.4;display:block; }
  .empty-state p { margin:0;font-size:.9rem; }
</style>

<div class="bank-card">
  <div class="card-header-custom">
    <h5><i class="fas fa-university text-primary me-2"></i>Bank Reconciliation</h5>
    <div class="d-flex gap-2">
      <button class="btn btn-sm btn-outline-light"><i class="fas fa-download me-1"></i>Export</button>
      <button class="btn btn-sm btn-outline-light"><i class="fas fa-sync me-1"></i>Refresh</button>
    </div>
  </div>

  <!-- Summary Stats -->
  <div class="stat-row">
    <div class="stat-item">
      <div class="stat-label">Bank Statement</div>
      <div class="stat-value">Rp 12.450.000</div>
      <small class="text-muted" style="font-size:.7rem">Per 30 Sep 2026</small>
    </div>
    <div class="stat-item">
      <div class="stat-label">Book Balance</div>
      <div class="stat-value">Rp 12.450.000</div>
      <small class="text-muted" style="font-size:.7rem">Sebelum rekonsiliasi</small>
    </div>
    <div class="stat-item">
      <div class="stat-label">Selisih</div>
      <div class="stat-value match">Rp 0</div>
      <small class="text-muted" style="font-size:.7rem">Dapat direkonsiliasi</small>
    </div>
    <div class="stat-item">
      <div class="stat-label">Status</div>
      <div class="stat-value match" style="font-size:1rem">
        <i class="fas fa-check-circle"></i> Seimbang
      </div>
    </div>
  </div>

  <div class="table-responsive">
    <table class="table bank-table">
      <thead>
        <tr>
          <th style="width:110px">Tanggal</th>
          <th style="width:100px">No. Ref</th>
          <th>Keterangan</th>
          <th style="width:140px;text-align:right">Bank (Rp)</th>
          <th style="width:140px;text-align:right">Buku (Rp)</th>
          <th style="width:100px">Status</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td style="white-space:nowrap;color:#64748b">01/09/2026</td>
          <td style="font-family:monospace;color:#64748b;font-size:.8rem">BK-001</td>
          <td>
            <span style="color:#475569">Transfer dari PT Maju</span>
            <small class="text-muted d-block" style="font-size:.7rem">Invoice INV/01/26/0400</small>
          </td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">Rp 350.000</td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">Rp 350.000</td>
          <td>
            <span class="badge-booked"><i class="fas fa-check"></i> Booked</span>
          </td>
        </tr>
        <tr>
          <td style="white-space:nowrap;color:#64748b">02/09/2026</td>
          <td style="font-family:monospace;color:#64748b;font-size:.8rem">BK-002</td>
          <td>
            <span style="color:#475569">Pengeluaran Gaji</span>
            <small class="text-muted d-block" style="font-size:.7rem">Jurnal JE-2026-0045</small>
          </td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">Rp -850.000</td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">Rp -850.000</td>
          <td>
            <span class="badge-booked"><i class="fas fa-check"></i> Booked</span>
          </td>
        </tr>
        <tr>
          <td style="white-space:nowrap;color:#64748b">05/09/2026</td>
          <td style="font-family:monospace;color:#64748b;font-size:.8rem">BK-003</td>
          <td>
            <span style="color:#475569">Deposit Pembelian</span>
            <small class="text-muted d-block" style="font-size:.7rem">Supplier: Bersaudara</small>
          </td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">Rp 1.200.000</td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">Rp 1.200.000</td>
          <td>
            <span class="badge-booked"><i class="fas fa-check"></i> Booked</span>
          </td>
        </tr>
        <tr>
          <td style="white-space:nowrap;color:#64748b">10/09/2026</td>
          <td style="font-family:monospace;color:#64748b;font-size:.8rem">BK-004</td>
          <td>
            <span style="color:#475569">Biaya Listrik</span>
            <small class="text-muted d-block" style="font-size:.7rem">Tagihan bulan Agustus</small>
          </td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">Rp -150.000</td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">-</td>
          <td>
            <span class="badge-unmatched"><i class="fas fa-exclamation"></i> Unmatched</span>
          </td>
        </tr>
        <tr>
          <td style="white-space:nowrap;color:#64748b">12/09/2026</td>
          <td style="font-family:monospace;color:#64748b;font-size:.8rem">INV/01/26/0450</td>
          <td>
            <span style="color:#475569">Penjualan Warnet Lestari</span>
            <small class="text-muted d-block" style="font-size:.7rem">Kasir: Siti</small>
          </td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">-</td>
          <td style="text-align:right;font-family:monospace;font-weight:600;color:#1e293b">Rp 185.000</td>
          <td>
            <span class="badge-pending"><i class="fas fa-clock"></i> Pending</span>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>

<?= $this->endSection() ?>