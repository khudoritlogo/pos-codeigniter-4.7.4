<?= $this->extend('layouts/main') ?>
<?php $pageTitle = 'Chart of Accounts'; ?>
<?= $this->section('content') ?>
<style>
  .coa-card {
    border:1px solid #e2e8f0;border-radius:1rem;
    overflow:hidden;
  }
  .coa-card .card-header-custom {
    background:linear-gradient(135deg,#1e293b,#0f172a);
    color:#fff;padding:.75rem 1.25rem;
    display:flex;align-items:center;justify-content:space-between;
    flex-wrap:wrap;gap:.5rem;
  }
  .coa-card .card-header-custom h5 {
    margin:0;font-weight:600;font-size:1rem;
    display:flex;align-items:center;gap:.5rem;
  }
  .coa-table {
    margin:0;
  }
  .coa-table thead th {
    background:#f8fafc;
    color:#475569;
    font-weight:600;
    font-size:.82rem;
    text-transform:uppercase;
    letter-spacing:.3px;
    padding:.55rem .85rem;
    border-bottom:2px solid #e2e8f0;
  }
  .coa-table tbody td {
    padding:.5rem .85rem;
    vertical-align:middle;
    border-bottom:1px solid #f1f5f9;
    font-size:.88rem;
  }
  .coa-table tbody tr:hover { background:#f8fafc; }
  .coa-table tbody tr:last-child td { border-bottom:none; }
  .badge-type {
    font-size:.75rem;
    padding:.2rem .55rem;
    border-radius:999px;
    font-weight:500;
    text-transform:capitalize;
  }
  .badge-asset { background:#dbeafe; color:#1d4ed8; }
  .badge-liab { background:#fef3c7; color:#92400e; }
  .badge-equity { background:#f3e8ff; color:#6b21a8; }
  .badge-income { background:#d1fae5; color:#065f46; }
  .badge-expense { background:#fee2e2; color:#991b1b; }
  .balance-indicator {
    display:inline-flex;align-items:center;gap:.3rem;
    font-size:.8rem;font-weight:500;
  }
  .balance-indicator .dot {
    width:6px;height:6px;border-radius:50%;
  }
  .dot-debit { background:#2563eb; }
  .dot-credit { background:#dc2626; }
  .empty-state {
    text-align:center;padding:3rem 1rem;
    color:#94a3b8;
  }
  .empty-state i { font-size:2.5rem;margin-bottom:.75rem;opacity:.4; }
  .empty-state p { margin:0;font-size:.9rem; }
</style>

<div class="coa-card">
  <div class="card-header-custom">
    <h5><i class="fas fa-code-branch text-primary me-2"></i>Chart of Accounts</h5>
    <div class="d-flex gap-2">
      <button class="btn btn-sm btn-outline-light"><i class="fas fa-plus me-1"></i>Tambah</button>
      <button class="btn btn-sm btn-outline-light"><i class="fas fa-download me-1"></i>Export</button>
    </div>
  </div>
  <div class="table-responsive">
    <table class="table coa-table">
      <thead>
        <tr>
          <th>Kode</th>
          <th>Nama Akun</th>
          <th style="width:110px">Tipe</th>
          <th style="width:110px">Normal Balance</th>
        </tr>
      </thead>
      <tbody>
        <?php if (!empty($rows)): ?>
          <?php foreach ($rows as $r): ?>
          <tr>
            <td style="font-weight:600;color:#2563eb;font-family:monospace;font-size:.9rem">
              <?= esc($r['code']) ?>
            </td>
            <td>
              <div class="fw-medium" style="color:#1e293b"><?= esc($r['name']) ?></div>
              <small class="text-muted" style="font-size:.75rem"><?= esc($r['description'] ?? '') ?></small>
            </td>
            <td>
              <span class="badge-type <?php
                switch(strtolower($r['account_type'])):
                  case 'asset': echo 'badge-asset'; break;
                  case 'liability': echo 'badge-liab'; break;
                  case 'equity': echo 'badge-equity'; break;
                  case 'income': echo 'badge-income'; break;
                  case 'expense': echo 'badge-expense'; break;
                  default: echo 'badge-secondary bg-light text-dark';
                endswitch; ?>">
                <?= esc(ucwords($r['account_type'])) ?>
              </span>
            </td>
            <td>
              <span class="balance-indicator">
                <span class="dot <?= $r['normal_balance'] === 'debit' ? 'dot-debit' : 'dot-credit' ?>"></span>
                <?= esc(ucfirst($r['normal_balance'])) ?>
              </span>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="4">
              <div class="empty-state">
                <i class="fas fa-code-branch"></i>
                <p>Belum ada akun di Chart of Accounts</p>
                <small class="text-muted">Tambahkan akun pertama untuk mulai mencatat transaksi</small>
              </div>
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?= $this->endSection() ?>