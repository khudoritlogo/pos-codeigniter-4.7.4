<?= $this->extend('layouts/main') ?>
<?php $pageTitle=$title; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <div class="mb-3 d-flex justify-content-between">
    <h5 class="mb-0">Daftar <?= esc($title) ?></h5>
    <a class="btn btn-primary" href="<?= service('router')->getMatchedRoute()[1] ? site_url('') : site_url($this->getRoute()[1] ?? '') ?><?= uri_string() ?>/new"><i class="fas fa-plus"></i> Tambah</a>
  </div>
  <table class="table datatable table-striped">
    <thead><tr><th>#</th><th>Nama</th><th>Kode/Detail</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($rows as $i=>$r): ?>
      <tr>
        <td><?= $i+1 ?></td>
        <td><?= esc($r['name']) ?></td>
        <td><?= esc($r['symbol'] ?? $r['code'] ?? $r['phone'] ?? $r['description'] ?? '') ?></td>
        <td class="text-end">
          <a class="btn btn-sm btn-outline-primary" href="<?= '/'.uri_string().'/'.$r['id'].'/edit' ?>"><i class="fas fa-edit"></i></a>
          <form method="post" action="<?= '/'.uri_string().'/'.$r['id'] ?>" class="d-inline" onsubmit="return confirm('Hapus?')"><?= csrf_field() ?><input type="hidden" name="_method" value="DELETE"><button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button></form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
