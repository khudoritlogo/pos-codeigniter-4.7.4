<?= $this->extend('layouts/main') ?>
<?php $pageTitle = $page_title ?? 'Data Pengguna'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <div class="mb-3 d-flex justify-content-between">
    <h5 class="mb-0"><?= esc($page_title) ?></h5>
    <a class="btn btn-primary" href="<?= site_url('users/new') ?>"><i class="fas fa-plus"></i> Tambah</a>
  </div>
  <?php if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
  <?php endif; ?>
  <table class="table datatable table-striped">
    <thead><tr><th>#</th><th>Username</th><th>Nama</th><th>Email</th><th>Status</th><th>Terakhir Login</th></tr></thead>
    <tbody>
    <?php if (!empty($rows)): ?>
      <?php foreach ($rows as $i => $r): ?>
      <tr>
        <td><?= $i + 1 ?></td>
        <td><code><?= esc($r['username']) ?></code></td>
        <td><?= esc($r['fullname'] ?? $r['username']) ?></td>
        <td><?= esc($r['email'] ?? '-') ?></td>
        <td><span class="badge bg-<?= $r['is_active'] ? 'success' : 'danger' ?>"><?= $r['is_active'] ? 'Aktif' : 'Nonaktif' ?></span></td>
        <td><?= $r['last_login'] ? date('d/m/Y H:i', strtotime($r['last_login'])) : '-' ?></td>
      </tr>
      <?php endforeach; ?>
    <?php else: ?>
      <tr><td colspan="6" class="text-center text-muted">Belum ada pengguna</td></tr>
    <?php endif; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
