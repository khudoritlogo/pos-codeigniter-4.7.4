<?= $this->extend('layouts/main') ?>
<?php $pageTitle=($row?'Edit':'Tambah').' User'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <form method="post" action="<?= $row?'/users/'.$row['id']:'/users' ?>">
    <?= csrf_field() ?><?php if($row): ?><input type="hidden" name="_method" value="PUT"><?php endif; ?>
    <div class="row g-3">
      <div class="col-md-4"><label class="form-label">Username *</label><input required class="form-control" name="username" value="<?= esc($row['username']??'') ?>"></div>
      <div class="col-md-4"><label class="form-label">Password <?= $row?'<small>(kosongkan jika tidak diubah)</small>':'*' ?></label><input class="form-control" type="password" name="password" <?= $row?'':'required' ?>></div>
      <div class="col-md-4"><label class="form-label">Nama Lengkap *</label><input required class="form-control" name="fullname" value="<?= esc($row['fullname']??'') ?>"></div>
      <div class="col-md-4"><label class="form-label">Level *</label>
        <select required class="form-select select2" name="level_id">
          <?php foreach($levels as $l): ?><option value="<?=$l['id']?>" <?=($row['level_id']??0)==$l['id']?'selected':''?>><?=esc($l['name'])?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-4"><label class="form-label">Cabang</label>
        <select class="form-select select2" name="branch_id"><option value="">--</option>
          <?php foreach($branches as $b): ?><option value="<?=$b['id']?>" <?=($row['branch_id']??0)==$b['id']?'selected':''?>><?=esc($b['name'])?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-4"><label class="form-label">Email</label><input class="form-control" name="email" value="<?= esc($row['email']??'') ?>"></div>
      <div class="col-md-4"><label class="form-label">No. HP</label><input class="form-control" name="phone" value="<?= esc($row['phone']??'') ?>"></div>
      <div class="col-md-4"><label class="form-label">WhatsApp</label><input class="form-control" name="whatsapp" value="<?= esc($row['whatsapp']??'') ?>"></div>
      <div class="col-md-4"><label class="form-label">Status</label>
        <select class="form-select" name="is_active"><option value="1" <?=($row['is_active']??1)==1?'selected':''?>>Aktif</option><option value="0" <?=($row['is_active']??1)==0?'selected':''?>>Nonaktif</option></select>
      </div>
    </div><hr>
    <button class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
    <a class="btn btn-secondary" href="<?= site_url('users') ?>">Batal</a>
  </form>
</div></div>
<?= $this->endSection() ?>
