<?php $store = $store ?? []; ?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= esc($store['store_name'] ?? 'Customer App') ?></title>
<link rel="manifest" href="<?= site_url('manifest.webmanifest') ?>">
<meta name="theme-color" content="#0d6efd">
<link rel="apple-touch-icon" href="<?= site_url('assets/pwa/icon-192.png') ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
<style>
  body{background:linear-gradient(180deg,#0d6efd 0%,#0d6efd 60px,#f8f9fa 60px);min-height:100vh}
  .app-shell{max-width:480px;margin:0 auto;padding:16px}
  .app-header{color:#fff;text-align:center;padding:8px 0 16px}
  .voucher-card{border-left:5px solid #ffc107}
  .hide{display:none}
</style>
</head>
<body>
<div class="app-shell">
  <div class="app-header">
    <h5 class="mb-0"><i class="fas fa-store me-1"></i> <?= esc($store['store_name'] ?? 'POS Kasir') ?></h5>
    <small class="opacity-75">Customer Self-Service</small>
  </div>

  <!-- STEP 1: request OTP -->
  <div id="stepPhone" class="card shadow-sm">
    <div class="card-body">
      <label class="form-label small">Nomor HP / WhatsApp</label>
      <input id="phone" type="tel" class="form-control form-control-lg" placeholder="08xxxxxxxxxx" inputmode="numeric">
      <button id="btnOtp" class="btn btn-primary w-100 mt-3"><i class="fas fa-paper-plane me-1"></i> Kirim OTP</button>
      <div id="phoneErr" class="text-danger small mt-2"></div>
    </div>
  </div>

  <!-- STEP 2: OTP -->
  <div id="stepOtp" class="card shadow-sm hide">
    <div class="card-body">
      <label class="form-label small">Masukkan 6 digit OTP</label>
      <input id="otp" type="text" class="form-control form-control-lg text-center" maxlength="6" inputmode="numeric">
      <button id="btnVerify" class="btn btn-success w-100 mt-3"><i class="fas fa-check me-1"></i> Verifikasi</button>
      <div id="otpErr" class="text-danger small mt-2"></div>
    </div>
  </div>

  <!-- STEP 3: Home -->
  <div id="stepHome" class="hide">
    <div class="card mb-3 bg-primary text-white">
      <div class="card-body">
        <small>Halo,</small>
        <h5 id="cName" class="mb-1">-</h5>
        <div class="d-flex justify-content-between">
          <div><small>Poin Loyalty</small><div class="h4 mb-0" id="cPoints">0</div></div>
          <div class="text-end"><small>Level</small><div class="h6 mb-0" id="cLevel">-</div></div>
        </div>
      </div>
    </div>

    <ul class="nav nav-pills nav-fill mb-2" role="tablist">
      <li class="nav-item"><button class="nav-link active" data-tab="tabV">Voucher</button></li>
      <li class="nav-item"><button class="nav-link" data-tab="tabO">Riwayat</button></li>
      <li class="nav-item"><button class="nav-link" data-tab="tabR">Referral</button></li>
    </ul>

    <div id="tabV"><div id="voucherList"></div></div>
    <div id="tabO" class="hide"><div id="orderList"></div></div>
    <div id="tabR" class="hide">
      <div class="card"><div class="card-body text-center">
        <small class="text-muted">Bagikan link ini — dapat bonus poin tiap teman belanja pertama:</small>
        <input id="refLink" class="form-control mt-2" readonly>
        <button class="btn btn-outline-primary mt-2 w-100" onclick="navigator.clipboard.writeText(document.getElementById('refLink').value)"><i class="fas fa-copy me-1"></i> Salin Link</button>
      </div></div>
    </div>
  </div>
</div>

<script>
const $ = (s)=>document.querySelector(s);
let token = null;

async function post(url, data){
  const fd = new FormData();
  for (const k in data) fd.append(k, data[k]);
  const r = await fetch(url, {method:'POST', body: fd});
  return r.json();
}

$('#btnOtp').addEventListener('click', async ()=>{
  $('#phoneErr').textContent = '';
  const j = await post('/app/request-otp', {phone: $('#phone').value});
  if (! j.ok){ $('#phoneErr').textContent = j.msg; return; }
  token = j.token;
  $('#stepPhone').classList.add('hide');
  $('#stepOtp').classList.remove('hide');
});

$('#btnVerify').addEventListener('click', async ()=>{
  $('#otpErr').textContent = '';
  const j = await post('/app/verify-otp', {token, otp: $('#otp').value});
  if (! j.ok){ $('#otpErr').textContent = j.msg; return; }
  loadHome();
});

async function loadHome(){
  const r = await fetch('/app/me?token=' + token);
  const j = await r.json();
  if (! j.ok) { $('#stepHome').classList.add('hide'); return; }
  const c = j.customer;
  $('#cName').textContent = c.name || '-';
  $('#cPoints').textContent = c.loyalty_points || 0;
  $('#cLevel').textContent = c.level_name || 'Regular';
  $('#refLink').value = j.referral_link;
  $('#voucherList').innerHTML = (j.vouchers||[]).map(v => `
    <div class="card voucher-card mb-2"><div class="card-body py-2">
      <div class="d-flex justify-content-between"><b>${v.code}</b><span class="badge bg-warning text-dark">${v.discount_type==='percent' ? v.discount_value+'%' : 'Rp '+Number(v.discount_value).toLocaleString('id-ID')}</span></div>
      <small class="text-muted">${v.name || ''}</small>
    </div></div>`).join('') || '<div class="text-muted text-center py-3">Belum ada voucher aktif</div>';
  $('#orderList').innerHTML = (j.orders||[]).map(o => `
    <div class="card mb-2"><div class="card-body py-2 d-flex justify-content-between">
      <div><b>${o.invoice_no}</b><br><small class="text-muted">${o.created_at||''}</small></div>
      <div class="text-end"><b>Rp ${Number(o.total).toLocaleString('id-ID')}</b><br><span class="badge bg-secondary">${o.status}</span></div>
    </div></div>`).join('') || '<div class="text-muted text-center py-3">Belum ada transaksi</div>';
  $('#stepOtp').classList.add('hide');
  $('#stepHome').classList.remove('hide');
}

document.querySelectorAll('[data-tab]').forEach(btn => btn.addEventListener('click', () => {
  document.querySelectorAll('[data-tab]').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  ['tabV','tabO','tabR'].forEach(id => $('#'+id).classList.add('hide'));
  $('#' + btn.dataset.tab).classList.remove('hide');
}));

// Register service worker (offline capable)
if ('serviceWorker' in navigator) navigator.serviceWorker.register('<?= site_url('service-worker.js') ?>').catch(()=>{});
</script>
</body>
</html>
