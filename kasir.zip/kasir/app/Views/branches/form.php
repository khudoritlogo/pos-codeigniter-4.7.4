<?= $this->extend('layouts/main') ?>
<?php $pageTitle = ($row?'Edit':'Tambah').' '.$title; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body" style="max-width:700px">
  <form method="post" action="<?= $row ? '/'.uri_string().'/'.$row['id'] : '/'.explode('/',uri_string())[0] ?>">
    <?= csrf_field() ?>
    <?php if ($row): ?><input type="hidden" name="_method" value="PUT"><?php endif; ?>
    <div class="mb-3"><label class="form-label">Nama *</label><input class="form-control" name="name" required value="<?= esc($row['name']??'') ?>"></div>
    <?php $isUnit=(strpos(uri_string(),'units')!==false); if ($isUnit): ?>
      <div class="mb-3"><label class="form-label">Simbol</label><input class="form-control" name="symbol" value="<?= esc($row['symbol']??'') ?>"></div>
    <?php else: ?>
      <div class="mb-3"><label class="form-label">Deskripsi</label><textarea class="form-control" name="description"><?= esc($row['description']??'') ?></textarea></div>
    <?php endif; ?>
    <button class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
    <a class="btn btn-secondary" href="javascript:history.back()">Batal</a>
  </form>
</div></div>
<?= $this->endSection() ?>
