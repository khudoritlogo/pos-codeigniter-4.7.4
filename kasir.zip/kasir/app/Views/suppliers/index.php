<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <div><h1 class="h3 mb-0 text-gray-800"><?= esc($title ?? 'Supplier') ?></h1></div>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?= site_url('suppliers/new') ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Tambah</a>
        <div class="input-group" style="max-width:300px">
            <input type="text" name="q" class="form-control" placeholder="Cari..." value="<?= esc($search ?? '') ?>">
            <div class="input-group-append">
                <button class="btn btn-info" type="submit"><i class="fas fa-search"></i></button>
            </div>
        </div>
    </div>
</div>
<div class="card shadow"><div class="card-body p-0">
<table class="table table-hover table-striped mb-0">
  <thead class="table-light"><tr><th>No</th><th>Nama Supplier</th><th>Telepon</th><th>Email</th><th>Alamat</th><th class="text-center" style="width:80px">Status</th><th style="width:100px" class="text-center">Aksi</th></tr></thead>
  <tbody>
    <?php if(empty($suppliers)): ?><tr><td colspan="7" class="text-center py-4"><i class="fas fa-truck-loading fa-2x text-muted"></i><p class="mt-2 text-muted">Belum ada supplier.</p></td></tr><?php endif; ?>
    <?php foreach($suppliers ?? [] as $i => $s): ?>
    <tr>
      <td><?= $i+1 ?></td>
      <td><b><?= esc($s['name']) ?></b><br><small class="text-muted"><?= esc($s['code'] ?? '-') ?></small></td>
      <td><?= esc($s['phone'] ?? '-') ?></td>
      <td><?= esc($s['email'] ?? '-') ?></td>
      <td><small><?= esc($s['address'] ?? '-') ?></small></td>
      <td class="text-center"><?php if($s['is_active']): ?><span class="badge badge-success">Aktif</span><?php else: ?><span class="badge badge-secondary">Nonaktif</span><?php endif; ?></td>
      <td class="text-center">
        <div class="btn-group btn-group-sm">
          <a href="<?= site_url("suppliers/edit/$s[id]") ?>" class="btn btn-info btn-sm"><i class="fas fa-edit"></i></a>
          <?php if(session()->get('level_code')==='superadmin'): ?>
          <form action="<?= site_url("suppliers/delete/$s[id]") ?>" method="post" class="d-inline" onsubmit="return confirm('Hapus supplier ini?')"><button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></form>
          <?php endif; ?>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div></div>
<?= $this->endSection() ?>