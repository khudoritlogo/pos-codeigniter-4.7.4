<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<?php $pageTitle = ($supplier ? 'Edit' : 'Tambah') . ' Supplier'; ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <div><h1 class="h3 mb-0 text-gray-800"><?= esc($pageTitle) ?></h1></div>
    <a href="<?= site_url('suppliers') ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Kembali</a>
</div>
<?php if (session('errors')): ?>
<div class="alert alert-danger alert-dismissible"><?= session('errors') ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>
<div class="card shadow"><div class="card-body">
<form method="post" action="<?= $action ?>">
  <?= csrf_field() ?>
  <?php if($supplier): ?><input type="hidden" name="_method" value="PUT"><?php endif; ?>
  <div class="row g-3">
    <div class="col-md-6"><label class="form-label">Nama Supplier *</label><input class="form-control" name="name" required value="<?= esc($supplier['name'] ?? '') ?>"></div>
    <div class="col-md-6"><label class="form-label">Kode Supplier</label><input class="form-control" name="code" value="<?= esc($supplier['code'] ?? '') ?>"></div>
    <div class="col-md-6"><label class="form-label">Nomor Telepon</label><input class="form-control" name="phone" value="<?= esc($supplier['phone'] ?? '') ?>"></div>
    <div class="col-md-6"><label class="form-label">Email</label><input class="form-control" name="email" type="email" value="<?= esc($supplier['email'] ?? '') ?>"></div>
    <div class="col-md-12"><label class="form-label">Alamat</label><textarea class="form-control" name="address" rows="2"><?= esc($supplier['address'] ?? '') ?></textarea></div>
    <div class="col-md-6"><label class="form-label">Kontak Person</label><input class="form-control" name="contact_person" value="<?= esc($supplier['contact_person'] ?? '') ?>"></div>
    <div class="col-md-6"><label class="form-label">Keterangan</label><input class="form-control" name="notes" value="<?= esc($supplier['notes'] ?? '') ?>"></div>
    <div class="col-md-6 form-check ms-3 mt-4"><input class="form-check-input" type="checkbox" name="is_active" value="1" <?= ($supplier['is_active'] ?? 1)?'checked':'' ?>><label class="form-check-label">Aktif</label></div>
  </div>
  <hr>
  <div class="d-flex justify-content-end gap-2">
    <a href="<?= site_url('suppliers') ?>" class="btn btn-secondary">Batal</a>
    <button class="btn btn-primary"><i class="fas fa-save"></i> <?= $supplier ? 'Perbarui' : 'Simpan' ?></button>
  </div>
</form>
</div></div>
<?= $this->endSection() ?>