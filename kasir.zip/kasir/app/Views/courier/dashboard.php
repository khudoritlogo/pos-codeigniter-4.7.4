<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Dashboard Kurir'; $mapsKey = $store['google_maps_api_key'] ?? ''; ?>
<?= $this->section('content') ?>

<div class="row g-3">
  <div class="col-md-3"><div class="stat-card bg-warning"><small>Menunggu Diantar</small><h3><?= (int)$stats['pending'] ?></h3></div></div>
  <div class="col-md-3"><div class="stat-card bg-info"><small>Dalam Perjalanan</small><h3><?= (int)$stats['in_progress'] ?></h3></div></div>
  <div class="col-md-3"><div class="stat-card bg-success"><small>Selesai Hari Ini</small><h3><?= (int)$stats['delivered_today'] ?></h3></div></div>
  <div class="col-md-3"><div class="stat-card bg-primary"><small>Total Order</small><h3><?= (int)$stats['total'] ?></h3></div></div>
</div>

<div class="text-end my-3">
    <a class="btn btn-warning" href="<?= site_url('courier/route-planner') ?>"><i class="fas fa-route"></i> Optimasi Rute (Multi-Stop)</a>
  <button class="btn btn-info" id="btnToggleTracking"><i class="fas fa-satellite-dish"></i> Aktifkan Live Tracking</button>
  <span id="trackingStatus" class="ms-2 small text-muted">Tracking OFF</span>
</div>

<div class="row g-3 mt-1">
  <div class="col-lg-7">
    <div class="card"><div class="card-header bg-dark text-white"><b><i class="fas fa-list-check"></i> Daftar Pengiriman Aktif</b></div>
      <div class="card-body p-0">
        <table class="table table-sm mb-0">
          <thead><tr><th>Invoice</th><th>Customer</th><th>Alamat</th><th>Status</th><th></th></tr></thead>
          <tbody>
            <?php foreach ($deliveries as $d): ?>
            <tr>
              <td><small><?= esc($d['invoice_no']) ?></small></td>
              <td><?= esc($d['customer_name'] ?? '-') ?><br><small class="text-muted"><?= esc($d['customer_phone'] ?? '') ?></small></td>
              <td><small><?= esc($d['delivery_address']) ?></small></td>
              <td><span class="badge bg-<?= $d['delivery_status']=='pending'?'warning':'info' ?>"><?= $d['delivery_status'] ?></span></td>
              <td>
                <div class="btn-group btn-group-sm">
                  <?php if ($d['delivery_lat'] && $d['delivery_lng']): ?>
                    <a class="btn btn-outline-primary" target="_blank" href="https://www.google.com/maps/dir/?api=1&destination=<?=$d['delivery_lat']?>,<?=$d['delivery_lng']?>"><i class="fas fa-map-marker-alt"></i></a>
                  <?php endif; ?>
                  <button class="btn btn-outline-success" onclick="sendWa(<?= $d['id'] ?>)"><i class="fab fa-whatsapp"></i></button>
                  <button class="btn btn-outline-info" onclick="setStatus(<?= $d['id'] ?>,'in_progress')"><i class="fas fa-truck"></i></button>
                  <button class="btn btn-outline-success" onclick="setStatus(<?= $d['id'] ?>,'delivered')"><i class="fas fa-check"></i></button>
                </div>
              </td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <div class="col-lg-5">
    <div class="card">
      <div class="card-header"><b><i class="fas fa-map"></i> Peta Pengiriman</b></div>
      <div class="card-body p-0"><div id="map" style="height:400px;background:#eef"></div></div>
    </div>
  </div>
</div>

<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
function setStatus(id,st){
  fetch('/courier/update-status/'+id,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'delivery_status='+st})
    .then(r=>r.json()).then(()=>location.reload());
}
function sendWa(id){
  fetch('/courier/send-wa/'+id,{method:'POST'}).then(r=>r.json()).then(res=>{
    if (res.link) window.open(res.link,'_blank'); else Swal.fire('Info',res.msg||'','info');
  });
}

// ==== Kurir Live Tracking ====
let trackingWatcher = null;
document.getElementById('btnToggleTracking').addEventListener('click',()=>{
  const btn = document.getElementById('btnToggleTracking');
  const status = document.getElementById('trackingStatus');
  if (trackingWatcher) {
    navigator.geolocation.clearWatch(trackingWatcher); trackingWatcher = null;
    btn.innerHTML = '<i class="fas fa-satellite-dish"></i> Aktifkan Live Tracking';
    btn.className = 'btn btn-info';
    status.textContent = 'Tracking OFF'; status.className='ms-2 small text-muted';
    return;
  }
  if (!navigator.geolocation) return Swal.fire('Info','Browser tidak mendukung GPS','warning');
  trackingWatcher = navigator.geolocation.watchPosition(pos => {
    fetch('/courier/location',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({latitude:pos.coords.latitude,longitude:pos.coords.longitude,accuracy:pos.coords.accuracy,speed:pos.coords.speed,heading:pos.coords.heading})
    }).catch(()=>{});
    status.textContent = 'Tracking ON · ('+pos.coords.latitude.toFixed(5)+', '+pos.coords.longitude.toFixed(5)+')';
    status.className = 'ms-2 small text-success';
  }, err => {
    status.textContent = 'Error: '+err.message; status.className='ms-2 small text-danger';
  }, { enableHighAccuracy:true, maximumAge:5000, timeout:15000 });
  btn.innerHTML = '<i class="fas fa-stop-circle"></i> Matikan Tracking';
  btn.className = 'btn btn-danger';
});
</script>
<?php if ($mapsKey): ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?= esc($mapsKey) ?>"></script>
<script>
const deliveries = <?= json_encode(array_map(fn($d)=>['lat'=>$d['delivery_lat'],'lng'=>$d['delivery_lng'],'title'=>$d['invoice_no']],$deliveries)) ?>;
const validPts = deliveries.filter(d=>d.lat&&d.lng);
const center = validPts[0] ? {lat:+validPts[0].lat,lng:+validPts[0].lng}:{lat:-6.2,lng:106.816};
const map = new google.maps.Map(document.getElementById('map'),{center,zoom:12});
validPts.forEach(p=>new google.maps.Marker({position:{lat:+p.lat,lng:+p.lng},map,title:p.title}));
</script>
<?php else: ?>
<script>document.getElementById('map').innerHTML='<div class="text-center text-muted p-4">Set Google Maps API Key di Pengaturan untuk mengaktifkan peta.</div>';</script>
<?php endif; ?>
<?= $this->endSection() ?>
