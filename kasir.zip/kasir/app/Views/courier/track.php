<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8">
<title>Lacak Kiriman <?= esc($invoice) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
<style>
  body{font-family:system-ui;margin:0;background:#0f172a;color:#fff}
  .header{padding:16px 20px;background:rgba(0,0,0,.4);display:flex;justify-content:space-between;align-items:center}
  .container{display:grid;grid-template-columns:1fr 400px;gap:0;height:calc(100vh - 60px)}
  @media(max-width:960px){.container{grid-template-columns:1fr;grid-template-rows:1fr auto}}
  #map{width:100%;height:100%;background:#e5e7eb}
  .side{padding:20px;overflow:auto;background:#1e293b}
  .status-pill{padding:6px 14px;border-radius:999px;font-size:.85rem;font-weight:600}
  .courier-card{background:rgba(255,255,255,.08);border-radius:12px;padding:16px;margin-top:16px}
  .step{padding:12px 0;border-bottom:1px solid rgba(255,255,255,.1);display:flex;gap:12px;align-items:center}
  .step.active{color:#fbbf24}
  .step .icon{width:32px;height:32px;border-radius:50%;background:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center}
  .step.active .icon{background:#fbbf24;color:#111}
</style></head><body>
<div class="header">
  <div><b><?= esc($store['store_name'] ?? 'POS') ?></b> · Lacak Kiriman</div>
  <div class="text-white-50 small"><?= esc($invoice) ?></div>
</div>
<div class="container">
  <div id="map"></div>
  <div class="side">
    <div class="status-pill" id="statusPill" style="background:#fbbf24;color:#111">Loading...</div>
    <div id="orderInfo" class="mt-3"></div>
    <div class="courier-card" id="courierCard" style="display:none">
      <div style="opacity:.7;font-size:.85rem">Kurir Anda</div>
      <div id="courierName" style="font-size:1.3rem;font-weight:700"></div>
      <div id="courierPhone" class="text-white-50 small"></div>
      <div class="mt-2 d-flex gap-2">
        <a id="courierCall" class="btn btn-sm btn-outline-light"><i class="fas fa-phone"></i> Call</a>
        <a id="courierWa" target="_blank" class="btn btn-sm btn-success"><i class="fab fa-whatsapp"></i> WhatsApp</a>
      </div>
      <div id="lastUpdate" class="mt-3 small text-white-50"></div>
    </div>
    <div class="mt-3">
      <div class="step" id="stp-pending"><div class="icon"><i class="fas fa-box"></i></div><div><b>Menunggu Diambil</b><br><small class="text-white-50">Pesanan sedang disiapkan</small></div></div>
      <div class="step" id="stp-progress"><div class="icon"><i class="fas fa-motorcycle"></i></div><div><b>Dalam Perjalanan</b><br><small class="text-white-50">Kurir sedang menuju ke lokasi Anda</small></div></div>
      <div class="step" id="stp-delivered"><div class="icon"><i class="fas fa-check"></i></div><div><b>Terkirim</b><br><small class="text-white-50">Pesanan sudah diterima</small></div></div>
    </div>
  </div>
</div>

<?php $mapsKey = $store['google_maps_api_key'] ?? ''; ?>
<?php if ($mapsKey): ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?= esc($mapsKey) ?>"></script>
<script>
let map, courierMarker, destinationMarker;
function initMap(){
  map = new google.maps.Map(document.getElementById('map'),{center:{lat:-6.2,lng:106.816},zoom:14,streetViewControl:false,mapTypeControl:false});
}
initMap();

async function poll(){
  try {
    const r = await fetch('/api/track/<?= esc($invoice) ?>',{cache:'no-store'});
    const j = await r.json();
    if (! j.ok) return;
    const s = j.sale;

    // Status pill
    const statusMap = {pending:['#fbbf24','Menunggu Diambil'],in_progress:['#3b82f6','Dalam Perjalanan'],delivered:['#22c55e','Terkirim'],cancelled:['#ef4444','Dibatalkan']};
    const [c,label] = statusMap[s.delivery_status]||['#6b7280',s.delivery_status||'-'];
    document.getElementById('statusPill').style.background = c;
    document.getElementById('statusPill').textContent = label;

    // Steps
    ['pending','progress','delivered'].forEach(k=>document.getElementById('stp-'+k).classList.remove('active'));
    if (s.delivery_status==='pending') document.getElementById('stp-pending').classList.add('active');
    if (s.delivery_status==='in_progress') document.getElementById('stp-progress').classList.add('active');
    if (s.delivery_status==='delivered') document.getElementById('stp-delivered').classList.add('active');

    // Order info
    document.getElementById('orderInfo').innerHTML =
      `<div class="small text-white-50">Alamat Tujuan</div><div>${s.delivery_address||'-'}</div>`;

    // Courier
    if (s.courier_name) {
      document.getElementById('courierCard').style.display='block';
      document.getElementById('courierName').textContent = s.courier_name;
      document.getElementById('courierPhone').textContent = s.courier_phone||'';
      if (s.courier_phone) document.getElementById('courierCall').href = 'tel:'+s.courier_phone;
      if (s.courier_wa || s.courier_phone) document.getElementById('courierWa').href = 'https://wa.me/'+String(s.courier_wa||s.courier_phone).replace(/\D/g,'');
      if (s.location_updated_at) {
        const d = new Date(s.location_updated_at);
        document.getElementById('lastUpdate').textContent = 'Update lokasi: '+d.toLocaleString('id-ID');
      }
    }

    // Map markers
    const dLat = parseFloat(s.delivery_lat); const dLng = parseFloat(s.delivery_lng);
    if (dLat && dLng) {
      if (! destinationMarker) destinationMarker = new google.maps.Marker({map,position:{lat:dLat,lng:dLng},label:'📍',title:'Alamat Anda'});
      else destinationMarker.setPosition({lat:dLat,lng:dLng});
    }
    const cLat = parseFloat(s.current_lat); const cLng = parseFloat(s.current_lng);
    if (cLat && cLng) {
      const pos = {lat:cLat,lng:cLng};
      if (! courierMarker) courierMarker = new google.maps.Marker({map,position:pos,icon:{path:google.maps.SymbolPath.CIRCLE,scale:12,fillColor:'#3b82f6',fillOpacity:1,strokeColor:'#fff',strokeWeight:3},title:'Posisi Kurir'});
      else courierMarker.setPosition(pos);
      // Fit bounds
      if (destinationMarker) {
        const b = new google.maps.LatLngBounds();
        b.extend(pos); b.extend(destinationMarker.getPosition());
        map.fitBounds(b, 80);
      }
    } else if (destinationMarker) {
      map.setCenter(destinationMarker.getPosition()); map.setZoom(15);
    }
  } catch(e) { console.error(e); }
}
poll(); setInterval(poll, 10000);
</script>
<?php else: ?>
<script>document.getElementById('map').innerHTML='<div style="padding:60px;text-align:center;color:#111">Google Maps API belum di-set. Hubungi admin toko.</div>';</script>
<?php endif; ?>
</body></html>
