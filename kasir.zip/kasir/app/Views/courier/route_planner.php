<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Route Planner Kurir'; $mapsKey = $store['google_maps_api_key'] ?? ''; ?>
<?= $this->section('content') ?>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="card"><div class="card-header bg-primary text-white"><b><i class="fas fa-route"></i> Pilih Pengiriman</b></div>
      <div class="card-body">
        <label class="form-label small">Titik Awal (kosongkan = lokasi saat ini)</label>
        <input class="form-control mb-2" id="startingPoint" placeholder="Alamat / lat,lng">

        <div class="mb-2 small text-muted"><?= count($deliveries) ?> pengiriman siap dioptimasi</div>

        <div style="max-height:400px;overflow:auto">
          <?php foreach ($deliveries as $d): ?>
            <div class="form-check border-bottom py-2">
              <input class="form-check-input delivery-cb" type="checkbox" value="<?= $d['id'] ?>"
                     data-lat="<?= $d['delivery_lat'] ?>" data-lng="<?= $d['delivery_lng'] ?>"
                     data-name="<?= esc($d['customer_name']) ?>"
                     data-address="<?= esc($d['delivery_address']) ?>"
                     data-invoice="<?= esc($d['invoice_no']) ?>" id="d<?= $d['id'] ?>">
              <label class="form-check-label small" for="d<?= $d['id'] ?>">
                <b><?= esc($d['invoice_no']) ?></b><br>
                <?= esc($d['customer_name']) ?> — <?= esc($d['customer_phone']) ?><br>
                <span class="text-muted"><?= esc($d['delivery_address']) ?></span>
              </label>
            </div>
          <?php endforeach; ?>
        </div>

        <button class="btn btn-success w-100 mt-3" id="btnOptimize"><i class="fas fa-magic"></i> Optimasi Rute</button>
      </div>
    </div>

    <div class="card mt-3" id="resultCard" style="display:none">
      <div class="card-header bg-success text-white"><b><i class="fas fa-check-circle"></i> Hasil Optimasi</b></div>
      <div class="card-body">
        <div class="mb-2"><i class="fas fa-road"></i> Jarak: <b id="totalDist">0 km</b></div>
        <div class="mb-2"><i class="fas fa-clock"></i> Estimasi: <b id="totalTime">0 menit</b></div>
        <hr>
        <div id="orderList"></div>
        <button class="btn btn-primary w-100 mt-2" id="btnSaveRoute"><i class="fas fa-save"></i> Simpan Rute</button>
      </div>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="card"><div class="card-header"><b><i class="fas fa-map"></i> Peta Rute</b></div>
      <div class="card-body p-0"><div id="map" style="height:600px;background:#eef"></div></div>
    </div>
  </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<?php if ($mapsKey): ?>
<script src="https://maps.googleapis.com/maps/api/js?key=<?= esc($mapsKey) ?>&libraries=places"></script>
<script>
let map, directionsService, directionsRenderer;
function initMap(){
  map = new google.maps.Map(document.getElementById('map'),{center:{lat:-6.2,lng:106.816},zoom:12});
  directionsService = new google.maps.DirectionsService();
  directionsRenderer = new google.maps.DirectionsRenderer({map, suppressMarkers:false});
}
initMap();

$('#btnOptimize').on('click', ()=>{
  const selected = [...document.querySelectorAll('.delivery-cb:checked')];
  if (selected.length < 2) return Swal.fire('Info','Pilih minimal 2 tujuan','info');

  const startInput = $('#startingPoint').val().trim();
  const geocode = (addr) => new Promise((res,rej)=>{
    if (! addr) return res({lat:-6.2,lng:106.816}); // fallback
    const parts = addr.split(',');
    if (parts.length===2 && !isNaN(+parts[0])) return res({lat:+parts[0],lng:+parts[1]});
    const g = new google.maps.Geocoder();
    g.geocode({address:addr},(r,s)=>{ if(s==='OK') res(r[0].geometry.location.toJSON()); else rej(s); });
  });

  geocode(startInput).then(origin => {
    const waypoints = selected.slice(0,-1).map(cb=>({location:{lat:+cb.dataset.lat,lng:+cb.dataset.lng},stopover:true}));
    const destination = { lat:+selected.at(-1).dataset.lat, lng:+selected.at(-1).dataset.lng };

    directionsService.route({
      origin, destination, waypoints, optimizeWaypoints:true,
      travelMode:'DRIVING'
    },(res,st)=>{
      if (st!=='OK') return Swal.fire('Gagal','Directions error: '+st,'error');
      directionsRenderer.setDirections(res);
      const legs = res.routes[0].legs;
      const totalDist = legs.reduce((s,l)=>s+l.distance.value,0)/1000;
      const totalTime = Math.round(legs.reduce((s,l)=>s+l.duration.value,0)/60);
      $('#totalDist').text(totalDist.toFixed(2)+' km');
      $('#totalTime').text(totalTime+' menit');
      // Reorder list
      const order = [...res.routes[0].waypoint_order.map(i=>selected[i]), selected.at(-1)];
      $('#orderList').html(order.map((cb,i)=>`
        <div class="border rounded p-2 mb-1 small">
          <b>${i+1}. ${cb.dataset.invoice}</b> — ${cb.dataset.name}<br>
          <span class="text-muted">${cb.dataset.address}</span>
        </div>`).join(''));
      window._optResult = {
        order: order.map(cb=>+cb.value),
        distance_km: totalDist,
        duration_min: totalTime,
        starting_point: startInput,
      };
      $('#resultCard').show();
    });
  }).catch(()=>Swal.fire('Gagal','Alamat titik awal tidak valid','error'));
});

$('#btnSaveRoute').on('click', async ()=>{
  if (! window._optResult) return;
  const r = await fetch('/courier/route-planner/save',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(window._optResult)});
  const j = await r.json();
  Swal.fire(j.ok?'Rute Disimpan':'Gagal','','success');
});
</script>
<?php else: ?>
<div class="alert alert-warning m-3">
  <b>Google Maps API Key belum di-set.</b> Buka <a href="<?= site_url('settings') ?>">Pengaturan → Integrasi</a> dan isi <code>Google Maps API Key</code> (aktifkan API: Maps JavaScript, Directions, Places, Geocoding).
</div>
<?php endif; ?>
<?= $this->endSection() ?>
