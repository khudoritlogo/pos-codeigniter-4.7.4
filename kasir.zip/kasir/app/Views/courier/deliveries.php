<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Riwayat Pengiriman'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <table class="table datatable table-striped">
    <thead><tr><th>Invoice</th><th>Tanggal</th><th>Customer</th><th>Status Kirim</th><th class="text-end">Total</th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= esc($r['invoice_no']) ?></td>
        <td><?= date('d/m/Y H:i',strtotime($r['sale_date'])) ?></td>
        <td><?= esc($r['customer_name']) ?></td>
        <td><span class="badge bg-secondary"><?= esc($r['delivery_status']) ?></span></td>
        <td class="text-end">Rp <?= number_format((float)$r['total'],0,',','.') ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
