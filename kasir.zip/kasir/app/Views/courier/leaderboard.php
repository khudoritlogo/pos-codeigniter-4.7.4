<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Leaderboard Kurir · '.$month; ?>
<?= $this->section('content') ?>

<div class="card mb-3"><div class="card-body">
  <form class="d-flex align-items-end gap-2">
    <div><label class="form-label small">Bulan</label><input type="month" name="month" class="form-control" value="<?= esc($month) ?>"></div>
    <button class="btn btn-primary"><i class="fas fa-filter"></i> Tampilkan</button>
  </form>
</div></div>

<!-- Podium Top 3 -->
<?php $top3 = array_slice($rows, 0, 3); ?>
<div class="row g-3 mb-3">
  <?php foreach ($top3 as $i => $r):
    $bg = ['linear-gradient(135deg,#fbbf24,#f59e0b)','linear-gradient(135deg,#d1d5db,#9ca3af)','linear-gradient(135deg,#f97316,#c2410c)'];
    $medal = ['🥇','🥈','🥉'];
  ?>
    <div class="col-md-4">
      <div class="card border-0 text-white text-center" style="background:<?= $bg[$i] ?>">
        <div class="card-body py-4">
          <div style="font-size:3rem"><?= $medal[$i] ?></div>
          <h4 class="mb-1"><?= esc($r['fullname']) ?></h4>
          <div class="small opacity-90 mb-3">Rank #<?= $i+1 ?></div>
          <div class="row text-center">
            <div class="col"><small class="opacity-75">Pengiriman</small><br><b><?= (int)$r['delivered'] ?></b></div>
            <div class="col"><small class="opacity-75">Rating</small><br><b><?= $r['avg_rating'] ? number_format((float)$r['avg_rating'],1).' ⭐' : '-' ?></b></div>
            <div class="col"><small class="opacity-75">Jarak</small><br><b><?= number_format((float)$r['distance_km'],1) ?> km</b></div>
          </div>
          <div class="mt-3"><span class="badge bg-dark fs-6"><?= (int)$r['points'] ?> pts</span></div>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
</div>

<div class="card"><div class="card-body">
  <table class="table datatable table-striped">
    <thead><tr><th>Rank</th><th>Kurir</th><th class="text-end">Total Order</th><th class="text-end">Delivered</th><th class="text-end">Avg Rating</th><th class="text-end">Jarak (km)</th><th class="text-end">Omzet</th><th class="text-end">Total Poin</th></tr></thead>
    <tbody>
      <?php foreach ($rows as $i => $r): ?>
      <tr class="<?= $i<3?'table-warning':'' ?>">
        <td><b><?= $i+1 ?></b> <?= $r['badge']?'<span class="badge bg-'.($r['badge']==='gold'?'warning':($r['badge']==='silver'?'secondary':'danger')).'">'.strtoupper($r['badge']).'</span>':'' ?></td>
        <td><?= esc($r['fullname']) ?></td>
        <td class="text-end"><?= (int)$r['deliveries'] ?></td>
        <td class="text-end text-success"><?= (int)$r['delivered'] ?></td>
        <td class="text-end"><?= $r['avg_rating']?number_format((float)$r['avg_rating'],2).' <span class="text-warning">★</span>':'-' ?> <small class="text-muted">(<?= (int)$r['rating_count'] ?> rating)</small></td>
        <td class="text-end"><?= number_format((float)$r['distance_km'],2) ?></td>
        <td class="text-end">Rp <?= number_format((float)$r['total_omzet'],0,',','.') ?></td>
        <td class="text-end fw-bold"><?= (int)$r['points'] ?></td>
      </tr>
      <?php endforeach; ?>
      <?php if (empty($rows)): ?><tr><td colspan="8" class="text-center text-muted py-3">Belum ada data kurir</td></tr><?php endif; ?>
    </tbody>
  </table>
</div></div>

<div class="mt-3 small text-muted">
  <b>Formula Poin</b>: (Delivered × 10) + (Avg Rating × 20) + (Jarak × 0.5). Jarak dihitung dari perpindahan GPS harian kurir.
</div>
<?= $this->endSection() ?>
