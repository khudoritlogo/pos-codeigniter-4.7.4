<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8">
<title>TV Mode - POS Kasir</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
<style>
  *{box-sizing:border-box}
  body{margin:0;background:linear-gradient(135deg,#0f172a 0%,#1e40af 50%,#0f172a 100%);color:#fff;min-height:100vh;font-family:'Segoe UI',system-ui;overflow:hidden}
  .header{padding:20px 40px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(255,255,255,.1);background:rgba(0,0,0,.3)}
  .header h1{margin:0;font-size:1.8rem;font-weight:800}
  .live-dot{width:12px;height:12px;background:#22c55e;border-radius:50%;display:inline-block;animation:blink 1s infinite;margin-right:8px}
  @keyframes blink{50%{opacity:.3}}
  @keyframes glow{0%,100%{text-shadow:0 0 20px rgba(251,191,36,.5)}50%{text-shadow:0 0 40px rgba(251,191,36,1)}}
  @keyframes slideup{from{opacity:0;transform:translateY(30px)}to{opacity:1;transform:translateY(0)}}
  .clock{font-size:1.3rem;font-variant-numeric:tabular-nums}
  .container{padding:40px;display:grid;grid-template-columns:1fr 1fr;gap:30px;height:calc(100vh - 78px)}
  .hero{background:rgba(255,255,255,.05);border-radius:24px;padding:40px;text-align:center;backdrop-filter:blur(10px);display:flex;flex-direction:column;justify-content:center}
  .hero .label{opacity:.7;font-size:1.4rem;letter-spacing:.1em}
  .hero .value{font-size:6rem;font-weight:900;color:#fbbf24;animation:glow 2s infinite;margin:16px 0;line-height:1}
  .hero .sub{font-size:1.5rem;opacity:.9}
  .side{display:flex;flex-direction:column;gap:20px}
  .card-tv{background:rgba(255,255,255,.08);border-radius:20px;padding:24px;backdrop-filter:blur(8px);flex:1;overflow:hidden}
  .card-tv h3{margin:0 0 16px;font-size:1.3rem;opacity:.9}
  .top-item{display:flex;justify-content:space-between;padding:10px 0;border-bottom:1px solid rgba(255,255,255,.1);font-size:1.1rem;animation:slideup .4s}
  .top-item .rank{background:#fbbf24;color:#111;width:28px;height:28px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-weight:800;margin-right:12px}
  .sale-item{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.08);font-size:1rem;animation:slideup .4s}
  .sale-item .amount{color:#fbbf24;font-weight:700}
</style></head><body>
<div class="header">
  <h1><span class="live-dot"></span> POS DASHBOARD — <?= esc($user['branch_name'] ?? 'ALL') ?></h1>
  <div class="clock" id="clock"></div>
</div>

<div class="container">
  <div class="hero">
    <div class="label">OMZET HARI INI</div>
    <div class="value" id="omzetToday">Rp <?= number_format((float)$todayStats->o,0,',','.') ?></div>
    <div class="sub"><span id="trxToday"><?= number_format((int)$todayStats->c) ?></span> transaksi</div>
    <hr style="border-color:rgba(255,255,255,.15);width:60%;margin:30px auto">
    <div class="label" style="font-size:1rem">BULAN INI</div>
    <div style="font-size:2.5rem;font-weight:700;color:#a7f3d0" id="omzetMonth">Rp <?= number_format((float)$monthStats->o,0,',','.') ?></div>
    <div style="opacity:.7"><?= number_format((int)$monthStats->c) ?> transaksi</div>
  </div>

  <div class="side">
    <div class="card-tv"><h3>⭐ Top Produk Hari Ini</h3>
      <div id="topProducts">
        <?php foreach ($topProducts as $i=>$p): ?>
          <div class="top-item"><span><span class="rank"><?= $i+1 ?></span><?= esc($p['name']) ?></span><b><?= (int)$p['qty'] ?> pcs</b></div>
        <?php endforeach; ?>
      </div>
    </div>
    <div class="card-tv"><h3>💰 Transaksi Terbaru</h3>
      <div id="recentSales">
        <?php foreach ($recentSales as $s): ?>
          <div class="sale-item"><span><b><?= esc($s['invoice_no']) ?></b><br><small style="opacity:.6"><?= esc($s['customer_name'] ?? 'Umum') ?></small></span><span class="amount">Rp <?= number_format((float)$s['total'],0,',','.') ?></span></div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>

<script>
function rupiah(v){return new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',minimumFractionDigits:0}).format(v||0)}
function clock(){ document.getElementById('clock').textContent = new Date().toLocaleString('id-ID',{dateStyle:'full',timeStyle:'medium'}); }
setInterval(clock,1000); clock();

let lastId = 0;
async function refresh(){
  try {
    const r = await fetch('<?= site_url("api/live-ticker/feed") ?>?since='+lastId,{cache:'no-store'});
    const j = await r.json();
    if (!j.ok) return;
    document.getElementById('trxToday').textContent = j.today.c;
    document.getElementById('omzetToday').textContent = rupiah(j.today.omzet);
    if (j.rows && j.rows.length) {
      const el = document.getElementById('recentSales');
      j.rows.slice(0,8).forEach(row=>{
        if (row.id > lastId) {
          const html = `<div class="sale-item"><span><b>${row.invoice_no}</b><br><small style="opacity:.6">${row.customer_name||'Umum'}</small></span><span class="amount">${rupiah(row.total)}</span></div>`;
          el.insertAdjacentHTML('afterbegin', html);
          while (el.children.length > 8) el.removeChild(el.lastElementChild);
        }
      });
      lastId = j.rows[0].id;
    }
  } catch(e){}
}
refresh(); setInterval(refresh, 5000);

// Full refresh every 5 min biar Top Produk update
setInterval(()=>location.reload(), 300000);
</script>
</body></html>
