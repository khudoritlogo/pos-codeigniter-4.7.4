<?= $this->extend('layouts/main') ?>
<?php $pageTitle = 'Dashboard'; ?>
<?= $this->section('content') ?>

<style>
  /* ===== GLOBAL ===== */
  .dashboard-page { font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; }

  /* ===== STAT CARDS ===== */
  .stat-card-custom {
    background: #fff;
    border-radius: 12px;
    padding: 1.25rem;
    border: 1px solid #e5e7eb;
    box-shadow: 0 1px 3px rgba(0,0,0,.04);
    transition: box-shadow .2s, transform .2s;
  }
  .stat-card-custom:hover {
    box-shadow: 0 4px 12px rgba(0,0,0,.08);
    transform: translateY(-1px);
  }
  .stat-icon-circle {
    width: 48px;
    height: 48px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.25rem;
  }
  .stat-value {
    font-size: 1.75rem;
    font-weight: 700;
    color: #111827;
    line-height: 1.2;
  }
  .stat-label {
    font-size: 0.875rem;
    color: #6b7280;
    font-weight: 500;
  }

  /* ===== CHART CARD ===== */
  .chart-card-custom {
    background: #fff;
    border-radius: 12px;
    padding: 1.25rem;
    border: 1px solid #e5e7eb;
    box-shadow: 0 1px 3px rgba(0,0,0,.04);
  }
  .chart-card-custom h5 {
    font-weight: 600;
    color: #111827;
    font-size: 1rem;
    margin-bottom: 1rem;
  }

  /* ===== PANEL LAPORAN ===== */
  .report-panel-custom {
    background: #fff;
    border-radius: 12px;
    border: 1px solid #e5e7eb;
    box-shadow: 0 1px 3px rgba(0,0,0,.04);
    overflow: hidden;
  }
  .report-panel-custom .panel-header {
    padding: 0.75rem 1rem;
    font-weight: 600;
    font-size: 0.9rem;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    border-bottom: 1px solid #f3f4f6;
  }
  .report-panel-custom table {
    margin: 0;
    font-size: 0.8125rem;
    width: 100%;
    border-collapse: collapse;
  }
  .report-panel-custom th {
    background: #f9fafb;
    color: #6b7280;
    font-weight: 600;
    padding: 0.5rem 0.75rem;
    text-align: left;
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.025em;
    border-bottom: 1px solid #e5e7eb;
  }
  .report-panel-custom td {
    padding: 0.5rem 0.75rem;
    border-bottom: 1px solid #f3f4f6;
    color: #374151;
    vertical-align: middle;
  }
  .report-panel-custom tbody tr:hover td {
    background: #f9fafb;
  }
  .report-panel-custom .empty-msg {
    text-align: center;
    padding: 2rem 1rem;
    color: #9ca3af;
    font-size: 0.875rem;
  }

  /* ===== BADGES ===== */
  .badge-stok-kritis { background: #fee2e2; color: #dc2626; padding: 2px 8px; border-radius: 999px; font-size: 0.75rem; font-weight: 600; }
  .badge-stok-warn   { background: #fef3c7; color: #d97706; padding: 2px 8px; border-radius: 999px; font-size: 0.75rem; font-weight: 600; }
  .badge-rank-1st    { background: #d1fae5; color: #059669; padding: 2px 8px; border-radius: 999px; font-size: 0.75rem; font-weight: 700; }
  .badge-rank-2nd    { background: #dbeafe; color: #2563eb; padding: 2px 8px; border-radius: 999px; font-size: 0.75rem; font-weight: 600; }
  .badge-rank-3rd    { background: #fef3c7; color: #d97706; padding: 2px 8px; border-radius: 999px; font-size: 0.75rem; font-weight: 600; }
  .badge-rank-other  { background: #f3f4f6; color: #6b7280; padding: 2px 8px; border-radius: 999px; font-size: 0.75rem; font-weight: 500; }

  .text-invoice { color: #2563eb; font-weight: 600; }
  .text-customer { color: #475569; }
  .text-cashier { color: #94a3b8; font-size: 0.78rem; }
  .text-total { font-weight: 700; color: #111827; text-align: right; }

  /* ===== SIDEBAR MENU HIGHLIGHT (dashboard reports) ===== */
  .nav-link-active-reports {
    background: #eff6ff;
    color: #2563eb;
    border-radius: 8px;
    margin: 2px 0;
  }

  /* ===== MOBILE ===== */
  @media (max-width: 768px) {
    .stat-value { font-size: 1.5rem; }
    .dashboard-grid { gap: 0.75rem; }
  }

  /* ===== ANIMATION ===== */
  @keyframes fadeSlideUp {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  .stat-card-custom, .chart-card-custom, .report-panel-custom {
    animation: fadeSlideUp 0.35s ease-out;
  }
  .stat-card-custom:nth-child(1) { animation-delay: 0.05s; }
  .stat-card-custom:nth-child(2) { animation-delay: 0.1s; }
  .stat-card-custom:nth-child(3) { animation-delay: 0.15s; }
  .stat-card-custom:nth-child(4) { animation-delay: 0.2s; }
</style>

<div class="dashboard-page">

  <!-- HEADER SECTION -->
  <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
    <div>
      <h3 class="fw-bold mb-1" style="color:#111827;font-size:1.35rem">
        <i class="fas fa-th-large text-primary me-2"></i>Dashboard
      </h3>
      <small class="text-muted">
        <i class="far fa-calendar-alt me-1"></i><?= date('l, d F Y') ?>
        &middot; <i class="far fa-clock me-1"></i>Update real-time
      </small>
    </div>
    <div class="text-end">
      <small class="text-muted d-block">
        <i class="fas fa-sync-alt me-1"></i>Auto-refresh: 5 detik
      </small>
    </div>
  </div>

  <!-- 4 STATISTIK CARDS -->
  <div class="row g-3 mb-4">
    <!-- Omzet Hari Ini -->
    <div class="col-xl-3 col-md-6">
      <div class="card stat-card-custom">
        <div class="card-body p-3">
          <div class="d-flex justify-content-between align-items-start mb-3">
            <div class="stat-icon-circle" style="background:#eff6ff;color:#2563eb">
              <i class="fas fa-money-bill-wave"></i>
            </div>
            <span class="badge bg-success bg-opacity-75 text-success small fw-bold px-2 py-1">
              <i class="fas fa-arrow-up me-1"></i>+12%
            </span>
          </div>
          <div class="stat-value">
            Rp <?= number_format((float)($invoicesToday->omzet ?? 0),0,',','.') ?>
          </div>
          <div class="stat-label">Omzet Hari Ini</div>
        </div>
      </div>
    </div>

    <!-- Transaksi Hari Ini -->
    <div class="col-xl-3 col-md-6">
      <div class="card stat-card-custom">
        <div class="card-body p-3">
          <div class="d-flex justify-content-between align-items-start mb-3">
            <div class="stat-icon-circle" style="background:#fef3c7;color:#d97706">
              <i class="fas fa-cash-register"></i>
            </div>
            <span class="badge bg-success bg-opacity-75 text-success small fw-bold px-2 py-1">
              <i class="fas fa-arrow-up me-1"></i>+8%
            </span>
          </div>
          <div class="stat-value">
            <?= number_format($invoicesToday->c ?? 0) ?>
          </div>
          <div class="stat-label">Transaksi Hari Ini</div>
        </div>
      </div>
    </div>

    <!-- Barang Terjual -->
    <div class="col-xl-3 col-md-6">
      <div class="card stat-card-custom">
        <div class="card-body p-3">
          <div class="d-flex justify-content-between align-items-start mb-3">
            <div class="stat-icon-circle" style="background:#f0fdf4;color:#16a34a">
              <i class="fas fa-box-open"></i>
            </div>
            <span class="badge bg-success bg-opacity-75 text-success small fw-bold px-2 py-1">
              <i class="fas fa-arrow-up me-1"></i>+5%
            </span>
          </div>
          <div class="stat-value">
            <?= number_format($soldToday) ?>
          </div>
          <div class="stat-label">Barang Terjual</div>
        </div>
      </div>
    </div>

    <!-- Total Customer -->
    <div class="col-xl-3 col-md-6">
      <div class="card stat-card-custom">
        <div class="card-body p-3">
          <div class="d-flex justify-content-between align-items-start mb-3">
            <div class="stat-icon-circle" style="background:#f5f3ff;color:#7c3aed">
              <i class="fas fa-users"></i>
            </div>
            <span class="badge bg-secondary bg-opacity-75 text-secondary small fw-bold px-2 py-1">
              <i class="fas fa-minus me-1"></i>0%
            </span>
          </div>
          <div class="stat-value">
            <?= number_format($customersCount) ?>
          </div>
          <div class="stat-label">Total Customer</div>
        </div>
      </div>
    </div>
  </div>

  <!-- CHART + LAPORAN (2 kolom: kiri chart, kanan 3 panel laporan) -->
  <div class="row g-4">
    
    <!-- KIRI: Grafik Omzet -->
    <div class="col-lg-8">
      <div class="card chart-card-custom h-100">
        <div class="card-body">
          <h5><i class="fas fa-chart-area text-primary me-2"></i>Omzet 7 Hari Terakhir</h5>
          <div style="position:relative;height:220px">
            <canvas id="omzetChart"></canvas>
          </div>
        </div>
      </div>
    </div>

    <!-- KANAN: 3 Panel Laporan -->
    <div class="col-lg-4">
      
      <!-- Panel 1: Stok Terkecil -->
      <div class="card report-panel-custom mb-3">
        <div class="panel-header" style="background:#fff7ed;color:#d97706">
          <i class="fas fa-exclamation-triangle"></i>Stok Terkecil
        </div>
        <div style="max-height:180px;overflow-y:auto">
          <table>
            <thead><tr><th>Produk</th><th>Stok</th></tr></thead>
            <tbody>
              <?php if (!empty($lowStock)): ?>
                <?php foreach ($lowStock as $p): ?>
                  <tr>
                    <td class="text-truncate" style="max-width:160px">
                      <?= esc($p['name']) ?>
                      <small class="text-muted d-block" style="font-size:0.7rem">
                        <?= esc($p['branch_name'] ?? '') ?>
                      </small>
                    </td>
                    <td>
                      <?php 
                        $stock = (int)$p['stock'];
                        $badgeClass = $stock <= 5 ? 'badge-stok-kritis' : 'badge-stok-warn';
                      ?>
                      <span class="<?= $badgeClass ?>"><?= $stock ?></span>
                    </td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="2" class="empty-msg">Stok semua aman</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Panel 2: Barang Terlaris -->
      <div class="card report-panel-custom mb-3">
        <div class="panel-header" style="background:#ecfdf5;color:#059669">
          <i class="fas fa-trophy"></i>Barang Terlaris
        </div>
        <div style="max-height:180px;overflow-y:auto">
          <table>
            <thead><tr><th>#</th><th>Produk</th><th>Qty</th></tr></thead>
            <tbody>
              <?php if (!empty($topProducts)): ?>
                <?php foreach ($topProducts as $i => $p): ?>
                  <tr>
                    <td>
                      <?php
                        $rank = $i + 1;
                        $badge = $rank === 1 ? 'badge-rank-1st' : ($rank === 2 ? 'badge-rank-2nd' : ($rank === 3 ? 'badge-rank-3rd' : 'badge-rank-other'));
                      ?>
                      <span class="<?= $badge ?>"><?= $rank ?></span>
                    </td>
                    <td class="text-truncate" style="max-width:140px"><?= esc($p['name']) ?></td>
                    <td class="text-end fw-bold"><?= number_format((float)$p['qty_sold']) ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="3" class="empty-msg">Belum ada data</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

      <!-- Panel 3: Invoice Terbaru -->
      <div class="card report-panel-custom">
        <div class="panel-header" style="background:#f8fafc;color:#475569;border-bottom:1px solid #e5e7eb">
          <i class="fas fa-receipt"></i>Invoice Terbaru
        </div>
        <div style="max-height:180px;overflow-y:auto">
          <table>
            <thead><tr><th>No</th><th>Customer</th><th>Total</th></tr></thead>
            <tbody>
              <?php if (!empty($recentInvoices)): ?>
                <?php foreach ($recentInvoices as $r): ?>
                  <tr>
                    <td><span class="text-invoice"><?= esc($r['invoice_no']) ?></span></td>
                    <td><span class="text-customer"><?= esc($r['customer_name'] ?? 'Umum') ?></span></td>
                    <td class="text-total">Rp <?= number_format((float)$r['total'],0,',','.') ?></td>
                  </tr>
                <?php endforeach; ?>
              <?php else: ?>
                <tr><td colspan="3" class="empty-msg">Belum ada transaksi</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </div>

</div>

<!-- LIVE TICKER (toast di pojok) -->
<div id="liveTicker" class="position-fixed bottom-0 end-0 p-3" style="z-index:1055;display:none">
  <div class="toast align-items-center text-bg-success border-0 show" role="alert">
    <div class="d-flex">
      <div class="toast-body small">
        <i class="fas fa-check-circle me-2"></i>
        <b><span id="tickerInvoiceNo"></span></b> &mdash;
        <span id="tickerTotal"></span>
        <span class="text-muted ms-2">&middot; <span id="tickerCashier"></span></span>
      </div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" onclick="document.getElementById('liveTicker').classList.remove('show')"></button>
    </div>
  </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
// ===== FORMAT RUPIAH =====
function rupiah(u){
  const n = Math.round(parseFloat(u) || 0);
  return 'Rp ' + n.toLocaleString('id-ID');
}

// ===== CHART =====
const labels = <?= json_encode(array_column($chart, 'd')) ?>;
const data   = <?= json_encode(array_map('floatval', array_column($chart, 'omzet'))) ?>;

new Chart(document.getElementById('omzetChart'), {
  type: 'line',
  data: {
    labels,
    datasets: [{
      label: 'Omzet',
      data,
      borderColor: '#2563eb',
      backgroundColor: 'rgba(37,99,235,0.08)',
      fill: true,
      tension: 0.4,
      pointBackgroundColor: '#2563eb',
      pointRadius: 4,
      pointHoverRadius: 6,
      borderWidth: 2.5,
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#1f2937',
        titleColor: '#fff',
        bodyColor: '#e5e7eb',
        padding: 12,
        cornerRadius: 8,
        callbacks: { label: ctx => rupiah(ctx.raw) }
      }
    },
    scales: {
      y: {
        beginAtZero: true,
        grid: { color: '#f3f4f6' },
        ticks: { color: '#9ca3af', font: { size: 11 }, callback: v => rupiah(v) }
      },
      x: {
        grid: { display: false },
        ticks: { color: '#9ca3af', font: { size: 11 } }
      }
    },
    interaction: { intersect: false, mode: 'index' }
  }
});

// ===== LIVE TICKER =====
let tickerSince = 0;
async function pollTicker(){
  try {
    const r = await fetch('<?= site_url("api/live-ticker/feed") ?>?since=' + tickerSince, { cache: 'no-store' });
    const j = await r.json();
    if (!j.ok) return;

    // Update stat card values
    const todayCount = document.querySelector('.col-xl-3.col-md-6:nth-child(2) .stat-value');
    const todayOmzet = document.querySelector('.col-xl-3.col-md-6:nth-child(1) .stat-value');
    if (todayCount) todayCount.textContent = j.today.c;
    if (todayOmzet) todayOmzet.textContent = rupiah(j.today.omzet);

    if (j.rows && j.rows.length) {
      const latest = j.rows[0];
      if (latest.id > tickerSince) {
        if (tickerSince > 0) {
          document.getElementById('tickerInvoiceNo').textContent = latest.invoice_no;
          document.getElementById('tickerTotal').textContent = rupiah(latest.total);
          document.getElementById('tickerCashier').textContent = latest.cashier_name || '-';
          const ticker = document.getElementById('liveTicker');
          ticker.classList.add('show');
          setTimeout(() => ticker.classList.remove('show'), 5000);
        }
        tickerSince = latest.id;
      }
    }
  } catch(e){}
}
pollTicker();
setInterval(pollTicker, 5000);
</script>
<?= $this->endSection() ?>