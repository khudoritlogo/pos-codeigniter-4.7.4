<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Kirim Pesan · '.$b['campaign_name']; ?>
<?= $this->section('content') ?>
<div class="card mb-3"><div class="card-body">
  <div class="d-flex justify-content-between align-items-center">
    <div>
      <h5 class="mb-1"><?= esc($b['campaign_name']) ?></h5>
      <div class="small text-muted">Total: <?= (int)$b['total_target'] ?> · Terkirim: <?= (int)$b['total_sent'] ?> · Gagal: <?= (int)$b['total_failed'] ?></div>
    </div>
    <div>
      <button class="btn btn-warning" onclick="sendGateway()"><i class="fas fa-rocket"></i> Kirim via Gateway API</button>
    </div>
  </div>
</div></div>

<div class="alert alert-info small">
  <b>Mode Manual</b>: Klik tombol WA di kolom aksi tiap baris untuk buka WhatsApp Web/App dengan pesan siap kirim. Klik "✔ Tandai Terkirim" setelah dikirim.<br>
  <b>Mode Gateway</b>: Klik tombol atas untuk kirim otomatis via WA gateway (butuh URL & Token di Pengaturan → Integrasi).
</div>

<div class="card"><div class="card-body">
  <table class="table datatable table-striped table-sm">
    <thead><tr><th>Customer</th><th>Phone</th><th>Poin</th><th>Status</th><th class="text-end">Aksi</th></tr></thead>
    <tbody>
      <?php foreach ($recs as $r): ?>
      <tr id="r<?= $r['id'] ?>">
        <td><?= esc($r['customer_name'] ?? '-') ?></td>
        <td><?= esc($r['phone']) ?></td>
        <td><?= (int)($r['points']??0) ?></td>
        <td><span class="badge bg-<?= $r['status']==='sent'?'success':($r['status']==='failed'?'danger':'warning') ?>"><?= $r['status'] ?></span></td>
        <td class="text-end">
          <button class="btn btn-sm btn-success" onclick="openWa(<?= $r['id'] ?>,'<?= esc($r['phone']) ?>','<?= esc($r['customer_name']??'') ?>')"><i class="fab fa-whatsapp"></i> Kirim</button>
          <button class="btn btn-sm btn-outline-secondary" onclick="markSent(<?= $r['id'] ?>)"><i class="fas fa-check"></i></button>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div></div>

<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
const template = <?= json_encode($b['message_template']) ?>;
const voucher = <?= json_encode($voucher) ?>;
function renderMsg(customerName){
  let msg = template.replace(/\{nama\}/g, customerName||'Pelanggan');
  if (voucher) {
    msg += `\n\n🎟️ Voucher: *${voucher.code}*\n${voucher.name}\nLink: <?= site_url('v/') ?>${voucher.code.toLowerCase()}`;
  }
  return msg;
}
function openWa(id, phone, name){
  const url = `https://wa.me/${phone}?text=${encodeURIComponent(renderMsg(name))}`;
  window.open(url,'_blank');
  markSent(id);
}
function markSent(id){
  fetch('/wa-broadcast/mark-sent/'+id,{method:'POST'}).then(r=>r.json()).then(()=>{
    $('#r'+id+' .badge').removeClass().addClass('badge bg-success').text('sent');
  });
}
async function sendGateway(){
  const btn = event.target; btn.disabled=true; btn.innerHTML='<i class="fas fa-spinner fa-spin"></i> Mengirim...';
  const r = await fetch('/wa-broadcast/<?= $b['id'] ?>/send-gateway',{method:'POST'});
  const j = await r.json();
  Swal.fire(j.ok?'Selesai':'Gagal', j.ok?`Terkirim: ${j.sent} · Gagal: ${j.failed}`:(j.msg||''), j.ok?'success':'error').then(()=>location.reload());
}
</script>
<?= $this->endSection() ?>
