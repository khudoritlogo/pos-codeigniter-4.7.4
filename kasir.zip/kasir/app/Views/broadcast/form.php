<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Buat WA Blast Campaign'; ?>
<?= $this->section('content') ?>
<div class="row g-3">
<div class="col-lg-7">
<div class="card"><div class="card-header bg-success text-white"><b><i class="fab fa-whatsapp"></i> Pesan & Template</b></div>
<div class="card-body">
  <label>Nama Campaign</label>
  <input class="form-control mb-2" id="campaignName" value="Blast Voucher <?= date('d M') ?>">

  <label>Voucher (opsional)</label>
  <select class="form-select select2 mb-2" id="voucherId">
    <option value="">-- Tidak pakai voucher --</option>
    <?php foreach ($vouchers as $v): ?><option value="<?= $v['id'] ?>" data-code="<?= esc($v['code']) ?>" data-name="<?= esc($v['name']) ?>"><?= esc($v['code']) ?> — <?= esc($v['name']) ?></option><?php endforeach; ?>
  </select>

  <label>Template Pesan</label>
  <textarea class="form-control" id="messageTemplate" rows="10">Halo {nama}! 👋

Terima kasih sudah menjadi pelanggan setia kami. Poin kamu: *{poin}*.

Kami punya penawaran spesial untuk kamu. Cek di link berikut ya!

Terima kasih 🙏</textarea>
  <small class="text-muted">Variabel: <code>{nama}</code>, <code>{poin}</code>, <code>{spent}</code></small>
</div></div>
</div>

<div class="col-lg-5">
<div class="card"><div class="card-header bg-primary text-white"><b><i class="fas fa-filter"></i> Filter Target</b></div>
<div class="card-body">
  <label>Level Customer</label>
  <select class="form-select select2 mb-2" id="filterLevels" multiple>
    <?php foreach ($levels as $lv): ?><option value="<?= $lv['id'] ?>"><?= esc($lv['name']) ?></option><?php endforeach; ?>
  </select>

  <label>Min. Total Belanja (Rp)</label>
  <input type="number" class="form-control mb-2" id="filterMinSpent" placeholder="0">

  <label>Min. Poin</label>
  <input type="number" class="form-control mb-2" id="filterMinPoints" placeholder="0">

  <label>Aktif Belanja (X hari terakhir)</label>
  <input type="number" class="form-control mb-2" id="filterActive" placeholder="kosong=semua">

  <button class="btn btn-outline-primary w-100 mb-2" onclick="previewFilter()"><i class="fas fa-eye"></i> Preview Target</button>
  <div id="previewBox" class="small"></div>
</div></div>

<div class="mt-2 d-grid">
  <button class="btn btn-success btn-lg" onclick="createCampaign()"><i class="fas fa-rocket"></i> Buat Campaign</button>
</div>
</div>
</div>

<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
function collectFilter(){
  return {
    level_ids: ($('#filterLevels').val()||[]).map(x=>+x),
    min_spent: +$('#filterMinSpent').val()||0,
    min_points: +$('#filterMinPoints').val()||0,
    active_since_days: +$('#filterActive').val()||0,
  };
}
async function previewFilter(){
  const r = await fetch('/wa-broadcast/preview',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(collectFilter())});
  const j = await r.json();
  $('#previewBox').html(`<div class="alert alert-info mb-1"><b>${j.total}</b> customer sesuai filter</div>
    <div style="max-height:200px;overflow:auto">${(j.sample||[]).map(c=>`<div class="border-bottom py-1"><b>${c.name}</b> · ${c.whatsapp||c.phone||'-'} · ${c.points||0} poin</div>`).join('')}</div>`);
}
async function createCampaign(){
  const payload = {
    campaign_name: $('#campaignName').val(),
    voucher_id: $('#voucherId').val() || null,
    message_template: $('#messageTemplate').val(),
    filter: collectFilter(),
  };
  const r = await fetch('/wa-broadcast',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  const j = await r.json();
  if (j.ok) location.href = '/wa-broadcast/'+j.broadcast_id+'/links';
  else Swal.fire('Gagal',j.msg||'','error');
}
</script>
<?= $this->endSection() ?>
