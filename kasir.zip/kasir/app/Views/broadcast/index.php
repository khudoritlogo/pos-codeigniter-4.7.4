<?= $this->extend('layouts/main') ?>
<?php $pageTitle='WhatsApp Blast Campaigns'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <a class="btn btn-primary" href="<?= site_url('wa-broadcast/new') ?>"><i class="fas fa-plus"></i> Buat Blast</a></div>
  <table class="table datatable table-striped">
    <thead><tr><th>Nama</th><th>Voucher</th><th>Tanggal</th><th class="text-end">Target</th><th class="text-end">Terkirim</th><th class="text-end">Gagal</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= esc($r['campaign_name']) ?></td>
        <td><?= $r['voucher_code'] ? '<span class="badge bg-primary">'.esc($r['voucher_code']).'</span>' : '-' ?></td>
        <td><small><?= date('d/m/Y H:i',strtotime($r['created_at'])) ?></small></td>
        <td class="text-end"><?= (int)$r['total_target'] ?></td>
        <td class="text-end text-success"><?= (int)$r['total_sent'] ?></td>
        <td class="text-end text-danger"><?= (int)$r['total_failed'] ?></td>
        <td><span class="badge bg-<?= match($r['status']){'draft'=>'warning','sending'=>'info','completed'=>'success',default=>'secondary'} ?>"><?= $r['status'] ?></span></td>
        <td><a class="btn btn-sm btn-primary" href="<?= site_url('wa-broadcast/' . $r['id'] . '/links') ?>"><i class="fas fa-list"></i> Kelola</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
