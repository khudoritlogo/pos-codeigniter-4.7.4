<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <div><h1 class="h3 mb-0 text-gray-800"><?= esc($title ?? 'Merek / Brand') ?></h1></div>
    <a href="<?= site_url('brands/new') ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Tambah</a>
</div>
<div class="card shadow"><div class="card-body p-0">
<table class="table table-hover table-striped mb-0">
  <thead class="table-light"><tr><th>No</th><th>Nama Merek</th><th class="text-center" style="width:80px">Status</th><th style="width:100px" class="text-center">Aksi</th></tr></thead>
  <tbody>
    <?php $brands = $brands ?? []; ?>
    <?php if(empty($brands)): ?><tr><td colspan="4" class="text-center py-4"><i class="fas fa-copyright fa-2x text-muted"></i><p class="mt-2 text-muted">Belum ada merek.</p></td></tr><?php endif; ?>
    <?php foreach($brands as $i => $b): ?>
    <tr>
      <td><?= $i+1 ?></td>
      <td><b><?= esc($b['name']) ?></b></td>
      <td class="text-center"><?php if(!empty($b['is_active'])): ?><span class="badge badge-success">Aktif</span><?php else: ?><span class="badge badge-secondary">Nonaktif</span><?php endif; ?></td>
      <td class="text-center">
        <div class="btn-group btn-group-sm">
          <a href="<?= site_url("brands/edit/$b[id]") ?>" class="btn btn-info btn-sm"><i class="fas fa-edit"></i></a>
          <?php if(session()->get('level_code')==='superadmin'): ?>
          <form action="<?= site_url("brands/delete/$b[id]") ?>" method="post" class="d-inline" onsubmit="return confirm('Hapus merek ini?')"><button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></form>
          <?php endif; ?>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div></div>
<?= $this->endSection() ?>