<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<?php $pageTitle = ($brand ? 'Edit' : 'Tambah') . ' Merek / Brand'; ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <div><h1 class="h3 mb-0 text-gray-800"><?= esc($pageTitle) ?></h1></div>
    <a href="<?= site_url('brands') ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Kembali</a>
</div>
<?php if (session('errors')): ?>
<div class="alert alert-danger alert-dismissible"><?= session('errors') ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>
<div class="card shadow"><div class="card-body">
<form method="post" action="<?= $action ?>">
  <?= csrf_field() ?>
  <?php if($brand): ?><input type="hidden" name="_method" value="PUT"><?php endif; ?>
  <div class="row g-3">
    <div class="col-md-6"><label class="form-label">Nama Merek *</label><input class="form-control" name="name" required value="<?= esc($brand['name'] ?? '') ?>"></div>
    <div class="col-md-6"><label class="form-label">Keterangan</label><input class="form-control" name="description" value="<?= esc($brand['description'] ?? '') ?>"></div>
    <div class="col-md-6 form-check ms-3 mt-4"><input class="form-check-input" type="checkbox" name="is_active" value="1" <?= !empty($brand['is_active'])?'checked':'' ?>><label class="form-check-label">Aktif</label></div>
  </div>
  <hr>
  <div class="d-flex justify-content-end gap-2">
    <a href="<?= site_url('brands') ?>" class="btn btn-secondary">Batal</a>
    <button class="btn btn-primary"><i class="fas fa-save"></i> <?= $brand ? 'Perbarui' : 'Simpan' ?></button>
  </div>
</form>
</div></div>
<?= $this->endSection() ?>