<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="container mt-4">
  <h1>Mobile Scanner</h1>
  <div class="card">
    <div class="card-body">
      <p>Halaman scanner.</p>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
