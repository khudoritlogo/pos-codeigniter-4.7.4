<?php
/**
 * Scanner Lookup View
 * Halaman pencarian barcode / lookup hasil scan
 */
?>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Scanner Lookup</h3>
    </div>
    <div class="card-body">
        <h4>Hasil Pencarian Barcode</h4>
        <p class="text-muted">Scan barcode untuk melihat informasi produk.</p>
        
        <div id="scanResult" class="alert alert-info" style="display:none;">
            <strong>Kode:</strong> <span id="resultCode"></span><br>
            <strong>Nama Produk:</strong> <span id="resultName"></span><br>
            <strong>Kategori:</strong> <span id="resultCategory"></span><br>
            <strong>Stok:</strong> <span id="resultStock"></span><br>
            <strong>Harga Jual:</strong> <span id="resultPrice"></span>
        </div>
        
        <div class="input-group">
            <input type="text" class="form-control" id="scanInput" placeholder="Tempelkan barcode di sini..." autofocus>
            <button class="btn btn-primary" type="button" id="scanBtn">Cari</button>
            <button class="btn btn-secondary" type="button" id="clearBtn">Hapus</button>
        </div>
        
        <div class="mt-3">
            <small class="text-muted">Tips: Tekan Enter setelah scan barcode untuk langsung mencari.</small>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const scanInput = document.getElementById('scanInput');
    const scanBtn = document.getElementById('scanBtn');
    const clearBtn = document.getElementById('clearBtn');
    const scanResult = document.getElementById('scanResult');

    // Cari saat tombol diklik
    scanBtn.addEventListener('click', function () {
        searchBarcode(scanInput.value.trim());
    });

    // Cari saat Enter ditekan
    scanInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            searchBarcode(scanInput.value.trim());
        }
    });

    // Hapus input dan hasil
    clearBtn.addEventListener('click', function () {
        scanInput.value = '';
        scanResult.style.display = 'none';
        scanInput.focus();
    });

    function searchBarcode(barcode) {
        if (!barcode) {
            showAlert('Masukkan kode barcode terlebih dahulu.');
            return;
        }

        fetch('<?= site_url('api/products/search') ?>?q=' + encodeURIComponent(barcode))
            .then(res => res.json())
            .then(data => {
                if (data.success && data.data) {
                    const product = data.data;
                    document.getElementById('resultCode').textContent = product.kode_barang || 'N/A';
                    document.getElementById('resultName').textContent = product.nama || 'N/A';
                    document.getElementById('resultCategory').textContent = product.kategori_nama || 'N/A';
                    document.getElementById('resultStock').textContent = product.stock || 0;
                    document.getElementById('resultPrice').textContent = Rp(product.harga_jual || 0);
                    scanResult.style.display = 'block';
                } else {
                    showAlert('Produk tidak ditemukan dengan barcode: ' + barcode);
                    scanResult.style.display = 'none';
                }
            })
            .catch(err => {
                showAlert('Gagal menghubungi server: ' + err.message);
            });
    }

    function showAlert(msg) {
        const alertDiv = document.createElement('div');
        alertDiv.className = 'alert alert-warning mt-3';
        alertDiv.textContent = msg;
        document.querySelector('.card-body').appendChild(alertDiv);
        setTimeout(() => alertDiv.remove(), 5000);
    }

    function Rp(angka) {
        return 'Rp ' + angka.toLocaleString('id-ID');
    }
});
</script>