<?= $this->extend('layouts/main') ?>
<?php $pageTitle='AI Sales Assistant'; ?>
<?= $this->section('content') ?>
<div class="row g-3">
  <div class="col-md-3">
    <div class="card"><div class="card-header"><b>Riwayat Chat</b></div>
      <div class="card-body p-2" style="max-height:560px;overflow:auto">
        <button class="btn btn-primary w-100 mb-2" onclick="newChat()"><i class="fas fa-plus"></i> Chat Baru</button>
        <?php foreach ($sessions as $s): ?>
          <div class="d-flex align-items-center gap-1 border-bottom py-2">
            <a class="text-decoration-none flex-grow-1 small" href="#" onclick="loadSession(<?= $s['id'] ?>);return false"><?= esc(mb_substr($s['title'] ?? 'Chat',0,40)) ?></a>
            <button class="btn btn-sm btn-link text-danger p-0" onclick="delSession(<?= $s['id'] ?>)"><i class="fas fa-times"></i></button>
          </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
  <div class="col-md-9">
    <div class="card"><div class="card-body p-0" style="height:560px;display:flex;flex-direction:column">
      <div id="chatArea" class="p-3" style="flex:1;overflow:auto;background:#f8fafc">
        <div class="text-center text-muted py-5">
          <i class="fas fa-robot fa-3x mb-3 text-primary"></i>
          <p>Halo! Tanya saya apa saja tentang toko Anda.</p>
          <div class="row g-2 mt-3">
            <?php $samples = ['Berapa omzet minggu ini?','Produk apa yang paling laris bulan ini?','Stok mana yang harus segera direstock?','Kasir mana yang paling banyak transaksi hari ini?']; ?>
            <?php foreach ($samples as $s): ?>
              <div class="col-md-6"><button class="btn btn-outline-primary btn-sm w-100" onclick="ask('<?= esc($s) ?>')"><?= esc($s) ?></button></div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
      <div class="p-3 border-top bg-white">
        <div class="input-group">
          <input id="chatInput" class="form-control" placeholder="Tanya sesuatu... (Enter untuk kirim)" onkeypress="if(event.key==='Enter')ask()">
          <button class="btn btn-primary" onclick="ask()"><i class="fas fa-paper-plane"></i></button>
        </div>
        <small class="text-muted"><i class="fas fa-info-circle"></i> Powered by Gemini 3 Flash. Set API key di <a href="<?= site_url('settings') ?>">Pengaturan → Integrasi</a>.</small>
      </div>
    </div></div>
  </div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
let currentSession = 0;
function esc(s){return String(s).replace(/[<>&]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;'}[c]))}
function newChat(){ currentSession = 0; document.getElementById('chatArea').innerHTML='<div class="text-center text-muted py-5"><i class="fas fa-robot fa-3x mb-3 text-primary"></i><p>Halo! Tanya saya apa saja.</p></div>'; }
async function loadSession(id){
  currentSession = id;
  const r = await fetch('/ai/messages/'+id).then(r=>r.json());
  const area = document.getElementById('chatArea'); area.innerHTML='';
  r.messages.forEach(m=>append(m.role, m.content));
  area.scrollTop = area.scrollHeight;
}
async function delSession(id){
  if (! confirm('Hapus chat?')) return;
  await fetch('/ai/session/'+id+'/delete',{method:'POST'});
  location.reload();
}
function append(role, text){
  const area = document.getElementById('chatArea');
  const bubble = role === 'user'
    ? `<div class="d-flex justify-content-end mb-2"><div class="bg-primary text-white rounded-3 p-2 px-3" style="max-width:75%">${esc(text)}</div></div>`
    : `<div class="d-flex mb-2"><div class="bg-white border rounded-3 p-2 px-3" style="max-width:75%"><i class="fas fa-robot text-primary me-1"></i>${esc(text).replace(/\n/g,'<br>')}</div></div>`;
  area.insertAdjacentHTML('beforeend', bubble);
  area.scrollTop = area.scrollHeight;
}
async function ask(text){
  const input = document.getElementById('chatInput');
  const msg = text || input.value.trim();
  if (!msg) return;
  input.value='';
  append('user', msg);
  append('assistant','⏳ Menganalisis data toko...');
  const area = document.getElementById('chatArea');
  const loading = area.lastElementChild;
  try {
    const r = await fetch('/ai/ask',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({message:msg,session_id:currentSession})});
    const j = await r.json();
    loading.remove();
    if (j.ok) { append('assistant', j.answer); currentSession = j.session_id; }
    else append('assistant','❌ '+(j.msg||'Gagal'));
  } catch(e){ loading.remove(); append('assistant','❌ Error: '+e.message); }
}
</script>
<?= $this->endSection() ?>
