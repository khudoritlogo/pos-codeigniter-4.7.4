<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Stock Opname'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <a class="btn btn-primary" href="<?= site_url('stock-opnames/new') ?>"><i class="fas fa-plus"></i> Opname Baru</a></div>
  <table class="table datatable table-striped">
    <thead><tr><th>No</th><th>Tanggal</th><th>Cabang</th><th>User</th><th>Status</th></tr></thead>
    <tbody><?php foreach ($rows as $r): ?><tr><td><?= esc($r['opname_no']) ?></td><td><?= date('d/m/Y H:i',strtotime($r['opname_date'])) ?></td><td><?= esc($r['branch_name']) ?></td><td><?= esc($r['fullname']) ?></td><td><span class="badge bg-success"><?= $r['status'] ?></span></td></tr><?php endforeach; ?></tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
