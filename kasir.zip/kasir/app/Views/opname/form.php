<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Opname Baru'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <p class="text-muted">Isi kolom "Fisik" untuk mencatat jumlah sebenarnya. Selisih akan menyesuaikan stok otomatis.</p>
  <table class="table table-sm table-bordered">
    <thead><tr><th>SKU</th><th>Produk</th><th class="text-end">Sistem</th><th class="text-end">Fisik</th><th class="text-end">Selisih</th><th>Catatan</th></tr></thead>
    <tbody>
      <?php foreach ($products as $i=>$p): ?>
      <tr data-pid="<?= $p['id'] ?>" data-sys="<?= $p['system_qty'] ?>">
        <td><?= esc($p['sku']) ?></td><td><?= esc($p['name']) ?></td>
        <td class="text-end"><?= (float)$p['system_qty'] ?></td>
        <td><input type="number" step="0.01" class="form-control form-control-sm text-end phys" value="<?= (float)$p['system_qty'] ?>" onchange="calc(this)"></td>
        <td class="text-end diff">0</td>
        <td><input class="form-control form-control-sm note"></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <textarea id="notes" class="form-control mb-2" placeholder="Catatan Opname..."></textarea>
  <button class="btn btn-success" onclick="save()"><i class="fas fa-save"></i> Simpan Opname</button>
</div></div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
function calc(input){
  const row = input.closest('tr');
  const sys = +row.dataset.sys; const phys = +input.value;
  row.querySelector('.diff').textContent = (phys-sys).toFixed(2);
}
async function save(){
  const items = [];
  document.querySelectorAll('#items,tbody tr').forEach(row=>{
    if (!row.dataset.pid) return;
    items.push({ product_id:+row.dataset.pid, system_qty:+row.dataset.sys, physical_qty:+row.querySelector('.phys').value, notes:row.querySelector('.note').value });
  });
  const r = await fetch('/stock-opnames',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({notes:$('#notes').val(),items})});
  const j = await r.json(); Swal.fire(j.ok?'Berhasil':'Gagal',j.opname_no||'',j.ok?'success':'error').then(()=>location='/stock-opnames');
}
</script>
<?= $this->endSection() ?>
