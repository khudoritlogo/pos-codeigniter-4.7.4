<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <div><h1 class="h3 mb-0 text-gray-800"><?= esc($title ?? 'Satuan') ?></h1></div>
    <a href="<?= site_url('units/new') ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Tambah</a>
</div>
<div class="card shadow"><div class="card-body p-0">
<table class="table table-hover table-striped mb-0">
  <thead class="table-light"><tr><th>No</th><th>Nama Satuan</th><th>Symbol</th><th class="text-center" style="width:80px">Status</th><th style="width:100px" class="text-center">Aksi</th></tr></thead>
  <tbody>
    <?php if(empty($units)): ?><tr><td colspan="5" class="text-center py-4"><i class="fas fa-ruler fa-2x text-muted"></i><p class="mt-2 text-muted">Belum ada satuan.</p></td></tr><?php endif; ?>
    <?php foreach($units ?? [] as $i => $u): ?>
    <tr>
      <td><?= $i+1 ?></td>
      <td><b><?= esc($u['name']) ?></b></td>
      <td><small><?= esc($u['symbol'] ?? '-') ?></small></td>
      <td class="text-center"><?php if(!empty($u['is_active'])): ?><span class="badge badge-success">Aktif</span><?php else: ?><span class="badge badge-secondary">Nonaktif</span><?php endif; ?></td>
      <td class="text-center">
        <div class="btn-group btn-group-sm">
          <a href="<?= site_url("units/edit/$u[id]") ?>" class="btn btn-info btn-sm"><i class="fas fa-edit"></i></a>
          <?php if(session()->get('level_code')==='superadmin'): ?>
          <form action="<?= site_url("units/delete/$u[id]") ?>" method="post" class="d-inline" onsubmit="return confirm('Hapus satuan ini?')"><button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></form>
          <?php endif; ?>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div></div>
<?= $this->endSection() ?>