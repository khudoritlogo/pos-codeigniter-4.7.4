<?= $this->extend('layouts.app') ?>
<?= $this->section('content') ?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Manajemen Lisensi</h1>
        <a href="<?= base_url('license/create') ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
            <i class="fas fa-plus fa-sm text-white-50"></i> Generate Key Baru
        </a>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success"><?= session()->getFlashdata('success') ?></div>
            <?php endif; ?>
            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Key</th>
                            <th>Status</th>
                            <th>Domain</th>
                            <th>IP</th>
                            <th>Customer</th>
                            <th>Valid Sampai</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($licenses as $license): ?>
                        <tr>
                            <td><small><?= substr($license['license_key'], 0, 20) ?>...</small></td>
                            <td>
                                <?php if ($license['status'] == 'active'): ?>
                                    <span class="badge badge-success">Active</span>
                                <?php elseif ($license['status'] == 'inactive'): ?>
                                    <span class="badge badge-danger">Inactive</span>
                                <?php else: ?>
                                    <span class="badge badge-warning"><?= $license['status'] ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?= $license['domain'] ?? '-' ?></td>
                            <td><?= $license['ip_address'] ?? '-' ?></td>
                            <td><?= $license['customer_name'] ?? '-' ?></td>
                            <td><?= $license['valid_until'] ?></td>
                            <td>
                                <a href="<?= base_url('license/edit/' . $license['id']) ?>" class="btn btn-sm btn-info">Edit</a>
                                <button onclick="deactivate(<?= $license['id'] ?>)" class="btn btn-sm btn-danger">Deactivate</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <?= $this->pagination->links() ?>
        </div>
    </div>
</div>

<script>
function deactivate(id) {
    if (confirm('Deactivate lisensi ini?')) {
        fetch('<?= base_url('license/deactivate') ?>/' + id, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: '<?= csrf_token() ?>'
        })
        .then(r => r.json())
        .then(d => {
            if (d.success) location.reload();
            else alert(d.error || 'Gagal');
        });
    }
}
</script>

<?= $this->endSection() ?>
