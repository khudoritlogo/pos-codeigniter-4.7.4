<?= $this->extend('layouts.app') ?>
<?= $this->section('content') ?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <a href="<?= base_url('license') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
        <h1 class="h3 mb-0 text-gray-800">Riwayat Aktivasi</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Waktu</th>
                            <th>Aksi</th>
                            <th>Domain Lama</th>
                            <th>Domain Baru</th>
                            <th>IP Lama</th>
                            <th>IP Baru</th>
                            <th>Peredarah</th>
                            <th>Alasan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?= $log['created_at'] ?></td>
                            <td><?= ucfirst($log['action']) ?></td>
                            <td><?= $log['old_domain'] ?? '-' ?></td>
                            <td><?= $log['new_domain'] ?? '-' ?></td>
                            <td><?= $log['old_ip'] ?? '-' ?></td>
                            <td><?= $log['new_ip'] ?? '-' ?></td>
                            <td><?= $log['performed_by'] ?? '-' ?></td>
                            <td><?= $log['notes'] ?? '-' ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
