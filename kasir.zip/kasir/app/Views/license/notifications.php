<?= $this->extend('layouts.app') ?>
<?= $this->section('content') ?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <a href="<?= base_url('license') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
        <h1 class="h3 mb-0 text-gray-800">Log Notifikasi</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead>
                        <tr>
                            <th>Waktu</th>
                            <th>Tipe</th>
                            <th>Tujuan</th>
                            <th>Subject</th>
                            <th>Status</th>
                            <th>Error</th>
                            <th>Retry</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($notifications as $notif): ?>
                        <tr>
                            <td><?= $notif['created_at'] ?></td>
                            <td><?= $notif['type'] ?></td>
                            <td><?= $notif['recipient'] ?></td>
                            <td><?= $notif['subject'] ?></td>
                            <td>
                                <?php if ($notif['status'] == 'sent'): ?>
                                    <span class="badge badge-success">Kirim</span>
                                <?php elseif ($notif['status'] == 'failed'): ?>
                                    <span class="badge badge-danger">Gagal</span>
                                <?php elseif ($notif['status'] == 'pending'): ?>
                                    <span class="badge badge-warning">Pending</span>
                                <?php else: ?>
                                    <span class="badge badge-secondary"><?= $notif['status'] ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?= $notif['error'] ?? '-' ?></td>
                            <td><?= $notif['retry_count'] ?>/3</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
