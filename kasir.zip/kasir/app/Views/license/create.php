<?= $this->extend('layouts.app') ?>
<?= $this->section('content') ?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <a href="<?= base_url('license') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
        <h1 class="h3 mb-0 text-gray-800">Generate License Key Baru</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
            <?php endif; ?>

            <form action="<?= base_url('license/store') ?>" method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nama Customer</label>
                        <input type="text" name="customer_name" class="form-control" required placeholder="Nama customer / perusahaan">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Email Customer</label>
                        <input type="email" name="customer_email" class="form-control" required placeholder="email@domain.com">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Domain (opsional)</label>
                        <input type="text" name="domain" class="form-control" placeholder="example.com">
                        <small class="text-muted">Bisa dikosongkan, akan terisi saat aktivasi pertama</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Valid Until</label>
                        <input type="date" name="valid_until" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Order ID (opsional)</label>
                        <input type="text" name="order_id" class="form-control" placeholder="ORDER-12345">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Notes</label>
                        <textarea name="notes" class="form-control" rows="3" placeholder="Catatan tambahan..."></textarea>
                    </div>
                </div>
                <div class="mb-3">
                    <label class="form-label">Jumlah Key</label>
                    <input type="number" name="count" class="form-control" value="1" min="1" max="10">
                </div>
                <button type="submit" class="btn btn-primary">Generate & Simpan</button>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
