<?= $this->extend('layouts.app') ?>
<?= $this->section('content') ?>

<div class="container-fluid">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <a href="<?= base_url('license') ?>" class="d-none d-sm-inline-block btn btn-sm btn-secondary shadow-sm">
            <i class="fas fa-arrow-left"></i> Kembali
        </a>
        <h1 class="h3 mb-0 text-gray-800">Edit Lisensi</h1>
    </div>

    <div class="card shadow mb-4">
        <div class="card-body">
            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger"><?= session()->getFlashdata('error') ?></div>
            <?php endif; ?>

            <form action="<?= base_url('license/update/' . $license['id']) ?>" method="POST">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Nama Customer</label>
                        <input type="text" name="customer_name" class="form-control" value="<?= old('customer_name', $license['customer_name']) ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Email Customer</label>
                        <input type="email" name="customer_email" class="form-control" value="<?= old('customer_email', $license['customer_email']) ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Domain</label>
                        <input type="text" name="domain" class="form-control" value="<?= old('domain', $license['domain']) ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">IP Address</label>
                        <input type="text" name="ip_address" class="form-control" value="<?= old('ip_address', $license['ip_address']) ?>" readonly>
                        <small class="text-muted">Diisi otomatis saat aktivasi</small>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Valid Until</label>
                        <input type="date" name="valid_until" class="form-control" value="<?= old('valid_until', $license['valid_until']) ?>" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-control">
                            <option value="active" <?= $license['status'] == 'active' ? 'selected' : '' ?>>Active</option>
                            <option value="inactive" <?= $license['status'] == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                            <option value="expired" <?= $license['status'] == 'expired' ? 'selected' : '' ?>>Expired</option>
                        </select>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label">Notes</label>
                        <textarea name="notes" class="form-control" rows="3"><?= old('notes', $license['notes']) ?></textarea>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        </div>
    </div>
</div>

<?= $this->endSection() ?>
