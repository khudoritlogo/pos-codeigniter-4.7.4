<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Piutang Customer'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <div class="mb-2 d-flex gap-2">
    <a href="<?= site_url('receivables') ?>" class="btn btn-outline-primary btn-sm">Semua</a>
    <a href="<?= site_url('receivables/overdue') ?>" class="btn btn-outline-danger btn-sm">Menunggak</a>
  </div>
  <table class="table datatable table-striped">
    <thead><tr><th>Invoice</th><th>Customer</th><th>Jatuh Tempo</th><th class="text-end">Total</th><th class="text-end">Sisa</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <?php if (isset($rows) && is_array($rows) && count($rows)): ?>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= esc($r['invoice_no']) ?></td><td><?= esc($r['customer_name']) ?></td>
        <td><?= $r['due_date'] ?></td>
        <td class="text-end">Rp <?= number_format((float)$r['amount'],0,',','.') ?></td>
        <td class="text-end fw-bold">Rp <?= number_format((float)$r['remaining'],0,',','.') ?></td>
        <td><span class="badge bg-<?= $r['status']=='paid'?'success':($r['status']=='partial'?'warning':'danger') ?>"><?= $r['status'] ?></span></td>
         <a class="btn btn-sm btn-primary" href="<?= site_url('receivables/' . $r['id']) ?>"><i class="fas fa-eye"></i></a>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
