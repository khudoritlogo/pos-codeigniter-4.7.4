<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Detail Piutang & Cicilan'; ?>
<?= $this->section('content') ?>
<div class="row g-3"><div class="col-md-6">
  <div class="card"><div class="card-header"><b>Info Piutang</b></div><div class="card-body">
    <div>Total: <b>Rp <?= number_format((float)$r['amount'],0,',','.') ?></b></div>
    <div>Dibayar: Rp <?= number_format((float)$r['paid_amount'],0,',','.') ?></div>
    <div>Sisa: <b class="text-danger">Rp <?= number_format((float)$r['remaining'],0,',','.') ?></b></div>
    <div>Jatuh Tempo: <?= $r['due_date'] ?></div>
    <div>Status: <span class="badge bg-secondary"><?= $r['status'] ?></span></div>
  </div></div>
</div><div class="col-md-6">
  <div class="card"><div class="card-header bg-success text-white"><b>Bayar Cicilan</b></div><div class="card-body">
    <form method="post" action="/receivables/pay/<?= $r['id'] ?>">
      <?= csrf_field() ?>
      <div class="mb-2"><label>Jumlah</label><input type="number" name="amount" class="form-control" required max="<?= $r['remaining'] ?>"></div>
      <div class="mb-2"><label>Metode</label>
        <select class="form-select" name="method"><option value="cash">Cash</option><option value="transfer">Transfer</option><option value="qris">QRIS</option></select>
      </div>
      <div class="mb-2"><label>Catatan</label><input class="form-control" name="notes"></div>
      <button class="btn btn-success w-100"><i class="fas fa-money-bill"></i> Bayar</button>
    </form>
  </div></div>
</div></div>

<div class="card mt-3"><div class="card-header"><b>Riwayat Pembayaran</b></div>
  <div class="card-body p-0"><table class="table table-sm mb-0">
    <thead><tr><th>Tanggal</th><th>Metode</th><th class="text-end">Jumlah</th><th>Catatan</th></tr></thead>
    <tbody><?php foreach ($payments as $p): ?><tr><td><?= $p['payment_date'] ?></td><td><?= $p['method'] ?></td><td class="text-end">Rp <?= number_format((float)$p['amount'],0,',','.') ?></td><td><?= esc($p['notes']) ?></td></tr><?php endforeach; ?></tbody>
  </table></div>
</div>
<?= $this->endSection() ?>
