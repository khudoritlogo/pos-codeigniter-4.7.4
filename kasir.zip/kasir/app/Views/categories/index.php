<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <div>
        <h1 class="h3 mb-0 text-gray-800"><?= esc($title ?? 'Kategori') ?></h1>
    </div>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?= site_url('categories/new') ?>" class="btn btn-primary btn-sm">
            <i class="fas fa-plus"></i> Tambah
        </a>
    </div>
</div>

<div class="card shadow">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover table-striped mb-0">
                <thead class="table-light">
                    <tr>
                        <th>No</th>
                        <th>Nama Kategori</th>
                        <th>Deskripsi</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Produk</th>
                        <th style="width:100px" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($categories)): ?>
                    <tr><td colspan="6" class="text-center py-4">
                        <i class="fas fa-tags fa-2x text-muted"></i>
                        <p class="mt-2 text-muted">Belum ada kategori.</p>
                    </td></tr>
                    <?php endif; ?>
                    <?php foreach($categories ?? [] as $i => $c): ?>
                    <tr>
                        <td><?= $i+1 ?></td>
                        <td><b><?= esc($c['name']) ?></b></td>
                        <td><small class="text-muted"><?= esc($c['description'] ?? '-') ?></small></td>
                        <td class="text-center">
                            <?php if($c['is_active']): ?>
                            <span class="badge badge-success">Aktif</span>
                            <?php else: ?>
                            <span class="badge badge-secondary">Nonaktif</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center">
                            <span class="badge badge-info"><?= (int)($c['products_count'] ?? 0) ?></span>
                        </td>
                        <td class="text-center">
                            <div class="btn-group btn-group-sm">
                                <a href="<?= site_url("categories/edit/$c[id]") ?>" class="btn btn-info btn-sm" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <?php if(session()->get('level_code') === 'superadmin'): ?>
                                <form action="<?= site_url("categories/delete/$c[id]") ?>" method="post" class="d-inline" onsubmit="return confirm('Hapus kategori ini?')">
                                    <button class="btn btn-danger btn-sm" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?= $this->endSection() ?>