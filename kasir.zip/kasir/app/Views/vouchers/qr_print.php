<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Cetak QR Voucher - <?= esc($v['code']) ?></title>
<style>
  @page{margin:6mm} body{font-family:Arial,sans-serif;margin:0}
  .item{display:inline-block;text-align:center;padding:8px;margin:3px;border:1px dashed #999;width:200px;vertical-align:top;border-radius:8px}
  .item img{max-width:100%}
  .item .code{font-size:16px;font-weight:800;letter-spacing:.1em;background:#0d6efd;color:#fff;padding:4px 8px;border-radius:4px;margin-top:6px;display:inline-block}
  .item .desc{font-size:11px;color:#666;margin-top:4px}
  .no-print button{margin:10px}
</style></head><body>
<div class="no-print">
  <button onclick="window.print()">🖨️ Cetak</button>
  Jumlah: <input type="number" value="<?= (int)$qty ?>" onchange="location='?qty='+this.value">
</div>
<?php for ($i=0;$i<$qty;$i++): ?>
  <div class="item">
    <div style="font-weight:bold;font-size:12px"><?= esc($v['name']) ?></div>
    <img src="<?= esc($qr_png) ?>" alt="QR">
    <div class="code"><?= esc($v['code']) ?></div>
    <div class="desc">
      <?php if ($v['type']==='percent'): ?>Diskon <?= (float)$v['value'] ?>%<?php elseif ($v['type']==='nominal'): ?>Potongan Rp <?= number_format((float)$v['value'],0,',','.') ?><?php else: ?>Gratis Ongkir<?php endif; ?><br>
      Min. Rp <?= number_format((float)$v['min_purchase'],0,',','.') ?> · s/d <?= $v['valid_until'] ?>
    </div>
  </div>
<?php endfor; ?>
</body></html>
