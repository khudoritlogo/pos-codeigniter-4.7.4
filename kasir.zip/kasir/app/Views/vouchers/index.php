<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Voucher & Kupon'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
   <a class="btn btn-primary" href="<?= site_url('vouchers/new') ?>"><i class="fas fa-plus"></i> Tambah Voucher</a></div>
  <table class="table datatable table-striped">
    <thead><tr><th>Kode</th><th>Nama</th><th>Tipe</th><th class="text-end">Nilai</th><th class="text-end">Min. Belanja</th><th>Berlaku</th><th class="text-end">Kuota</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td><span class="badge bg-primary fs-6"><?= esc($r['code']) ?></span></td>
        <td><?= esc($r['name']) ?></td>
        <td><small class="text-uppercase"><?= esc($r['type']) ?></small></td>
        <td class="text-end"><?= $r['type']==='percent'? esc($r['value']).'%' : ($r['type']==='free_shipping'?'Gratis Ongkir':'Rp '.number_format((float)$r['value'],0,',','.')) ?></td>
        <td class="text-end">Rp <?= number_format((float)$r['min_purchase'],0,',','.') ?></td>
        <td><small><?= $r['valid_from'] ?> s/d <?= $r['valid_until'] ?></small></td>
        <td class="text-end"><?= (int)$r['used_count'] ?> / <?= $r['usage_limit'] ?? '∞' ?></td>
        <td><span class="badge bg-<?= $r['is_active']?'success':'secondary' ?>"><?= $r['is_active']?'Aktif':'Nonaktif' ?></span></td>
        <td class="text-end">
          <a class="btn btn-sm btn-success" href="<?= site_url('vouchers/' . $r['id'] . '/share') ?>" title="Share & QR"><i class="fas fa-share-alt"></i></a>
          <a class="btn btn-sm btn-outline-primary" href="<?= site_url('vouchers/' . $r['id'] . '/edit') ?>"><i class="fas fa-edit"></i></a>
          <a class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button></form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
