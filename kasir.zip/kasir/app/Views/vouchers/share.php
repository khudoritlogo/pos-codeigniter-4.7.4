<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Share Voucher: '.$v['code']; ?>
<?= $this->section('content') ?>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="card text-center"><div class="card-header bg-warning"><b><i class="fas fa-qrcode"></i> QR Voucher</b></div>
      <div class="card-body">
        <img src="<?= esc($qr_png) ?>" alt="QR Code" style="max-width:300px;width:100%">
        <div class="mt-3">
          <div class="h3 mb-1"><span class="badge bg-primary" style="letter-spacing:.15em"><?= esc($v['code']) ?></span></div>
          <div class="text-muted small"><?= esc($v['name']) ?></div>
        </div>
        <div class="d-grid gap-2 mt-3">
    <a class="btn btn-outline-secondary" target="_blank" href="<?= site_url('vouchers/' . $v['id'] . '/qr-print?qty=6') ?>"><i class="fas fa-print"></i> Cetak QR (siap tempel)</a>
        </div>
        <hr>
        <div class="text-start">
          <label class="form-label">Link Publik</label>
          <div class="input-group input-group-sm">
            <input type="text" readonly class="form-control" id="publicUrl" value="<?= esc($public_url) ?>" onclick="this.select()">
            <button class="btn btn-outline-primary" onclick="copyLink()"><i class="fas fa-copy"></i></button>
          </div>
          <small class="text-muted">Scan QR di atas atau buka URL di HP → customer langsung lihat detail voucher</small>
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-7">
    <div class="card"><div class="card-header bg-success text-white"><b><i class="fab fa-whatsapp"></i> Share via WhatsApp</b></div>
      <div class="card-body">
        <label>Nomor WA Customer (62812xxxx)</label>
        <div class="input-group mb-3">
          <input type="text" id="waNumber" class="form-control" placeholder="62812xxxxx">
          <button class="btn btn-success" onclick="shareToWa()"><i class="fab fa-whatsapp"></i> Kirim</button>
        </div>
        <label>Template Pesan (bisa diedit)</label>
        <textarea id="waMessage" class="form-control" rows="8">Halo! 🎉

Kami mau kasih voucher khusus untuk kamu di *<?= esc($store['store_name'] ?? 'Toko Kami') ?>*:

🎟️ *<?= esc($v['name']) ?>*
Kode: *<?= esc($v['code']) ?>*
<?php if ($v['type']==='percent'): ?>Diskon: <?= (float)$v['value'] ?>%<?php elseif ($v['type']==='nominal'): ?>Diskon: Rp <?= number_format((float)$v['value'],0,',','.') ?><?php else: ?>Gratis Ongkir<?php endif; ?>
Min. Belanja: Rp <?= number_format((float)$v['min_purchase'],0,',','.') ?>
Berlaku sampai: <?= $v['valid_until'] ?? '-' ?>

Detail voucher & QR: <?= esc($public_url) ?>

Tunjukan kode di atas saat berbelanja untuk dapat diskon. Selamat berbelanja! 🛍️</textarea>
        <div class="mt-3">
          <a class="btn btn-outline-success" href="#" id="waBroadcast" target="_blank"><i class="fab fa-whatsapp"></i> Buka WA Web (tanpa nomor)</a>
        </div>

        <hr>
        <b>Statistik Pemakaian</b>
        <div class="row g-2 mt-2">
          <div class="col-md-4"><div class="stat-card bg-primary"><small>Digunakan</small><h4><?= (int)$v['used_count'] ?></h4></div></div>
          <div class="col-md-4"><div class="stat-card bg-success"><small>Kuota Total</small><h4><?= $v['usage_limit'] ?? '∞' ?></h4></div></div>
          <div class="col-md-4"><div class="stat-card bg-warning"><small>Sisa</small><h4><?= $v['usage_limit'] ? max(0,(int)$v['usage_limit'] - (int)$v['used_count']) : '∞' ?></h4></div></div>
        </div>
      </div>
    </div>
  </div>
</div>

<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
function copyLink(){
  const el = document.getElementById('publicUrl'); el.select(); document.execCommand('copy');
  Swal.fire({toast:true,position:'top-end',icon:'success',title:'Link disalin',timer:1500,showConfirmButton:false});
  fetch('/vouchers/<?= $v['id'] ?>/log-share',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'channel=link'});
}
function shareToWa(){
  const nm = document.getElementById('waNumber').value.replace(/\D/g,'');
  const msg = encodeURIComponent(document.getElementById('waMessage').value);
  if (!nm) return Swal.fire('Info','Isi nomor WA','info');
  window.open(`https://wa.me/${nm}?text=${msg}`,'_blank');
  fetch('/vouchers/<?= $v['id'] ?>/log-share',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'channel=whatsapp&to='+encodeURIComponent(nm)});
}
document.getElementById('waBroadcast').onclick = e=>{
  e.preventDefault();
  const msg = encodeURIComponent(document.getElementById('waMessage').value);
  window.open(`https://web.whatsapp.com/send?text=${msg}`,'_blank');
};
</script>
<?= $this->endSection() ?>
