<?= $this->extend('layouts/main') ?>
<?php $pageTitle=($row?'Edit':'Tambah').' Voucher'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <form method="post" action="<?= $row?'/vouchers/'.$row['id']:'/vouchers' ?>">
    <?= csrf_field() ?><?php if($row): ?><input type="hidden" name="_method" value="PUT"><?php endif; ?>
    <div class="row g-3">
      <div class="col-md-4"><label>Kode *</label><input required class="form-control text-uppercase" name="code" value="<?= esc($row['code']??'') ?>" placeholder="WELCOME10"></div>
      <div class="col-md-8"><label>Nama *</label><input required class="form-control" name="name" value="<?= esc($row['name']??'') ?>"></div>
      <div class="col-md-4"><label>Tipe *</label>
        <select class="form-select" name="type" required>
          <option value="percent" <?=($row['type']??'')=='percent'?'selected':''?>>Persen (%)</option>
          <option value="nominal" <?=($row['type']??'')=='nominal'?'selected':''?>>Nominal (Rp)</option>
          <option value="free_shipping" <?=($row['type']??'')=='free_shipping'?'selected':''?>>Gratis Ongkir</option>
        </select>
      </div>
      <div class="col-md-4"><label>Nilai</label><input type="number" step="0.01" class="form-control" name="value" value="<?= esc($row['value']??0) ?>"></div>
      <div class="col-md-4"><label>Max. Diskon (Rp)</label><input type="number" class="form-control" name="max_discount" value="<?= esc($row['max_discount']??'') ?>" placeholder="opsional"></div>
      <div class="col-md-4"><label>Min. Belanja (Rp)</label><input type="number" class="form-control" name="min_purchase" value="<?= esc($row['min_purchase']??0) ?>"></div>
      <div class="col-md-4"><label>Kuota Total</label><input type="number" class="form-control" name="usage_limit" value="<?= esc($row['usage_limit']??'') ?>" placeholder="kosong = tak terbatas"></div>
      <div class="col-md-4"><label>Kuota per Customer</label><input type="number" class="form-control" name="usage_per_customer" value="<?= esc($row['usage_per_customer']??'') ?>" placeholder="kosong = tak terbatas"></div>
      <div class="col-md-4"><label>Berlaku Mulai</label><input type="date" class="form-control" name="valid_from" value="<?= esc($row['valid_from']??date('Y-m-d')) ?>"></div>
      <div class="col-md-4"><label>Sampai</label><input type="date" class="form-control" name="valid_until" value="<?= esc($row['valid_until']??date('Y-m-d',strtotime('+30 days'))) ?>"></div>
      <div class="col-md-4"><label>Level Customer (opsional)</label><input class="form-control" name="applicable_customer_levels" value="<?= esc($row['applicable_customer_levels']??'') ?>" placeholder="1,2,3 (kosong=semua)"></div>
      <div class="col-md-4 form-check mt-4 ms-3"><input class="form-check-input" type="checkbox" name="is_active" value="1" <?= ($row['is_active']??1)?'checked':'' ?>><label class="form-check-label">Aktif</label></div>
    </div><hr>
    <button class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
    <a class="btn btn-secondary" href="<?= site_url('vouchers') ?>">Batal</a>
  </form>
</div></div>
<?= $this->endSection() ?>
