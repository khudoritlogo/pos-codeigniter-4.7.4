<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8">
<title>Voucher <?= esc($v['code']) ?> - <?= esc($store['store_name'] ?? 'POS') ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
<style>
  body{background:linear-gradient(135deg,#fbbf24,#f97316);min-height:100vh;font-family:system-ui;display:flex;align-items:center;justify-content:center;padding:20px}
  .ticket{max-width:420px;width:100%;background:#fff;border-radius:20px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.3);position:relative}
  .top{background:linear-gradient(135deg,#0f172a,#1e40af);color:#fff;padding:28px;text-align:center}
  .cutout{height:24px;background:radial-gradient(circle at 12px 12px,transparent 12px,#fff 13px) repeat-x;background-size:24px}
  .body{padding:24px}
  .code-box{background:#0d6efd;color:#fff;padding:16px;border-radius:12px;text-align:center;font-size:1.8rem;font-weight:900;letter-spacing:.2em;margin:16px 0}
  .info-row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px dashed #eee;font-size:.9rem}
  .btn-primary{background:#0d6efd;border:none}
</style></head><body>
<div class="ticket">
  <div class="top">
    <div style="font-size:.85rem;opacity:.85"><?= esc($store['store_name'] ?? 'Toko') ?></div>
    <h3 class="my-1" style="font-weight:800">🎉 <?= esc($v['name']) ?></h3>
    <div style="font-size:1.05rem">
      <?php if ($v['type']==='percent'): ?>Diskon <?= (float)$v['value'] ?>%<?php elseif ($v['type']==='nominal'): ?>Potongan Rp <?= number_format((float)$v['value'],0,',','.') ?><?php else: ?>Gratis Ongkir<?php endif; ?>
    </div>
  </div>
  <div class="cutout"></div>
  <div class="body">
    <div class="text-center small text-muted">Tunjukan kode ini di kasir</div>
    <div class="code-box" id="codeBox"><?= esc($v['code']) ?></div>
    <button class="btn btn-outline-primary w-100 mb-3" onclick="copyCode()"><i class="fas fa-copy"></i> Salin Kode</button>

    <div class="info-row"><span>Min. Belanja</span><b>Rp <?= number_format((float)$v['min_purchase'],0,',','.') ?></b></div>
    <?php if (!empty($v['max_discount'])): ?><div class="info-row"><span>Maks. Diskon</span><b>Rp <?= number_format((float)$v['max_discount'],0,',','.') ?></b></div><?php endif; ?>
    <div class="info-row"><span>Berlaku Sampai</span><b><?= $v['valid_until'] ?? '-' ?></b></div>
    <?php if ($v['usage_limit']): ?><div class="info-row"><span>Kuota</span><b><?= max(0,(int)$v['usage_limit']-(int)$v['used_count']) ?> tersisa</b></div><?php endif; ?>

    <?php if (!empty($v['description'])): ?><p class="small text-muted mt-3"><?= nl2br(esc($v['description'])) ?></p><?php endif; ?>

    <div class="text-center mt-4">
      <div class="text-muted small">Terima kasih, sampai jumpa di toko!</div>
      <?php if (!empty($store['phone'])): ?><a class="btn btn-success btn-sm mt-2" href="https://wa.me/<?= preg_replace('/\D/','',$store['phone']) ?>"><i class="fab fa-whatsapp"></i> Hubungi Kami</a><?php endif; ?>
    </div>
  </div>
</div>
<script>
function copyCode(){
  navigator.clipboard.writeText(document.getElementById('codeBox').textContent.trim());
  event.target.innerHTML = '<i class="fas fa-check"></i> Kode Disalin!';
}
</script>
</body></html>
