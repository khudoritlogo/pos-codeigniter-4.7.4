<?= $this->extend('layouts/main') ?>
<?php $pageTitle = 'Verifikasi Email'; ?>
<?= $this->section('content') ?>
<div class="card">
  <div class="card-body text-center py-5">
    <?php if ($ok): ?>
      <i class="fas fa-check-circle text-success" style="font-size:5rem"></i>
      <h3 class="mt-3">Email Berhasil Diverifikasi!</h3>
      <p class="text-muted"><b><?= esc($email) ?></b> sudah aktif sebagai recovery email.<br>Sekarang Anda bisa pakai fitur "Lupa Password" dengan email ini.</p>
    <?php else: ?>
      <i class="fas fa-times-circle text-danger" style="font-size:5rem"></i>
      <h3 class="mt-3">Verifikasi Gagal</h3>
      <p class="text-muted">Link ini mungkin sudah expired (24 jam), sudah dipakai, atau tidak valid.</p>
    <?php endif; ?>
<a class="btn btn-primary mt-3" href="<?= site_url('profile') ?>"><i class="fas fa-user me-1"></i>Kembali ke Profil</a>
  </div>
</div>
<?= $this->endSection() ?>
