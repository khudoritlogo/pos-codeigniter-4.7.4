<?= $this->extend('layouts/main') ?>
<?php $pageTitle = 'Profil Saya'; ?>
<?= $this->section('content') ?>

<div class="row g-3">
  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-primary text-white"><b><i class="fas fa-user me-1"></i> Info Akun</b></div>
      <div class="card-body">
        <table class="table table-sm mb-0">
          <tr><th style="width:40%">Username</th><td><b><?= esc($user['username']) ?></b></td></tr>
          <tr><th>Nama Lengkap</th><td><?= esc($user['fullname']) ?></td></tr>
          <tr><th>Level</th><td><span class="badge bg-info"><?= esc(session('level_name')) ?></span></td></tr>
          <tr><th>Email</th><td><?= esc($user['email'] ?? '-') ?></td></tr>
          <tr>
            <th>Recovery Email</th>
            <td>
              <?php if (! empty($user['recovery_email'])): ?>
                <?= esc($user['recovery_email']) ?>
                <?php if (! empty($user['recovery_email_verified_at'])): ?>
                  <span class="badge bg-success ms-1"><i class="fas fa-check"></i> Verified</span>
                <?php else: ?>
                  <span class="badge bg-warning text-dark ms-1"><i class="fas fa-exclamation-triangle"></i> Belum Verified</span>
                <?php endif; ?>
              <?php else: ?>
                <span class="text-muted">Belum diset</span>
              <?php endif; ?>
            </td>
          </tr>
          <tr><th>Login Terakhir</th><td><?= esc($user['last_login'] ?? '-') ?></td></tr>
        </table>
      </div>
    </div>
  </div>

  <div class="col-lg-6">
    <div class="card">
      <div class="card-header bg-warning"><b><i class="fas fa-key me-1"></i> Recovery Email</b></div>
      <div class="card-body">
        <p class="small text-muted">Email ini dipakai kalau Anda lupa password. Sistem akan kirim link reset ke email ini (WAJIB verifikasi dulu supaya bisa dipakai).</p>
        <form action="/profile/recovery-email" method="post">
          <?= csrf_field() ?>
          <div class="input-group">
            <input type="email" name="recovery_email" class="form-control" placeholder="email@contoh.com" value="<?= esc($user['recovery_email'] ?? '') ?>" required>
            <button class="btn btn-warning" type="submit"><i class="fas fa-paper-plane me-1"></i>Simpan &amp; Kirim Verifikasi</button>
          </div>
          <small class="text-muted mt-1 d-block">Setelah simpan, cek inbox email untuk link verifikasi (berlaku 24 jam).</small>
        </form>
      </div>
    </div>

    <div class="card mt-3">
      <div class="card-header bg-dark text-white"><b><i class="fas fa-lock me-1"></i> Ganti Password</b></div>
      <div class="card-body">
        <form action="/profile/change-password" method="post">
          <?= csrf_field() ?>
          <div class="mb-2"><label class="form-label small">Password Lama</label><input type="password" name="old_password" class="form-control" required></div>
          <div class="mb-2"><label class="form-label small">Password Baru</label><input type="password" name="new_password" class="form-control" required minlength="8"><small class="text-muted">Min 8 karakter, huruf + angka.</small></div>
          <div class="mb-2"><label class="form-label small">Konfirmasi Password Baru</label><input type="password" name="confirm_password" class="form-control" required minlength="8"></div>
          <button class="btn btn-dark w-100" type="submit"><i class="fas fa-save me-1"></i>Simpan Password Baru</button>
        </form>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
