<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Cetak Barcode - <?= esc($product['name']) ?></title>
<style>
  @page{margin:5mm} body{font-family:Arial;margin:0}
  .barcode-item{display:inline-block;text-align:center;padding:6px;margin:2px;border:1px dashed #ccc;width:180px;vertical-align:top}
  .barcode-item .name{font-size:11px;font-weight:bold} .barcode-item .price{font-size:12px}
  .barcode-item svg{max-width:100%}
  .no-print button{margin:10px}
</style></head>
<body>
<div class="no-print">
  <button onclick="window.print()">🖨️ Cetak</button>
  Jumlah: <input type="number" value="<?= (int)$qty ?>" onchange="location='?qty='+this.value">
</div>
<?php for ($i=0;$i<$qty;$i++): ?>
  <div class="barcode-item">
    <div class="name"><?= esc($product['name']) ?></div>
    <div><?= $barcode_html ?></div>
    <div class="price">Rp <?= number_format((float)$product['sell_price'],0,',','.') ?></div>
  </div>
<?php endfor; ?>
</body></html>
