<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Import Produk Massal'; ?>
<?php $this->section('content') ?>

<div class="row g-3">
  <div class="col-lg-5">
    <div class="card"><div class="card-header bg-primary text-white"><b><i class="fas fa-file-upload"></i> Upload File</b></div>
      <div class="card-body">
        <p class="text-muted small">Unggah file <b>CSV</b> atau <b>XLSX</b> berisi data produk. Baris yang cocok dengan barcode/SKU yang sudah ada akan diperbarui, baris baru akan ditambahkan.</p>
        <form method="post" action="<?= site_url('products/import/upload') ?>" enctype="multipart/form-data">
          <?= csrf_field() ?>
          <div class="mb-3">
            <input type="file" name="file" class="form-control" accept=".csv,.xlsx,.xls" required>
            <small class="text-muted">Maks 5 MB. Kolom: barcode, sku, name, category, unit, cost_price, sell_price, wholesale_price, min_wholesale_qty, stock_alert, has_serial_number, has_expired_date, warranty_months</small>
          </div>
          <button class="btn btn-success"><i class="fas fa-upload"></i> Upload & Import</button>
          <a class="btn btn-outline-secondary" href="<?= site_url('products/import/template?format=xlsx') ?>"><i class="fas fa-download"></i> Template XLSX</a>
          <a class="btn btn-outline-secondary" href="<?= site_url('products/import/template?format=csv') ?>"><i class="fas fa-download"></i> Template CSV</a>
        </form>
      </div>
    </div>

    <?php if (session('import_errors')): ?>
    <div class="card mt-3"><div class="card-header bg-danger text-white"><b>Detail Error</b></div>
      <div class="card-body p-0"><ul class="list-group list-group-flush small">
        <?php foreach (session('import_errors') as $e): ?><li class="list-group-item"><?= esc($e) ?></li><?php endforeach; ?>
      </ul></div>
    </div>
    <?php endif; ?>
  </div>

  <div class="col-lg-7">
    <div class="card"><div class="card-header"><b><i class="fas fa-history"></i> Riwayat Import</b></div>
      <div class="card-body p-0"><table class="table table-sm mb-0">
        <thead><tr><th>Tanggal</th><th>User</th><th class="text-end">Total</th><th class="text-end">Ditambah</th><th class="text-end">Update</th><th class="text-end">Gagal</th></tr></thead>
        <tbody>
          <?php foreach ($logs as $l): ?>
          <tr>
            <td><small><?= date('d/m/Y H:i',strtotime($l['created_at'])) ?></small></td>
            <td><?= esc($l['fullname']) ?></td>
            <td class="text-end"><?= (int)$l['total_rows'] ?></td>
            <td class="text-end text-success"><?= (int)$l['imported'] ?></td>
            <td class="text-end text-info"><?= (int)$l['updated'] ?></td>
            <td class="text-end text-danger"><?= (int)$l['failed'] ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table></div>
    </div>
  </div>
</div>

<?= $this->endSection() ?>
