<?= $this->extend('layouts/main') ?>
<?php $pageTitle = 'Daftar Produk'; ?>
<?= $this->section('content') ?>
<style>
  .prod-header {
    display:flex;align-items:center;justify-content:space-between;
    flex-wrap:wrap;gap:.75rem;margin-bottom:1.25rem;
  }
  .prod-header h1 {
    font-weight:700;font-size:1.35rem;color:#1e293b;margin:0;
    display:flex;align-items:center;gap:.5rem;
  }
  .prod-header .actions {
    display:flex;align-items:center;gap:.5rem;flex-wrap:wrap;
  }
  .prod-search {
    position:relative;
    max-width:320px;
  }
  .prod-search .input-group-text {
    background:#fff;border-right:none;
  }
  .prod-search .form-control {
    border-left:none;
    border-radius:0 .5rem .5rem 0;
  }
  .prod-table {
    margin:0;border-radius:1rem;overflow:hidden;
  }
  .prod-table thead th {
    background:#f8fafc;
    color:#475569;
    font-weight:600;
    font-size:.78rem;
    text-transform:uppercase;
    letter-spacing:.3px;
    padding:.65rem .85rem;
    border-bottom:2px solid #e2e8f0;
    white-space:nowrap;
  }
  .prod-table tbody td {
    padding:.55rem .85rem;
    vertical-align:middle;
    border-bottom:1px solid #f1f5f9;
    font-size:.88rem;
  }
  .prod-table tbody tr:hover { background:#f8fafc; }
  .prod-table tbody tr:last-child td { border-bottom:none; }
  .prod-name-cell {
    display:flex;align-items:center;gap:.6rem;
  }
  .prod-thumb {
    width:40px;height:40px;
    border-radius:8px;
    object-fit:cover;
    background:#e2e8f0;
    flex-shrink:0;
    display:flex;align-items:center;justify-content:center;
    color:#94a3b8;
    font-size:.9rem;
  }
  .prod-info .pname {
    font-weight:600;color:#1e293b;
    font-size:.88rem;
    white-space:nowrap;overflow:hidden;
    text-overflow:ellipsis;
    max-width:200px;
  }
  .prod-info .psku {
    font-size:.72rem;color:#94a3b8;
  }
  .stock-badge {
    display:inline-flex;align-items:center;gap:.25rem;
    padding:.15rem .45rem;
    border-radius:999px;
    font-size:.75rem;
    font-weight:600;
  }
  .stock-badge::before {
    content:'';
    width:6px;height:6px;
    border-radius:50%;
    background:currentColor;
  }
  .stock-ok { background:#d1fae5; color:#065f46; }
  .stock-warn { background:#fef3c7; color:#92400e; }
  .stock-low { background:#fee2e2; color:#991b1b; }
  .price-display {
    font-weight:700;color:#1e293b;
    font-family:'Courier New',monospace;
    font-size:.9rem;
  }
  .prod-actions .btn {
    padding:.3rem .45rem;
    font-size:.8rem;
  }
  .empty-state {
    text-align:center;padding:3rem 1rem;
    color:#94a3b8;
  }
  .empty-state i { font-size:2.5rem;margin-bottom:.75rem;opacity:.4;display:block; }
  .empty-state p { margin:0;font-size:.9rem; }
  .pagination-custom .page-link {
    border-radius:.5rem;
    border:none;
    color:#475569;
    background:#fff;
    padding:.4rem .65rem;
    margin:0 .15rem;
  }
  .pagination-custom .page-item.active .page-link {
    background:#2563eb;color:#fff;
  }
</style>

<div class="prod-header">
  <h1><i class="fas fa-box text-primary me-2"></i>Daftar Produk</h1>
  <div class="actions">
    <div class="prod-search">
      <div class="input-group">
        <span class="input-group-text bg-white"><i class="fas fa-search text-muted"></i></span>
        <input type="text" name="q" class="form-control" placeholder="Cari produk, SKU, barcode..." value="<?=esc($search ?? '')?>" id="prodSearchInput">
        <button class="btn btn-outline-secondary" type="submit"><i class="fas fa-search"></i></button>
      </div>
    </div>
    <a href="<?=site_url('products/new')?>" class="btn btn-primary">
      <i class="fas fa-plus me-1"></i>Tambah Produk
    </a>
    <a href="<?=site_url('products/import')?>" class="btn btn-outline-secondary">
      <i class="fas fa-file-import me-1"></i>Import
    </a>
  </div>
</div>

<div class="card border-0 shadow-sm">
  <div class="table-responsive">
    <table class="table prod-table">
      <thead>
        <tr>
          <th>#</th>
          <th>Produk</th>
          <th>SKU</th>
          <th>Barcode</th>
          <th>Kategori</th>
          <th style="text-align:right">Stok</th>
          <th style="text-align:right">Harga Jual</th>
          <th>Status</th>
          <th style="width:110px">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php if(empty($products)): ?>
        <tr>
          <td colspan="9">
            <div class="empty-state">
              <i class="fas fa-box-open"></i>
              <p>Belum ada produk</p>
              <small class="text-muted">Tambahkan produk pertama atau unduh template import</small>
            </div>
          </td>
        </tr>
        <?php else: ?>
          <?php foreach($products ?? [] as $i => $p): ?>
          <tr>
            <td style="color:#94a3b8;font-size:.8rem">
              <?= ($i+1) + (($pager->getCurrentPage()-1)*$pager->getPerPage()) ?>
            </td>
            <td>
              <div class="prod-name-cell">
                <div class="prod-thumb">
                  <?php if(!empty($p['image'])): ?>
                    <img src="<?=base_url('uploads/products/'.esc($p['image']))?>"
                         style="width:100%;height:100%;object-fit:cover;border-radius:8px"
                         onerror="this.style.display='none';this.innerHTML='<i class=\\'fas fa-image\\'\\'></i>'">
                  <?php else: ?>
                    <i class="fas fa-box"></i>
                  <?php endif; ?>
                </div>
                <div class="prod-info">
                  <a href="<?=site_url("products/show/$p[id]")?>" class="pname text-decoration-none">
                    <?=esc($p['name'])?>
                  </a>
                  <div class="psku"><?=esc($p['sku'] ?? '-')?></div>
                </div>
              </div>
            </td>
            <td style="color:#64748b;font-size:.82rem;font-family:monospace">
              <?=esc($p['sku'] ?? '-')?>
            </td>
            <td style="color:#64748b;font-size:.82rem">
              <?=esc($p['barcode'] ?? '-')?>
            </td>
            <td>
              <span class="badge bg-light text-dark border px-2 py-1" style="font-size:.78rem">
                <?=esc($p['category_name'] ?? '-')?>
              </span>
            </td>
            <td style="text-align:right">
              <span class="stock-badge <?=$p['stock'] < 10 ? 'stock-low' : ($p['stock'] < 50 ? 'stock-warn' : 'stock-ok')?>">
                <?=number_format($p['stock'] ?? 0, 0, ',', '.')?>
              </span>
            </td>
            <td style="text-align:right">
              <span class="price-display">Rp <?=number_format($p['sell_price'] ?? 0, 0, ',', '.')?></span>
            </td>
            <td>
              <?php if($p['is_active']): ?>
                <span class="badge bg-success bg-opacity-10 text-success border border-success bg-opacity-10" style="font-size:.75rem;font-weight:500">
                  <i class="fas fa-check-circle me-1"></i>Aktif
                </span>
              <?php else: ?>
                <span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary bg-opacity-10" style="font-size:.75rem;font-weight:500">
                  <i class="fas fa-pause-circle me-1"></i>Nonaktif
                </span>
              <?php endif; ?>
            </td>
            <td>
              <div class="btn-group btn-group-sm prod-actions">
                <a href="<?=site_url("products/show/$p[id]")?>" class="btn btn-outline-primary" title="Lihat">
                  <i class="fas fa-eye"></i>
                </a>
                <a href="<?=site_url("products/edit/$p[id]")?>" class="btn btn-outline-info" title="Edit">
                  <i class="fas fa-edit"></i>
                </a>
                <?php if(session()->get('level_code') === 'superadmin' || session()->get('level_code') === 'admin'): ?>
                <form action="<?=site_url("products/delete/$p[id]")?>" method="post" class="d-inline" onsubmit="return confirm('Hapus produk ini?')">
                  <button class="btn btn-outline-danger" title="Hapus">
                    <i class="fas fa-trash"></i>
                  </button>
                </form>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($totalRecords > $perPage): ?>
  <div class="d-flex justify-content-center py-3 border-top">
    <ul class="pagination pagination-custom mb-0">
      <?= $pager->links('products', 'default_full') ?>
    </ul>
  </div>
  <?php endif; ?>
</div>

<?= $this->endSection() ?>