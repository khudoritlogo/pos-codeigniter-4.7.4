<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<?php
$pageTitle = ($product ? 'Edit' : 'Tambah') . ' Barang';
$isEdit = !empty($product);
?>

<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <div><h1 class="h3 mb-0 text-gray-800"><?= esc($pageTitle) ?></h1></div>
    <a href="<?= site_url('products') ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Kembali</a>
</div>

<?php if (session('errors')): ?>
<div class="alert alert-danger alert-dismissible">
    <?= session('errors') ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<div class="card shadow">
    <div class="card-body">
        <form method="post" action="<?= $action ?? site_url('products/create') ?>" enctype="multipart/form-data" id="productForm">
            <?= csrf_field() ?>
            <?php if ($isEdit): ?><input type="hidden" name="_method" value="PUT"><?php endif; ?>

            <div class="row g-3">
                <!-- Barcode & SKU -->
                <div class="col-md-4">
                    <label class="form-label">Barcode</label>
                    <input class="form-control" name="barcode" value="<?= esc($product['barcode'] ?? '') ?>">
                    <small class="text-muted">Kosongkan jika ingin otomatis generate</small>
                </div>
                <div class="col-md-4">
                    <label class="form-label">SKU</label>
                    <input class="form-control" name="sku" value="<?= esc($product['sku'] ?? '') ?>">
                    <small class="text-muted">Kosongkan jika ingin otomatis generate</small>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Nama Produk *</label>
                    <input class="form-control" name="name" required value="<?= esc($product['name'] ?? '') ?>">
                </div>

                <!-- Kategori & Satuan Utama -->
                <div class="col-md-4">
                    <label class="form-label">Kategori</label>
                    <select name="category_id" class="form-select select2">
                        <option value="">-- Pilih --</option>
                        <?php foreach ($categories ?? [] as $c): ?>
                            <option value="<?= $c['id'] ?>" <?= ($product['category_id'] ?? 0) == $c['id'] ? 'selected' : '' ?>>
                                <?= esc($c['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Satuan Utama</label>
                    <select name="unit_id" class="form-select select2">
                        <option value="">-- Pilih --</option>
                        <?php foreach ($units ?? [] as $u): ?>
                            <option value="<?= $u['id'] ?>" <?= ($product['unit_id'] ?? 0) == $u['id'] ? 'selected' : '' ?>>
                                <?= esc($u['name']) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Merek / Brand</label>
                    <input class="form-control" name="brand" value="<?= esc($product['brand'] ?? '') ?>">
                </div>

                <!-- Harga -->
                <div class="col-md-4">
                    <label class="form-label">Harga Modal (Cost)</label>
                    <input type="number" step="0.01" min="0" class="form-control" name="cost_price"
                           value="<?= esc($product['cost_price'] ?? 0) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Harga Jual (Retail) *</label>
                    <input type="number" step="0.01" min="0" class="form-control" name="sell_price"
                           value="<?= esc($product['sell_price'] ?? 0) ?>" required>
                </div>
                <div class="col-md-4">
                    <label class="form-label">Harga Grosir</label>
                    <input type="number" step="0.01" min="0" class="form-control" name="wholesale_price"
                           value="<?= esc($product['wholesale_price'] ?? 0) ?>">
                </div>

                <div class="col-md-4">
                    <label class="form-label">Harga Member</label>
                    <input type="number" step="0.01" min="0" class="form-control" name="member_price"
                           value="<?= esc($product['member_price'] ?? 0) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Min. Qty Grosir</label>
                    <input type="number" min="0" class="form-control" name="min_wholesale_qty"
                           value="<?= esc($product['min_wholesale_qty'] ?? 0) ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label">Stok Minimum (Alert)</label>
                    <input type="number" min="0" class="form-control" name="min_stock"
                           value="<?= esc($product['min_stock'] ?? 0) ?>">
                </div>

                <!-- Pajak & Fitur -->
                <div class="col-md-4">
                    <label class="form-label">PPN (%)</label>
                    <input type="number" min="0" max="100" class="form-control" name="ppn"
                           value="<?= esc($product['ppn'] ?? 0) ?>">
                </div>
                <div class="col-md-3 form-check ms-3 mt-4">
                    <input class="form-check-input" type="checkbox" name="has_serial_number" value="1"
                           <?= !empty($product['has_serial_number']) ? 'checked' : '' ?>>
                    <label class="form-check-label">Produk dengan Serial Number</label>
                </div>
                <div class="col-md-3 form-check mt-4">
                    <input class="form-check-input" type="checkbox" name="has_expired_date" value="1"
                           <?= !empty($product['has_expired_date']) ? 'checked' : '' ?>>
                    <label class="form-check-label">Memiliki Tanggal Kedaluwarsa (FEFO)</label>
                </div>
                <div class="col-md-3 form-check mt-4">
                    <input class="form-check-input" type="checkbox" name="is_active" value="1"
                           <?= ($product['is_active'] ?? 1) ? 'checked' : '' ?>>
                    <label class="form-check-label">Aktif</label>
                </div>

                <div class="col-md-12">
                    <label class="form-label">Deskripsi</label>
                    <textarea class="form-control" name="description" rows="2"><?= esc($product['description'] ?? '') ?></textarea>
                </div>
            </div>

            <!-- --- MULTI SATUAN --- -->
            <hr>
            <h5 class="mb-3"><i class="fas fa-ruler-combined text-primary"></i> Multi Satuan & Harga per Satuan</h5>
            <div id="unitsContainer">
                <?php
                $productUnits = $productUnits ?? [];
                if (empty($productUnits) && !$isEdit):
                    // Default: satu satuan kosong
                    $productUnits = [['unit_id' => '', 'conversion_factor' => 1, 'is_primary' => 1, 'price' => '']];
                endif;
                foreach ($productUnits as $ui => $pu): ?>
                <div class="row g-2 unit-row mb-2 p-2 bg-light rounded">
                    <div class="col-md-3">
                        <select name="product_units[<?= $ui ?>][unit_id]" class="form-select select2" required>
                            <option value="">-- Satuan --</option>
                            <?php foreach ($units ?? [] as $u): ?>
                                <option value="<?= $u['id'] ?>"
                                    <?= ($pu['unit_id'] ?? '') == $u['id'] ? 'selected' : '' ?>>
                                    <?= esc($u['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Faktor</label>
                        <input type="number" step="0.0001" min="0.0001" class="form-control"
                               name="product_units[<?= $ui ?>][conversion_factor]"
                               value="<?= esc($pu['conversion_factor'] ?? 1) ?>">
                        <small class="text-muted">1 <?= esc(current(array_column($units ?? [], 'name', 'id') ?: [''])[0] ?? 'satuan') ?> = X satuan utama</small>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Harga</label>
                        <input type="number" step="0.01" min="0" class="form-control"
                               name="product_units[<?= $ui ?>][price]"
                               value="<?= esc($pu['price'] ?? '') ?>">
                    </div>
                    <div class="col-md-2 form-check ms-2 mt-4">
                        <input class="form-check-input" type="checkbox" name="product_units[<?= $ui ?>][is_primary]" value="1"
                               <?= !empty($pu['is_primary']) ? 'checked' : '' ?>>
                        <label class="form-check-label small">Satuan utama</label>
                    </div>
                    <div class="col-md-3 text-end">
                        <button type="button" class="btn btn-sm btn-outline-danger btn-remove-unit">
                            <i class="fas fa-times"></i> Hapus
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="btn btn-outline-secondary btn-sm mt-2" id="btnAddUnit">
                <i class="fas fa-plus"></i> + Tambah Satuan
            </button>

            <!-- --- MULTI HARGA (TIERED) --- -->
            <hr>
            <h5 class="mb-3"><i class="fas fa-layer-group text-warning"></i> Multi Harga Bertingkat (Tiered Pricing)</h5>
            <p class="small text-muted mb-3">Harga otomatis berdasarkan jumlah pembelian. Server akan menghitung ulang harga — tidak percaya frontend.</p>
            <div id="tiersContainer">
                <?php
                $priceTiers = $priceTiers ?? [];
                if (empty($priceTiers) && !$isEdit):
                    $priceTiers = [['min_qty' => '', 'price' => '']];
                endif;
                foreach ($priceTiers as $ti => $tier): ?>
                <div class="row g-2 tier-row mb-2 p-2 bg-light rounded">
                    <div class="col-md-3">
                        <label class="form-label">Min. Qty</label>
                        <input type="number" min="1" class="form-control"
                               name="price_tiers[<?= $ti ?>][min_qty]"
                               value="<?= esc($tier['min_qty'] ?? '') ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Harga</label>
                        <input type="number" step="0.01" min="0" class="form-control"
                               name="price_tiers[<?= $ti ?>][price]"
                               value="<?= esc($tier['price'] ?? '') ?>">
                    </div>
                    <div class="col-md-6 text-end">
                        <button type="button" class="btn btn-sm btn-outline-danger btn-remove-tier">
                            <i class="fas fa-times"></i> Hapus
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="btn btn-outline-secondary btn-sm mt-2" id="btnAddTier">
                <i class="fas fa-plus"></i> + Tambah Level Harga
            </button>

            <!-- --- FOTO --- -->
            <hr>
            <h5 class="mb-3">Foto Produk</h5>
            <div class="row g-3">
                <div class="col-md-4">
                    <label class="form-label">Gambar</label>
                    <input type="file" class="form-control" name="image" accept="image/*">
                </div>
                <div class="col-md-4">
                    <?php if (!empty($product['image'])): ?>
                        <img src="<?= base_url('uploads/products/' . esc($product['image'])) ?>"
                             class="img-thumbnail" style="max-height:120px"
                             onerror="this.style.display='none'">
                    <?php endif; ?>
                </div>
            </div>

            <hr class="my-4">
            <div class="d-flex justify-content-end gap-2">
                <a href="<?= site_url('products') ?>" class="btn btn-secondary">Batal</a>
                <button class="btn btn-primary" type="submit">
                    <i class="fas fa-save"></i> <?= $isEdit ? 'Perbarui' : 'Simpan' ?>
                </button>
            </div>
        </form>
    </div>
</div>

<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
// Tambah satuan baru
$('#btnAddUnit').on('click', function() {
    const idx = $('#unitsContainer .unit-row').length;
    const html = `
        <div class="row g-2 unit-row mb-2 p-2 bg-light rounded">
            <div class="col-md-3">
                <select name="product_units[${idx}][unit_id]" class="form-select select2" required>
                    <option value="">-- Satuan --</option>
                    ${unitsOptions}
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Faktor</label>
                <input type="number" step="0.0001" min="0.0001" class="form-control"
                       name="product_units[${idx}][conversion_factor]" value="1">
            </div>
            <div class="col-md-2">
                <label class="form-label">Harga</label>
                <input type="number" step="0.01" min="0" class="form-control"
                       name="product_units[${idx}][price]">
            </div>
            <div class="col-md-2 form-check ms-2 mt-4">
                <input class="form-check-input" type="checkbox" name="product_units[${idx}][is_primary]" value="1">
                <label class="form-check-label small">Satuan utama</label>
            </div>
            <div class="col-md-3 text-end">
                <button type="button" class="btn btn-sm btn-outline-danger btn-remove-unit"><i class="fas fa-times"></i> Hapus</button>
            </div>
        </div>`;
    $('#unitsContainer').append(html);
    // Inisialisasi select2
    $(`.unit-row:last .select2`).remove();
    $(`.unit-row:last select`).select2({theme:'bootstrap-5', width:'100%'});
});

// Tambah tiered price
$('#btnAddTier').on('click', function() {
    const idx = $('#tiersContainer .tier-row').length;
    const html = `
        <div class="row g-2 tier-row mb-2 p-2 bg-light rounded">
            <div class="col-md-3">
                <label class="form-label">Min. Qty</label>
                <input type="number" min="1" class="form-control"
                       name="price_tiers[${idx}][min_qty]">
            </div>
            <div class="col-md-3">
                <label class="form-label">Harga</label>
                <input type="number" step="0.01" min="0" class="form-control"
                       name="price_tiers[${idx}][price]">
            </div>
            <div class="col-md-6 text-end">
                <button type="button" class="btn btn-sm btn-outline-danger btn-remove-tier"><i class="fas fa-times"></i> Hapus</button>
            </div>
        </div>`;
    $('#tiersContainer').append(html);
});

// Hapus satuan
$(document).on('click', '.btn-remove-unit', function() {
    const row = $(this).closest('.unit-row');
    if (row.siblings('.unit-row').length === 0) {
        // Ganti dengan row kosong
        row.html(`<div class="col-md-12 text-muted py-2">Satuan kosong</div>`);
        row.find('select, input').remove();
    } else {
        row.remove();
    }
});

// Hapus tier
$(document).on('click', '.btn-remove-tier', function() {
    const row = $(this).closest('.tier-row');
    if (row.siblings('.tier-row').length === 0) {
        row.html(`<div class="col-md-12 text-muted py-2">Tiered price kosong</div>`);
        row.find('input').remove();
    } else {
        row.remove();
    }
});

// Generate barcode/SKU otomatis
$('#btnGenerateCode').on('click', function() {
    fetch('<?= site_url("products/generate-code") ?>', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'act=' + ($('#actBarcode').prop('checked') ? 'barcode' : 'sku')
    }).then(r => r.json()).then(d => {
        if (d.code) {
            if ($('#actBarcode').prop('checked')) $('#barcode').val(d.code);
            else $('#sku').val(d.code);
            Swal.fire('OKE', 'Kode berhasil digenerate.', 'success');
        }
    });
});
</script>
<?= $this->endSection() ?>