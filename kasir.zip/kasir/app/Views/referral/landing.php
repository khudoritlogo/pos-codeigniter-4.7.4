<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8">
<title>Referral <?= esc($ref['referral_code']) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<style>
  body{background:linear-gradient(135deg,#8b5cf6,#ec4899);min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:system-ui;padding:20px;color:#fff}
  .card{max-width:420px;width:100%;background:#fff;color:#111;border-radius:20px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.3)}
</style></head><body>
<div class="card">
  <div style="background:linear-gradient(135deg,#8b5cf6,#ec4899);color:#fff;padding:28px;text-align:center">
    <div style="font-size:3rem">🎁</div>
    <h4 class="mb-0"><?= esc($store['store_name'] ?? 'Toko') ?></h4>
    <small class="opacity-75">Program Referral</small>
  </div>
  <div class="p-4">
    <p><b><?= esc($ref['name']) ?></b> mengundang Anda menjadi pelanggan!</p>
    <div class="alert alert-info">
      <b>Benefit Anda:</b><br>
      🎁 <b><?= (int)$config['points_referee'] ?> Poin</b> gratis saat transaksi pertama<br>
      💰 Min. belanja: Rp <?= number_format((float)$config['min_first_purchase'],0,',','.') ?><br>
      ⏰ Berlaku <?= (int)$config['expiry_days'] ?> hari
    </div>
    <form onsubmit="register(event)">
      <div class="mb-2"><label>Nama Anda</label><input required class="form-control" id="regName"></div>
      <div class="mb-2"><label>No. HP/WhatsApp</label><input required class="form-control" id="regPhone" placeholder="08xxx"></div>
      <button class="btn btn-primary w-100 btn-lg"><i class="fas fa-user-plus"></i> Daftar Sekarang</button>
      <div id="result" class="mt-3"></div>
    </form>
  </div>
</div>
<script>
async function register(e){ e.preventDefault();
  const r = await fetch('/ref/<?= esc($ref['referral_code']) ?>/register',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:'name='+encodeURIComponent(document.getElementById('regName').value)+'&phone='+encodeURIComponent(document.getElementById('regPhone').value)});
  const j = await r.json();
  document.getElementById('result').innerHTML = j.ok
    ? '<div class="alert alert-success">🎉 '+j.msg+'</div>'
    : '<div class="alert alert-danger">'+j.msg+'</div>';
}
</script>
</body></html>
