<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Referral Program'; ?>
<?= $this->section('content') ?>
<div class="row g-3">
  <div class="col-lg-5">
    <div class="card"><div class="card-header bg-primary text-white"><b><i class="fas fa-cog"></i> Konfigurasi Referral</b></div>
      <form method="post" action="/referrals/config"><?= csrf_field() ?>
        <div class="card-body">
          <div class="form-check form-switch mb-3"><input class="form-check-input" type="checkbox" name="is_active" value="1" <?= ($config['is_active']??1)?'checked':'' ?>><label class="form-check-label"><b>Program Aktif</b></label></div>
          <div class="mb-2"><label>Poin untuk yang Mengajak</label><input type="number" class="form-control" name="points_referrer" value="<?= esc($config['points_referrer']??100) ?>"></div>
          <div class="mb-2"><label>Poin untuk yang Diajak</label><input type="number" class="form-control" name="points_referee" value="<?= esc($config['points_referee']??50) ?>"></div>
          <div class="mb-2"><label>Min. Belanja Pertama (Rp)</label><input type="number" class="form-control" name="min_first_purchase" value="<?= esc($config['min_first_purchase']??50000) ?>"></div>
          <div class="mb-2"><label>Deadline Belanja Pertama (hari)</label><input type="number" class="form-control" name="expiry_days" value="<?= esc($config['expiry_days']??30) ?>"></div>
          <div class="mb-2"><label>Voucher Bonus (opsional)</label>
            <select class="form-select select2" name="voucher_referrer_id"><option value="">-- --</option>
              <?php foreach (model('VoucherModel')->findAll() as $v): ?><option value="<?=$v['id']?>" <?=($config['voucher_referrer_id']??0)==$v['id']?'selected':''?>><?=esc($v['code'])?> - <?=esc($v['name'])?></option><?php endforeach; ?>
            </select>
          </div>
          <button class="btn btn-primary w-100"><i class="fas fa-save"></i> Simpan</button>
        </div>
      </form>
    </div>
  </div>
  <div class="col-lg-7">
    <div class="card"><div class="card-header bg-warning"><b><i class="fas fa-trophy"></i> Top Referrers</b></div>
      <div class="card-body p-0"><table class="table table-sm mb-0">
        <thead><tr><th>Customer</th><th>Kode</th><th class="text-end">Total</th><th class="text-end">Sukses</th><th class="text-end">Poin Earned</th></tr></thead>
        <tbody>
          <?php foreach ($top as $t): ?>
          <tr><td><?= esc($t['name']) ?></td><td><span class="badge bg-primary"><?= esc($t['referral_code']) ?></span></td><td class="text-end"><?= (int)$t['total_referral'] ?></td><td class="text-end text-success"><?= (int)$t['success'] ?></td><td class="text-end"><?= (int)$t['points_earned'] ?></td></tr>
          <?php endforeach; ?>
          <?php if (empty($top)): ?><tr><td colspan="5" class="text-center text-muted py-3">Belum ada referral</td></tr><?php endif; ?>
        </tbody>
      </table></div>
    </div>
  </div>
</div>

<div class="card mt-3"><div class="card-header"><b>Riwayat Referral</b></div>
  <div class="card-body p-0"><table class="table datatable table-sm mb-0">
    <thead><tr><th>Tanggal</th><th>Pengajak</th><th>Kode</th><th>Diajak</th><th>Status</th><th>Invoice</th><th class="text-end">Poin Diberikan</th></tr></thead>
    <tbody>
      <?php foreach ($events as $e): ?>
      <tr>
        <td><small><?= date('d/m/Y', strtotime($e['created_at'])) ?></small></td>
        <td><?= esc($e['referrer_name']) ?></td>
        <td><span class="badge bg-primary"><?= esc($e['referral_code']) ?></span></td>
        <td><?= esc($e['referee_name']) ?></td>
        <td><span class="badge bg-<?= $e['status']==='rewarded'?'success':($e['status']==='expired'?'danger':'warning') ?>"><?= $e['status'] ?></span></td>
        <td><?= esc($e['invoice_no'] ?? '-') ?></td>
        <td class="text-end"><?= (int)$e['points_awarded_referrer'] ?> / <?= (int)$e['points_awarded_referee'] ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table></div>
</div>
<?= $this->endSection() ?>
