<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Data Penjualan'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <div class="mb-2 d-flex justify-content-between">
    <a href="<?= site_url('sales/pos') ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Transaksi Baru</a>
    <a href="<?= site_url('reports/sales') ?>" class="btn btn-outline-info"><i class="fas fa-chart-line"></i> Laporan</a>
  </div>
  <table class="table datatable table-striped">
    <thead><tr><th>Invoice</th><th>Tanggal</th><th>Customer</th><th>Kasir</th><th>Metode</th><th class="text-end">Total</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td><?= esc($r['invoice_no']) ?></td>
        <td><?= date('d/m/Y H:i',strtotime($r['sale_date'])) ?></td>
        <td><?= esc($r['customer_name'] ?? '-') ?></td>
        <td><?= esc($r['cashier_name'] ?? '-') ?></td>
        <td><span class="badge bg-secondary"><?= esc($r['payment_method']) ?></span></td>
        <td class="text-end">Rp <?= number_format((float)$r['total'],0,',','.') ?></td>
        <td><span class="badge bg-<?= $r['status']=='completed'?'success':($r['status']=='void'?'danger':'warning') ?>"><?= $r['status'] ?></span></td>
        <td class="text-end">
          <a class="btn btn-sm btn-outline-primary" href="<?= site_url('sales/invoice/' . $r['id']) ?>"><i class="fas fa-eye"></i></a>
          <a class="btn btn-sm btn-outline-secondary" target="_blank" href="<?= site_url('sales/receipt/' . $r['id']) ?>"><i class="fas fa-print"></i></a>
          <?php if (in_array($user['level_code'],['super_admin','admin'])): ?>
          <button class="btn btn-sm btn-outline-danger" onclick="voidSale(<?= $r['id'] ?>)"><i class="fas fa-ban"></i></button>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
function voidSale(id){
  Swal.fire({title:'Void Transaksi?',input:'text',inputLabel:'Alasan',showCancelButton:true}).then(x=>{
    if (!x.isConfirmed) return;
    fetch('<?= site_url('sales/void/') ?>'+id,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'reason='+encodeURIComponent(x.value)})
      .then(r=>r.json()).then(res=>{ Swal.fire(res.ok?'Berhasil':'Gagal', res.msg||'', res.ok?'success':'error').then(()=>location.reload()); });
  });
}
</script>
<?= $this->endSection() ?>
