<div style="font-family:Arial,sans-serif;color:#111;max-width:600px;margin:auto;padding:24px">
  <div style="text-align:center;padding:20px 0;border-bottom:3px solid #0d6efd">
    <h2 style="margin:0;color:#0d6efd"><?= esc($store['store_name'] ?? 'TOKO') ?></h2>
    <small style="color:#666"><?= esc($store['address'] ?? '') ?></small>
  </div>
  <p>Halo <b><?= esc($sale['customer_name'] ?? 'Pelanggan') ?></b>,</p>
  <p>Terima kasih telah berbelanja di <?= esc($store['store_name'] ?? 'toko kami') ?>. Berikut adalah invoice pembelian Anda:</p>

  <table style="width:100%;background:#f8fafc;padding:16px;border-radius:8px;margin:16px 0">
    <tr><td><b>No. Invoice</b></td><td style="text-align:right"><?= esc($sale['invoice_no']) ?></td></tr>
    <tr><td><b>Tanggal</b></td><td style="text-align:right"><?= date('d M Y H:i', strtotime($sale['sale_date'])) ?></td></tr>
    <tr><td><b>Total</b></td><td style="text-align:right;font-size:1.4rem;color:#0d6efd"><b>Rp <?= number_format((float)$sale['total'],0,',','.') ?></b></td></tr>
    <tr><td><b>Status</b></td><td style="text-align:right"><span style="background:#22c55e;color:#fff;padding:4px 10px;border-radius:4px"><?= strtoupper($sale['status']) ?></span></td></tr>
  </table>

  <p>File PDF invoice lengkap terlampir. Simpan sebagai bukti transaksi Anda.</p>
  <p style="color:#666;font-size:0.9rem;margin-top:24px">Email ini dikirim otomatis dari sistem POS Kasir. Jika ada pertanyaan silakan hubungi kami di <?= esc($store['phone'] ?? '-') ?>.</p>
</div>
