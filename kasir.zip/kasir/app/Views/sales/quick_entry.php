<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Entri Penjualan Cepat'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-header d-flex justify-content-between align-items-center">
  <b><i class="fas fa-bolt me-1"></i> Entri Penjualan Cepat</b>
  <button class="btn btn-success btn-sm" onclick="alert('Fitur quick entry akan segera tersedia.');"><i class="fas fa-plus"></i> Transaksi Baru</button>
</div>
<div class="card-body">
  <div class="row g-3">
    <div class="col-lg-6">
      <div class="card bg-light mb-3"><div class="card-header"><b><i class="fas fa-box me-1"></i> Produk (<?= count($products) ?>)</b></div>
        <div class="card-body p-0">
          <div class="list-group list-group-flush">
          <?php foreach (array_slice($products, 0, 30) as $p): ?>
          <a href="#" class="list-group-item list-group-item-action py-2" onclick="alert('Produk: <?= addslashes($p['name']) ?>')">
            <div class="d-flex w-100 justify-content-between"><b><?= esc($p['name']) ?></b></div>
            <small class="text-muted"><?= esc($p['sku']) ?> · <?= esc($p['category_name'] ?? '-') ?> · Rp <?= number_format((float)$p['sell_price'],0,',','.') ?></small>
          </a>
          <?php endforeach; ?>
          </div>
          <?php if (count($products) > 30): ?>
          <div class="text-center py-2 text-muted small">+ <?= count($products) - 30 ?> produk lainnya (lihat di halaman produk)</div>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <div class="col-lg-6">
      <div class="card bg-light mb-3"><div class="card-header"><b><i class="fas fa-users me-1"></i> Customer (<?= count($customers) ?>)</b></div>
        <div class="card-body p-0">
          <div class="list-group list-group-flush">
          <?php foreach (array_slice($customers, 0, 10) as $c): ?>
          <a href="#" class="list-group-item list-group-item-action py-2" onclick="alert('Customer: <?= addslashes($c['name']) ?>')">
            <?= esc($c['name']) ?>
            <?php if (!empty($c['phone'])): ?><small class="text-muted d-block"><?= esc($c['phone']) ?></small><?php endif; ?>
          </a>
          <?php endforeach; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="text-center mt-3 text-muted">
    <i class="fas fa-info-circle me-1"></i> Untuk transaksi lengkap, gunakan halaman <a href="<?= site_url('sales/pos') ?>">POS</a>.
  </div>
</div></div>
<?= $this->endSection() ?>
