<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Daftar Struk'; ?>
<?= $this->section('content') ?>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="card"><div class="card-header"><b><i class="fas fa-receipt me-1"></i> Ringkasan</b></div>
      <div class="card-body">
        <div class="mb-2"><b>Total Struk:</b> <?= number_format((int)$total_count, 0) ?></div>
        <div class="mb-0"><b>Total Pendapatan:</b>
          <span class="text-primary"><?= number_format((float)$total_amount, 0, ',', '.') ?></span>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="card"><div class="card-header d-flex justify-content-between align-items-center"><b><i class="fas fa-list me-1"></i> Struk Penjualan</b></div>
      <div class="card-body p-0">
        <?php if (empty($receipts)): ?>
          <div class="text-center py-4 text-muted"><i class="fas fa-receipt fa-2x mb-2"></i><p class="mb-0">Belum ada struk penjualan.</p></div>
        <?php else: ?>
        <table class="table table-sm table-striped mb-0">
          <thead><tr><th>Tanggal</th><th>Invoice</th><th>Customer</th><th>Kasir</th><th class="text-end">Total</th></tr></thead>
          <tbody>
          <?php foreach ($receipts as $r): ?>
          <tr>
            <td><small><?= date('d/m/Y H:i', strtotime($r['sale_date'])) ?></small></td>
            <td><a href="<?= site_url('sales/invoice/' . $r['id']) ?>" class="text-decoration-none"><?= esc($r['invoice_no']) ?></a></td>
            <td><?= esc($r['customer_name'] ?? 'Umum') ?></td>
            <td><?= esc($r['cashier_name'] ?? '-') ?></td>
            <td class="text-end"><?= number_format((float)$r['total'], 0, ',', '.') ?></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
