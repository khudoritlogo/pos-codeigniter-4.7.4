<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Transaksi Pending'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <h4 class="mb-3"><i class="fas fa-hourglass-half me-1"></i> Transaksi Pending</h4>
  <?php if (empty($rows)): ?>
    <div class="text-center py-4 text-muted"><i class="fas fa-check-circle fa-2x mb-2"></i><p class="mb-0">Tidak ada transaksi pending.</p></div>
  <?php else: ?>
  <table class="table datatable table-striped">
    <thead><tr><th>Invoice</th><th>Tanggal</th><th>Customer</th><th class="text-end">Total</th><th>Status</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
    <tr>
      <td><?= esc($r['invoice_no']) ?></td>
      <td><?= date('d/m/Y H:i',strtotime($r['sale_date'])) ?></td>
      <td><?= esc($r['customer_name'] ?? 'Umum') ?></td>
      <td class="text-end"><?= number_format((float)$r['total'],0,',','.') ?></td>
      <td><span class="badge bg-warning">Pending</span></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</div></div>
<?= $this->endSection() ?>
