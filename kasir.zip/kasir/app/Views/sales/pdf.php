<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>Invoice <?= esc($sale['invoice_no']) ?></title>
<style>
  body{font-family:DejaVu Sans, sans-serif;font-size:11px;color:#111;margin:0}
  .header{border-bottom:2px solid #111;padding-bottom:8px;margin-bottom:16px}
  .header table{width:100%}
  h2{margin:0} .muted{color:#666}
  table.items{width:100%;border-collapse:collapse;margin-top:10px}
  table.items th{background:#f1f5f9;border:1px solid #cbd5e1;padding:6px;text-align:left}
  table.items td{border:1px solid #cbd5e1;padding:6px}
  .right{text-align:right}
  .totals{width:280px;margin-left:auto;margin-top:12px}
  .totals td{padding:4px 8px}
  .totals .grand{background:#0f172a;color:#fff;font-weight:700;font-size:14px}
  .footer{margin-top:30px;padding-top:10px;border-top:1px dashed #999;color:#666}
</style></head><body>

<div class="header">
  <table><tr>
    <td>
      <h2><?= esc($store['store_name'] ?? 'TOKO') ?></h2>
      <div class="muted"><?= esc($store['address'] ?? '') ?></div>
      <div class="muted">Telp: <?= esc($store['phone'] ?? '-') ?><?= !empty($store['email']) ? ' • '.esc($store['email']) : '' ?></div>
    </td>
    <td class="right">
      <h2 style="color:#0f172a">INVOICE</h2>
      <div><b><?= esc($sale['invoice_no']) ?></b></div>
      <div class="muted"><?= date('d M Y H:i', strtotime($sale['sale_date'])) ?></div>
    </td>
  </tr></table>
</div>

<table style="width:100%;margin-bottom:14px">
  <tr>
    <td>
      <b>Kepada:</b><br>
      <?= esc($sale['customer_name'] ?? 'Umum') ?><br>
      <span class="muted">Kasir: <?= esc($sale['cashier_name']) ?></span>
    </td>
    <td class="right">
      <b>Metode Bayar:</b> <?= strtoupper($sale['payment_method']) ?><br>
      <b>Status:</b> <?= strtoupper($sale['status']) ?>
    </td>
  </tr>
</table>

<table class="items">
  <thead><tr><th>#</th><th>Produk</th><th>SKU</th><th class="right">Qty</th><th class="right">Harga</th><th class="right">Subtotal</th></tr></thead>
  <tbody>
    <?php foreach ($items as $i => $it): ?>
    <tr>
      <td><?= $i+1 ?></td>
      <td><?= esc($it['product_name']) ?><?= $it['serial_number'] ? '<br><small class="muted">SN: '.esc($it['serial_number']).'</small>':'' ?></td>
      <td><?= esc($it['sku']) ?></td>
      <td class="right"><?= (float) $it['qty'] ?></td>
      <td class="right">Rp <?= number_format((float)$it['price'],0,',','.') ?></td>
      <td class="right">Rp <?= number_format((float)$it['subtotal'],0,',','.') ?></td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<table class="totals">
  <tr><td>Subtotal</td><td class="right">Rp <?= number_format((float)$sale['subtotal'],0,',','.') ?></td></tr>
  <?php if ((float)$sale['discount_amount']>0): ?><tr><td>Diskon</td><td class="right">- Rp <?= number_format((float)$sale['discount_amount'],0,',','.') ?></td></tr><?php endif; ?>
  <?php if ((float)$sale['tax_amount']>0): ?><tr><td>Pajak</td><td class="right">Rp <?= number_format((float)$sale['tax_amount'],0,',','.') ?></td></tr><?php endif; ?>
  <?php if ((float)$sale['shipping_cost']>0): ?><tr><td>Ongkir</td><td class="right">Rp <?= number_format((float)$sale['shipping_cost'],0,',','.') ?></td></tr><?php endif; ?>
  <tr class="grand"><td>TOTAL</td><td class="right">Rp <?= number_format((float)$sale['total'],0,',','.') ?></td></tr>
  <tr><td>Bayar</td><td class="right">Rp <?= number_format((float)$sale['paid'],0,',','.') ?></td></tr>
  <tr><td>Kembali</td><td class="right">Rp <?= number_format((float)$sale['change_amount'],0,',','.') ?></td></tr>
  <?php if ((float)$sale['debt_amount']>0): ?><tr><td><b>Piutang</b></td><td class="right"><b>Rp <?= number_format((float)$sale['debt_amount'],0,',','.') ?></b></td></tr><?php endif; ?>
</table>

<div class="footer">
  <?= nl2br(esc($store['receipt_footer'] ?? 'Terima kasih atas kepercayaan Anda.')) ?>
</div>

</body></html>
