<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<?php
$branchId = session()->get('branch_id') ?: 1;
$invoiceNo = sprintf('INV/%s/%s/%s',
    date('Y'),
    str_pad($branchId, 2, '0', STR_PAD_LEFT),
    str_pad(rand(1000, 9999), 4, '0', STR_PAD_LEFT)
);
?>

<style>
  .pos-layout {
    display:grid;
    grid-template-columns:1fr 380px;
    gap:1rem;
    height:calc(100vh - 200px);
    align-items:start;
  }
  @media (max-width:991px){
    .pos-layout{grid-template-columns:1fr;height:auto}
    .pos-cart{order:1}
    .pos-products{order:2}
  }
  .pos-products, .pos-cart {
    overflow-y:auto;
    border:1px solid #e2e8f0;
    border-radius:1rem;
    background:#fff;
    box-shadow: 0 1px 3px rgba(0,0,0,.04);
  }
  .pos-products .card-header-custom, .pos-cart .card-header-custom {
    padding: .75rem 1rem;
    border-bottom:1px solid #f1f5f9;
    background:#fafafa;
  }
  .product-card {
    cursor:pointer;
    border:1px solid #e2e8f0;
    border-radius:.65rem;
    padding:.65rem;
    transition:.15s;
    display:flex;
    gap:.65rem;
    align-items:center;
    margin-bottom:.4rem;
    background:#fff;
  }
  .product-card:hover {
    background:#f8fafc;
    border-color:#cbd5e1;
    transform:translateY(-1px);
    box-shadow:0 4px 12px rgba(0,0,0,.06);
  }
  .product-card.selected {
    border-color:#2563eb;
    background:#eff6ff;
    box-shadow:0 0 0 2px rgba(37,99,235,.15);
  }
  .product-card .thumb {
    width:52px;
    height:52px;
    border-radius:8px;
    object-fit:cover;
    background:#f1f5f9;
    flex-shrink:0;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:1.25rem;
  }
  .product-card .prod-info {
    flex:1;
    min-width:0;
  }
  .product-card .prod-name {
    font-size:.875rem;
    font-weight:600;
    color:#1e293b;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
    margin-bottom:2px;
  }
  .product-card .prod-sku {
    font-size:.7rem;
    color:#94a3b8;
    margin-bottom:2px;
  }
  .product-card .prod-price {
    font-size:.9rem;
    font-weight:700;
    color:#0d6efd;
  }
  .cart-item {
    display:flex;
    align-items:center;
    gap:.5rem;
    padding:.5rem .5rem;
    border-bottom:1px dashed #e2e8f0;
    background:#fff;
    transition:background .1s;
  }
  .cart-item:hover {
    background:#f8fafc;
  }
  .cart-item .remove-btn {
    color:#dc3545;
    cursor:pointer;
    padding:.2rem .4rem;
    border-radius:4px;
    font-size:.85rem;
  }
  .cart-item .remove-btn:hover {
    background:#fef2f2;
    color:#b91c1c;
  }
  .cart-item .item-info {
    flex:1;
    min-width:0;
  }
  .cart-item .item-name {
    font-size:.85rem;
    font-weight:600;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
  }
  .cart-item .item-qty {
    font-size:.75rem;
    color:#64748b;
  }
  .cart-item .item-price {
    font-weight:700;
    color:#1e293b;
    font-size:.9rem;
  }
  .price-display {
    font-size:.95rem;
  }
  .price-display .total {
    font-size:1.35rem;
    font-weight:800;
    color:#1565C0;
    letter-spacing:.3px;
  }
  .price-display .total-bg {
    background:linear-gradient(135deg,#2563eb,#7c3aed);
    -webkit-background-clip:text;
    -webkit-text-fill-color:transparent;
    background-clip:text;
  }
  .pos-btn {
    border-radius:.65rem;
    font-weight:600;
    padding:.55rem .85rem;
    transition:.15s;
  }
  .pos-btn-primary {
    background:linear-gradient(135deg,#2563eb,#1d4ed8);
    border:none;
    color:#fff;
  }
  .pos-btn-primary:hover {
    transform:translateY(-1px);
    box-shadow:0 4px 12px rgba(37,99,235,.35);
    color:#fff;
  }
  .pos-btn-success {
    background:linear-gradient(135deg,#059669,#047857);
    border:none;
    color:#fff;
  }
  .pos-btn-success:hover {
    transform:translateY(-1px);
    box-shadow:0 4px 12px rgba(5,150,105,.35);
    color:#fff;
  }
  .search-highlight {
    background:#fef08a;
    padding:0 2px;
    border-radius:2px;
  }
</style>

<!-- Header POS -->
<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
  <div>
    <h3 class="h4 mb-0 fw-bold text-primary">
      <i class="fas fa-cash-register me-2"></i>POS — <?= esc($shift && isset($shift['branch_name']) ? $shift['branch_name'] : esc($branch_name ?? 'Cabang')) ?>
    </h3>
    <small class="text-muted">
      Kasir: <?= esc(session()->get('fullname') ?? session()->get('username')) ?>
      · Shift: <?= $shift ? date('d/m/Y H:i', strtotime($shift['start_time'] ?? $shift['opened_at'] ?? time())) : 'Belum buka shift' ?>
    </small>
  </div>
  <div class="d-flex gap-2 align-items-center">
    <button class="btn pos-btn btn-outline-secondary btn-sm" onclick="newInvoice()">
      <i class="fas fa-redo me-1"></i>Reset
    </button>
    <button class="btn pos-btn btn-outline-primary btn-sm" onclick="window.print()">
      <i class="fas fa-print me-1"></i>Cetak
    </button>
    <button class="btn pos-btn pos-btn-success btn-sm" id="btnPay" onclick="doPayment()">
      <i class="fas fa-check-circle me-1"></i>Bayar
    </button>
  </div>
</div>

<!-- Layout Utama: Produk (kiri) + Keranjang (kanan) -->
<div class="pos-layout">
  <!-- KIRI: Pencarian + Grid Produk -->
  <div class="pos-products">
    <div class="card-header-custom d-flex gap-2 align-items-center flex-wrap">
      <div class="input-group" style="flex:1;min-width:200px">
        <span class="input-group-text bg-white border-end-0" style="border-radius:.5rem 0 0 .5rem">
          <i class="fas fa-search text-muted"></i>
        </span>
        <input type="text" id="productSearch" class="form-control border-start-0" style="border-radius:0 .5rem .5rem 0"
               placeholder="Cari: nama, SKU, barcode..." autofocus autocomplete="off">
      </div>
      <select id="unitFilter" class="form-select" style="width:130px">
        <option value="">Semua satuan</option>
      </select>
      <span id="searchCount" class="text-muted small"></span>
    </div>
    <div id="productsGrid" class="p-2">
      <div class="text-center text-muted py-5">
        <i class="fas fa-spinner fa-spin fa-2x"></i>
        <p class="mt-2 mb-0">Memuat produk...</p>
      </div>
    </div>
  </div>

  <!-- KANAN: Keranjang + Pembayaran -->
  <div class="pos-cart">
    <div class="card-header-custom d-flex justify-content-between align-items-center">
      <h5 class="mb-0 fw-semibold">
        <i class="fas fa-shopping-cart text-primary me-2"></i>Keranjang
      </h5>
      <small id="itemCount" class="text-muted px-2 py-1 rounded bg-light">0 item</small>
    </div>

    <div id="cartItems" class="p-2" style="max-height:320px;overflow-y:auto">
      <div class="text-center text-muted py-4">
        <i class="fas fa-box-open fa-2x opacity-50"></i>
        <p class="mt-2 mb-0 fw-medium">Keranjang kosong</p>
        <small class="text-muted">Pilih produk dari daftar</small>
      </div>
    </div>

    <div class="px-2 pb-2">
      <div class="price-display mb-2 p-2 bg-light rounded">
        <div class="d-flex justify-content-between mb-1">
          <span class="text-muted">Subtotal</span>
          <span>Rp 0</span>
        </div>
        <div class="d-flex justify-content-between mb-1">
          <span class="text-muted">Diskon</span>
          <span class="text-danger">- Rp 0</span>
        </div>
        <div class="d-flex justify-content-between mb-1">
          <span class="text-muted">Pajak</span>
          <span>Rp 0</span>
        </div>
        <hr class="my-1">
        <div class="d-flex justify-content-between total">
          <span class="total-bg fw-bold">TOTAL</span>
          <span class="total fw-bold text-primary" id="totalPrice">Rp 0</span>
        </div>
      </div>

      <div class="input-group mb-2">
        <span class="input-group-text bg-white"><i class="fas fa-money-bill-wave text-muted"></i></span>
        <input type="number" id="paidInput" class="form-control" placeholder="Jumlah bayar" min="0" step="1"
               style="font-size:1rem;font-weight:600">
      </div>
      <div class="d-flex justify-content-between small text-muted mb-2">
        <span class="fw-medium text-dark">Kembalian:</span>
        <strong id="changeDisplay" class="text-success fw-semibold">Rp 0</strong>
      </div>
    </div>

    <div class="px-2 py-2 border-top bg-gradient-to-r from-blue-50 to-purple-50 rounded-bottom">
      <small class="text-muted d-flex align-items-center gap-1">
        <i class="fas fa-keyboard text-primary"></i>
        Tekan <kbd class="bg-white border px-1 rounded small">Enter</kbd> atau scan barcode untuk tambah produk
      </small>
    </div>
  </div>
</div>

<!-- Modal Konfirmasi Pembayaran -->
<div class="modal fade" id="paymentModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content border-0 shadow-sm">
      <div class="modal-header bg-primary bg-opacity-10 border-0 pb-0">
        <h5 class="modal-title fw-semibold text-dark">
          <i class="fas fa-receipt text-primary me-2"></i>Konfirmasi Pembayaran
        </h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body p-3">
        <div class="d-flex justify-content-between mb-2">
          <span class="text-muted">Invoice</span>
          <strong class="text-primary"><?= esc($invoiceNo) ?></strong>
        </div>
        <div class="d-flex justify-content-between mb-2">
          <span class="text-muted">Total Tagihan</span>
          <strong id="modalTotal" class="text-dark">Rp 0</strong>
        </div>
        <div class="input-group mb-3">
          <span class="input-group-text bg-white">Rp</span>
          <input type="number" id="modalPaid" class="form-control" style="font-weight:600;font-size:1rem"
                 placeholder="Jumlah bayar" min="0" step="1">
        </div>
        <div class="d-flex justify-content-between bg-light p-2 rounded mb-3">
          <span class="text-muted">Kembalian</span>
          <strong id="modalChange" class="text-success fw-bold">Rp 0</strong>
        </div>
        <div class="d-flex gap-2 flex-wrap">
          <button type="button" class="pos-btn pos-btn-success flex-fill" id="btnQRIS" onclick="openQRIS()">
            <i class="fas fa-qrcode me-2"></i>Bayar QRIS
          </button>
          <button type="button" class="btn btn-sm pos-btn pos-btn-success flex-fill" id="btnConfirmPay">
            <i class="fas fa-check me-2"></i>Konfirmasi Tunai
          </button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal Hasil Transaksi -->
<div class="modal fade" id="resultModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered modal-sm">
    <div class="modal-content text-center border-0 shadow-sm">
      <div class="modal-body p-4">
        <div class="mb-3">
          <i class="fas fa-check-circle fa-3x text-success"></i>
        </div>
        <h5 class="fw-bold mb-1">Transaksi Berhasil!</h5>
        <p class="text-muted small mb-3">
          Invoice: <strong id="resultInvoice" class="text-primary"></strong>
        </p>
        <div class="bg-light rounded p-2 mb-3">
          <div class="d-flex justify-content-between text-muted small">
            <span>Total</span>
            <strong id="resultTotal" class="text-dark"></strong>
          </div>
          <div class="d-flex justify-content-between text-muted small">
            <span>Bayar</span>
            <strong id="resultPaid" class="text-dark"></strong>
          </div>
          <div class="d-flex justify-content-between text-muted small mt-1">
            <span>Kembalian</span>
            <strong id="resultChange" class="text-success"></strong>
          </div>
        </div>
        <button class="btn pos-btn pos-btn-primary btn-sm" onclick="newInvoice(); $('#resultModal').modal('hide')">
          <i class="fas fa-plus me-1"></i>Transaksi Baru
        </button>
      </div>
    </div>
  </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
// State
let cart = [];
let products = [];
let selectedProduct = null;

// DOM refs
const $grid = document.getElementById('productsGrid');
const $cart = document.getElementById('cartItems');
const $search = document.getElementById('productSearch');
const $unitFilter = document.getElementById('unitFilter');
const $count = document.getElementById('searchCount');
const $itemCount = document.getElementById('itemCount');
const $subtotal = document.getElementById('subtotal');
const $discount = document.getElementById('discount');
const $tax = document.getElementById('tax');
const $total = document.getElementById('totalPrice');
const $paid = document.getElementById('paidInput');
const $change = document.getElementById('changeDisplay');
const $modalTotal = document.getElementById('modalTotal');
const $modalPaid = document.getElementById('modalPaid');
const $modalChange = document.getElementById('modalChange');

// Load products
async function loadProducts() {
  try {
    const r = await fetch('<?= site_url("api/pos/products") ?>');
    products = await r.json();
    renderProducts(products);
    populateUnitFilter();
  } catch(e) {
    $grid.innerHTML = `<div class="text-center text-danger py-4"><i class="fas fa-exclamation-triangle fa-2x"></i><p class="mt-2">Gagal memuat produk</p></div>`;
  }
}

function populateUnitFilter() {
  const units = [...new Set(products.map(p => p.unit_name).filter(Boolean))];
  $unitFilter.innerHTML = '<option value="">Semua satuan</option>' +
    units.map(u => `<option value="${u}">${u}</option>`).join('');
}

function renderProducts(list) {
  if (!list.length) {
    $grid.innerHTML = `<div class="text-center text-muted py-4"><i class="fas fa-box-open fa-2x opacity-50"></i><p class="mt-2 mb-0">Tidak ada produk</p></div>`;
    return;
  }
  $grid.innerHTML = list.map(p => `
    <div class="product-card ${selectedProduct?.id === p.id ? 'selected' : ''}"
         data-id="${p.id}" data-name="${escJs(p.name)}" data-price="${p.harga_jual || p.price || 0}"
         data-sku="${escJs(p.sku || '')}" data-barcode="${escJs(p.barcode || '')}"
         onclick="addToCart(${p.id})">
      <div class="thumb">
        ${p.foto ? `<img src="${escJs(p.foto)}" style="width:100%;height:100%;object-fit:cover;border-radius:8px" alt="" onerror="this.style.display='none';this.innerHTML='<i class=\\'fas fa-box\\'\\'style=\\'font-size:1.25rem;color:#94a3b8\\'\\'></i>'">` : '<i class="fas fa-box text-muted" style="font-size:1.25rem"></i>'}
      </div>
      <div class="prod-info">
        <div class="prod-name">${escJs(p.name)}</div>
        <div class="prod-sku">${escJs((p.sku || p.kode || '') + (p.barcode ? ' · ' + escJs(p.barcode) : ''))}</div>
        <div class="prod-price">${rupiah(p.harga_jual || p.price || 0)}</div>
      </div>
    </div>
  `).join('');
  $count.textContent = `(${list.length} produk)`;
}

function escJs(s) {
  return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function rupiah(v) {
  if (!v || v === 0) return 'Rp 0';
  return new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',minimumFractionDigits:0}).format(v||0);
}

// Search
$search.addEventListener('input', () => {
  const q = $search.value.toLowerCase().trim();
  const unit = $unitFilter.value;
  const filtered = products.filter(p => {
    const matchName = !q || p.name.toLowerCase().includes(q);
    const matchSku = !q || (p.sku||'').toLowerCase().includes(q);
    const matchBarcode = !q || (p.barcode||'').toString().includes(q);
    const matchUnit = !unit || (p.unit_name||'') === unit;
    return (matchName || matchSku || matchBarcode) && matchUnit;
  });
  renderProducts(filtered);
});

$unitFilter.addEventListener('change', () => $search.dispatchEvent(new Event('input')));

// Cart
function addToCart(productId) {
  const p = products.find(x => x.id === productId);
  if (!p) return;
  const existing = cart.find(c => c.id === productId);
  if (existing) {
    existing.qty += 1;
  } else {
    cart.push({ id:p.id, name:p.name, price:p.harga_jual||p.price||0, qty:1, satuan:p.unit_name||'' });
  }
  selectedProduct = p;
  renderCart();
  renderProducts(products); // re-render untuk highlight
}

function removeFromCart(productId) {
  cart = cart.filter(c => c.id !== productId);
  selectedProduct = null;
  renderCart();
  renderProducts(products);
}

function updateQty(productId, delta) {
  const item = cart.find(c => c.id === productId);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) { removeFromCart(productId); return; }
  renderCart();
}

function renderCart() {
  if (!cart.length) {
    $cart.innerHTML = `<div class="text-center text-muted py-4">
      <i class="fas fa-box-open fa-2x opacity-50"></i>
      <p class="mt-2 mb-0 fw-medium">Keranjang kosong</p>
      <small class="text-muted">Pilih produk dari daftar</small>
    </div>`;
    $itemCount.textContent = '0 item';
  } else {
    $cart.innerHTML = cart.map(c => `
      <div class="cart-item">
        <i class="fas fa-times remove-btn" onclick="removeFromCart(${c.id})" title="Hapus"></i>
        <div class="item-info">
          <div class="item-name">${escJs(c.name)}</div>
          <div class="item-qty">qty: ${c.qty} ${c.satuan ? '· ' + escJs(c.satuan) : ''}</div>
        </div>
        <div class="item-price">${rupiah(c.price * c.qty)}</div>
      </div>
    `).join('');
    $itemCount.textContent = `${cart.length} item`;
  }
  updateTotals();
}

function updateTotals() {
  const sub = cart.reduce((sum, c) => sum + c.price * c.qty, 0);
  const disc = 0; // placeholder diskon
  const tax = 0; // placeholder pajak
  const total = sub - disc + tax;
  $subtotal.innerHTML = rupiah(sub);
  $discount.innerHTML = `- ${rupiah(disc)}`;
  $tax.innerHTML = rupiah(tax);
  $total.innerHTML = rupiah(total);
  
  const paid = parseFloat($paid.value) || 0;
  $change.textContent = paid >= total ? rupiah(paid - total) : rupiah(0);
  $change.style.color = paid >= total ? '#059669' : '#333';
}

$paid.addEventListener('input', updateTotals);

// Payment
function doPayment() {
  const total = parseFloat($total.textContent.replace(/[^0-9]/g,'')) || 0;
  if (total === 0) { swal2Warning('Keranjang kosong'); return; }
  $modalTotal.innerHTML = rupiah(total);
  $modalPaid.value = '';
  $modalChange.innerHTML = rupiah(0);
  $('#paymentModal').modal('show');
}

$modalPaid.addEventListener('input', () => {
  const total = parseFloat($modalTotal.textContent.replace(/[^0-9]/g,'')) || 0;
  const paid = parseFloat($modalPaid.value) || 0;
  $modalChange.innerHTML = paid >= total ? rupiah(paid - total) : rupiah(0);
});

document.getElementById('btnConfirmPay').addEventListener('click', async () => {
  const total = parseFloat($modalTotal.textContent.replace(/[^0-9]/g,'')) || 0;
  const paid = parseFloat($modalPaid.value) || 0;
  if (paid < total) { swal2Error('Jumlah bayar kurang'); return; }
  
  const data = {
    items: cart.map(c => ({ product_id:c.id, qty:c.qty, price:c.price })),
    total, paid, payment_method: 'cash',
    cashier_id: <?= session()->get('user_id') ?>,
    branch_id: <?= $branchId ?>,
  };
  
  try {
    const r = await fetch('<?= site_url("api/pos/transaction") ?>', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify(data),
    });
    const j = await r.json();
    if (j.ok) {
      $('#resultInvoice').textContent = j.invoice_no;
      $('#resultTotal').textContent = rupiah(j.total);
      $('#resultPaid').textContent = rupiah(j.paid);
      $('#resultChange').textContent = rupiah(j.paid - j.total);
      $('#resultModal').modal('show');
      cart = [];
      selectedProduct = null;
      renderCart();
      renderProducts(products);
      $paid.value = '';
      updateTotals();
    } else {
      swal2Error(j.message || 'Gagal');
    }
  } catch(e) {
    swal2Error('Koneksi error');
  }
});

function newInvoice() {
  cart = [];
  selectedProduct = null;
  renderCart();
  renderProducts(products);
  $paid.value = '';
  updateTotals();
}

// Keyboard shortcut
document.addEventListener('keydown', e => {
  if (e.key === 'Enter' && document.activeElement === $search) {
    e.preventDefault();
    const q = $search.value.trim();
    if (q) addByBarcodeOrSku(q);
  }
});

function addByBarcodeOrSku(q) {
  const p = products.find(x =>
    (x.barcode || '').toString() === q ||
    (x.sku || '').toLowerCase() === q.toLowerCase()
  );
  if (p) {
    addToCart(p.id);
    $search.value = '';
    renderProducts(products);
  } else {
    // Cari berdasarkan nama parsial
    const match = products.find(x => x.name.toLowerCase().includes(q.toLowerCase()));
    if (match) addToCart(match.id);
  }
}

// Init
loadProducts();

// ===== QRIS PAYMENT =====
let currentQRISOrderId = null;

async function openQRIS() {
  const total = parseFloat($total.textContent.replace(/[^0-9]/g,'')) || 0;
  if (total === 0) { swal2Warning('Keranjang kosong'); return; }

  // Tampilkan loading
  Swal.fire({
    icon: 'loading',
    title: 'Membuat QRIS...',
    text: 'Mohon tunggu sebentar...',
    allowOutsideClick: false,
  });

  try {
    const r = await fetch('<?= site_url("api/pos/transaction") ?>', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        items: cart.map(c => ({ product_id: c.id, qty: c.qty, price: c.price })),
        total, paid: 0, payment_method: 'qris',
        cashier_id: <?= session()->get('user_id') ?>,
        branch_id: <?= $branchId ?>,
      }),
    });
    const j = await r.json();
    if (!j.ok) { Swal.close(); swal2Error(j.message || 'Gagal buat transaksi'); return; }

    // Ambil order_id dari transaksi
    const txId = j.invoice_no || j.id;

    // Buat QRIS via API
    const qrResp = await fetch('<?= site_url("qris/create") ?>', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        sale_id: txId,
        amount: total.toString(),
        provider: 'midtrans',
      }),
    });
    const qrData = await qrResp.json();

    Swal.close();

    if (!qrData.ok) {
      swal2Error(qrData.msg || 'Gagal buat QRIS');
      return;
    }

    currentQRISOrderId = qrData.order_id;
    showQRISModal(qrData);
  } catch (e) {
    Swal.close();
    swal2Error('Koneksi error');
  }
}

function showQRISModal(qrData) {
  // Buat modal QRIS dinamis
  if (document.getElementById('qrisModal')) return;

  const modalHtml = `
    <div class="modal fade" id="qrisModal" data-bs-backdrop="static" tabindex="-1">
      <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content border-0 shadow-sm">
          <div class="modal-header bg-success bg-opacity-10 border-0 pb-0">
            <h5 class="modal-title fw-semibold text-dark">
              <i class="fas fa-qrcode text-success me-2"></i>Pembayaran QRIS
            </h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body p-3">
            <div class="text-center mb-3">
              <div class="badge bg-success mb-2">Scan melalui e-wallet</div>
              ${qrData.qr_url
                ? `<img src="${escJs(qrData.qr_url)}" alt="QRIS" class="img-fluid qr-code-img" style="max-width:220px;border-radius:.5rem;border:2px solid #e2e8f0"/>`
                : `<div class="qr-code-img" style="width:220px;height:220px;background:#1e293b;border-radius:.5rem;display:flex;align-items:center;justify-content:center;color:#94a3b8;font-size:.85rem">QR Code</div>`
              }
            </div>
            <div class="text-center mb-3">
              <div class="fs-4 fw-bold text-dark">Rp ${rupiah(qrData.amount || 0)}</div>
              <small class="text-muted">Scan QR di atas dengan e-wallet Anda</small>
            </div>
            <div class="row g-2 text-center mb-3">
              <div class="col-4">
                <small class="text-muted d-block">Order ID</small>
                <div class="fw-medium text-primary font-family-monospace" style="font-size:.85rem">${escJs(qrData.order_id)}</div>
              </div>
              <div class="col-4">
                <small class="text-muted d-block">Provider</small>
                <div class="fw-medium" style="font-size:.85rem">${escJs(qrData.provider)}</div>
              </div>
              <div class="col-4">
                <small class="text-muted d-block">Masih berlaku</small>
                <div class="fw-medium text-success" style="font-size:.85rem" id="qrisTimer">15:00</div>
              </div>
            </div>
            <div class="d-flex gap-2 flex-wrap">
              <button type="button" class="btn btn-sm pos-btn pos-btn-primary flex-fill" onclick="checkQRISStatus()">
                <i class="fas fa-sync me-1"></i>Cek Status
              </button>
              <button type="button" class="btn btn-sm btn-outline-secondary flex-fill" data-bs-dismiss="modal">
                <i class="fas fa-times me-1"></i>Tutup
              </button>
              <button type="button" class="btn btn-sm btn-outline-danger flex-fill" onclick="cancelQRIS()">
                <i class="fas fa-ban me-1"></i>Batal
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `;

  $('body').append(modalHtml);
  $(`#qrisModal`).modal('show');

  // Timer countdown 15 menit
  let remaining = 900;
  const timerEl = document.getElementById('qrisTimer');
  const timerInterval = setInterval(() => {
    const m = Math.floor(remaining / 60);
    const s = remaining % 60;
    timerEl.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    if (remaining <= 60) timerEl.style.color = '#dc2626';
    remaining--;
    if (remaining < 0) clearInterval(timerInterval);
  }, 1000);

  // Auto-check status setiap 5 detik
  const statusInterval = setInterval(checkQRISStatus, 5000);

  // Hentikan interval saat modal ditutup
  $(`#qrisModal`).on('hidden.bs.modal', () => {
    clearInterval(timerInterval);
    clearInterval(statusInterval);
  });
}

async function checkQRISStatus() {
  if (!currentQRISOrderId) return;

  try {
    const r = await fetch(`<?= site_url("qris/check/") ?>${encodeURIComponent(currentQRISOrderId)}`);
    const j = await r.json();

    if (j.ok && j.status === 'paid') {
      // Transaksi QRIS berhasil
      const tx = await fetch(`<?= site_url("api/pos/transaction") ?>/${encodeURIComponent(currentQRISOrderId)}`);
      // Refresh halaman atau tampilkan notifikasi
      Swal.fire({
        icon: 'success',
        title: 'Pembayaran Berhasil!',
        text: 'QRIS berhasil dibayar. Transaksi selesai.',
        confirmButtonText: 'OK',
      }).then(() => {
        window.location.reload();
      });
    } else if (j.status === 'expired') {
      Swal.fire({
        icon: 'warning',
        title: 'QRIS Kedaluwarsa',
        text: 'QRIS sudah tidak berlaku. Mohon buat ulang.',
        confirmButtonText: 'OK',
      });
    }
  } catch (e) {
    // Ignore - akan retry di interval berikutnya
  }
}

async function cancelQRIS() {
  if (!currentQRISOrderId) return;

  Swal.fire({
    icon: 'warning',
    title: 'Batal QRIS?',
    text: 'Transaksi akan dibatalkan. Lakukan pembayaran lain.',
    showCancelButton: true,
    confirmButtonText: 'Ya, Batal',
    cancelButtonText: 'Tidak',
  }).then(result => {
    if (result.isConfirmed) {
      $('#qrisModal').modal('hide');
      currentQRISOrderId = null;
    }
  });
}

function swal2Warning(text) {
  Swal.fire({ icon: 'warning', title: 'Peringatan', text, confirmButtonText: 'OK' });
}
function swal2Error(text) {
  Swal.fire({ icon: 'error', title: 'Error', text, confirmButtonText: 'OK' });
}

// Helper: escape JS string
function escJs(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
</script>
<?= $this->endSection() ?>