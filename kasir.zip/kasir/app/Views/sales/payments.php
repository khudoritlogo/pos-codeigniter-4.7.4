<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Pembayaran Penjualan'; ?>
<?= $this->section('content') ?>
<div class="row g-3">
  <div class="col-lg-4">
    <div class="card"><div class="card-header"><b><i class="fas fa-wallet me-1"></i> Ringkasan Pembayaran</b></div>
      <div class="card-body">
        <div class="text-center mb-3">
          <h2 class="text-primary"><?= number_format((float)$total_collected,0,',','.') ?></h2>
          <small class="text-muted">Total Terkumpul</small>
        </div>
      </div>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="card"><div class="card-header d-flex justify-content-between align-items-center"><b><i class="fas fa-history me-1"></i> Riwayat Pembayaran</b></div>
      <div class="card-body p-0">
        <?php if (empty($payments)): ?>
          <div class="text-center py-4 text-muted"><i class="fas fa-inbox fa-2x mb-2"></i><p class="mb-0">Belum ada pembayaran.</p></div>
        <?php else: ?>
        <table class="table table-sm table-striped mb-0">
          <thead><tr><th>Tanggal</th><th>Invoice</th><th>Kasir</th><th class="text-end">Jumlah</th><th>Metode</th></tr></thead>
          <tbody>
          <?php foreach ($payments as $p): ?>
          <tr>
            <td><small><?= date('d/m/Y H:i',strtotime($p['created_at'])) ?></small></td>
            <td><?= esc($p['invoice_no']) ?></td>
            <td><?= esc($p['cashier_name'] ?? '-') ?></td>
            <td class="text-end"><?= number_format((float)$p['amount'],0,',','.') ?></td>
            <td><span class="badge bg-info"><?= esc($p['payment_method'] ?? 'cash') ?></span></td>
          </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
