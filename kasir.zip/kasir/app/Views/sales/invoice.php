<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Detail Penjualan'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <div class="d-flex justify-content-between mb-3">
    <div>
      <h4>Invoice: <?= esc($sale['invoice_no']) ?></h4>
      <div><b>Tanggal:</b> <?= date('d/m/Y H:i',strtotime($sale['sale_date'])) ?></div>
      <div><b>Customer:</b> <?= esc($sale['customer_name'] ?? 'Umum') ?></div>
      <div><b>Kasir:</b> <?= esc($sale['cashier_name']) ?></div>
      <?php if (!empty($sale['courier_name'])): ?><div><b>Kurir:</b> <?= esc($sale['courier_name']) ?></div><?php endif; ?>
    </div>
    <div>
      <a class="btn btn-primary no-print" target="_blank" href="<?= site_url('sales/receipt/' . $sale['id']) ?>"><i class="fas fa-print"></i> Cetak Struk</a>
      <a class="btn btn-danger no-print" target="_blank" href="<?= site_url('invoice/pdf/' . $sale['id']) ?>"><i class="fas fa-file-pdf"></i> Lihat PDF</a>
      <a class="btn btn-outline-danger no-print" href="<?= site_url('invoice/pdf/download/' . $sale['id']) ?>"><i class="fas fa-download"></i> Unduh PDF</a>
      <button class="btn btn-success no-print" data-bs-toggle="modal" data-bs-target="#emailModal"><i class="fas fa-envelope"></i> Kirim Email</button>
      <?php if (!empty($sale['courier_id'])): ?>
        <a class="btn btn-info no-print" target="_blank" href="<?= site_url('track/' . esc($sale['invoice_no'])) ?>"><i class="fas fa-map-marker-alt"></i> Lacak Kiriman</a>
      <?php endif; ?>
    </div>
  </div>
  <table class="table table-bordered">
    <thead><tr><th>Produk</th><th>SKU</th><th class="text-end">Qty</th><th class="text-end">Harga</th><th class="text-end">Subtotal</th></tr></thead>
    <tbody>
    <?php foreach ($items as $it): ?>
      <tr>
        <td><?= esc($it['product_name']) ?><?= $it['serial_number'] ? '<br><small class="text-muted">SN: '.esc($it['serial_number']).'</small>' : '' ?></td>
        <td><?= esc($it['sku']) ?></td>
        <td class="text-end"><?= (float)$it['qty'] ?></td>
        <td class="text-end">Rp <?= number_format((float)$it['price'],0,',','.') ?></td>
        <td class="text-end">Rp <?= number_format((float)$it['subtotal'],0,',','.') ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr><th colspan="4" class="text-end">Subtotal</th><th class="text-end">Rp <?= number_format((float)$sale['subtotal'],0,',','.') ?></th></tr>
      <?php if ((float)$sale['discount_amount']>0): ?><tr><th colspan="4" class="text-end">Diskon</th><th class="text-end">- Rp <?= number_format((float)$sale['discount_amount'],0,',','.') ?></th></tr><?php endif; ?>
      <tr class="table-primary"><th colspan="4" class="text-end">TOTAL</th><th class="text-end">Rp <?= number_format((float)$sale['total'],0,',','.') ?></th></tr>
      <tr><th colspan="4" class="text-end">Bayar (<?= esc($sale['payment_method']) ?>)</th><th class="text-end">Rp <?= number_format((float)$sale['paid'],0,',','.') ?></th></tr>
      <tr><th colspan="4" class="text-end">Kembali</th><th class="text-end">Rp <?= number_format((float)$sale['change_amount'],0,',','.') ?></th></tr>
    </tfoot>
  </table>
</div></div>

<!-- Modal Kirim Email PDF -->
<div class="modal fade" id="emailModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title"><i class="fas fa-envelope"></i> Kirim Invoice via Email</h5>
        <button class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <label class="form-label">Email Tujuan</label>
        <input type="email" class="form-control" id="emailTo" placeholder="customer@example.com">
        <small class="text-muted">Invoice PDF akan dilampirkan otomatis.</small>
        <div id="emailResult" class="mt-2"></div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
        <button class="btn btn-success" onclick="sendInvoiceEmail(<?= $sale['id'] ?>)"><i class="fas fa-paper-plane"></i> Kirim</button>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
async function sendInvoiceEmail(id){
  const to = document.getElementById('emailTo').value.trim();
  if (! to) return;
  const btn = event.target; btn.disabled=true; btn.innerHTML='<i class="fas fa-spinner fa-spin"></i>';
  const r = await fetch('/invoice/pdf/email/'+id, {method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'email='+encodeURIComponent(to)});
  const j = await r.json();
  document.getElementById('emailResult').innerHTML = j.ok
    ? '<div class="alert alert-success">Email berhasil dikirim ke '+to+'</div>'
    : '<div class="alert alert-danger">Gagal: '+(j.msg||'Unknown error')+'</div>';
  btn.disabled=false; btn.innerHTML='<i class="fas fa-paper-plane"></i> Kirim';
}
</script>
<?= $this->endSection() ?>
