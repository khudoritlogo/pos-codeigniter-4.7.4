<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8">
<title>Beri Rating - <?= esc($sale['invoice_no']) ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<style>
  body{background:linear-gradient(135deg,#1e40af,#0f172a);color:#fff;min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:system-ui;padding:20px}
  .card{max-width:420px;width:100%;background:#fff;color:#111;border-radius:20px;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.3)}
  .stars{font-size:3rem;user-select:none;text-align:center;padding:20px 0}
  .star{cursor:pointer;color:#e5e7eb;transition:.15s}
  .star.active,.star:hover{color:#fbbf24;transform:scale(1.15)}
</style></head><body>
<div class="card">
  <div style="background:#0d6efd;color:#fff;padding:24px;text-align:center">
    <h4 class="mb-1"><?= esc($store['store_name'] ?? 'Toko') ?></h4>
    <div class="opacity-75">Terima kasih telah berbelanja!</div>
  </div>
  <div class="p-4">
    <h5 class="text-center mb-1">Bagaimana pengalaman Anda?</h5>
    <div class="text-center text-muted small">Invoice: <?= esc($sale['invoice_no']) ?></div>
    <div class="stars" id="stars">
      <?php for ($i=1;$i<=5;$i++): ?><span class="star" data-v="<?= $i ?>">★</span><?php endfor; ?>
    </div>
    <div class="text-center mb-3" id="ratingLabel">Ketuk bintang untuk memberi rating</div>
    <textarea class="form-control mb-3" id="review" placeholder="Ceritakan pengalaman Anda (opsional)..." rows="3"></textarea>
    <button class="btn btn-primary w-100 btn-lg" onclick="submit()">Kirim Rating</button>
    <div id="result" class="mt-3"></div>
  </div>
</div>
<script>
let rating = 0;
document.querySelectorAll('.star').forEach(s=>s.onclick=()=>{
  rating = +s.dataset.v;
  document.querySelectorAll('.star').forEach((x,i)=>x.classList.toggle('active', i<rating));
  document.getElementById('ratingLabel').textContent = ['Sangat kurang','Kurang','Cukup','Bagus','Sangat Bagus!'][rating-1];
});
async function submit(){
  if (!rating) return alert('Pilih rating dulu');
  const r = await fetch(location.pathname,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:`rating=${rating}&review=${encodeURIComponent(document.getElementById('review').value)}`});
  const j = await r.json();
  document.getElementById('result').innerHTML = j.ok
    ? '<div class="alert alert-success text-center">🎉 Terima kasih atas rating Anda!</div>'
    : '<div class="alert alert-danger">Gagal: '+(j.msg||'')+'</div>';
}
</script>
</body></html>
