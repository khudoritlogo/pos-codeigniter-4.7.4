<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Struk Penjualan'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <div class="d-flex justify-content-between mb-3">
    <div><h4>Struk: <?= esc($sale['invoice_no']) ?></h4></div>
    <div class="text-end"><small class="text-muted"><a href="#" onclick="window.print()"><i class="fas fa-print"></i> Cetak</a></small></div>
  </div>
  <div class="row">
    <div class="col-md-6">
      <p><b>Tanggal:</b> <?= date('d/m/Y H:i',strtotime($sale['sale_date'])) ?></p>
      <p><b>Kasir:</b> <?= esc($sale['cashier_name']) ?></p>
      <p><b>Customer:</b> <?= esc($sale['customer_name'] ?? 'Umum') ?></p>
    </div>
    <div class="col-md-6 text-end">
      <p><b>Metode:</b> <?= esc($sale['payment_method']) ?></p>
      <p><b>Total:</b> Rp <?= number_format((float)$sale['total'],0,',','.') ?></p>
      <p><b>Bayar:</b> Rp <?= number_format((float)$sale['paid'],0,',','.') ?></p>
    </div>
  </div>
  <hr>
  <table class="table table-sm mb-0">
    <thead><tr><th>Produk</th><th class="text-end">Qty</th><th class="text-end">Harga</th><th class="text-end">Subtotal</th></tr></thead>
    <tbody>
    <?php foreach ($items as $it): ?>
    <tr>
      <td><?= esc($it['product_name']) ?></td>
      <td class="text-end"><?= (float)$it['qty'] ?></td>
      <td class="text-end"><?= number_format((float)$it['price'],0,',','.') ?></td>
      <td class="text-end"><?= number_format((float)$it['subtotal'],0,',','.') ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <hr>
  <div class="text-end"><b>TOTAL:</b> Rp <?= number_format((float)$sale['total'],0,',','.') ?></div>
  <?php if ((float)$sale['discount_amount'] > 0): ?><div class="text-end text-danger">Diskon: -<?= number_format((float)$sale['discount_amount'],0,',','.') ?></div><?php endif; ?>
</div></div>
<?= $this->endSection() ?>
