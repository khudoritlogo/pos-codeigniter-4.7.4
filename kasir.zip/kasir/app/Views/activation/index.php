<?= $this->extend('layouts/admin') ?>
<?= $this->section('content') ?>

<div class="row justify-content-center">
    <div class="col-lg-8 col-md-10">

        <?php if ($requireActivation): ?>
        <div class="card border-primary mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0"><i class="fas fa-key"></i> Aktivasi Lisensi</h5>
            </div>
            <div class="card-body">
                <div class="alert alert-warning">
                    <i class="fas fa-shield-alt"></i> Aplikasi ini dilindungi lisensi. 
                    Silakan masukkan <strong>License Key</strong> yang diberikan untuk mengaktivasi aplikasi.
                </div>

                <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show">
                    <i class="fas fa-check-circle"></i> <?= session()->getFlashdata('success') ?>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
                <?php endif; ?>

                <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show">
                    <i class="fas fa-exclamation-circle"></i> <?= session()->getFlashdata('error') ?>
                    <button type="button" class="close" data-dismiss="alert">&times;</button>
                </div>
                <?php endif; ?>

                <form action="<?= base_url('activation/activate') ?>" method="post">
                    <?= csrf_field() ?>

                    <div class="form-group mb-3">
                        <label class="form-label">
                            <i class="fas fa-key text-primary"></i> License Key
                            <span class="text-danger">*</span>
                        </label>
                        <input type="text" 
                               name="license_key" 
                               class="form-control font-monospace" 
                               value="<?= old('license_key') ?>" 
                               placeholder="PK-XXXXXXXX-XXXXXXXX-XXXXXXXX"
                               required 
                               autofocus>
                        <small class="text-muted">Masukkan license key yang diberikan oleh admin/penjual</small>
                    </div>

                    <hr class="my-4">
                    <h6 class="text-uppercase text-muted fw-bold"><i class="fas fa-info-circle"></i> Informasi Server (Otomatis Terdeteksi)</h6>
                    <div class="card bg-light mb-3">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-sm-6">
                                    <strong>Domain:</strong><br>
                                    <span class="text-break font-monospace"><?= esc($currentDomain) ?></span>
                                </div>
                                <div class="col-sm-6">
                                    <strong>IP Address:</strong><br>
                                    <span class="text-break font-monospace"><?= esc($serverInfo['ip_address']) ?></span>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-sm-6">
                                    <strong>Server Name:</strong><br>
                                    <span class="text-break font-monospace"><?= esc($serverInfo['server_name']) ?></span>
                                </div>
                                <div class="col-sm-6">
                                    <strong>PHP Version:</strong><br>
                                    <span class="text-break font-monospace"><?= esc($serverInfo['php_version']) ?></span>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-sm-6">
                                    <strong>MySQL Version:</strong><br>
                                    <span class="text-break font-monospace"><?= esc($serverInfo['mysql_version']) ?></span>
                                </div>
                                <div class="col-sm-6">
                                    <strong>OS:</strong><br>
                                    <span class="text-break font-monospace"><?= esc($serverInfo['os']) ?></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <hr class="my-4">
                    <h6 class="text-uppercase text-muted fw-bold"><i class="fas fa-user"></i> Informasi Pembeli (Opsional)</h6>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Nama Pembeli</label>
                            <input type="text" name="customer_name" class="form-control" value="<?= old('customer_name') ?>" placeholder="Nama pembeli / perusahaan">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Email Pembeli</label>
                            <input type="email" name="customer_email" class="form-control" value="<?= old('customer_email') ?>" placeholder="email@pembeli.com">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Order ID <small class="text-muted">(No. referensi pembelian)</small></label>
                            <input type="text" name="order_id" class="form-control" value="<?= old('order_id') ?>" placeholder="ORDER-001">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Berlaku Hingga <small class="text-muted">(tanggal, kosongkan = forever)</small></label>
                            <input type="date" name="valid_until" class="form-control" value="<?= old('valid_until') ?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Catatan <small class="text-muted">(opsional)</small></label>
                        <textarea name="notes" class="form-control" rows="2" placeholder="Catatan tambahan..."><?= old('notes') ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary btn-lg w-100">
                        <i class="fas fa-check-circle"></i> Aktivasi Sekarang
                    </button>
                </form>

                <div class="mt-4 text-center text-muted">
                    <small>
                        <i class="fas fa-shield-alt"></i> 
                        Informasi server yang terkirim: Domain, IP Address, Server Name, PHP Version, MySQL Version.
                        <br>
                        Notifikasi akan dikirim ke email owner: <strong>khudoritlogo@gmail.com</strong>
                    </small>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="card">
            <div class="card-body text-center py-5">
                <i class="fas fa-check-circle text-success fa-3x mb-3"></i>
                <h4 class="text-success">Lisensi Sudah Aktif</h4>
                <p class="text-muted">Aplikasi sudah terekam dengan lisensi aktif.</p>
                <p>
                    <a href="<?= base_url('activation/deactivate') ?>" class="btn btn-outline-danger btn-sm">
                        <i class="fas fa-unlock"></i> Deaktivasi (Admin)
                    </a>
                </p>
            </div>
        </div>
        <?php endif; ?>

    </div>
</div>

<?= $this->endSection() ?>
