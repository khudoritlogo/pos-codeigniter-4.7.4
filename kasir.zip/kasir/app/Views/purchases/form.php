<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Pembelian Baru'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <div class="row g-3">
    <div class="col-md-4"><label>Supplier *</label>
      <select id="supplier" class="form-select select2">
        <?php foreach($suppliers as $s): ?><option value="<?=$s['id']?>"><?=esc($s['name'])?></option><?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-8"><label>Cari & Tambah Produk</label>
      <select id="productPick" class="form-select select2"><option></option>
        <?php foreach($products as $p): ?><option value="<?=$p['id']?>" data-cost="<?=$p['cost_price']?>" data-name="<?=esc($p['name'])?>" data-sn="<?=$p['has_serial_number']?>" data-exp="<?=$p['has_expired_date']?>"><?=esc($p['name'])?> (<?=$p['sku']?>)</option><?php endforeach; ?>
      </select>
    </div>
  </div>
  <hr>
  <table class="table table-bordered">
    <thead><tr><th>Produk</th><th>SN</th><th>Batch</th><th>Exp</th><th class="text-end">Qty</th><th class="text-end">Modal</th><th class="text-end">Subtotal</th><th></th></tr></thead>
    <tbody id="items"></tbody>
    <tfoot>
      <tr><th colspan="6" class="text-end">Total</th><th class="text-end" id="tTotal">Rp 0</th><th></th></tr>
      <tr><th colspan="6" class="text-end">Bayar</th><th><input type="number" id="paid" class="form-control form-control-sm" value="0"></th><th>
        <select id="paymentMethod" class="form-select form-select-sm"><option value="cash">Cash</option><option value="transfer">Transfer</option><option value="debt">Hutang</option></select>
      </th></tr>
    </tfoot>
  </table>
  <textarea id="notes" class="form-control mb-2" placeholder="Catatan..."></textarea>
  <button class="btn btn-success" id="btnSave"><i class="fas fa-save"></i> Simpan Pembelian</button>
  <a class="btn btn-secondary" href="<?= site_url('purchases') ?>">Batal</a>
</div></div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
const items = [];
$('#productPick').on('change',function(){
  const opt = this.options[this.selectedIndex]; if (!opt.value) return;
  items.push({product_id:+opt.value, name:opt.dataset.name, has_sn:+opt.dataset.sn, has_exp:+opt.dataset.exp,
    serial_number:'', batch_code:'', expired_date:'', qty:1, cost_price:+opt.dataset.cost, subtotal:+opt.dataset.cost});
  render(); $(this).val('').trigger('change');
});
function render(){
  $('#items').html(items.map((it,i)=>`
    <tr>
      <td>${it.name}</td>
      <td>${it.has_sn?`<input class="form-control form-control-sm" value="${it.serial_number}" onchange="items[${i}].serial_number=this.value">`:'-'}</td>
      <td><input class="form-control form-control-sm" value="${it.batch_code}" onchange="items[${i}].batch_code=this.value"></td>
      <td>${it.has_exp?`<input type="date" class="form-control form-control-sm" value="${it.expired_date}" onchange="items[${i}].expired_date=this.value">`:'-'}</td>
      <td><input type="number" class="form-control form-control-sm text-end" value="${it.qty}" onchange="items[${i}].qty=+this.value;calc(${i})"></td>
      <td><input type="number" class="form-control form-control-sm text-end" value="${it.cost_price}" onchange="items[${i}].cost_price=+this.value;calc(${i})"></td>
      <td class="text-end">${rupiah(it.qty*it.cost_price)}</td>
      <td><button class="btn btn-sm btn-outline-danger" onclick="items.splice(${i},1);render()"><i class="fas fa-times"></i></button></td>
    </tr>`).join(''));
  $('#tTotal').text(rupiah(items.reduce((s,i)=>s+i.qty*i.cost_price,0)));
}
function calc(i){items[i].subtotal=items[i].qty*items[i].cost_price; render();}
$('#btnSave').on('click',async ()=>{
  const payload = { supplier_id: $('#supplier').val(), payment_method: $('#paymentMethod').val(),
    paid: +$('#paid').val()||0, notes: $('#notes').val(),
    items: items.map(i=>({...i, subtotal:i.qty*i.cost_price})) };
  const r = await fetch('/purchases',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  const j = await r.json();
  Swal.fire(j.ok?'Berhasil':'Gagal','Invoice '+(j.invoice_no||''),j.ok?'success':'error').then(()=>location='/purchases');
});
</script>
<?= $this->endSection() ?>
