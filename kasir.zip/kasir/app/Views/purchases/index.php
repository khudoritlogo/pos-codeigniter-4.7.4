<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Pembelian'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <a class="btn btn-primary" href="<?= site_url('purchases/new') ?>"><i class="fas fa-plus"></i> Pembelian Baru</a></div>
  <table class="table datatable table-striped">
    <thead><tr><th>Invoice</th><th>Tanggal</th><th>Supplier</th><th>User</th><th class="text-end">Total</th><th class="text-end">Hutang</th><th>Status</th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr><td><?= esc($r['invoice_no']) ?></td><td><?= date('d/m/Y',strtotime($r['purchase_date'])) ?></td><td><?= esc($r['supplier_name']) ?></td><td><?= esc($r['user_name']) ?></td><td class="text-end">Rp <?= number_format((float)$r['total'],0,',','.') ?></td><td class="text-end">Rp <?= number_format((float)$r['debt_amount'],0,',','.') ?></td><td><span class="badge bg-success"><?= $r['status'] ?></span></td></tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
