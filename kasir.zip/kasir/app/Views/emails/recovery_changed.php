<?php $storeName = esc($store['store_name'] ?? 'POS Kasir'); ?>
<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;background:#fff7ed;padding:24px;border-radius:8px">
  <div style="background:#c2410c;color:#fff;padding:16px 20px;border-radius:8px 8px 0 0">
    <h2 style="margin:0">⚠️ Peringatan Keamanan</h2>
  </div>
  <div style="background:#fff;padding:24px 20px;border-radius:0 0 8px 8px">
    <p>Halo <b><?= esc($user['fullname'] ?? $user['username']) ?></b>,</p>
    <p>Kami memberitahu Anda bahwa <b>Recovery Email</b> di akun <?= $storeName ?> baru saja diubah:</p>
    <ul>
      <li>Email lama: <b><?= esc($user['recovery_email']) ?></b> (ini)</li>
      <li>Email baru: <b><?= esc($newEmail) ?></b></li>
      <li>Waktu: <b><?= date('d M Y H:i:s') ?></b></li>
    </ul>
    <p><b>Jika ini bukan Anda</b>, segera:</p>
    <ol>
      <li>Login ke <?= $storeName ?> dan ubah password Anda</li>
      <li>Kembalikan Recovery Email ke email ini di menu Profil</li>
      <li>Hubungi Super Admin untuk audit log</li>
    </ol>
    <p style="font-size:12px;color:#999">Jika perubahan ini Anda lakukan sendiri, abaikan email ini.</p>
  </div>
</div>
