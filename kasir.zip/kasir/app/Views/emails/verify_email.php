<?php $storeName = esc($store['store_name'] ?? 'POS Kasir'); ?>
<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;background:#f7f8fa;padding:24px;border-radius:8px">
  <div style="background:#065f46;color:#fff;padding:16px 20px;border-radius:8px 8px 0 0">
    <h2 style="margin:0"><?= $storeName ?></h2>
  </div>
  <div style="background:#fff;padding:24px 20px;border-radius:0 0 8px 8px">
    <p>Halo <b><?= esc($user['fullname'] ?? $user['username']) ?></b>,</p>
    <p>Anda baru saja mendaftarkan email ini sebagai <b>Recovery Email</b> di akun <?= $storeName ?>.</p>
    <p>Klik tombol di bawah untuk mengaktifkan (link berlaku <b>24 jam</b>):</p>
    <p style="text-align:center;margin:32px 0">
      <a href="<?= esc($link) ?>" style="background:#065f46;color:#fff;padding:12px 32px;border-radius:6px;text-decoration:none;font-weight:bold">
        Verifikasi Email Saya
      </a>
    </p>
    <p style="font-size:12px;color:#666">Atau salin URL: <code style="word-break:break-all"><?= esc($link) ?></code></p>
    <hr>
    <p style="font-size:12px;color:#999">Jika Anda tidak mendaftarkan email ini, abaikan pesan ini.</p>
  </div>
</div>
