<?php $storeName = esc($store['store_name'] ?? 'POS Kasir'); ?>
<div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;background:#f7f8fa;padding:24px;border-radius:8px">
  <div style="background:#0f172a;color:#fff;padding:16px 20px;border-radius:8px 8px 0 0">
    <h2 style="margin:0"><?= $storeName ?></h2>
  </div>
  <div style="background:#fff;padding:24px 20px;border-radius:0 0 8px 8px">
    <p>Halo <b><?= esc($user['fullname'] ?? $user['username']) ?></b>,</p>
    <p>Kami menerima permintaan reset password untuk akun <b><?= esc($user['username']) ?></b>.</p>
    <p>Klik tombol di bawah untuk membuat password baru. Link ini <b>berlaku 30 menit</b> dan hanya bisa dipakai <b>satu kali</b>.</p>
    <p style="text-align:center;margin:32px 0">
      <a href="<?= esc($link) ?>" style="background:#0d6efd;color:#fff;padding:12px 32px;border-radius:6px;text-decoration:none;font-weight:bold">
        Reset Password Saya
      </a>
    </p>
    <p style="font-size:12px;color:#666">Jika tombol tidak berfungsi, salin URL berikut ke browser:<br>
      <code style="word-break:break-all"><?= esc($link) ?></code>
    </p>
    <hr>
    <p style="font-size:12px;color:#999">
      Jika Anda <b>tidak meminta</b> reset password, abaikan email ini. Password Anda tetap aman selama tidak ada yang mengklik link di atas.
    </p>
  </div>
</div>
