<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Lupa Password - POS Kasir</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
<style>
  body{background:linear-gradient(135deg,#1e293b,#0f172a);min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:system-ui}
  .card-fp{width:100%;max-width:460px;border:none;border-radius:1rem;box-shadow:0 20px 40px rgba(0,0,0,.3)}
  .brand{font-size:2rem;font-weight:700;color:#fff;text-align:center;margin-bottom:1.5rem}
</style>
</head>
<body>
<div>
  <div class="brand"><i class="fas fa-key me-2"></i>Lupa Password</div>
  <div class="card card-fp">
    <div class="card-body p-4">
      <?php if (session('error')): ?><div class="alert alert-danger py-2"><?= session('error') ?></div><?php endif; ?>
      <?php if (session('success')): ?>
        <div class="alert alert-success py-2"><i class="fas fa-check-circle me-1"></i><?= session('success') ?></div>
        <a href="<?= site_url('auth/login') ?>" class="btn btn-outline-dark w-100"><i class="fas fa-arrow-left me-1"></i>Kembali ke Login</a>
      <?php else: ?>
        <p class="text-muted small">Masukkan <b>username</b> dan <b>recovery email</b> yang sudah terdaftar. Kami akan kirim link reset password ke email Anda (berlaku 30 menit).</p>
        <form action="<?= site_url('auth/forgot') ?>" method="post">
          <?= csrf_field() ?>
          <div class="mb-3">
            <label class="form-label">Username</label>
            <input type="text" name="username" class="form-control" required autofocus>
          </div>
          <div class="mb-3">
            <label class="form-label">Recovery Email</label>
            <input type="email" name="email" class="form-control" required placeholder="email@contoh.com">
            <small class="text-muted">Email yang sudah Anda verifikasi di menu Profil.</small>
          </div>
          <button class="btn btn-dark w-100" type="submit"><i class="fas fa-paper-plane me-2"></i>Kirim Link Reset</button>
        </form>
        <div class="text-center mt-3">
          <a href="<?= site_url('auth/login') ?>" class="small text-decoration-none"><i class="fas fa-arrow-left me-1"></i>Kembali ke Login</a>
        </div>
      <?php endif; ?>
    </div>
  </div>
  <div class="text-center text-white-50 small mt-3">
    <i class="fas fa-info-circle me-1"></i>
    Belum punya recovery email? Hubungi Super Admin untuk reset manual.
  </div>
</div>
</body>
</html>
