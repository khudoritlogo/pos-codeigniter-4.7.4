<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8"><title>Token Tidak Valid</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
<style>body{background:#0f172a;min-height:100vh;display:flex;align-items:center;justify-content:center;color:#fff}</style>
</head>
<body>
  <div class="text-center p-4">
    <i class="fas fa-times-circle text-danger" style="font-size:5rem"></i>
    <h3 class="mt-3">Link Reset Tidak Valid</h3>
    <p class="text-white-50">Link ini mungkin sudah expired (30 menit), sudah dipakai, atau salah.</p>
    <a href="<?= site_url('auth/forgot') ?>" class="btn btn-warning"><i class="fas fa-redo me-1"></i>Minta Link Baru</a>
    <a href="<?= site_url('auth/login') ?>" class="btn btn-outline-light"><i class="fas fa-sign-in-alt me-1"></i>Login</a>
  </div>
</body>
</html>
