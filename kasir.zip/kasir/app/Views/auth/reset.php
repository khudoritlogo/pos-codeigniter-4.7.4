<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Reset Password - POS Kasir</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
<style>
  body{background:linear-gradient(135deg,#065f46,#0f172a);min-height:100vh;display:flex;align-items:center;justify-content:center;font-family:system-ui}
  .card-rp{width:100%;max-width:460px;border:none;border-radius:1rem;box-shadow:0 20px 40px rgba(0,0,0,.3)}
  .brand{font-size:2rem;font-weight:700;color:#fff;text-align:center;margin-bottom:1.5rem}
</style>
</head>
<body>
<div>
  <div class="brand"><i class="fas fa-shield-alt me-2"></i>Set Password Baru</div>
  <div class="card card-rp">
    <div class="card-body p-4">
      <?php if (session('error')): ?><div class="alert alert-danger py-2"><?= session('error') ?></div><?php endif; ?>
      <p class="text-muted small">Token verifikasi valid. Silakan set password baru Anda.</p>
      <form action="<?= site_url('auth/reset/' . $token) ?>" method="post">
        <?= csrf_field() ?>
        <div class="mb-3">
          <label class="form-label">Password Baru</label>
          <input type="password" name="password" class="form-control" required autofocus minlength="8">
          <small class="text-muted">Min 8 karakter, huruf + angka.</small>
        </div>
        <div class="mb-3">
          <label class="form-label">Konfirmasi Password</label>
          <input type="password" name="password_confirm" class="form-control" required minlength="8">
        </div>
        <button class="btn btn-success w-100" type="submit"><i class="fas fa-check me-2"></i>Simpan Password</button>
      </form>
    </div>
  </div>
</div>
</body>
</html>
