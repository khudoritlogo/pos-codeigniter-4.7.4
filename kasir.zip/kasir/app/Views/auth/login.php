<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>TLOGO SMART — Masuk</title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<style>
  :root {
    --primary: #2563eb;
    --primary-dark: #1d4ed8;
    --secondary: #7c3aed;
    --dark: #1e293b;
    --darker: #0f172a;
  }
  * { box-sizing: border-box; }
  body {
    font-family:'Inter',system-ui,-apple-system,sans-serif;
    margin:0;
    background:#f1f5f9;
    color:#1e293b;
  }

  /* ===== LOGIN PAGE ===== */
  .login-bg {
    min-height:100vh;
    background: linear-gradient(135deg, var(--darker) 0%, var(--dark) 40%, #1e3a5f 100%);
    position:relative;
    overflow:hidden;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:2rem;
  }
  .login-bg::before {
    content:'';
    position:absolute;
    top:-50%;left:-50%;
    width:200%;height:200%;
    background:
      radial-gradient(circle at 30% 50%, rgba(37,99,235,.12) 0%, transparent 50%),
      radial-gradient(circle at 70% 80%, rgba(124,58,237,.08) 0%, transparent 50%);
    animation: bgShift 20s ease-in-out infinite alternate;
  }
  @keyframes bgShift {
    0% { transform:translate(0,0) rotate(0deg); }
    100% { transform:translate(2%,2%) rotate(3deg); }
  }
  .login-card {
    width:100%;max-width:420px;
    border:none;border-radius:1.25rem;
    box-shadow:0 25px 50px -12px rgba(0,0,0,.5);
    overflow:hidden;
    position:relative;z-index:1;
  }
  .login-card-head {
    background:var(--dark);
    padding:1.5rem;
    text-align:center;
    border-bottom:1px solid rgba(255,255,255,.05);
  }
  .logo-icon {
    width:48px;height:48px;
    background:linear-gradient(135deg,var(--primary),var(--secondary));
    border-radius:.85rem;
    display:flex;align-items:center;justify-content:center;
    font-size:1.4rem;color:#fff;margin:0 auto 1rem;
  }
  .login-card-head h1 {
    color:#fff;font-weight:700;margin:0;
    letter-spacing:.3px;
  }
  .login-card-head p {
    color:#94a3b8;margin:0.25rem 0 0;font-size:.85rem;
  }
  .login-card-body {
    background:var(--dark);
    padding:1.5rem;
  }
  .login-card-body .form-control {
    background:rgba(255,255,255,.05);
    border:1px solid rgba(255,255,255,.12);
    color:#fff;
    border-radius:.65rem;
    padding:.65rem .85rem;
  }
  .login-card-body .form-control::placeholder { color:#64748b; }
  .login-card-body .form-control:focus {
    border-color:var(--primary);
    box-shadow:0 0 0 3px rgba(37,99,235,.25);
    background:rgba(255,255,255,.08);
  }
  .login-card-body .form-label {
    color:#94a3b8;font-size:.85rem;font-weight:500;
  }
  .btn-login {
    background:linear-gradient(135deg,var(--primary),var(--secondary));
    border:none;
    color:#fff;
    font-weight:600;
    padding:.65rem;
    border-radius:.65rem;
    transition:.2s;
  }
  .btn-login:hover {
    transform:translateY(-1px);
    box-shadow:0 8px 20px rgba(37,99,235,.4);
    color:#fff;
  }
  .demo-badge {
    background:rgba(255,255,255,.06);
    border:1px solid rgba(255,255,255,.1);
    border-radius:.75rem;
    padding:.75rem 1rem;
  }
  .demo-badge .user-pill {
    display:inline-block;
    background:rgba(37,99,235,.25);
    color:#93c5fd;
    padding:2px 10px;
    border-radius:999px;
    font-size:.8rem;
    margin:2px 3px;
  }
  .link-forgot {
    color:#60a5fa;
    font-size:.85rem;
  }
  .link-forgot:hover { color:#93c5fd; }
</style>
</head>
<body>

<div class="login-bg">
  <div class="login-card">
    <div class="login-card-head">
      <div class="logo-icon"><i class="fas fa-store"></i></div>
      <h1>TLOGO SMART</h1>
      <p>All-in-One Smart Retail</p>
    </div>
    <div class="login-card-body">
      <h5 class="text-white mb-3 text-center">Silakan Masuk</h5>

      <!-- Error display from CI4 session -->
      <?php if (session('error')): ?>
        <div class="alert alert-danger py-2 mb-3" style="background:rgba(220,38,38,.15);border:1px solid rgba(220,38,38,.3);color:#fca5a5;border-radius:.65rem">
          <i class="fas fa-exclamation-circle me-2"></i><?= esc(session('error')) ?>
        </div>
      <?php endif; ?>

      <form method="post" action="<?= site_url('auth/attempt') ?>">
        <?= csrf_field() ?>
        <div class="mb-3">
          <label class="form-label">Username</label>
          <input type="text" class="form-control" name="username" required autofocus placeholder="Masukkan username" value="superadmin" autocomplete="username">
        </div>
        <div class="mb-3">
          <label class="form-label">Password</label>
          <input type="password" class="form-control" name="password" required placeholder="Masukkan password" value="password123" autocomplete="current-password">
        </div>
        <button type="submit" class="btn btn-login w-100 mb-3"><i class="fas fa-sign-in-alt me-2"></i>Masuk</button>
      </form>
      <div class="text-center mb-2">
        <a href="<?= site_url('auth/forgot') ?>" class="link-forgot"><i class="fas fa-key me-1"></i>Lupa Password?</a>
      </div>
      <hr>
      <div class="demo-badge">
        <div class="small text-muted mb-2" style="color:#94a3b8"><b style="color:#93c5fd">Akun Demo</b> (password: <code style="color:#fff">password123</code>)</div>
        <div>
          <span class="user-pill">superadmin</span>
          <span class="user-pill">admin</span>
          <span class="user-pill">kasir</span>
          <span class="user-pill">kurir</span>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  // Auto-focus username field
  document.addEventListener('DOMContentLoaded', () => {
    document.querySelector('input[name="username"]').focus();
  });
</script>
</body>
</html>