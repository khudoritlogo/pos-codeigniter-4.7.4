<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="container mt-4">
  <h1>Audit Log</h1>
  <div class="card">
    <div class="card-body">
      <p>Halaman audit log.</p>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
