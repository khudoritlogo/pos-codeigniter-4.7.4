<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<?php
$pageTitle = ($customer ? 'Edit' : 'Tambah') . ' Pelanggan';
?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <div><h1 class="h3 mb-0 text-gray-800"><?= esc($pageTitle) ?></h1></div>
    <a href="<?= site_url('customers') ?>" class="btn btn-secondary btn-sm"><i class="fas fa-arrow-left"></i> Kembali</a>
</div>
<?php if (session('errors')): ?>
<div class="alert alert-danger alert-dismissible"><?= session('errors') ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>
<div class="card shadow"><div class="card-body">
<form method="post" action="<?= $action ?>">
  <?= csrf_field() ?>
  <?php if($customer): ?><input type="hidden" name="_method" value="PUT"><?php endif; ?>
  <div class="row g-3">
    <div class="col-md-6"><label class="form-label">Nama *</label><input class="form-control" name="name" required value="<?= esc($customer['name'] ?? '') ?>"></div>
    <div class="col-md-6"><label class="form-label">Kode Pelanggan</label><input class="form-control" name="code" value="<?= esc($customer['code'] ?? '') ?>"></div>
    <div class="col-md-6"><label class="form-label">Nomor Telepon</label><input class="form-control" name="phone" value="<?= esc($customer['phone'] ?? '') ?>"></div>
    <div class="col-md-6"><label class="form-label">Email</label><input class="form-control" name="email" type="email" value="<?= esc($customer['email'] ?? '') ?>"></div>
    <div class="col-md-6">
      <label class="form-label">Level Pelanggan</label>
      <select name="level_id" class="form-select select2"><option value="">-- Pilih --</option>
        <?php foreach($levels ?? [] as $l): ?>
          <option value="<?= $l['id'] ?>" <?= ($customer['level_id'] ?? 0)==$l['id']?'selected':'' ?>><?= esc($l['name']) ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-6"><label class="form-label">Alamat</label><textarea class="form-control" name="address" rows="2"><?= esc($customer['address'] ?? '') ?></textarea></div>
    <div class="col-md-6"><label class="form-label">Limit Piutang</label><input type="number" step="0.01" min="0" class="form-control" name="credit_limit" value="<?= esc($customer['credit_limit'] ?? 0) ?>"></div>
    <div class="col-md-6 form-check ms-3 mt-4"><input class="form-check-input" type="checkbox" name="is_active" value="1" <?= ($customer['is_active'] ?? 1)?'checked':'' ?>><label class="form-check-label">Aktif</label></div>
  </div>
  <hr>
  <div class="d-flex justify-content-end gap-2">
    <a href="<?= site_url('customers') ?>" class="btn btn-secondary">Batal</a>
    <button class="btn btn-primary"><i class="fas fa-save"></i> <?= $customer ? 'Perbarui' : 'Simpan' ?></button>
  </div>
</form>
</div></div>
<?= $this->endSection() ?>