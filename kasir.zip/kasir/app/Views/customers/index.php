<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="d-sm-flex align-items-center justify-content-between mb-4">
    <div><h1 class="h3 mb-0 text-gray-800"><?= esc($title ?? 'Pelanggan') ?></h1></div>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?= site_url('customers/new') ?>" class="btn btn-primary btn-sm"><i class="fas fa-plus"></i> Tambah</a>
        <div class="input-group" style="max-width:300px">
            <input type="text" name="q" class="form-control" placeholder="Cari..." value="<?= esc($search ?? '') ?>">
            <div class="input-group-append">
                <button class="btn btn-info" type="submit"><i class="fas fa-search"></i></button>
            </div>
        </div>
    </div>
</div>
<div class="card shadow"><div class="card-body p-0">
<table class="table table-hover table-striped mb-0">
  <thead class="table-light"><tr><th>No</th><th>Nama</th><th>Telepon</th><th>Email</th><th>Level</th><th>Aksi</th></tr></thead>
  <tbody>
    <?php if(empty($customers)): ?><tr><td colspan="6" class="text-center py-4"><i class="fas fa-users fa-2x text-muted"></i><p class="mt-2 text-muted">Belum ada pelanggan.</p></td></tr><?php endif; ?>
    <?php foreach($customers ?? [] as $i => $c): ?>
    <tr>
      <td><?= $i+1 ?></td>
      <td><b><?= esc($c['name']) ?></b><br><small class="text-muted"><?= esc($c['code'] ?? '-') ?></small></td>
      <td><?= esc($c['phone'] ?? '-') ?></td>
      <td><?= esc($c['email'] ?? '-') ?></td>
      <td><span class="badge badge-info"><?= esc($c['level_name'] ?? '-') ?></span></td>
      <td class="text-nowrap">
        <div class="btn-group btn-group-sm">
          <a href="<?= site_url("customers/edit/$c[id]") ?>" class="btn btn-info btn-sm"><i class="fas fa-edit"></i></a>
          <?php if(session()->get('level_code')==='superadmin'): ?>
          <form action="<?= site_url("customers/delete/$c[id]") ?>" method="post" class="d-inline" onsubmit="return confirm('Hapus pelanggan ini?')"><button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button></form>
          <?php endif; ?>
        </div>
      </td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>
</div></div>
<?= $this->endSection() ?>