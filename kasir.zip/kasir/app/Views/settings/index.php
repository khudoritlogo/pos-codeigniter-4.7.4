<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="container-fluid mt-4">
  <h1 class="h3"><i class="fas fa-cog"></i> Pengaturan Toko</h1>
  <div class="card">
    <div class="card-body">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Nama Toko</label>
            <input type="text" class="form-control" value="POS KASIR" disabled>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label>Owner</label>
            <input type="text" class="form-control" value="" disabled>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6">
          <div class="form-group">
            <label>Alamat</label>
            <textarea class="form-control" rows="3" disabled></textarea>
          </div>
        </div>
        <div class="col-md-6">
          <div class="form-group">
            <label>Telepon</label>
            <input type="text" class="form-control" value="" disabled>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
