<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Transfer Stok Antar Cabang'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <a class="btn btn-primary" href="<?= site_url('stock-transfers/new') ?>"><i class="fas fa-plus"></i> Transfer Baru</a></div>
  <table class="table datatable table-striped">
    <thead><tr><th>No</th><th>Tanggal</th><th>Dari</th><th>Ke</th><th>User</th><th>Status</th></tr></thead>
    <tbody><?php foreach ($rows ?? [] as $r): ?><tr><td><?= esc($r['transfer_no']) ?></td><td><?= date('d/m/Y H:i',strtotime($r['transfer_date'])) ?></td><td><?= esc($r['from_name']) ?></td><td><?= esc($r['to_name']) ?></td><td><?= esc($r['fullname']) ?></td><td><span class="badge bg-success"><?= $r['status'] ?></span></td></tr><?php endforeach; ?></tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
