<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Transfer Stok Baru'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <div class="row g-3">
    <div class="col-md-4"><label>Cabang Asal</label><select id="from" class="form-select select2"><?php foreach($branches as $b): ?><option value="<?=$b['id']?>"><?=esc($b['name'])?></option><?php endforeach; ?></select></div>
    <div class="col-md-4"><label>Cabang Tujuan</label><select id="to" class="form-select select2"><?php foreach($branches as $b): ?><option value="<?=$b['id']?>"><?=esc($b['name'])?></option><?php endforeach; ?></select></div>
    <div class="col-md-4"><label>Produk</label><select id="pick" class="form-select select2"><option></option><?php foreach($products as $p): ?><option value="<?=$p['id']?>" data-name="<?=esc($p['name'])?>"><?=esc($p['name'])?></option><?php endforeach; ?></select></div>
  </div>
  <hr>
  <table class="table table-bordered"><thead><tr><th>Produk</th><th class="text-end">Qty</th><th></th></tr></thead><tbody id="items"></tbody></table>
  <textarea id="notes" class="form-control mb-2" placeholder="Catatan..."></textarea>
  <button class="btn btn-success" onclick="save()"><i class="fas fa-save"></i> Simpan Transfer</button>
</div></div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
const items = [];
$('#pick').on('change',function(){
  const o = this.options[this.selectedIndex]; if (!o.value) return;
  items.push({product_id:+o.value, name:o.dataset.name, qty:1}); render(); $(this).val('').trigger('change');
});
function render(){ $('#items').html(items.map((it,i)=>`<tr><td>${it.name}</td><td><input type="number" min="1" value="${it.qty}" class="form-control form-control-sm text-end" onchange="items[${i}].qty=+this.value"></td><td><button class="btn btn-sm btn-outline-danger" onclick="items.splice(${i},1);render()"><i class="fas fa-times"></i></button></td></tr>`).join('')); }
async function save(){
  const r = await fetch('/stock-transfers',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({from_branch_id:$('#from').val(),to_branch_id:$('#to').val(),notes:$('#notes').val(),items})});
  const j = await r.json(); Swal.fire(j.ok?'Berhasil':'Gagal',j.transfer_no||'',j.ok?'success':'error').then(()=>location='/stock-transfers');
}
</script>
<?= $this->endSection() ?>
