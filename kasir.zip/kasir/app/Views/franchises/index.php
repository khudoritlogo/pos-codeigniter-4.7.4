<?= $this->extend('layouts/main') ?>
<?php $pageTitle = 'Franchise ' . (!isset($isHq) || $isHq ? '(HQ Mode)' : ''); ?>
<?= $this->section('content') ?>
<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center">
    <b><i class="fas fa-sitemap me-1"></i> Daftar Franchise</b>
    <?php if (! $isHq): ?>
      <span class="badge bg-secondary">Kelola via tabel <code>franchises</code> — CRUD form disediakan lewat SimpleCrud (super admin)</span>
    <?php endif; ?>
  </div>
  <div class="card-body">
    <?php if (! $rows): ?>
      <div class="text-muted text-center py-4"><i class="fas fa-info-circle me-1"></i> Belum ada data franchise. Tambahkan via database atau menu Master Franchise.</div>
    <?php else: ?>
    <table class="table datatable">
      <thead><tr><th>Kode</th><th>Nama Brand</th><th>HQ Owner</th><th class="text-end">Royalty %</th><th class="text-end">Jumlah Cabang</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td><b><?= esc($r['code']) ?></b></td>
        <td><?= esc($r['name']) ?></td>
        <td><?= esc($r['hq_name'] ?? '-') ?></td>
        <td class="text-end"><?= number_format((float) $r['royalty_percent'], 2) ?>%</td>
        <td class="text-end"><span class="badge bg-info"><?= (int) $r['total_branches'] ?></span></td>
        <td><a class="btn btn-sm btn-primary" href="<?= site_url('franchises/' . $r['id'] . '/dashboard') ?>"><i class="fas fa-chart-line"></i> Dashboard HQ</a></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>
<?= $this->endSection() ?>
