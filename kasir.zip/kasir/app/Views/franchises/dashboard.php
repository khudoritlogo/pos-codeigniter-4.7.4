<?= $this->extend('layouts/main') ?>
<?php $pageTitle = 'HQ Dashboard — ' . esc($franchise['name']); ?>
<?= $this->section('content') ?>

<div class="row g-3 mb-3">
  <div class="col-md-3">
    <div class="stat-card bg-primary">
      <div class="small">Omzet Hari Ini</div>
      <div class="h4 mb-0"><?= number_format($totalToday, 0, ',', '.') ?></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="stat-card bg-success">
      <div class="small">Omzet Bulan Ini</div>
      <div class="h4 mb-0"><?= number_format($totalMonth, 0, ',', '.') ?></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="stat-card bg-warning">
      <div class="small">Royalty HQ (<?= number_format((float) $franchise['royalty_percent'], 2) ?>%)</div>
      <div class="h4 mb-0"><?= number_format($royalty, 0, ',', '.') ?></div>
    </div>
  </div>
  <div class="col-md-3">
    <div class="stat-card bg-dark">
      <div class="small">Total Cabang</div>
      <div class="h4 mb-0"><?= count($perBranch) ?></div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header"><b><i class="fas fa-store me-1"></i> Roll-up per Cabang</b></div>
  <div class="card-body">
    <table class="table table-striped">
      <thead><tr><th>Cabang</th><th>Kota</th><th class="text-end">Trx Hari Ini</th><th class="text-end">Omzet Hari Ini</th><th class="text-end">Omzet Bulan Ini</th></tr></thead>
      <tbody>
      <?php foreach ($perBranch as $b): ?>
      <tr>
        <td><b><?= esc($b['name']) ?></b></td>
        <td><?= esc($b['city'] ?? '-') ?></td>
        <td class="text-end"><?= (int) $b['tx_today'] ?></td>
        <td class="text-end"><?= number_format((float) $b['today'], 0, ',', '.') ?></td>
        <td class="text-end"><b><?= number_format((float) $b['this_month'], 0, ',', '.') ?></b></td>
      </tr>
      <?php endforeach; ?>
      <?php if (! $perBranch): ?><tr><td colspan="5" class="text-center text-muted">Belum ada cabang di franchise ini.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?= $this->endSection() ?>
