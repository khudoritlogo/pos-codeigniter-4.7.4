<!DOCTYPE html>
<html lang="id"><head><meta charset="UTF-8">
<title>Customer Display — <?= esc($store['store_name'] ?? 'POS') ?></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
<style>
  body{background:linear-gradient(135deg,#0f172a,#1e40af);color:#fff;min-height:100vh;font-family:system-ui;margin:0;overflow:hidden}
  .brand{padding:20px 32px;display:flex;justify-content:space-between;align-items:center;background:rgba(0,0,0,.3)}
  .brand h1{margin:0;font-size:2rem;font-weight:800}
  .brand small{opacity:.7}
  .container-cfd{padding:24px 32px;display:grid;grid-template-columns:1.5fr 1fr;gap:24px;height:calc(100vh - 82px)}
  .items-box{background:rgba(255,255,255,.05);border-radius:16px;padding:20px;overflow:auto;backdrop-filter:blur(8px)}
  .item{display:flex;justify-content:space-between;padding:12px 8px;border-bottom:1px solid rgba(255,255,255,.1);font-size:1.4rem}
  .item .qty{opacity:.7;font-size:1.1rem}
  .item .subtotal{color:#facc15;font-weight:700}
  .total-box{background:rgba(255,255,255,.08);border-radius:16px;padding:24px;display:flex;flex-direction:column;justify-content:space-between}
  .row-total{display:flex;justify-content:space-between;padding:8px 0;font-size:1.2rem}
  .grand{font-size:3.5rem;color:#facc15;font-weight:900;text-align:right;margin-top:16px;line-height:1.1}
  .promo{background:#facc15;color:#111;padding:12px;border-radius:12px;font-weight:700;text-align:center;margin-top:16px;font-size:1.1rem}
  .empty{opacity:.5;text-align:center;padding:60px 0;font-size:1.4rem}
  .clock{font-variant-numeric:tabular-nums}
</style>
</head><body>
<div class="brand">
  <div><h1><?= esc($store['store_name'] ?? 'TOKO POS') ?></h1><small><?= esc($store['address'] ?? '') ?></small></div>
  <div class="text-end"><div class="clock" id="clock" style="font-size:1.6rem"></div><small><?= esc($store['phone'] ?? '') ?></small></div>
</div>

<div class="container-cfd">
  <div class="items-box">
    <h4 class="mb-3 opacity-75"><i class="fas fa-shopping-cart"></i> Item Belanja Anda</h4>
    <div id="itemsList"><div class="empty">Silakan tunggu, kasir sedang melayani...</div></div>
  </div>
  <div class="total-box">
    <div>
      <div class="row-total"><span>Subtotal</span><span id="subtotal">Rp 0</span></div>
      <div class="row-total"><span>Diskon</span><span id="discount">Rp 0</span></div>
      <div class="row-total"><span>Ongkir</span><span id="shipping">Rp 0</span></div>
      <hr style="border-color:rgba(255,255,255,.2)">
      <div style="text-align:right;font-size:1rem;opacity:.75">TOTAL</div>
      <div class="grand" id="grand">Rp 0</div>
    </div>
    <div class="promo" id="promo">🎉 Selamat berbelanja & terima kasih atas kunjungan Anda!</div>
  </div>
</div>

<script>
const branchId  = <?= (int) $branch_id ?>;
const cashierId = <?= $cashier_id ? (int)$cashier_id : 'null' ?>;
const rupiah = v => new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',minimumFractionDigits:0}).format(v||0);

function clock(){
  const d = new Date();
  document.getElementById('clock').textContent = d.toLocaleString('id-ID',{dateStyle:'medium',timeStyle:'medium'});
}
setInterval(clock,1000); clock();

let lastUpdate = null;
async function poll(){
  try {
    const url = cashierId ? `/cfd/state/${branchId}/${cashierId}` : `/cfd/state/${branchId}`;
    const r = await fetch(url,{cache:'no-store'});
    const j = await r.json();
    if (j.ok && j.updated_at !== lastUpdate) {
      lastUpdate = j.updated_at;
      render(j.state || {items:[],total:0});
    }
  } catch(e){}
}
function render(s){
  const items = s.items || [];
  const el = document.getElementById('itemsList');
  el.innerHTML = items.length===0
    ? '<div class="empty">Silakan tunggu, kasir sedang melayani...</div>'
    : items.map(i=>`<div class="item"><div><b>${i.name}</b><div class="qty">${i.qty} × ${rupiah(i.price)}</div></div><div class="subtotal">${rupiah(i.subtotal||i.qty*i.price)}</div></div>`).join('');
  document.getElementById('subtotal').textContent = rupiah(s.subtotal||0);
  document.getElementById('discount').textContent = '- '+rupiah(s.discount||0);
  document.getElementById('shipping').textContent = rupiah(s.shipping||0);
  document.getElementById('grand').textContent    = rupiah(s.total||0);
  if (s.message) document.getElementById('promo').innerHTML = s.message;
}
setInterval(poll, 1200); poll();
</script>
</body></html>
