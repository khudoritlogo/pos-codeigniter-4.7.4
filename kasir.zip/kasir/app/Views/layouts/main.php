<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title><?= esc($title ?? 'POS Kasir') ?></title>
<meta name="csrf-token" content="<?= csrf_hash() ?>">
<link rel="manifest" href="<?= site_url('manifest.webmanifest') ?>">
<meta name="theme-color" content="#0d6efd">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="POS Kasir">
<link rel="apple-touch-icon" href="<?= site_url('assets/pwa/icon-192.png') ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.5.2/css/all.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@4.0.0-beta3/dist/css/adminlte.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0/dist/css/select2.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<style>
  .brand-link{background:#212529;color:#fff}
  .stat-card{border-radius:.75rem;padding:1rem 1.25rem;color:#fff}
  .cart-item{border-bottom:1px dashed #dee2e6;padding:.5rem 0}
  .pos-grid .card{cursor:pointer;transition:.15s}
  .pos-grid .card:hover{transform:translateY(-2px);box-shadow:0 4px 12px rgba(0,0,0,.08)}
  .qty-badge{position:absolute;top:8px;right:8px;background:#dc3545;color:#fff;border-radius:999px;padding:2px 8px;font-size:.75rem}
  @media print { .no-print { display:none !important } }
  /* Global UI Polish */
  body { font-family:'Inter',system-ui,-apple-system,sans-serif; }
  .card { border-color:#e2e8f0; box-shadow:0 1px 2px rgba(0,0,0,.03); }
  .card:hover { box-shadow:0 2px 8px rgba(0,0,0,.06); }
  .table thead th { background:#f8fafc; font-weight:600; color:#475569; font-size:.85rem; border-bottom:2px solid #e2e8f0; }
  .table tbody tr { transition:background .1s; }
  .table tbody tr:hover { background:#f8fafc; }
  .btn { border-radius:.5rem; font-weight:500; }
  .btn-sm { padding:.4rem .65rem; }
  .form-control:focus, .form-select:focus { border-color:#2563eb; box-shadow:0 0 0 3px rgba(37,99,235,.15); }
  .alert { border-radius:.65rem; border:1px solid transparent; }
  .alert-success { background:#f0fdf4; border-color:#bbf7d0; color:#166534; }
  .alert-danger { background:#fef2f2; border-color:#fecaca; color:#991b1b; }
  .alert-warning { background:#fffbeb; border-color:#fde68a; color:#92400e; }
  .breadcrumb-item+.breadcrumb-item { padding-left:1rem; color:#94a3b8; }
  .h4, .h5, .h6 { color:#1e293b; }
  .text-muted { color:#64748b !important; }
  .border-top { border-top:1px solid #e2e8f0; }
  .border-bottom { border-bottom:1px solid #e2e8f0; }
  .bg-light { background-color:#f8fafc; }
</style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <?= view('layouts/navbar') ?>
  <?= view('layouts/sidebar') ?>

  <div class="content-wrapper">
    <section class="content-header py-3 bg-white shadow-sm">
      <div class="container-fluid d-flex justify-content-between align-items-center">
        <h1 class="m-0 h4"><?= esc($pageTitle ?? ($title ?? 'Dashboard')) ?></h1>
        <ol class="breadcrumb float-sm-end mb-0">
          <li class="breadcrumb-item"><a href="<?= site_url('dashboard') ?>">Home</a></li>
          <li class="breadcrumb-item active"><?= esc($pageTitle ?? ($title ?? '')) ?></li>
        </ol>
      </div>
    </section>

    <section class="content pt-3">
      <div class="container-fluid">
        <?php if (session('success')): ?><div class="alert alert-success alert-dismissible"><?= session('success') ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
        <?php if (session('error')): ?><div class="alert alert-danger alert-dismissible"><?= session('error') ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>
        <?php if (session('warning')): ?><div class="alert alert-warning alert-dismissible"><?= session('warning') ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div><?php endif; ?>

        <?= $this->renderSection('content') ?>
      </div>
    </section>
  </div>

  <footer class="main-footer text-center py-2 bg-white border-top small">
    <strong>POS Kasir &copy; <?= date('Y') ?></strong> — Developed by TLOGO — All rights reserved.
  </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@4.0.0-beta3/dist/js/adminlte.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0/dist/js/select2.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
  $(function(){
    $('.datatable').DataTable({pageLength:25, order:[]});
    $('.select2').select2({theme:'bootstrap-5', width:'100%'});
  });
  window.rupiah = v => new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',minimumFractionDigits:0}).format(v||0);
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('<?= site_url('service-worker.js') ?>').catch(() => {});
    });
  }
  let __pwaPrompt = null;
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault(); __pwaPrompt = e;
    const btn = document.getElementById('btnInstallPwa');
    if (btn) btn.style.display = 'inline-block';
  });
  window.installPwa = () => {
    if (! __pwaPrompt) return;
    __pwaPrompt.prompt();
    __pwaPrompt.userChoice.finally(() => { __pwaPrompt = null; });
  };
</script>
<?= $this->renderSection('scripts') ?>
</body>
</html>
