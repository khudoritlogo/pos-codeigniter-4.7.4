<nav class="main-header navbar navbar-expand navbar-dark bg-dark">
  <ul class="navbar-nav">
    <li class="nav-item"><a class="nav-link" data-lte-toggle="sidebar" href="#"><i class="fas fa-bars"></i></a></li>
    <li class="nav-item d-none d-sm-inline-block"><span class="nav-link text-white-50"><?= esc($store['store_name'] ?? 'POS Kasir') ?> — <?= esc($user['branch_name'] ?? '-') ?></span></li>
  </ul>
  <ul class="navbar-nav ms-auto">
    <li class="nav-item"><button id="btnInstallPwa" class="btn btn-sm btn-warning me-2" style="display:none" onclick="installPwa()"><i class="fas fa-mobile-alt me-1"></i> Install App</button></li>
    <li class="nav-item"><a class="nav-link text-white" href="<?= site_url('sales/pos') ?>"><i class="fas fa-cash-register me-1"></i> Kasir</a></li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle text-white" data-bs-toggle="dropdown" href="#">
        <i class="fas fa-user-circle me-1"></i> <?= esc($user['fullname'] ?? 'User') ?>
        <span class="badge bg-primary ms-1"><?= esc($user['level_name'] ?? '') ?></span>
      </a>
      <div class="dropdown-menu dropdown-menu-end">
        <a class="dropdown-item" href="<?= site_url('profile') ?>"><i class="fas fa-user me-2"></i>Profil Saya</a>
        <a class="dropdown-item" href="<?= site_url('shifts') ?>"><i class="fas fa-clock me-2"></i>Shift Kasir</a>
        <div class="dropdown-divider"></div>
        <a class="dropdown-item" href="<?= site_url('auth/logout') ?>"><i class="fas fa-sign-out-alt me-2"></i>Logout</a>
      </div>
    </li>
  </ul>
</nav>
