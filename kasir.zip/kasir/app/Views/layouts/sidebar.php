<?php $lvl = $user['level_code'] ?? ''; $isSA=$lvl==='super_admin'; $isAd=$lvl==='admin'; $isKs=$lvl==='kasir'; $isKr=$lvl==='kurir'; $isHq=$lvl==='franchise_hq'; $isFo=$lvl==='franchise'; ?>
<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <a href="<?= site_url('dashboard') ?>" class="brand-link text-center py-3">
    <i class="fas fa-store me-2"></span class="brand-text fw-bold">POS KASIR</span>
  </a>
  <div class="sidebar">
    <nav class="mt-2">
      <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu">
        <?php if (!$isKr): ?>
          <li class="nav-item"><a href="<?= site_url('dashboard') ?>" class="nav-link"><i class="nav-icon fas fa-tachometer-alt"></i><p>Dashboard</p></a></li>
          <li class="nav-item"><a href="<?= site_url('sales/pos') ?>" class="nav-link"><i class="nav-icon fas fa-cash-register"></i><p>Kasir (POS)</p></a></li>
        <?php endif; ?>

        <?php if ($isSA || $isAd): ?>
          <li class="nav-header text-uppercase small mt-3">Master Data</li>
          <li class="nav-item"><a href="<?= site_url('products') ?>" class="nav-link"><i class="nav-icon fas fa-box"></i><p>Barang</p></a></li>
          <li class="nav-item"><a href="<?= site_url('products/import') ?>" class="nav-link"><i class="nav-icon fas fa-file-import"></i><p>Import Produk</p></a></li>
          <li class="nav-item"><a href="<?= site_url('categories') ?>" class="nav-link"><i class="nav-icon fas fa-tags"></i><p>Kategori</p></a></li>
          <li class="nav-item"><a href="<?= site_url('units') ?>" class="nav-link"><i class="nav-icon fas fa-ruler"></i><p>Satuan</p></a></li>
          <li class="nav-item"><a href="<?= site_url('suppliers') ?>" class="nav-link"><i class="nav-icon fas fa-truck-loading"></i><p>Supplier</p></a></li>
          <li class="nav-item"><a href="<?= site_url('expeditions') ?>" class="nav-link"><i class="nav-icon fas fa-truck"></i><p>Ekspedisi</p></a></li>
        <?php endif; ?>

        <?php if (!$isKr): ?>
          <li class="nav-item"><a href="<?= site_url('customers') ?>" class="nav-link"><i class="nav-icon fas fa-users"></i><p>Customer</p></a></li>
        <?php endif; ?>

        <?php if ($isSA): ?>
          <li class="nav-header text-uppercase small mt-3">Manajemen</li>
          <li class="nav-item"><a href="<?= site_url('users') ?>" class="nav-link"><i class="nav-icon fas fa-user-shield"></i><p>User & Level</p></a></li>
          <li class="nav-item"><a href="<?= site_url('branches') ?>" class="nav-link"><i class="nav-icon fas fa-building"></i><p>Cabang</p></a></li>
          <li class="nav-item"><a href="<?= site_url('customer-levels') ?>" class="nav-link"><i class="nav-icon fas fa-medal"></i><p>Level Customer</p></a></li>
          <li class="nav-item"><a href="<?= site_url('activation') ?>" class="nav-link"><i class="nav-icon fas fa-key"></i><p>Aktivasi Lisensi</p></a></li>
        <?php endif; ?>

        <?php if ($isSA || $isAd): ?>
          <li class="nav-header text-uppercase small mt-3">Transaksi</li>
          <li class="nav-item"><a href="<?= site_url('sales') ?>" class="nav-link"><i class="nav-icon fas fa-receipt"></i><p>Data Penjualan</p></a></li>
          <li class="nav-item"><a href="<?= site_url('sale-returns') ?>" class="nav-link"><i class="nav-icon fas fa-undo"></i><p>Retur Penjualan</p></a></li>
          <li class="nav-item"><a href="<?= site_url('purchases') ?>" class="nav-link"><i class="nav-icon fas fa-file-invoice-dollar"></i><p>Pembelian</p></a></li>
          <li class="nav-item"><a href="<?= site_url('invoice/pdf') ?>" class="nav-link"><i class="nav-icon fas fa-file-pdf"></i><p>Cetak Invoice PDF</p></a></li>

          <li class="nav-header text-uppercase small mt-3">Lisensi & Aktivasi</li>
          <li class="nav-item"><a href="<?= site_url('license') ?>" class="nav-link"><i class="nav-icon fas fa-id-card"></i><p>Manajemen Lisensi</p></a></li>
          <li class="nav-item"><a href="<?= site_url('activation') ?>" class="nav-link"><i class="nav-icon fas fa-key"></i><p>Aktivasi Lisensi</p></a></li>
          <li class="nav-item"><a href="<?= site_url('purchase-returns') ?>" class="nav-link"><i class="nav-icon fas fa-undo-alt"></i><p>Retur Pembelian</p></a></li>
          <li class="nav-item"><a href="<?= site_url('stock-transfers') ?>" class="nav-link"><i class="nav-icon fas fa-exchange-alt"></i><p>Transfer Stok</p></a></li>
          <li class="nav-item"><a href="<?= site_url('stock-opnames') ?>" class="nav-link"><i class="nav-icon fas fa-clipboard-check"></i><p>Stock Opname</p></a></li>
          <li class="nav-item"><a href="<?= site_url('receivables') ?>" class="nav-link"><i class="nav-icon fas fa-hand-holding-usd"></i><p>Piutang</p></a></li>
          <li class="nav-item"><a href="<?= site_url('payables') ?>" class="nav-link"><i class="nav-icon fas fa-money-bill-wave"></i><p>Hutang</p></a></li>
        <?php endif; ?>

        <?php if ($isKr): ?>
          <li class="nav-header text-uppercase small mt-3">Kurir</li>
          <li class="nav-item"><a href="<?= site_url('courier/dashboard') ?>" class="nav-link"><i class="nav-icon fas fa-motorcycle"></i><p>Dashboard Kurir</p></a></li>
          <li class="nav-item"><a href="<?= site_url('courier/deliveries') ?>" class="nav-link"><i class="nav-icon fas fa-shipping-fast"></i><p>Pengiriman Saya</p></a></li>
          <li class="nav-item"><a href="<?= site_url('reports/courier') ?>" class="nav-link"><i class="nav-icon fas fa-chart-bar"></i><p>Laporan Pribadi</p></a></li>
        <?php endif; ?>

        <?php if ($isSA || $isAd): ?>
          <li class="nav-header text-uppercase small mt-3">Promo & Loyalty</li>
          <li class="nav-item"><a href="<?= site_url('vouchers') ?>" class="nav-link"><i class="nav-icon fas fa-ticket-alt"></i><p>Voucher & Kupon</p></a></li>
          <li class="nav-item"><a href="<?= site_url('wa-broadcast') ?>" class="nav-link"><i class="nav-icon fab fa-whatsapp"></i><p>WA Blast Voucher</p></a></li>
          <li class="nav-item"><a href="<?= site_url('loyalty-rewards') ?>" class="nav-link"><i class="nav-icon fas fa-gift"></i><p>Reward Loyalty</p></a></li>
          <li class="nav-item"><a href="<?= site_url('purchase-orders') ?>" class="nav-link"><i class="nav-icon fas fa-clipboard-list"></i><p>Purchase Order</p></a></li>
        <?php endif; ?>

        <?php if ($isKr): ?>
          <li class="nav-item"><a href="<?= site_url('courier/route-planner') ?>" class="nav-link"><i class="nav-icon fas fa-route"></i><p>Route Planner</p></a></li>
        <?php endif; ?>

        <?php if (!$isKr): ?>
          <li class="nav-header text-uppercase small mt-3">Laporan</li>
          <li class="nav-item"><a href="<?= site_url('reports/sales') ?>" class="nav-link"><i class="nav-icon fas fa-chart-line"></i><p>Penjualan</p></a></li>
          <li class="nav-item"><a href="<?= site_url('reports/purchases') ?>" class="nav-link"><i class="nav-icon fas fa-chart-bar"></i><p>Pembelian</p></a></li>
          <li class="nav-item"><a href="<?= site_url('reports/cashier') ?>" class="nav-link"><i class="nav-icon fas fa-user-check"></i><p>Kasir</p></a></li>
          <li class="nav-item"><a href="<?= site_url('reports/customer') ?>" class="nav-link"><i class="nav-icon fas fa-user-friends"></i><p>Customer</p></a></li>
          <li class="nav-item"><a href="<?= site_url('reports/supplier') ?>" class="nav-link"><i class="nav-icon fas fa-truck-moving"></i><p>Supplier</p></a></li>
          <li class="nav-item"><a href="<?= site_url('reports/courier') ?>" class="nav-link"><i class="nav-icon fas fa-motorcycle"></i><p>Kurir</p></a></li>
          <li class="nav-item"><a href="<?= site_url('reports/top-products') ?>" class="nav-link"><i class="nav-icon fas fa-star"></i><p>Barang Terlaris</p></a></li>
          <li class="nav-item"><a href="<?= site_url('reports/low-stock') ?>" class="nav-link"><i class="nav-icon fas fa-exclamation-triangle"></i><p>Stok Terkecil</p></a></li>
          <li class="nav-item"><a href="<?= site_url('reports/predictive-restock') ?>" class="nav-link"><i class="nav-icon fas fa-crystal-ball"></i><p>Predictive Restock</p></a></li>
          <li class="nav-item"><a href="<?= site_url('reports/courier-leaderboard') ?>" class="nav-link"><i class="nav-icon fas fa-trophy"></i><p>Leaderboard Kurir</p></a></li>
          <li class="nav-item"><a href="<?= site_url('reports/cash-transfer') ?>" class="nav-link"><i class="nav-icon fas fa-wallet"></i><p>Cash & Transfer</p></a></li>
          <?php if ($isSA): ?>
          <li class="nav-item"><a href="<?= site_url('reports/profit') ?>" class="nav-link"><i class="nav-icon fas fa-coins"></i><p>Laba Bersih</p></a></li>
          <?php endif; ?>
        <?php endif; ?>

        <?php if (!$isKr): ?>
          <li class="nav-header text-uppercase small mt-3">Tools</li>
          <li class="nav-item"><a href="<?= site_url('ai') ?>" class="nav-link"><i class="nav-icon fas fa-robot"></i><p>AI Assistant</p></a></li>
          <li class="nav-item"><a href="<?= site_url('scanner') ?>" class="nav-link"><i class="nav-icon fas fa-camera"></i><p>Mobile Scanner</p></a></li>
          <li class="nav-item"><a href="<?= site_url('invoice/pdf') ?>" class="nav-link"><i class="nav-icon fas fa-file-pdf"></i><p>Cetak Invoice PDF</p></a></li>
          <li class="nav-item"><a href="<?= site_url('dashboard/tv') ?>" target="_blank" class="nav-link"><i class="nav-icon fas fa-tv"></i><p>TV Mode</p></a></li>
          <?php if ($isSA || $isAd): ?>
          <li class="nav-item"><a href="<?= site_url('referrals') ?>" class="nav-link"><i class="nav-icon fas fa-user-friends"></i><p>Referral Program</p></a></li>
          <?php endif; ?>
        <?php endif; ?>

        <?php if ($isSA): ?>
          <li class="nav-header text-uppercase small mt-3">Sistem</li>
          <li class="nav-item"><a href="<?= site_url('settings') ?>" class="nav-link"><i class="nav-icon fas fa-cog"></i><p>Pengaturan Toko</p></a></li>
          <li class="nav-item"><a href="<?= site_url('audit-logs') ?>" class="nav-link"><i class="nav-icon fas fa-history"></i><p>Audit Log</p></a></li>
          <li class="nav-item"><a href="<?= site_url('license') ?>" class="nav-link"><i class="nav-icon fas fa-id-card"></i><p>Manajemen Lisensi</p></a></li>
        <?php endif; ?>

        <?php if ($isSA || $isHq): ?>
          <li class="nav-header text-uppercase small mt-3">Franchise</li>
          <li class="nav-item"><a href="<?= site_url('franchises') ?>" class="nav-link"><i class="nav-icon fas fa-sitemap"></i><p><?= $isHq ? 'HQ Dashboard' : 'Kelola Franchise' ?></p></a></li>
        <?php endif; ?>
      </ul>
    </nav>
  </div>
</aside>
