<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Reward Loyalty'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
    <a class="btn btn-primary" href="<?= site_url('loyalty-rewards/new') ?>"><i class="fas fa-plus"></i> Tambah Reward</a></div>
  <table class="table datatable table-striped">
    <thead><tr><th>Nama</th><th>Tipe</th><th class="text-end">Poin</th><th>Nilai / Produk</th><th class="text-end">Stok</th><th>Status</th><th></th></tr></thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr>
        <td><b><?= esc($r['name']) ?></b><br><small class="text-muted"><?= esc($r['description']) ?></small></td>
        <td><span class="badge bg-info"><?= esc($r['type']) ?></span></td>
        <td class="text-end"><span class="badge bg-warning text-dark"><?= (int)$r['points_required'] ?> poin</span></td>
        <td><?= $r['type']==='free_product'? esc($r['product_name']) : ($r['type']==='discount_percent'? esc($r['discount_value']).'%' : 'Rp '.number_format((float)$r['discount_value'],0,',','.')) ?></td>
        <td class="text-end"><?= $r['stock']>=999 ? '∞' : (int)$r['stock'] ?></td>
        <td><span class="badge bg-<?= $r['is_active']?'success':'secondary' ?>"><?= $r['is_active']?'Aktif':'Nonaktif' ?></span></td>
        <td class="text-end">
    <a href="<?= site_url('loyalty-rewards/' . $r['id'] . '/edit') ?>" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i></a>
          <form method="post" action="/loyalty-rewards/<?= $r['id'] ?>" class="d-inline" onsubmit="return confirm('Hapus?')"><?= csrf_field() ?><input type="hidden" name="_method" value="DELETE"><button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button></form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
