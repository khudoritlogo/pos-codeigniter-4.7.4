<?= $this->extend('layouts/main') ?>
<?php $pageTitle=($row?'Edit':'Tambah').' Reward'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <form method="post" action="<?= $row?'/loyalty-rewards/'.$row['id']:'/loyalty-rewards' ?>">
    <?= csrf_field() ?><?php if($row): ?><input type="hidden" name="_method" value="PUT"><?php endif; ?>
    <div class="row g-3">
      <div class="col-md-6"><label>Nama *</label><input required class="form-control" name="name" value="<?= esc($row['name']??'') ?>"></div>
      <div class="col-md-3"><label>Poin Dibutuhkan *</label><input type="number" required class="form-control" name="points_required" value="<?= esc($row['points_required']??100) ?>"></div>
      <div class="col-md-3"><label>Stok</label><input type="number" class="form-control" name="stock" value="<?= esc($row['stock']??999) ?>"></div>
      <div class="col-md-4"><label>Tipe *</label>
        <select class="form-select" name="type" id="rewardType">
          <option value="discount_percent" <?=($row['type']??'')=='discount_percent'?'selected':''?>>Diskon Persen (%)</option>
          <option value="discount_nominal" <?=($row['type']??'')=='discount_nominal'?'selected':''?>>Diskon Nominal (Rp)</option>
          <option value="free_product" <?=($row['type']??'')=='free_product'?'selected':''?>>Free Product (barter)</option>
        </select>
      </div>
      <div class="col-md-4"><label>Nilai Diskon</label><input type="number" step="0.01" class="form-control" name="discount_value" value="<?= esc($row['discount_value']??0) ?>"></div>
      <div class="col-md-4"><label>Produk (utk Free Product)</label>
        <select class="form-select select2" name="product_id"><option value="">--</option>
          <?php foreach($products as $p): ?><option value="<?=$p['id']?>" <?=($row['product_id']??0)==$p['id']?'selected':''?>><?=esc($p['name'])?></option><?php endforeach; ?>
        </select>
      </div>
      <div class="col-md-12"><label>Deskripsi</label><textarea class="form-control" name="description"><?= esc($row['description']??'') ?></textarea></div>
      <div class="col-md-6"><label>Berhak (Level Customer)</label>
        <?php $levels = model('CustomerLevelModel')->findAll(); $applic = $row['applicable_customer_levels'] ?? ''; $selectedIds = array_filter(array_map('trim', explode(',', $applic))); ?>
        <select class="form-select select2" name="applicable_customer_levels_arr[]" multiple>
          <?php foreach ($levels as $lv): ?>
            <option value="<?= $lv['id'] ?>" <?= in_array((string)$lv['id'], $selectedIds, true)?'selected':'' ?>><?= esc($lv['name']) ?></option>
          <?php endforeach; ?>
        </select>
        <small class="text-muted">Kosongkan = semua customer level bisa tukar</small>
        <input type="hidden" name="applicable_customer_levels" id="applicableLevels" value="<?= esc($applic) ?>">
      </div>
      <div class="col-md-3"><label>Priority Tampil</label><input type="number" class="form-control" name="tier_priority" value="<?= esc($row['tier_priority']??0) ?>"></div>
      <div class="col-md-3 form-check mt-4 ms-3"><input class="form-check-input" type="checkbox" name="is_active" value="1" <?= ($row['is_active']??1)?'checked':'' ?>><label class="form-check-label">Aktif</label></div>
    </div><hr>
    <button class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
    <a href="<?= site_url('loyalty-rewards') ?>" class="btn btn-secondary">Batal</a>
  </form>
</div></div>
<?= $this->endSection() ?>
<?= $this->section('scripts') ?>
<script>
$('form').on('submit',function(){
  const arr = $('[name="applicable_customer_levels_arr[]"]').val() || [];
  $('#applicableLevels').val(arr.join(','));
});
</script>
<?= $this->endSection() ?>
