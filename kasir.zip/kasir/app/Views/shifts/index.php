<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Shift Kasir'; ?>
<?= $this->section('content') ?>
<div class="row g-3">
  <div class="col-md-5">
    <div class="card"><div class="card-header <?= $current?'bg-success text-white':'bg-secondary text-white' ?>"><b>Status Shift: <?= $current?'AKTIF':'TIDAK AKTIF' ?></b></div>
      <div class="card-body">
        <?php if ($current): ?>
          <div class="mb-2"><b>Dibuka:</b> <?= date('d/m/Y H:i',strtotime($current['opened_at'])) ?></div>
          <div class="mb-2"><b>Kas Awal:</b> Rp <?= number_format((float)$current['opening_cash'],0,',','.') ?></div>
          <hr>
          <form method="post" action="/shifts/close">
            <?= csrf_field() ?>
            <div class="mb-2"><label>Kas Fisik Saat Tutup</label><input type="number" name="closing_cash" class="form-control" required></div>
            <div class="mb-2"><label>Catatan</label><textarea name="notes" class="form-control"></textarea></div>
            <button class="btn btn-danger w-100"><i class="fas fa-lock"></i> Tutup Shift</button>
          </form>
        <?php else: ?>
          <form method="post" action="/shifts/open">
            <?= csrf_field() ?>
            <div class="mb-2"><label>Kas Awal</label><input type="number" name="opening_cash" class="form-control" required value="0"></div>
            <button class="btn btn-success w-100"><i class="fas fa-unlock"></i> Buka Shift</button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div class="col-md-7">
    <div class="card"><div class="card-header"><b>Riwayat Shift</b></div>
      <div class="card-body p-0">
        <table class="table table-sm mb-0">
          <thead><tr><th>Buka</th><th>Tutup</th><th class="text-end">Kas Awal</th><th class="text-end">Total Sales</th><th class="text-end">Selisih</th><th>Status</th></tr></thead>
          <tbody>
            <?php foreach ($history as $h): ?>
            <tr>
              <td><small><?= date('d/m H:i',strtotime($h['opened_at'])) ?></small></td>
              <td><small><?= $h['closed_at']?date('d/m H:i',strtotime($h['closed_at'])):'-' ?></small></td>
              <td class="text-end">Rp <?= number_format((float)$h['opening_cash'],0,',','.') ?></td>
              <td class="text-end">Rp <?= number_format((float)$h['total_sales'],0,',','.') ?></td>
              <td class="text-end <?= $h['difference']<0?'text-danger':'text-success' ?>">Rp <?= number_format((float)$h['difference'],0,',','.') ?></td>
              <td><span class="badge bg-<?= $h['status']=='open'?'success':'secondary' ?>"><?= $h['status'] ?></span></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?= $this->endSection() ?>
