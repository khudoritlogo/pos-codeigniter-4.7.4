<?php
/** Reusable date-range filter partial */
?>
<form class="row g-2 mb-3">
  <div class="col-md-3"><input type="date" name="from" class="form-control" value="<?= esc($from) ?>"></div>
  <div class="col-md-3"><input type="date" name="to" class="form-control" value="<?= esc($to) ?>"></div>
  <div class="col-md-3">
    <button class="btn btn-primary"><i class="fas fa-filter"></i> Filter</button>
    <?php if (!empty($exportType)): ?>
      <a class="btn btn-outline-success" href="<?= site_url('reports/export/' . $exportType . '/csv?from=' . $from . '&to=' . $to) ?>"><i class="fas fa-file-csv"></i> CSV</a>
      <a class="btn btn-outline-secondary" href="<?= site_url('reports/export/' . $exportType . '/txt?from=' . $from . '&to=' . $to) ?>"><i class="fas fa-file-alt"></i> TXT</a>
    <?php endif; ?>
    <button type="button" class="btn btn-outline-dark" onclick="window.print()"><i class="fas fa-print"></i> Cetak</button>
  </div>
</form>
