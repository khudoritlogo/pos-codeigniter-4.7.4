<?= $this->extend('layouts/main') ?>
<?php $pageTitle = $title ?? 'Data'; ?>
<?= $this->section('content') ?>
<div class="card"><div class="card-body">
  <div class="mb-3 d-flex justify-content-between">
    <h5 class="mb-0">Daftar <?= esc($title) ?></h5>
    <a class="btn btn-primary" href="<?= site_url($viewPath . '/new') ?>"><i class="fas fa-plus"></i> Tambah</a>
  </div>
  <table class="table datatable table-striped">
    <thead>
      <tr>
        <?php foreach ($columns as $col=>$label): ?><th><?= esc($label) ?></th><?php endforeach; ?>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($rows as $r): ?>
      <tr>
        <?php foreach ($columns as $col=>$label): ?>
          <td><?= esc($r[$col] ?? '-') ?></td>
        <?php endforeach; ?>
        <td class="text-end">
          <a class="btn btn-sm btn-outline-primary" href="<?= site_url($viewPath . '/' . $r['id'] . '/edit') ?>"><i class="fas fa-edit"></i></a>
          <form method="post" action="/<?= $viewPath ?>/<?= $r['id'] ?>" class="d-inline" onsubmit="return confirm('Hapus?')">
            <?= csrf_field() ?><input type="hidden" name="_method" value="DELETE">
            <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
