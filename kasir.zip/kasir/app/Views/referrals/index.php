<?= $this->extend('layouts/main') ?>
<?php $pageTitle='Referral Program'; ?>
<?= $this->section('content') ?>
<div class="row g-3">
  <div class="col-md-4"><div class="stat-card bg-info"><small>Total Referral Events</small><h3 class="mb-0"><?= $totalEvents ?></h3></div></div>
  <div class="col-md-4"><div class="stat-card bg-success"><small>Rewarded</small><h3 class="mb-0"><?= $rewardedCount ?></h3></div></div>
  <div class="col-md-4"><div class="stat-card bg-warning"><small>Pending</small><h3 class="mb-0"><?= $pendingCount ?></h3></div></div>
</div>
<div class="card mt-3"><div class="card-body">
  <table class="table datatable table-striped">
    <thead><tr><th>Tanggal</th><th>Referrer</th><th>Referee</th><th>Sale</th><th>Status</th><th>Poin Referrer</th><th>Poin Referee</th></tr></thead>
    <tbody>
      <?php foreach ($events as $e): ?>
      <tr>
        <td><?= date('d/m/Y H:i',strtotime($e['created_at'])) ?></td>
        <td><?= esc($e['referrer_name'] ?? '-') ?></td>
        <td><?= esc($e['referee_name'] ?? '-') ?></td>
        <td><?php if ($e['sale_id']): ?><small>INV-<?= substr($e['sale_invoice'],-10) ?? '-' ?></small><?php else: ?>-<?php endif; ?></td>
        <td><span class="badge <?= $e['status']=='rewarded' ? 'bg-success' : ($e['status']=='pending' ? 'bg-warning' : 'bg-secondary') ?>"><?= esc($e['status']) ?></span></td>
        <td class="text-end"><?= (int)$e['points_awarded_referrer'] ?></td>
        <td class="text-end"><?= (int)$e['points_awarded_referee'] ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div></div>
<?= $this->endSection() ?>
