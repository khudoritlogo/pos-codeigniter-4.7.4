<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        if (! $session->get('is_logged_in')) {
            return redirect()->to(site_url('auth/login'));
        }

        // Role restriction (arguments passed via route filter)
        if (! empty($arguments)) {
            $userLevel = $session->get('level_code');
            if (! in_array($userLevel, $arguments, true) && $userLevel !== 'super_admin') {
                return redirect()->to(site_url('dashboard'))->with('error', 'Anda tidak memiliki akses ke halaman tersebut.');
            }
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
    }
}
