<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class LicenseFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        // Skip activation check di halaman activation & auth
        $skipPaths = [
            'activation',
            'activation/check',
            'activation/activate',
            'auth/login',
            'auth/attempt',
            'auth/logout',
        ];

        $uri = $request->getUri()->getPath();

        foreach ($skipPaths as $path) {
            if (str_contains($uri, $path)) {
                return;
            }
        }

        // Cek apakah lisensi aktif
        $licenseService = service('license');
        $license = $licenseService->getActiveLicense();

        if (!$license) {
            // Kalau require_activation = false, cukup warn
            $config = config('LicenseConfig');
            if (!$config->requireActivation) {
                return;
            }

            // Redirect ke halaman activation
            return redirect()->to(base_url('activation'))
                ->with('license_required', true);
        }

        // Cek apakah domain sesuai
        $currentDomain = $request->getHeader('Host')->getValue();
        $currentDomain = str_replace('www.', '', $currentDomain);

        if ($license['domain'] && strtolower($license['domain']) !== strtolower($currentDomain)) {
            // Domain tidak cocok
            session()->setFlashdata('license_error', 'Lisensi tidak aktif untuk domain ini.');
            return redirect()->to(base_url('activation'));
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Tidak ada action setelah
    }
}
