<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Libraries\TelegramService;

/**
 * php spark telegram:daily
 *
 * Setup cron di server untuk kirim ringkasan omzet harian ke Owner tiap jam 21:00
 *   0 21 * * *  cd /path/to/pos-app && php spark telegram:daily
 */
class TelegramDaily extends BaseCommand
{
    protected $group       = 'Telegram';
    protected $name        = 'telegram:daily';
    protected $description = 'Kirim ringkasan omzet harian ke Telegram Owner';

    public function run(array $params)
    {
        $date = $params[0] ?? date('Y-m-d');
        CLI::write("Mengirim ringkasan tanggal $date...", 'yellow');
        $res = (new TelegramService())->sendDailySummary($date);
        if ($res['ok']) CLI::write('✓ Terkirim ke Telegram', 'green');
        else CLI::error('Gagal: ' . ($res['msg'] ?? ($res['error'] ?? 'unknown')));
    }
}
