<?php

namespace App\Commands;

use CodeIgniter\CLI\BaseCommand;
use CodeIgniter\CLI\CLI;
use App\Libraries\AutoOrderService;

/**
 * php spark po:auto-generate
 *
 * Setup di cron (harian jam 3 pagi):
 *   0 3 * * *  cd /path/to/pos-app && php spark po:auto-generate >> /var/log/pos-po.log 2>&1
 */
class PurchaseOrderAutoGenerate extends BaseCommand
{
    protected $group       = 'Purchase';
    protected $name        = 'po:auto-generate';
    protected $description = 'Generate PO draft otomatis untuk produk yang stoknya sudah kritis';

    public function run(array $params)
    {
        $window = (int) ($params[0] ?? 30);
        $threshold = (int) ($params[1] ?? 7);
        CLI::write("Analisis penjualan {$window} hari, threshold {$threshold} hari...", 'yellow');
        $r = (new AutoOrderService())->generateDrafts($window, $threshold);
        if (empty($r)) {
            CLI::write('✓ Semua stok aman. Tidak ada PO draft dibuat.', 'green');
        } else {
            CLI::write('✓ '.count($r).' PO draft baru dibuat:', 'green');
            foreach ($r as $po) CLI::write("  · {$po['po_number']} — Supplier #{$po['supplier_id']} — {$po['items']} item — Rp ".number_format($po['total'],0,',','.'));
        }
    }
}
