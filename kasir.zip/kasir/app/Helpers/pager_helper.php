<?php
// safety_wrapper.php — Helper wrapper untuk Pager methods yang berisiko
if (!function_exists('pager_safe_getTotal')) {
    /**
     * Wrapper aman untuk $pager->getTotal()
     * Menghindari TypeError jika Pager::getTotal() return null
     */
    function pager_safe_getTotal($pager): int
    {
        try {
            $result = $pager->getTotal();
            return $result !== null ? (int) $result : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }
}

if (!function_exists('pager_safe_getPerPage')) {
    function pager_safe_getPerPage($pager): int
    {
        try {
            $result = $pager->getPerPage();
            return $result !== null ? (int) $result : 0;
        } catch (\Throwable $e) {
            return 0;
        }
    }
}