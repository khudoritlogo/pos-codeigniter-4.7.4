<?php
/**
 * Helper format Rupiah
 */
if (!function_exists('rupiah')) {
    function rupiah(float $amount, bool $withSymbol = true): string
    {
        $formatted = number_format($amount, 0, ',', '.');
        return $withSymbol ? 'Rp ' . $formatted : $formatted;
    }
}

/**
 * Helper format angka umum
 */
if (!function_exists('formatNumber')) {
    function formatNumber(float $num, int $decimals = 0): string
    {
        return number_format($num, $decimals, ',', '.');
    }
}