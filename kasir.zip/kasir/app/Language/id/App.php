<?php
/**
 * Indonesian Language File - App
 * Translasi untuk label yang dipakai di view products, sales, dll.
 */

return [
    // Umum
    'add_new'       => 'Tambah',
    'add'           => 'Tambah',
    'edit'          => 'Edit',
    'delete'        => 'Hapus',
    'save'          => 'Simpan',
    'cancel'        => 'Batal',
    'search'        => 'Cari',
    'no'            => 'No',
    'action'        => 'Aksi',
    'status'        => 'Status',
    'name'          => 'Nama',
    'price'         => 'Harga',
    'date'          => 'Tanggal',
    'note'          => 'Catatan',
    'setting'       => 'Pengaturan',
    'yes'           => 'Ya',
    'no_label'      => 'Tidak',
    'loading'       => 'Memuat...',
    'no_results'    => 'Tidak ada hasil',
    'no_products_found' => 'Belum ada produk',

    // Produk
    'products'      => 'Data Barang',
    'product_name'  => 'Nama Produk',
    'sku'           => 'SKU',
    'barcode'       => 'Barcode',
    'category'      => 'Kategori',
    'stock'         => 'Stok',
    'sell_price'    => 'Harga Jual',
    'cost_price'    => 'Harga Modal',
    'wholesale_price' => 'Harga Grosir',
    'member_price'  => 'Harga Member',
    'unit'          => 'Satuan',
    'supplier'      => 'Supplier',
    'description'   => 'Deskripsi',
    'image'         => 'Gambar',
    'is_active'     => 'Aktif',
    'inactive'      => 'Nonaktif',

    // Kategori
    'categories'    => 'Kategori',

    // Satuan
    'units'         => 'Satuan',

    // Customer
    'customers'     => 'Pelanggan',
    'customer'      => 'Pelanggan',
    'customer_name' => 'Nama Pelanggan',
    'phone'         => 'Telepon',
    'email'         => 'Email',
    'address'       => 'Alamat',
    'customer_level' => 'Level Customer',

    // Supplier
    'suppliers'     => 'Supplier',
    'supplier_name' => 'Nama Supplier',
    'supplier_address' => 'Alamat Supplier',
    'supplier_phone' => 'Telepon Supplier',

    // Sales/POS
    'sales'         => 'Penjualan',
    'sales_pos'     => 'Kasir (POS)',
    'pos'           => 'POS',
    'invoice_no'    => 'Invoice',
    'subtotal'      => 'Subtotal',
    'discount'      => 'Diskon',
    'tax'           => 'Pajak',
    'total'         => 'Total',
    'paid'          => 'Bayar',
    'change'        => 'Kembalian',
    'payment_method'=> 'Cara Bayar',
    'cart'          => 'Keranjang',
    'items'         => 'Item',
    'qty'           => 'Jumlah',
    'empty_cart'    => 'Keranjang kosong',

    // Laporan
    'reports'       => 'Laporan',
    'report_purchases' => 'Laporan Pembelian',
    'report_sales'  => 'Laporan Penjualan',
    'date_from'     => 'Dari Tanggal',
    'date_to'       => 'Sampai Tanggal',
    'total_amount'  => 'Total',
    'payment'       => 'Pembayaran',

    // Dashboard
    'dashboard'     => 'Dashboard',
    'barang_terjual Hari ini' => 'Barang Terjual Hari Ini',
    'total_barang'  => 'Total Barang',
    'invoice_hari_ini' => 'Invoice Hari Ini',
    'omzet'         => 'Omzet',

    // Lain-lain
    'users'         => 'User & Level',
    'branches'      => 'Cabang',
    'branches_name' => 'Nama Cabang',
    'branches'      => 'Cabang',
];