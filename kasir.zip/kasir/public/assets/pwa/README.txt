PWA Icons — WAJIB DIISI SEBELUM GO-LIVE
========================================
Sertakan 2 file PNG di folder ini:
  - icon-192.png  (192x192, transparan)
  - icon-512.png  (512x512, transparan)

Cara cepat generate:
  1. Siapkan logo persegi (PNG, min 512x512)
  2. Buka https://realfavicongenerator.net/ atau https://maskable.app/editor
  3. Download, taruh 2 file di sini.

Icon ini muncul di:
  - Home screen HP kasir (setelah tap "Install App")
  - Splash screen saat PWA dibuka
  - Manifest badge di browser
