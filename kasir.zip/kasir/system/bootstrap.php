<?php
declare(strict_types=1);

use CodeIgniter\Boot;

// Define path constants needed before loading Paths.
require_once __DIR__ . '/Boot.php';

// Boot in web context
exit(Boot::bootWeb(new Config\Paths()));
