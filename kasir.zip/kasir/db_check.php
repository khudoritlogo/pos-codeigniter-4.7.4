<?php
// Script cek database - sinkronisasi dengan database_full.sql

$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'pos_kasir';

echo "=== Database Sync Checker ===\n";
echo "Database: $db\n";
echo "Host: $host\n\n";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
    
    // Dapatkan semua tabel yang ada
    $stmt = $pdo->query("SHOW TABLES");
    $existingTables = $stmt->fetchAll(PDO::FETCH_COLUMN);
    sort($existingTables);
    
    echo "Tabel yang ADA di database ($db):\n";
    echo str_repeat("-", 50) . "\n";
    foreach ($existingTables as $t) {
        echo "  ✓ $t\n";
    }
    echo "\nJumlah tabel: " . count($existingTables) . "\n\n";
    
    // Baca database_full.sql untuk dapatkan tabel yang seharusnya ada
    $sqlFile = __DIR__ . '/database_full.sql';
    if (file_exists($sqlFile)) {
        $content = file_get_contents($sqlFile);
        preg_match_all('/CREATE TABLE\s+`([^`]+)`/', $content, $matches);
        $expectedTables = $matches[1];
        sort($expectedTables);
        
        echo "Tabel yang seHARUSNYA ada (dari database_full.sql):\n";
        echo str_repeat("-", 50) . "\n";
        foreach ($expectedTables as $t) {
            $exists = in_array($t, $existingTables);
            echo ($exists ? "  ✓" : "  ✗") . " $t" . ($exists ? "" : " [MISSING]") . "\n";
        }
        echo "\nJumlah tabel seharusnya: " . count($expectedTables) . "\n\n";
        
        // Cari tabel yang hilang
        $missing = array_diff($expectedTables, $existingTables);
        if (count($missing) > 0) {
            echo "=== TABEL HILANG (perlu di-import ulang) ===\n";
            foreach ($missing as $t) {
                echo "  ✗ $t\n";
            }
            echo "\n";
        } else {
            echo "✓ Semua tabel sudah ada! Database sudah sinkron.\n\n";
        }
        
        // Cek juga apakah ada tabel ekstra yang tidak ada di SQL
        $extra = array_diff($existingTables, $expectedTables);
        if (count($extra) > 0) {
            echo "=== TABEL EKTRA (mungkin dari migrasi lain) ===\n";
            foreach ($extra as $t) {
                echo "  ? $t\n";
            }
            echo "\n";
        }
        
        // Dapatkan info kolom untuk tabel belakang
        echo "=== Sample: Info kolom tabel 'users' ===\n";
        $stmt = $pdo->query("DESCRIBE users");
        $cols = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($cols as $c) {
            echo "  {$c['Field']} ({$c['Type']})" . ($c['Null'] === 'NO' ? ' NOT NULL' : '') . ($c['Key'] === 'PRI' ? ' PRIMARY' : '') . "\n";
        }
        echo "\n";
        
        // Cek tabel cashier_shifts
        echo "=== Sample: Info kolom tabel 'cashier_shifts' ===\n";
        $stmt = $pdo->query("DESCRIBE cashier_shifts");
        $cols = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($cols as $c) {
            echo "  {$c['Field']} ({$c['Type']})" . ($c['Null'] === 'NO' ? ' NOT NULL' : '') . "\n";
        }
        echo "\n";
        
        // Cek jumlah record di beberapa tabel penting
        echo "=== Jumlah record di tabel penting ===\n";
        $importantTables = ['users', 'products', 'sales', 'cashier_shifts', 'branches', 'store_settings'];
        foreach ($importantTables as $t) {
            if (in_array($t, $existingTables)) {
                $count = $pdo->query("SELECT COUNT(*) FROM $t")->fetchColumn();
                echo "  $t: $count record\n";
            }
        }
    } else {
        echo "✗ database_full.sql tidak ditemukan!\n";
    }
    
} catch (PDOException $e) {
    echo "✗ Error koneksi database:\n";
    echo "  " . $e->getMessage() . "\n";
    echo "\nPastikan:\n";
    echo "  1. XAMPP MySQL sudah running\n";
    echo "  2. Database 'pos_kasir' sudah dibuat\n";
    echo "  3. File database_full.sql sudah di-import\n";
}
