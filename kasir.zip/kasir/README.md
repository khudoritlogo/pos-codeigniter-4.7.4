# 📱 POS KASIR — CodeIgniter 4.7.4 + AdminLTE 4

Aplikasi Point of Sale (Kasir) lengkap dengan 61+ fitur — Multi-Cabang, Multi-Level User, Kurir, Piutang/Hutang & Cicilan, Poin Loyalty, Shift Kasir, Stock Opname, Serial Number, FEFO, Cetak Struk Thermal, Barcode, Notifikasi Telegram Bot, **Modul Akuntansi (CoA, Jurnal Umum, Buku Besar, Neraca, Arus Kas, Laba Rugi)**, dan banyak lagi.

## 🧰 Requirement

| Software    | Versi Minimum |
|-------------|---------------|
| PHP         | 8.1 (extension: intl, mbstring, curl, gd, mysqli, mysqldump/mysql CLI, zip) |
| MySQL / MariaDB | 5.7 / 10.4 |
| Composer    | 2.x |
| Apache/Nginx| dengan `mod_rewrite` |
| Node/NPM    | tidak perlu (semua CSS/JS via CDN) |

Testing lokal cukup pakai **XAMPP** / **Laragon** / **WAMP**.

## 📦 Library Composer yang Otomatis Diinstall
- `codeigniter4/framework` — Framework utama
- `mike42/escpos-php` — Cetak struk thermal
- `picqer/php-barcode-generator` — Cetak barcode produk
- `dompdf/dompdf` — Generate PDF invoice
- `phpoffice/phpspreadsheet` — Import/Export Excel & CSV produk
- `phpmailer/phpmailer` — Kirim email via SMTP
- `chillerlan/php-qrcode` — Fallback QR generator

---

## 🚀 Cara Install (5 langkah)

### 1. Extract & Install Framework CodeIgniter 4.7.4

```bash
# Di direktori project (setelah download zip ini dan extract ke folder pos-app):
cd pos-app
composer install
# Composer akan otomatis mendownload:
#   - codeigniter4/framework ^4.7.4
#   - mike42/escpos-php (untuk print thermal)
#   - picqer/php-barcode-generator (untuk cetak barcode)
```

Jika belum punya composer: <https://getcomposer.org/download/>

### 2. Buat Database

**Cukuplah 1 perintah ini — jangan gunakan file SQL lainnya:**

```bash
mysql -u root -p pos_kasir < database_full.sql
```

`database_full.sql` adalah **satu-satunya file yang harus di-import**. File ini sudah berisi semua:
- Skema awal (`database.sql`)
- Migration v2 s.d. v8

**File berikut TIDAK digunakan untuk import — hanya sebagai referensi per-migration:**
- `database.sql`       ← hanya referensi skema base
- `database_v2.sql`    ← hanya referensi
- `database_v3.sql`    ← hanya referensi
- `database_v4.sql`    ← hanya referensi
- `database_v5.sql`    ← hanya referensi
- `database_v6.sql`    ← hanya referensi
- `database_v7.sql`    ← hanya referensi
- `database_v8.sql`    ← hanya referensi

> ⚠️ **Jangan import** `database.sql`, `database_v2.sql` s.d. `database_v8.sql` satu per satu — cukup `database_full.sql` saja. Import berurutan justru bisa menyebabkan duplikasi tabel & error FK.

### 3. Konfigurasi `.env`

```bash
cp .env.example .env
```

Edit `.env`, sesuaikan minimal:

```ini
CI_ENVIRONMENT = development
app.baseURL = 'http://localhost/pos-app/public/'

database.default.hostname = localhost
database.default.database = pos_kasir
database.default.username = root
database.default.password =

# (Opsional) Telegram Bot
telegram.botToken = 1234567:AAxxxxxx
telegram.chatId   = 123456789
```

### 4. Set Permission `writable/`

```bash
chmod -R 775 writable/
```

### 5. Jalankan

**Opsi A. Built-in PHP server (development):**

```bash
php spark serve
# akses: http://localhost/kasir
```

**Opsi B. Apache/XAMPP:**

Letakkan folder `pos-app` di `htdocs/`. Buka `http://localhost/pos-app/public/`.

**Opsi C. Nginx production:**

Arahkan `root` server block ke folder `pos-app/public`.

---

## 🔑 Akun Demo (password: `password123`)

| Username     | Level        | Akses |
|--------------|-------------|-------|
| `superadmin` | Super Admin | Semua fitur (Admin + Kasir + Kurir + System) |
| `admin`      | Admin       | Master data, transaksi, laporan (kecuali audit, backup, user) |
| `kasir`      | Kasir       | Kasir POS, customer, laporan pribadi |
| `kurir`      | Kurir       | Dashboard kurir, pengiriman, laporan pribadi |

---

## 🔒 Reset Password via Email (Lupa Password)

Fitur "Lupa Password" tersedia di halaman login. Alur:

### Setup Awal (WAJIB — 1x saja per user)
1. Login → menu **Profil Saya** (klik nama user di kanan atas)
2. Isi **Recovery Email** → klik **Simpan & Kirim Verifikasi**
3. Buka inbox email → klik link verifikasi (berlaku 24 jam)
4. Selesai — badge "Verified ✅" muncul di profil

### Setup SMTP Toko (wajib biar email keluar)
Menu **Pengaturan → SMTP** — isi contoh untuk Gmail:
```
SMTP Host       : smtp.gmail.com
SMTP Port       : 587
SMTP Username   : toko.anda@gmail.com
SMTP Password   : xxxx xxxx xxxx xxxx  (App Password, BUKAN password Gmail biasa)
Encryption      : tls
From Email      : toko.anda@gmail.com
From Name       : Nama Toko Anda
```
> Cara buat Gmail App Password (5 menit): https://myaccount.google.com/apppasswords
> Aktifkan 2FA dulu di akun Gmail, baru bisa generate App Password.

### Cara Reset Password Lupa
1. Login page → klik **"Lupa Password?"**
2. Input **Username** + **Recovery Email** yang sudah verified
3. Cek inbox email → klik tombol **Reset Password**
4. Set password baru (min 8 karakter, huruf + angka)
5. Login pakai password baru

### Fitur Keamanan
- 🔐 Token reset **1x pakai**, expired **30 menit**
- 📧 Notifikasi ke email lama saat recovery email diganti (cegah hijack)
- 📝 Semua aksi reset tercatat di audit log (kolom `action`: `password_reset_request`, `password_reset_success`, `update_recovery_email`, `verify_recovery_email`)
- 🛡️ Response generic untuk cegah user enumeration (attacker tidak tau username mana yang terdaftar)

### 🆘 Kalau Super Admin Lupa Password + Email Recovery Juga Hilang
Fallback pakai phpMyAdmin (akses server/hosting):
```sql
UPDATE users
SET password = '$2b$10$.PWqLU3jHJ/qAF0/B7AYN.2MGYrSmDfRRv4Z59liWc7qdK1mmv8UO'
WHERE username = 'superadmin';
-- password direset ke: password123
```
Setelah login, WAJIB langsung ganti password + set recovery email baru.

---

## 📋 Fitur Lengkap (61 Fitur)

### ✅ Master Data & Sistem
- CRUD Barang (dengan Multi-Satuan, Multi-Harga bertingkat, harga retail/grosir/member)
- CRUD Kategori, Satuan, Supplier, Ekspedisi, Customer
- Multi-Cabang & Transfer Stok Antar Cabang
- Level Customer (Regular, Silver, Gold, Platinum) dengan diskon otomatis
- Poin Loyalty (1 poin per Rp 10.000 belanja)
- Support Produk SN (Serial Number) dan Non-SN
- FEFO (First Expired First Out) — kelola tanggal kedaluwarsa & batch
- Manajemen Garansi berbasis SN

### 💰 Transaksi
- Kasir POS (barcode scan, grid produk, keranjang, shortcut keyboard F2)
- Transaksi Retail & Grosir (harga otomatis dari min. qty grosir)
- Diskon persentase & nominal, ongkir, pajak
- Metode: Cash, Transfer, QRIS, Piutang, Mixed
- Transaksi Pending
- Pemilihan Kurir berdasarkan status free / jumlah order aktif
- Pembelian dari Supplier + input SN + batch/expired
- Retur Penjualan & Retur Pembelian (stok otomatis)
- Piutang Customer + Cicilan Bertahap
- Hutang Supplier + Cicilan Bertahap
- Stock Opname (koreksi otomatis dari selisih fisik)

### 🖨️ Cetak & Barcode
- Cetak Struk Thermal (ESC/POS) via `mike42/escpos-php`
- Support ukuran kertas 58mm, 80mm, atau A4 (bisa diubah di Pengaturan)
- Cetak struk juga tersedia via browser (HTML print)
- Cetak Barcode produk (jumlah bebas) via `picqer/php-barcode-generator`

### 📊 Dashboard & Laporan
- Dashboard: barang terjual, jumlah barang/customer, invoice, chart omzet 7 hari, top produk, stok terkecil
- Laporan Penjualan per periode + export CSV/TXT
- Laporan Pembelian per periode + export
- Laporan Retur Penjualan & Pembelian
- Laporan Kasir, Kurir, Customer, Supplier (individu)
- Laporan Barang Terlaris & Stok Terkecil
- Laporan Cash vs Transfer vs QRIS vs Piutang
- Laporan Laba Bersih per periode (Omzet - HPP)
- Laporan Piutang & Hutang Menunggak

### 📒 Modul Akuntansi (Chart of Accounts, Jurnal, Buku Besar, Neraca, Arus Kas)

Sistem akuntansi terintegrasi dengan data transaksi toko — tiap penjualan & pembelian bisa terecord otomatis ke jurnal.

**Tabel & Struktur:**
- `chart_of_accounts` — Daftar akun (CoA) dengan 5 tipe: Asset, Liabilitas, Ekuitas, Income, Expense + tipe Contra & Memo. Sudah termasuk seed 34 akun standar akuntansi Indonesia (kode 1100 s.d. 5212).
- `financial_periods` — Periode akuntansi bulanan/tahunan (sudah di-seed 12 bulan 2025 + periode tahunan). Status `open`/`closed` untuk mengontrol apakah jurnal bisa masuk.
- `journal_entries` — Header jurnal umum: nomor urut (JE-2025-0001), tanggal, periode, referensi eksternal (NO.Faktur, NO.PO), status `draft`/`posted`.
- `journal_entry_items` — Detail jurnal: tiap baris punya akun tujuan + jumlah debit atau kredit. Kolom `reference_type` & `reference_id` menghubungkan jurnal dengan transaksi toko (sale, purchase, cogs, depreciation, dll).
- `ledger_entries` — Buku Besar denormalisasi per akun per periode (saldo awal, saldo akhir, total debit/kredit) — di-populasi saat jurnal dipost / periode ditutup.

**Laporan (VIEW):**
| VIEW | Keterangan |
|---|---|
| `vw_trial_balance` | Trial Balance: saldo per akun (debit, kredit, net) — cek apakah debit = kredit |
| `vw_income_statement` | Laporan Laba Rugi: Revenue → COGS → Gross Profit → Operating Expenses → Net Income |
| `vw_balance_sheet` | Neraca: Aktiva vs Liabilitas & Ekuitas + baris **Check: A = L + E** (harus 0/seimbang) |
| `vw_cash_flow` | Arus Kas metode tidak langsung: Operating (Net Income + penyesuaian non-kas + perubahan working capital) + Investing + Financing → Net Change in Cash |

**Cara pakai:**
1. **Master Akun** → lihat/edit Chart of Accounts. Tambah akun baru kalau perlu (misal kategori biaya khusus).
2. **Jurnal** → buat jurnal umum manual (adjustment, opening, closing, reversal) atau jurnal otomatis dari transaksi (sale/purchase → post ke akun revenue/COGS/piutang/utang).
3. **Buku Besar** → lihat saldo per akun per periode (bisa diselect berdasarkan periode).
4. **Laporan** → pilih periode → tampilkan Neraca, Laba Rugi, Arus Kas, atau Trial Balance dari VIEW.

**Integrasi otomatis (via `reference_type`):**
| reference_type | Akun tujuan |
|---|---|
| `sale` | Revenue (4101) + Piutang (1103) / Kas (1101) |
| `purchase` | Inventory (5101) + Utang (2101) / Kas (1102) |
| `cogs` | COGS (5100) + Inventory (1105) — saat barang terjual |
| `depreciation` | Depreciation Expense (5209) + Accumulated Depreciation (1205) |
| `fixed_asset_purchase` | Aset Tetap (1202/1203/1204) + Kas/Bank (1101/1102) |
| `loan` / `capital` | Utang Bank (2201) / Modal (3101) + Kas (1101/1102) |
| `loan_repayment` / `dividend` | Kas (1101/1102) + utang/modal berkurang |

> ⚠️ Modul akuntansi ini adalah foundation database & laporan. Implementasi Controller/Model/View (CRUD jurnal, UI laporan interaktif) masih perlu dikembangkan secara terpisah — struktur tabel & VIEW sudah siap pakai.

### 👥 Multi-User & Keamanan
- 4 Level: Super Admin, Admin, Kasir, Kurir (menu otomatis menyesuaikan)
- Manajemen Shift Kasir (Buka/Tutup dengan selisih kas)
- Audit Log semua aksi (login, void transaksi, CRUD sensitif)
- Otorisasi Void transaksi (hanya Super Admin & Admin)

### 🚚 Kurir & Integrasi
- Dashboard Kurir terintegrasi Google Maps (lihat lokasi delivery)
- Tombol Kirim WhatsApp ke customer (via `wa.me`)
- Notifikasi Telegram Bot ke Owner/Super Admin (omzet harian otomatis)
- QRIS static (tampilkan URL di struk)

### 🗄️ Sistem
- Backup Database ke `.sql` (via `mysqldump`)
- Restore Database via upload SQL
- Datatable client-side (jQuery DataTables) untuk semua list

---

## 🤖 Setup Telegram Bot (Ringkasan Harian + Interactive Commands)

Bot Telegram punya **2 mode**: (a) ringkasan omzet harian otomatis via cron, dan (b) interactive commands — owner ketik perintah untuk cek data real-time.

### Setup Umum
1. Buat bot di [@BotFather](https://t.me/BotFather), catat **Bot Token**.
2. Dapatkan **Chat ID** Owner: kirim pesan ke bot Anda, lalu buka `https://api.telegram.org/bot<TOKEN>/getUpdates` → cari `"chat":{"id": 123456789}`.
3. Login **Super Admin** → **Pengaturan** → tab **Integrasi** → isi Token & Chat ID → Simpan.

### A. Ringkasan Omzet Harian (Cron)
```cron
0 21 * * *  cd /path/to/pos-app && /usr/bin/php spark telegram:daily >> /var/log/pos-telegram.log 2>&1
```

Manual test: `php spark telegram:daily`

### B. Interactive Bot (Owner cek toko via chat)
1. Set webhook (hanya 1x, butuh HTTPS):
   ```
   https://your-domain.com/telegram/set-webhook?url=https://your-domain.com/telegram/webhook
   ```
   Untuk local testing gunakan `ngrok http 8080` untuk dapat URL HTTPS.
2. Buka Telegram, chat ke bot Anda, ketik salah satu:
   - `/omzet` — Omzet hari ini & bulan ini + laba
   - `/stok` — Ringkasan stok + alert produk menipis
   - `/piutang` — Total & jumlah piutang menunggak
   - `/hutang` — Total & jumlah hutang menunggak
   - `/top` — Top 5 produk terlaris bulan ini
   - `/kasir` — Kinerja kasir hari ini
   - `/kurir` — Status semua kurir
   - `/help` — Daftar perintah

---

## 🎁 Loyalty Reward Redeem (Tukar Poin)

Pelanggan yang punya poin bisa **menukarkan poinnya di kasir** dengan diskon atau produk gratis.

1. **Menu → Reward Loyalty** → tambah reward:
   - Discount Percent (contoh: 100 poin = diskon 5%)
   - Discount Nominal (contoh: 200 poin = potongan Rp 10.000)
   - Free Product (contoh: 500 poin = 1 kopi gratis)
2. Di **POS** → pilih customer → klik tombol **🎁 Poin** → modal tampilkan reward yang cukup poinnya → kasir pilih → diskon otomatis diterapkan → saat bayar, poin auto-dikurangi.

---

## 🎟️ Voucher & Kupon Promo

Buat kode voucher untuk diskon / gratis ongkir yang bisa dipakai customer di kasir.

1. **Menu → Voucher & Kupon** → tambah voucher:
   - Tipe: Persen (%), Nominal (Rp), atau Free Shipping
   - Kuota total & per customer, min. belanja, max. diskon, tanggal berlaku
   - Bisa dibatasi ke level customer tertentu
2. Contoh siap pakai (sudah di-seed): `WELCOME10`, `POTONG25K`, `FREEONGKIR`
3. Di **POS** → input kode voucher → klik ikon tag → sistem validasi & terapkan diskon otomatis.

---

## 🚚 Multi-Kurir Route Planner (Google Maps)

Kurir yang punya banyak order sekaligus bisa **mengoptimasi rute** dengan algoritma Google Maps (waypoint optimization).

**Prasyarat**: Google Maps API key dengan API aktif:
- Maps JavaScript API
- Directions API
- Places API
- Geocoding API

1. Isi API key di **Pengaturan → Integrasi → Google Maps API Key**
2. Login sebagai **Kurir** → menu **Route Planner**
3. Pilih 2-10 order yang akan diantar (yang punya lat/lng)
4. Isi titik awal (kosongkan = pakai default) → klik **Optimasi Rute**
5. Sistem tampilkan urutan terpendek + estimasi jarak & waktu di peta
6. Klik **Simpan Rute** → tersimpan di database untuk laporan

---

## 📡 Kurir Live Tracking (Customer Lacak Paket Real-Time)

Customer bisa lacak posisi kurir yang sedang mengantar paketnya, mirip aplikasi ojek online.

### Setup di sisi Kurir
1. Login sebagai kurir → **Dashboard Kurir** → klik tombol **"Aktifkan Live Tracking"** (izinkan akses GPS di browser)
2. Browser akan mengirim koordinat GPS tiap kali posisi berubah signifikan (butuh HTTPS untuk GPS di production)
3. Untuk running di background, buka di **HP Android** via Chrome / gunakan aplikasi PWA installer

### Cara Customer Melacak
1. Kasir/Admin buka detail invoice → klik **"Lacak Kiriman"**
2. Kirim URL `https://your-domain.com/track/{invoice_no}` ke customer via WhatsApp/SMS
3. Customer buka link → lihat peta real-time dengan:
   - Posisi kurir (titik biru) — auto-refresh tiap 10 detik
   - Alamat tujuan (pin merah)
   - Status delivery (pending / dalam perjalanan / terkirim)
   - Info kurir + tombol call & WhatsApp langsung
4. Halaman ini publik (tanpa login) & mobile-friendly

---

## 🎟️ Voucher QR Marketing (Share via WhatsApp)

Buat kode voucher lalu share ke customer via WhatsApp lengkap dengan QR code untuk redemption yang mudah.

1. **Voucher & Kupon** → klik tombol **🔗 Share** pada voucher
2. Sistem generate:
   - **QR Code** yang berisi URL landing `/v/{code}` — customer scan → langsung buka halaman voucher cantik
   - **Barcode** siap cetak
   - **Template pesan WA** — bisa diedit sebelum kirim
3. Isi nomor WA customer → klik **Kirim** → langsung buka WhatsApp dengan pesan siap kirim
4. Bisa juga cetak QR (siap tempel di kasir/leaflet) → customer scan → auto-buka detail voucher
5. Semua share dicatat di `voucher_shares` untuk analisis

**Landing page publik** (`/v/welcome10`):
- Design mobile-friendly seperti tiket
- Tombol "Salin Kode" 1-tap
- Info min. belanja, kuota tersisa, tanggal berlaku
- Tombol WhatsApp toko

---

## 📊 Predictive Restock (Prediksi Habis Stok)

Sistem otomatis menganalisis penjualan historis untuk memprediksi kapan stok akan habis, supaya admin bisa order ke supplier **sebelum kehabisan**.

1. **Laporan → Predictive Restock**
2. Sistem hitung:
   - Total qty terjual dalam **30 hari terakhir** (bisa diubah)
   - **Rata-rata penjualan per hari**
   - **Prediksi hari sampai habis** = stok saat ini / rata-rata harian
3. Tampilkan produk yang akan habis dalam ≤ **7 hari** (bisa diubah) dengan color code:
   - 🔴 **Merah** (< 3 hari): Order SEGERA
   - 🟡 **Kuning** (3-7 hari): Order minggu ini
   - 🔵 **Biru** (> 7 hari): Monitor
4. Estimasi qty order & biaya berdasarkan kebutuhan **stok 14 hari** ke depan
5. Filter per-cabang (khusus branch untuk non-super-admin)

---

## 🏆 Multi-Level Reward Tier

Reward loyalty bisa dibatasi hanya untuk level customer tertentu (Regular, Silver, Gold, Platinum).

1. **Reward Loyalty** → buat/edit reward → pilih **Level Customer** yang berhak (multi-select) → kosongkan = semua bisa akses
2. Contoh: Reward "Diskon 15%" hanya untuk Gold & Platinum
3. Set **Priority Tampil** untuk mengatur urutan reward di modal kasir (angka besar = paling atas)
4. Di POS: modal reward otomatis filter — customer Regular hanya lihat reward untuk levelnya

---

## 📦 Auto-Order Supplier (Purchase Order Otomatis)

Sistem generate PO draft otomatis untuk produk yang stoknya mendekati habis.

### Setup Produk
1. Master Data → Barang → edit produk → set **Default Supplier**, **Reorder Qty**, **Target Stok (hari)**

### Cara Kerja
- **Manual trigger**: Menu **Purchase Order** → klik **"Auto-Generate dari Predictive Restock"**
- **Cron otomatis** (rekomendasi harian jam 3 pagi):
  ```cron
  0 3 * * *  cd /path/to/pos-app && /usr/bin/php spark po:auto-generate >> /var/log/pos-po.log 2>&1
  ```
- Sistem akan:
  1. Analisis produk yang stoknya < 7 hari sisa (berdasar penjualan 30 hari)
  2. Group per supplier + cabang
  3. Buat PO Draft (idempotent — tidak dobel dalam 1 hari)
  4. Detail item + estimasi qty untuk stok 14 hari
- **Kirim ke supplier**: Klik tombol WA → pesan formal dengan detail item siap kirim
- **Convert**: Setelah supplier konfirmasi & barang datang → klik "Convert ke Pembelian" → stok auto-update, hutang auto-tercatat

---

## 📢 WhatsApp Blast Voucher

Kirim voucher/promo ke ratusan customer sekaligus dengan filter segmen.

1. **Menu → WA Blast Voucher → Buat Blast**
2. Pilih voucher (opsional), template pesan dengan variabel: `{nama}`, `{poin}`, `{spent}`
3. Filter target: level customer, min. total belanja, min. poin, aktif belanja X hari terakhir
4. Klik **Preview** untuk lihat berapa customer & sample
5. Klik **Buat Campaign** → sistem simpan daftar recipient
6. Dua mode kirim:
   - **Manual**: Klik tombol WA per baris → buka WhatsApp Web dengan pesan siap kirim (untuk volume kecil / gratis)
   - **Gateway API**: Klik "Kirim via Gateway API" → sistem kirim otomatis via WA Gateway (Fonnte, Wablas, dsb — set URL & Token di Pengaturan)
7. Status per recipient tercatat (pending / sent / failed) untuk retry

---

## 🏆 Kurir Leaderboard

Ranking bulanan kurir berdasar delivery, jarak, dan rating customer.

1. **Laporan → Leaderboard Kurir** → pilih bulan
2. Tampilkan podium Top 3 (Gold/Silver/Bronze) + full ranking
3. Metrik: Total Order, Delivered, Avg Rating (⭐), Jarak Tempuh (km dari GPS tracking), Total Omzet
4. **Formula Poin** = (Delivered × 10) + (Avg Rating × 20) + (Jarak × 0.5)
5. Achievement per bulan auto-tercatat di `courier_achievements` untuk history

### Customer Beri Rating
- Kasir/admin share link `https://your-domain.com/rate/{invoice_no}` ke customer via WA
- Customer buka link → pilih bintang 1-5 + review → auto-tersimpan
- Rating masuk perhitungan leaderboard

---

## 📡 Live Sales Ticker

Owner monitor transaksi real-time dari dashboard dimanapun.

- Widget banner "LIVE" di top dashboard auto-refresh tiap 5 detik
- Tampilkan transaksi terbaru: invoice, total, item count, customer, kasir, cabang
- Toast notification pop-up + suara "cha-ching" tiap ada transaksi baru
- Counter hari ini: jumlah transaksi + total omzet update real-time
- Multi-cabang: super admin lihat semua cabang, admin/kasir hanya cabangnya

---

## 🤖 AI Sales Assistant (Gemini)

Owner tanya pertanyaan bebas ke AI yang punya konteks data toko real-time.

1. Dapatkan **Gemini API Key** gratis di https://aistudio.google.com/app/apikey
2. **Pengaturan → Integrasi → AI Assistant** → paste API Key → Simpan
3. Menu **AI Assistant** → tanya apa saja, contoh:
   - "Berapa omzet minggu ini?"
   - "Produk apa yang paling laris bulan ini?"
   - "Kasir siapa yang top performer hari ini?"
   - "Barang apa yang harus segera direstock?"
4. Sistem otomatis inject data toko (omzet harian/mingguan/bulanan, top 5 produk, stok kritis, piutang/hutang, kasir performance) ke context Gemini sebelum tanya
5. Riwayat chat tersimpan per user untuk lanjutan diskusi

---

## 🎁 Referral Program

Customer dapat poin/voucher tiap ajak teman yang belanja pertama kali.

1. **Menu → Referral Program** → set poin referrer/referee, min. belanja pertama, deadline hari
2. Tiap customer otomatis punya `referral_code` unik (contoh: REF00042)
3. Share link `https://your-domain.com/ref/REF00042` ke teman
4. Teman buka link → daftar (nama + HP) → status "pending"
5. Saat teman belanja pertama ≥ min. purchase → auto trigger reward: poin masuk ke kedua customer
6. Leaderboard top referrer + riwayat semua event di halaman Referral

---

## 📷 Mobile Barcode Scanner

App mobile web untuk stock opname dengan kamera HP scan barcode langsung.

1. Buka **Menu → Mobile Scanner** dari HP (butuh HTTPS untuk kamera di production)
2. Klik **Aktifkan Kamera** → arahkan ke barcode produk → auto-scan (pakai `@zxing/browser`)
3. Vibrate feedback + produk otomatis muncul dengan info: nama, harga, kategori, satuan, stok saat ini
4. Aksi cepat: **Set Stok** (opname), **Tambah** stok (restock), **Kurang** stok (damaged/lost)
5. Bisa juga input barcode manual jika kamera tidak tersedia
6. Semua adjustment tercatat di audit log

---

## 📺 Dashboard TV Mode

Tampilan fullscreen dashboard untuk TV monitor toko dengan animasi omzet real-time.

1. Menu **TV Mode** (buka di tab baru) → set fullscreen (F11)
2. Layout:
   - **Kiri (Hero)**: Omzet hari ini dengan angka besar 6rem + glow effect + counter transaksi + omzet bulan
   - **Kanan atas**: Top 5 produk hari ini dengan ranking
   - **Kanan bawah**: Feed transaksi terbaru real-time (auto slide-in animasi)
3. Poll `/api/live-ticker/feed` tiap 5 detik untuk update omzet & feed
4. Auto full-reload tiap 5 menit untuk refresh top produk
5. Cocok untuk TV kasir / monitor besar di toko untuk display live

---

## 📱 Kasir Mobile PWA (Install ke HP)

Aplikasi POS kini bisa **di-install di HP** kasir/staff seperti native app (offline capable).

### Cara Install (Chrome/Edge di HP Android)
1. Buka POS dari HP: `https://domain-anda.com/sales/pos`
2. Muncul notifikasi/banner **"Install App"** di navbar → tap
3. Icon **POS Kasir** muncul di home screen HP
4. Buka dari icon → tampil fullscreen tanpa address bar
5. Setelah pertama kali online, **CSS/JS ter-cache** — bisa scan produk offline (transaksi POST tetap butuh online)

### File PWA
- `/public/manifest.webmanifest` — metadata app (nama, icon, warna, shortcut)
- `/public/service-worker.js` — cache strategy (app-shell cache-first, halaman network-first)
- `/public/assets/pwa/icon-192.png` & `icon-512.png` — **WAJIB Anda ganti** dengan logo toko sebelum go-live

### Customer Self-Service PWA (bonus)
Endpoint `GET /app` menyediakan halaman OTP-login untuk **customer** cek voucher, riwayat belanja, poin loyalty, dan link referral — bisa dishare via WhatsApp.

---

## 🏢 Franchise Multi-Owner + HQ Dashboard

Skema ini mendukung **brand franchise besar** yang punya banyak cabang milik owner berbeda, sekaligus **Master Franchise (HQ)** yang bisa melihat roll-up seluruh cabang.

### Role Baru
| Level Code       | Akses                                                                  |
|------------------|------------------------------------------------------------------------|
| `super_admin`    | Semua franchise + semua cabang (owner platform)                        |
| `franchise_hq`   | HANYA franchise miliknya, tapi **semua cabang** dalam franchise itu    |
| `franchise`      | Multi-cabang lewat tabel `user_branches` (owner cabang saja)           |
| `admin` / `kasir`| 1 cabang (default `branch_id` di session)                              |

### Setup
1. Import `database_v7.sql` — otomatis membuat tabel `franchises`, `user_branches`, dan menambah kolom `branches.franchise_id`
2. Buat user dengan level **Master Franchise (HQ)** di menu **User & Level**
3. Insert data franchise via SQL / menu master (contoh):
   ```sql
   INSERT INTO franchises (code, name, hq_user_id, royalty_percent, is_active, created_at)
   VALUES ('MYBRAND', 'My Brand Coffee', 5, 3.5, 1, NOW());
   ```
4. Update kolom `branches.franchise_id` untuk cabang yang milik brand ini
5. Login sebagai HQ → menu **Franchise → HQ Dashboard** → pilih franchise → lihat:
   - Total omzet hari ini & bulan ini (semua cabang)
   - Estimasi royalty HQ (berdasarkan % di tabel `franchises`)
   - Roll-up per cabang: transaksi, omzet hari ini, omzet bulan

---

## 🎙️ Voice Command Kasir

Kasir bisa input keranjang **hanya dengan suara** — cocok untuk yang tangan penuh.

### Cara Pakai
1. Di halaman POS, klik ikon **mikrofon** (kuning, sebelah tombol scan)
2. Ucapkan dalam Bahasa Indonesia: `"kopi 2, indomie 3, aqua 1"` (nama produk & qty)
3. Sistem auto-search produk cocok & tambah ke keranjang
4. Klik mikrofon lagi untuk stop

### Requirement
- Chrome/Edge (Web Speech API) — Firefox belum support
- Butuh **HTTPS** di production (browser kebijakan)
- Bahasa: `id-ID` (Indonesia) — sudah di-set default

---

## 🤖 AI Menu Recommender (Upsell Otomatis)

Setelah kasir scan / pilih 1 produk, sistem otomatis munculkan **"Sering dibeli bersama"** (co-occurrence dari data sales history) sebagai tombol tambah cepat.

### Cara Kerja
1. Cron/manual jalankan: `POST /recommender/rebuild` (analisis semua sales history → co-occurrence pair)
2. Data tersimpan di tabel `product_recommendations` (product_id ↔ recommended_id + score)
3. Saat kasir tambah produk ke cart → fetch `GET /api/recommender/for/{productId}` → tampilkan 3 top rekomendasi upsell

### Trigger Rebuild
```bash
# Manual via curl
curl -X POST https://domain-anda.com/recommender/rebuild
# Atau tambahkan cron harian jam 2 pagi:
0 2 * * * curl -X POST https://domain-anda.com/recommender/rebuild
```

---

## 🖨️ Setup Printer Thermal

Edit method `printReceipt()` di `app/Libraries/ThermalPrinter.php`, pilih connector sesuai OS:

```php
// Windows shared printer:
$connector = new WindowsPrintConnector('POS-58');

// Network printer (LAN, port 9100):
$connector = new NetworkPrintConnector('192.168.1.100', 9100);

// USB Linux:
$connector = new FilePrintConnector('/dev/usb/lp0');
```

Ukuran kertas & font diatur via **Pengaturan → Struk Printer**.

---

## 💳 Setup QRIS Dynamic (Midtrans / Xendit)

Aplikasi mendukung **dua provider** — user bisa memilih di Pengaturan.

### Midtrans
1. Daftar di https://midtrans.com (Sandbox gratis)
2. Dashboard → Settings → Access Keys → copy **Server Key** & **Client Key**
3. **Pengaturan → Integrasi → QRIS Dynamic** → pilih Midtrans → paste keys → Mode Sandbox
4. **Payment Notification URL**: copy URL dari halaman Pengaturan (biasanya `https://domain-anda.com/qris/callback`) → paste ke dashboard Midtrans → Settings → Configuration → Payment Notification URL
5. Test di POS: klik tombol **"Buat QRIS Dynamic"** → QR akan muncul, scan pakai app pembayaran → status auto-update

### Xendit
1. Daftar di https://xendit.co (Test Mode gratis)
2. Dashboard → Settings → API Keys → generate **Secret Key**
3. **Pengaturan → Integrasi → QRIS Dynamic** → pilih Xendit → paste Secret Key → Mode Test
4. **Callback URL**: `https://domain-anda.com/qris/callback?provider=xendit`
5. Set Callback Verification Token di Xendit → paste ke field yang sesuai di aplikasi

**Flow:** Klik "Buat QRIS Dynamic" di POS → sistem generate QR dengan nominal otomatis → customer scan → provider kirim webhook ke `/qris/callback` → status transaksi auto-update → checkout otomatis triggered.

---

## 📥 Import Produk Massal (CSV / XLSX)

1. **Master Data → Import Produk** → klik **Template XLSX** atau **Template CSV** untuk download template
2. Isi data di Excel/LibreOffice sesuai kolom: `barcode, sku, name, category, unit, cost_price, sell_price, wholesale_price, min_wholesale_qty, stock_alert, has_serial_number, has_expired_date, warranty_months`
3. Kategori & Satuan yang belum ada akan **otomatis dibuat**
4. Barcode/SKU yang cocok dengan produk yang sudah ada akan **diupdate**, sisanya **ditambah** baru
5. Upload file → sistem tampilkan ringkasan (imported / updated / failed) + detail error per baris

---

## 🖥️ Customer Facing Display (CFD)

Layar kedua untuk pelanggan agar bisa melihat item, subtotal, dan total secara **real-time**.

**Cara pakai:**
1. Buka POS di komputer kasir
2. Klik tombol **"Buka CFD"** di halaman POS → window baru terbuka di URL `/cfd/{branch_id}/{cashier_id}`
3. Drag window tersebut ke monitor kedua (pelanggan), fullscreen (F11)
4. Setiap kali kasir menambah/mengubah item, CFD **auto-refresh** dalam < 1 detik (polling JSON)

**Fitur CFD:**
- Nama toko, alamat, jam real-time
- List item + qty + harga + subtotal
- Total besar & mencolok
- Area promo/pesan (bisa dikustom via API)
- Tampilan modern (gradient biru, glassmorphism)

**URL langsung**: `http://your-pos.com/cfd/1/3` (branch 1, cashier user ID 3) — bisa dibuka tanpa login.

---

## 📧 Cetak Invoice PDF & Kirim via Email

1. **Pengaturan → Integrasi → SMTP**: isi Host, Port, Username (email Anda), Password (app password Gmail!), Enkripsi TLS/SSL, Nama & Email pengirim
2. Buka **Data Penjualan → detail invoice**
3. Klik:
   - **"Lihat PDF"** → buka PDF di tab baru
   - **"Unduh PDF"** → download `.pdf`
   - **"Kirim Email"** → modal muncul, isi email customer, PDF invoice otomatis dilampirkan

**Gmail SMTP setup cepat:**
- Host: `smtp.gmail.com` | Port: `587` | Enkripsi: `TLS`
- Username: email Gmail Anda | Password: [App Password](https://myaccount.google.com/apppasswords) (bukan password biasa!)

---

## 📁 Struktur Folder

```
pos-app/
├── app/
│   ├── Commands/           # CLI (spark telegram:daily)
│   ├── Config/             # Routes, Filters, Database, App
│   ├── Controllers/        # Auth, Dashboard, Sales, Products, dst
│   │   └── Api/            # JSON endpoints untuk AJAX
│   ├── Filters/            # AuthFilter, RoleFilter
│   ├── Libraries/          # TelegramService, ThermalPrinter, BackupService, BarcodeService
│   ├── Models/             # BaseCrudModel + semua model per tabel
│   └── Views/              # AdminLTE 4 layouts + halaman
├── public/                 # DocumentRoot untuk web server
│   ├── index.php
│   └── .htaccess
├── writable/               # cache, logs, uploads (perlu writable 775)
├── database_full.sql       # ★ **Satu-satunya file SQL yang di-import ke MySQL**
├── database.sql           # ← HANYA referensi (skema base + seed — jangan di-import)
├── database_v2.sql       # ← HANYA referensi migration v2 — jangan di-import
├── database_v3.sql       # ← HANYA referensi migration v3 — jangan di-import
├── database_v4.sql       # ← HANYA referensi migration v4 — jangan di-import
├── database_v5.sql       # ← HANYA referensi migration v5 — jangan di-import
├── database_v6.sql       # ← HANYA referensi migration v6 — jangan di-import
├── database_v7.sql       # ← HANYA referensi migration v7 — jangan di-import
├── database_v8.sql       # ← HANYA referensi migration v8 — jangan di-import
├── composer.json
└── README.md               # File ini
```

---

## ⚠️ Catatan Deployment Production

1. Set `CI_ENVIRONMENT = production` di `.env`
2. Set `app.forceGlobalSecureRequests = true` jika sudah pakai HTTPS
3. Generate encryption key baru:
   ```bash
   php spark key:generate
   ```
4. Optimize composer:
   ```bash
   composer install --optimize-autoloader --no-dev
   ```
5. Set writable folder ke owner web server (www-data) dengan permission 775
6. Konfigurasikan cron untuk `telegram:daily`

---

## 🐛 Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Halaman `Not Found` | Pastikan `mod_rewrite` aktif & `AllowOverride All` di Apache config |
| CSS/JS tidak muncul | Cek `app.baseURL` di `.env` benar |
| Print thermal error | Install `mike42/escpos-php` via composer + set connector yang benar |
| Backup gagal | Pastikan `mysqldump` ada di PATH server |
| Telegram tidak terkirim | Cek Token & Chat ID di Pengaturan + koneksi internet server |

---

## 📄 Lisensi
MIT — Bebas digunakan untuk keperluan komersial. Dibangun dengan ❤️ menggunakan CodeIgniter 4 & AdminLTE 4.
