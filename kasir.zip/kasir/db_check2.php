<?php
/**
 * Database Checker for pos_kasir
 * Mengecek struktur, kunci asing, dan potensi masalah tabel
 */

$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'pos_kasir';

echo "╔══════════════════════════════════════════════════════════╗\n";
echo "║          DATABASE CHECKER - pos_kasir                     ║\n";
echo "╚══════════════════════════════════════════════════════════╝\n\n";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ]);
    
    // 1. LIST SEMUA TABEL
    echo "── Tabel yang ada di pos_kasir ──\n\n";
    $stmt = $pdo->query("SELECT TABLE_NAME, TABLE_ROWS, DATA_LENGTH, INDEX_LENGTH 
                          FROM information_schema.TABLES 
                          WHERE TABLE_SCHEMA = '$db' 
                          ORDER BY TABLE_NAME");
    $tables = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    $totalRows = 0;
    $totalSize = 0;
    
    foreach ($tables as $t) {
        $totalRows += $t['TABLE_ROWS'];
        $totalSize += ($t['DATA_LENGTH'] + $t['INDEX_LENGTH']);
        $rows = number_format($t['TABLE_ROWS']);
        $size = number_format(($t['DATA_LENGTH'] + $t['INDEX_LENGTH']) / 1024, 1) . ' KB';
        $flag = $t['TABLE_ROWS'] == 0 ? '⚠ Kosong' : '';
        printf("  %-35s rows: %6s  size: %8s  %s\n", $t['TABLE_NAME'], $rows, $size, $flag);
    }
    
    echo "\nTotal tabel: " . count($tables) . "\n";
    echo "Total record: " . number_format($totalRows) . "\n";
    echo "Total size: " . number_format($totalSize / 1024 / 1024, 2) . " MB\n\n";
    
    // 2. CEK TABEL YANG PENUH (data tidak masuk akal)
    echo "── Potensi masalah ──\n\n";
    
    // Cek tabel dengan 0 record tapi seharusnya ada data
    $emptyImportant = ['users', 'products', 'categories', 'branches', 'store_settings', 
                       'cashier_shifts', 'sales', 'customers', 'suppliers', 'units'];
    foreach ($emptyImportant as $t) {
        $stmt = $pdo->query("SELECT COUNT(*) FROM $t");
        $count = $stmt->fetchColumn();
        if ($count == 0) {
            echo "  ⚠ Tabel '$t' TIDAK PUNYA RECORD (seharusnya punya data)\n";
        }
    }
    
    // 3. CEK STRUKTUR TABEL PENTING
    echo "\n── Struktur tabel kritis ──\n\n";
    
    $criticalTables = [
        'users' => ['id', 'username', 'password', 'level_code', 'branch_id', 'is_active'],
        'products' => ['id', 'name', 'sku', 'stock', 'harga_jual', 'harga_beli', 'kategori_id'],
        'sales' => ['id', 'invoice_no', 'customer_id', 'user_id', 'branch_id', 'total', 'status'],
        'sale_items' => ['id', 'sale_id', 'product_id', 'qty', 'harga', 'diskon'],
        'cashier_shifts' => ['id', 'user_id', 'branch_id', 'status', 'opening_cash'],
        'store_settings' => ['id', 'store_name', 'store_address', 'store_phone', 'cashier_name'],
        'branches' => ['id', 'nama_cabang', 'alamat', 'telepon', 'owner_id'],
        'categories' => ['id', 'nama', 'is_active'],
        'units' => ['id', 'nama', 'symbol', 'is_active'],
        'customers' => ['id', 'nama', 'telepon', 'alamat', 'tanggal_lahir'],
        'suppliers' => ['id', 'nama', 'telepon', 'alamat'],
        'expeditions' => ['id', 'nama', 'phone', 'address', 'is_active'],
        'receivables' => ['id', 'invoice_no', 'customer_id', 'user_id', 'amount', 'due_date', 'status'],
        'payables' => ['id', 'invoice_no', 'supplier_id', 'user_id', 'amount', 'due_date', 'status'],
        'chart_of_accounts' => ['id', 'kode', 'nama', 'tipe_akun', 'parent_id', 'is_active'],
        'journal_entries' => ['id', 'nomor', 'tanggal', 'keterangan', 'status'],
        'journal_entry_items' => ['id', 'journal_id', 'akun_id', 'debit', 'kredit'],
        'ledger_entries' => ['id', 'journal_id', 'akun_id', 'debit', 'kredit'],
        'fixed_asset_register' => ['id', 'nama_aset', 'kode_aset', 'tanggal_beli', 'nilai_beli', 'umur_ekonomis'],
        'financial_periods' => ['id', 'nama_periode', 'tanggal_mulai', 'tanggal_selesai', 'status'],
        'licenses' => ['id', 'license_key', 'status', 'domain', 'ip_address', 'customer_name'],
        'loyalty_rewards' => ['id', 'name', 'description', 'points_required', 'is_active'],
        'loyalty_transactions' => ['id', 'user_id', 'points', 'type', 'description'],
        'purchase_orders' => ['id', 'nomor', 'supplier_id', 'user_id', 'tanggal', 'status'],
        'purchase_order_items' => ['id', 'purchase_order_id', 'product_id', 'qty', 'harga'],
        'vouchers' => ['id', 'code', 'discount_type', 'discount_value', 'min_purchase', 'expired_at', 'is_active'],
        'stock_opnames' => ['id', 'user_id', 'branch_id', 'tanggal', 'status'],
        'stock_opname_items' => ['id', 'stock_opname_id', 'product_id', 'stok_awal', 'stok_akhir'],
        'stock_transfers' => ['id', 'from_branch_id', 'to_branch_id', 'user_id', 'tanggal', 'status'],
        'stock_transfer_items' => ['id', 'stock_transfer_id', 'product_id', 'qty'],
        'purchase_returns' => ['id', 'purchase_order_id', 'user_id', 'tanggal', 'status'],
        'purchase_return_items' => ['id', 'purchase_return_id', 'product_id', 'qty'],
        'sale_returns' => ['id', 'sale_id', 'user_id', 'tanggal', 'status'],
        'sale_return_items' => ['id', 'sale_return_id', 'product_id', 'qty'],
        'ai_chat_sessions' => ['id', 'user_id', 'title', 'created_at'],
        'ai_chat_messages' => ['id', 'session_id', 'role', 'content', 'created_at'],
        'audit_logs' => ['id', 'user_id', 'module', 'action', 'description', 'ip_address'],
        'referral_config' => ['id', 'code', 'discount', 'max_uses', 'is_active'],
        'referral_events' => ['id', 'user_id', 'event', 'redeemed_by', 'created_at'],
        'payment_transactions' => ['id', ' sale_id', 'method', 'amount', 'status', 'external_ref'],
        'voucher_shares' => ['id', 'voucher_id', 'share_code', 'used_by', 'used_at'],
        'wa_broadcasts' => ['id', 'message', 'status', 'sent_at'],
        'wa_broadcast_recipients' => ['id', 'wa_broadcast_id', 'phone', 'status'],
        'telegram_subscribers' => ['id', 'chat_id', 'fullname', 'phone'],
        'telegram_message_logs' => ['id', 'user_id', 'message', 'response', 'created_at'],
        'customer_tokens' => ['id', 'customer_id', 'token', 'expired_at'],
        'email_verifications' => ['id', 'user_id', 'token', 'verified_at'],
        'password_resets' => ['id', 'user_id', 'token', 'expires_at'],
        'bank_statements' => ['id', 'tanggal', 'keterangan', 'debit', 'kredit'],
        'courier_locations' => ['id', 'user_id', 'lat', 'lng', 'created_at'],
        'courier_routes' => ['id', 'from_branch_id', 'to_branch_id', 'estimated_duration'],
        'courier_achievements' => ['id', 'user_id', 'achievement_type', 'date'],
        'product_price_tiers' => ['id', 'product_id', 'min_qty', 'harga'],
        'product_stocks' => ['id', 'product_id', 'branch_id', 'stock'],
        'product_serials' => ['id', 'product_id', 'serial_number', 'status'],
        'product_batches' => ['id', 'product_id', 'batch_code', 'expired_date'],
        'product_import_logs' => ['id', 'filename', 'rows', 'status', 'created_at'],
        'product_recommendations' => ['id', 'product_id', 'recommended_product_id', 'score'],
        'pos_display_states' => ['id', 'kiosk_id', 'display_mode', 'updated_at'],
        'user_branches' => ['id', 'user_id', 'branch_id'],
        'user_levels' => ['id', 'name', 'level_code', 'permissions'],
        'customer_levels' => ['id', 'name', 'discount', 'description', 'is_active'],
        'franchises' => ['id', 'nama', 'alamat', 'owner_id', 'status'],
        'loyalty_redemptions' => ['id', 'user_id', 'reward_id', 'points_used', 'created_at'],
        'license_logs' => ['id', 'license_id', 'action', 'old_status', 'new_status', 'performed_by'],
        'license_notifications' => ['id', 'license_id', 'type', 'sent_at', 'is_read'],
        'referral_config' => ['id', 'code', 'discount', 'max_uses', 'is_active'],
        'referral_events' => ['id', 'user_id', 'event', 'redeemed_by', 'created_at'],
        'payment_transactions' => ['id', ' sale_id', 'method', 'amount', 'status', 'external_ref'],
        'voucher_shares' => ['id', 'voucher_id', 'share_code', 'used_by', 'used_at'],
        'wa_broadcasts' => ['id', 'message', 'status', 'sent_at'],
        'wa_broadcast_recipients' => ['id', 'wa_broadcast_id', 'phone', 'status'],
        'telegram_subscribers' => ['id', 'chat_id', 'fullname', 'phone'],
        'telegram_message_logs' => ['id', 'user_id', 'message', 'response', 'created_at'],
        'customer_tokens' => ['id', 'customer_id', 'token', 'expired_at'],
        'email_verifications' => ['id', 'user_id', 'token', 'verified_at'],
        'password_resets' => ['id', 'user_id', 'token', 'expires_at'],
        'bank_statements' => ['id', 'tanggal', 'keterangan', 'debit', 'kredit'],
        'courier_locations' => ['id', 'user_id', 'lat', 'lng', 'created_at'],
        'courier_routes' => ['id', 'from_branch_id', 'to_branch_id', 'estimated_duration'],
        'courier_achievements' => ['id', 'user_id', 'achievement_type', 'date'],
    ];
    
    foreach ($criticalTables as $table => $expectedCols) {
        $stmt = $pdo->query("DESCRIBE $table");
        $actualCols = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        $missing = array_diff($expectedCols, $actualCols);
        
        if (count($missing) > 0) {
            echo "  ✗ $table — Kolom hilang: " . implode(', ', $missing) . "\n";
        } else {
            echo "  ✓ $table — Struktur OK\n";
        }
    }
    
    // 4. CEK VIEW
    echo "\n── Views ──\n\n";
    $stmt = $pdo->query("SHOW FULL TABLES WHERE TABLE_TYPE = 'VIEW'");
    $views = $stmt->fetchAll(PDO::FETCH_COLUMN);
    foreach ($views as $v) {
        echo "  ▸ $v\n";
    }
    
    // 5. CEK TABEL KOSONG YANG PENTING
    echo "\n── Tabel dengan 0 record (perlu diisi) ──\n\n";
    foreach ($emptyImportant as $t) {
        $stmt = $pdo->query("SELECT COUNT(*) FROM $t");
        $count = $stmt->fetchColumn();
        $name = str_replace('_', ' ', ucwords($t));
        if ($count == 0) {
            echo "  ⚠️  $t ($name): 0 record\n";
        }
    }
    
    // 6. SUMMARY
    echo "\n╔══════════════════════════════════════════════════════════╗\n";
    echo "║                      RINGKASAN                            ║\n";
    echo "╚══════════════════════════════════════════════════════════╝\n\n";
    
    $issues = [];
    
    // Check if brand table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'brands'");
    if (!$stmt->fetchColumn()) {
        $issues[] = "Tabel 'brands' HILANG (di-referenced oleh controller Brands.php)";
    }
    
    // Check key junction tables
    $junctionTables = ['user_branches', 'product_stocks', 'stock_movements'];
    foreach ($junctionTables as $t) {
        $stmt = $pdo->query("SELECT COUNT(*) FROM $t");
        if ($stmt->fetchColumn() == 0) {
            $issues[] = "Tabel '$t' kosong tapi digunakan untuk relasi";
        }
    }
    
    if (count($issues) > 0) {
        echo "IsUES YANG PERLU DI-SOLUSI:\n";
        foreach ($issues as $i) {
            echo "  • $i\n";
        }
    } else {
        echo "✓ Tidak ada isu struktural kritis\n";
    }
    
    echo "\nTabel yang data-nya perlu diperiksa/manual:\n";
    echo "  • users: " . $pdo->query("SELECT COUNT(*) FROM users")->fetchColumn() . " user\n";
    echo "  • products: " . $pdo->query("SELECT COUNT(*) FROM products")->fetchColumn() . " produk\n";
    echo "  • sales: " . $pdo->query("SELECT COUNT(*) FROM sales")->fetchColumn() . " transaksi\n";
    echo "  • cashier_shifts: " . $pdo->query("SELECT COUNT(*) FROM cashier_shifts")->fetchColumn() . " shift\n";
    
} catch (PDOException $e) {
    echo "✗ ERROR: " . $e->getMessage() . "\n";
    echo "\nPastikan:\n";
    echo "  1. XAMPP MySQL berjalan\n";
    echo "  2. Database 'pos_kasir' ada\n";
    echo "  3. File database_full.sql sudah diimport\n";
}
